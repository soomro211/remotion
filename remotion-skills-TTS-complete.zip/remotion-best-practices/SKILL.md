---
name: remotion-best-practices
description: Router for all Remotion skills
version: 4.0.536
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout with continuous step-by-step drawing as the default across subjects and
languages. Avoid sudden scene/image swaps; carry the illustration forward smoothly.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


## Preserve user changes

Users may make edits in the code outside of the conversation.

If you detect a surprising change made in the meanwhile, don't overwrite it, assume it was intentional or ask for confirmation.

## Creating a video

If the user asks to make, create, or build a new video or composition, load [Create a new Remotion video](../remotion-create/SKILL.md), whether or not a Remotion project already exists.

## New project setup

If no Remotion project currently exists, load [Create a new Remotion project](../remotion-create/SKILL.md)

## React Markup Best Practices

If you are writing Remotion React Markup, load [Remotion Markup Best Practices](../remotion-markup/SKILL.md)

## Maps

For static maps, animated routes and markers, geographic explainers, Mapbox, MapLibre, MapTiler, GeoJSON, or 3D geographic flyovers, load [Remotion Maps](../remotion-maps/SKILL.md).

## Multimedia

For achieving multimedia tasks in the browser, such as trimming, cropping videos, or getting metadata from them, load [Remotion Multimedia](../remotion-multimedia/SKILL.md)

## Improving Interactivity

By structuring the Remotion markup well, we can allow users to interactively change things in the Studio and write back to code. If relevant: [Interactivity Best Practices](../remotion-interactivity/SKILL.md)

## Open the preview

If the user asks to "make" a video, "create" a video, etc.
Don't render the video by default unless they are very explicit. They want to instead see an interactive preview.
As soon as the project can run, start Studio and open the preview in the browser before building or editing the composition. Keep it open while you work so the user can watch progress and steer.

### If you are using Cursor

Run Studio without `--no-open` so it opens the browser automatically:

```bash
npx remotion studio
```

### If you are using another agent client with an in-app browser

You can use the command above to let Studio open the browser, or run:

```bash
npx remotion studio --no-open
```

This will start a long-running process and print the server URL for the preview.  
If the server is already started, it will print the URL.
If you use `--no-open`, open the exact printed URL in the in-app browser and verify that Studio loads. Once a composition exists, verify that its video preview loads. If you cannot open it there, run Studio without `--no-open`.
You can visit a specific composition by navigating to `/[composition-id]`, for example `http://localhost:3000/MapAnimation`.

:::note
The Studio supports WebMCP tools.
:::

### If you do not have an in-app browser

This will open the Studio in the browser or refocus it if it is already open.

```bash
npx remotion studio
```

### More options

To launch a project in Remotion Studio, open its exact local URL, or configure Studio CLI flags, load [Remotion Studio](../remotion-studio/SKILL.md).

## Render the video

Only render if the user is very explicit in asking for it.  
E.g. "Render the video", "Export", "Give me the MP4".

The preview also has a more intuitive rendering interface, so consider using it instead of the command line for rendering.

```
npx remotion render
```

For more options, see [Rendering](../remotion-render/SKILL.md).

For advanced rendering beyond simple `npx remotion render`, see: [Rendering Best Practices](../remotion-render/SKILL.md)

## Captions

When working with Captions, load [Remotion Captions](../remotion-captions/SKILL.md).

## Creating a SaaS, automation or application

Use the [Remotion SaaS skill](../remotion-saas/SKILL.md) for knowledge about Remotion-powered SaaS apps, such as `<Player>`, rendering on Lambda, Vercel, Cloudflare, via Express.js, client-side rendering, or for finding the right SaaS template.

## Looking up Remotion APIs and documentation

To find and read current Remotion documentation, load [Remotion Docs](../remotion-docs/SKILL.md).

## Upgrading

To upgrade Remotion, related packages, compatible Mediabunny packages, and installed Remotion Agent Skills, load [Remotion Upgrade](../remotion-upgrade/SKILL.md).

## Preproduction, scriptwriting and alternate themes

For a new video, load [Remotion Preproduction](../remotion-preproduction/SKILL.md) before composition code, then [Remotion Create](../remotion-create/SKILL.md). Reuse an approved plan rather than restarting it.

For hooks, scripts, voiceover copy or on-screen copy, load [Video Scriptwriting](../video-scriptwriting/SKILL.md). For technical transcription, timed captions and caption rendering, continue using Remotion Captions.

For an explicitly selected alternate theme or requested theme options, load [Video Themes Pack](../video-themes-pack/SKILL.md). Notebook remains the saved default; selecting another palette does not by itself remove continuous drawing or language requirements.

For the saved video-production workflow, content-plan approval authorizes the full build, internal checks and export described in the Notebook reference. The earlier preview-only/render-on-request guidance applies outside that workflow or when the current brief requests preview only. Current user instructions take precedence.

## TTS at plan approval

For video production, follow [User-provided TTS handoff](../remotion-preproduction/references/tts-handoff.md): present a complete TTS prompt plus exact narration when asking for content-plan approval, then use the audio returned by the user. Do not generate speech yourself or finalize narrated export before required audio arrives. Align timing and captions to the actual recording. Explicit silent briefs and existing final audio bypass the TTS request.
