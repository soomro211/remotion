# Notebook — saved default video theme

Approved by the user on 2026-10-19. Applies to all subjects and languages unless the current brief specifies another visual direction. Explicit user instructions always override this default.

## Final design choices

- Use the earlier bold, all-caps headings (“Tohumlar / Nasıl büyür?”): Bitter 800, left aligned for LTR scripts, ink first line and forest second line. Do not use the later sentence-case Lora/DM Sans/Fraunces heading experiments.
- Retain the improved subtitles: Source Sans 3 500, centered, slightly lower, with balanced semantic line breaks and at most two short lines. Load the CSS-safe alias `SourceSans3`.
- Main layers: title, one substantial original illustration, subtitle block. No running header, lesson badge, repeated topic tag, footer slogan, extra subtitle separator or decorative progress bar by default. Diagram labels/arrows should explain content.
- Warm ruled paper, restrained static grain, faint margin, ink outlines, flat considered color and purposeful diagram motion.
- Subtitles remain part of the default. For video production, provide the TTS model prompt and exact narration when asking for content-plan approval, then use the returned user audio. Do not generate speech yourself. Honor explicitly silent/text-only briefs.

## Assets and starter

From this skill's root directory, use `assets/notebook-theme/`: tokens, `NotebookLayout.tsx`, paper PNG, fonts/OFL notices, previews, and `install-theme.py`.

```sh
python assets/notebook-theme/install-theme.py /path/to/remotion-project
```

This copies the layout/tokens into `src/notebook/` and fonts/paper into `public/notebook/`. It refuses to overwrite differing user files unless `--overwrite` is supplied. Use matching Remotion packages including `@remotion/fonts`. Load required script fonts before rendering.

Portrait defaults at 1080×1920:

| Element | Setting |
|---|---|
| Title | x=80, y=316, width=920; Bitter 800, 104px, line-height 1.08; ink then forest |
| Illustration | nominal 1080×800 artboard, y=572, scale .92 from top center; frame for the subject |
| Subtitles | x=110, y=1392, width=860; Source Sans 3 500, 52px, line-height 1.35; centered, <=2 lines |
| Palette | paper #E9E3D7; ink #29251F; forest #214D3D; navy #25364F; burgundy #812B3E |
| Paper | 80px rules at 9% ink opacity, subtle grain, faint x=64 margin |

These positions are a starting layout. Fit real text/artwork, preserve diacritics and respect the destination's safe areas. Reflow other aspect ratios separately rather than stretching the portrait starter.

## Universal language support — required

Follow the requested language. Do not hardcode Turkish or another language. Subject, language, duration and scene count come from the current brief.

1. Set the correct BCP 47 language and text direction. LTR headings align left; RTL headings align right; subtitles remain centered. The starter resolves common RTL languages/scripts and accepts an explicit direction override.
2. Use locale-aware uppercase for cased scripts only. Turkish i/İ and ı/I must remain correct. Scripts without case retain natural forms; do not force uppercase or Latin letter spacing onto Arabic, Hebrew, CJK or other scripts. Preserve subtitle spelling/case.
3. Verify glyph coverage. Bitter and Source Sans 3 are the base pairing, not an assertion of complete Unicode coverage. Load explicit matching script fonts rather than accepting browser fallback or missing-glyph boxes. Preserve bold heading/readable caption hierarchy across scripts.
4. Bundled Arabic example: Noto Naskh Arabic 700 heading and Noto Sans Arabic 500 caption, aliases `NotoNaskhArabic`/`NotoSansArabic`, RTL, heading line-height about 1.28 and caption about 1.5. Use the appropriate script's type design while retaining the theme's hierarchy.
5. For other scripts, obtain a licensed family with verified coverage, e.g. the relevant Noto Serif/Sans family for Devanagari, Bengali, Hebrew, Thai or CJK; retain license notices. Those extra script families are not all bundled.
6. Shape full words naturally. Never split joined letters/graphemes for letter-by-letter animation. Check combining marks, vowel marks, punctuation, mixed numerals and bidirectional text. Balance subtitle lines at natural target-language phrase boundaries.
7. Inspect actual frames at phone size. Shorten/split a cue rather than shrinking subtitles to unreadable type. CJK wrapping, long compounds and Arabic marks can require different metrics; font families, sizes and line heights are configurable.

## Subject, motion and workflow

Create topic-specific original illustrations. Preview rivers/plants/eclipses are examples, not permanent backgrounds for unrelated subjects. Add subject colors only when they convey meaning. Exclude screenshot UI, account details and unrelated branding.

Animate the explanation as a continuous step-by-step drawing, following the production rules below. Use deterministic frame-based motion and readable holds. Avoid decorative particles, generic gradients and gratuitous bounce/shake.

Keep factual research, timing, licensing and rendering discipline. Read this reference during preproduction before choosing art direction. The saved theme supplies an approved recurring direction: do not repeatedly ask the user to reselect the same palette/fonts. Content planning and any review gates still follow the current instructions; explicit user instructions take precedence.

## Saved approval workflow

User update on 2026-10-19: retain content-plan approval, remove the second stage of showing a preview for approval. After the content plan is approved, perform style-frame/scene previews internally, obtain the user-provided TTS audio, align visuals and captions to its actual duration, build the full video, run quality checks and export the deliverables. For explicitly silent videos, proceed without audio. Prepare independent assets while waiting for required audio. Do not stop to request style-frame approval. Show previews when the user requests them.

## Continuous drawing production

User update on 2026-10-19: make explanations smooth and draw them step by step. This is the default for all future subjects and languages unless the current user explicitly requests another motion style.

- Build one evolving illustration. Draw meaningful outlines, structures and details in explanatory order, then move or transform the subject to demonstrate the next step. Keep completed marks visible when they still provide context.
- Plan every beat as: carried-in visual state → drawing/action steps → carried-out visual state → continuous bridge. The next beat starts from the previous beat's visible state. Preserve object identity, position and scale through the bridge; animate changes instead of teleporting or replacing objects.
- Use actual SVG stroke reveals (`strokeDasharray`/`strokeDashoffset`), progressive masks, causal reveals and physically meaningful transformations. Pace each mark for its path length and allow readable holds. A drawing-hand prop is optional, never required.
- No hard cuts, flashes, abrupt full-frame replacements, repeated blank-canvas resets or slideshow sequences of finished illustrations by default. Crossfading finished pictures, or panning/zooming a still, does not satisfy this drawing requirement.
- Connect chapters by continuing a drawing, transforming shared objects, or smoothly panning/reframing across an established illustrated world. If an unrelated diagram must enter, motivate its drawn introduction with a shared visual bridge rather than replacing the entire canvas. Use restrained easing; 18–30 frames at 30 fps is a starting range for a bridge, adjusted to travel and reading time.
- Keep the title/paper stable where practical. Change subtitle cues with a brief, readable fade or mask in the approved centered lower position; preserve natural word shaping in every script. Do not animate text so slowly that reading time is lost.
- Drive all progress from Remotion frames, preload assets/fonts and retain shared artwork outside scene mounts where needed. Separate scene components must not cause visual resets.
- Internal QA must inspect drawing progress within each beat and frames immediately before, during and after every boundary, then play the full video at normal speed. Reject unexpected pops, blank gaps, teleports and completed-image swaps. Check meaningful drawing continuity, not just smooth opacity.
