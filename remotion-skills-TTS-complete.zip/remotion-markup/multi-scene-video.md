# Multi-scene videos

## Saved continuous drawing default

Treat scenes as editing boundaries within one evolving illustration. Follow the
[Notebook motion policy](../remotion-best-practices/references/notebook-theme.md#continuous-drawing-production): draw paths progressively, reveal structure in causal order and transform shared objects smoothly. Carry the prior visual state into the next beat. Keep shared artwork/background mounted outside scene components when needed; preload assets and fonts. Separate components must not reset the canvas or replace a completed image abruptly. Crossfading complete illustrations is insufficient. Preserve stroke weights, geometry and object identity through bridges, and account for any transition overlap in the total duration.

## Editable structure

Give each substantial scene its own component and connect it when it benefits
from an independent editing timeline. Keep each instance's name, timing, and
props inline in the parent.

Choose the parent structure from the editing behavior:

- For independent scene start times, use a named `Track` with explicit `from`
  and `durationInFrames` on each scene. Its items must not overlap.
- For scenes that should remain adjacent as their durations change, use
  `TransitionSeries`. Keep each scene inside its own
  `TransitionSeries.Sequence`, with duration and source trim on that boundary.
  Add transitions when needed and account for their overlaps in the total
  composition duration.

Follow [editable timeline structure](../remotion-interactivity/timeline-structure.md)
for a complete scene, parent, and registration example. See
[transitions](transitions.md) for transition timing and presentations, and
[connected compositions](connected-compositions.md) for extraction and
verification in the full video.
