# Motion principles for Remotion

All numbers assume 30 fps. At 60 fps double frame counts. Verify API details
with `/remotion-docs` before implementing (spring, interpolate, Easing,
Sequence, @remotion/transitions, @remotion/motion-blur).

## Saved Notebook default

Use smooth continuous step-by-step drawing, with no hard cuts or finished-image swaps. Follow [the shared policy](../../remotion-best-practices/references/notebook-theme.md#continuous-drawing-production). The options below apply within that policy; another personality requires an explicit user brief.

## Pick one motion personality and use it everywhere
| Personality | Entrance | Easing / spring | Feel |
|---|---|---|---|
| Crisp | 8-14 frames | `spring({config:{damping:20, stiffness:200}})`, no visible overshoot | Technical, precise, modern software |
| Smooth | 18-30 frames | `Easing.bezier(0.16, 1, 0.3, 1)` (expo-out feel) or spring `damping:200` | Premium, calm, editorial |
| Playful | 12-20 frames | spring `damping:8-12` with overshoot, small scale pops | Consumer, fun |
| Cinematic | 40-90 frames | long ease-in-out, slow pushes, parallax | Brand films, emotional |
Write the chosen values into the theme tokens and reuse them. Do not mix personalities.

## Easing rules
- Entrances ease-out (fast start, soft landing). Exits ease-in (soft start, accelerate away). Repositioning ease-in-out.
- Useful curves: ease-out `bezier(0.16,1,0.3,1)`; ease-in-out `bezier(0.65,0,0.35,1)`; ease-in `bezier(0.7,0,0.84,0)`.
- Never linear for UI motion. Linear only for constant-speed things (scrolling tickers, rotations, progress).
- Springs: `damping:200` = smooth, no bounce. Lower damping = more bounce. Use bounce sparingly and only if the personality is Playful.

## Durations
- Micro (icon, cursor, small UI): 6-10 frames.
- Standard element entrance: 12-20 frames.
- Hero or large move: 20-30 frames.
- Exits are about 60-70% as long as entrances.
- Scene minimum: about 1.0s unless it is a deliberate rapid-fire sequence.
- Everything needs settle time: do not start the exit before the reading-time floor is met.

## Choreography
- **Hierarchy of arrival:** hero first, then supporting, then ambient. Larger elements move slower and farther; smaller ones faster and shorter.
- **Stagger:** 3-5 frames between items in reading order; cap total stagger around 20 frames so lists do not drag.
- **Overlap:** begin the next scene's entrance 4-8 frames before the previous exit ends. Avoid a gap where the frame is empty.
- **Anticipation and follow-through:** a 2-4 frame counter-move before a big motion, and a small settle after. Subtle.
- **Secondary motion:** shadows, highlights and background layers respond to the hero with a slight delay.
- **Motion path logic:** things leave in the direction they will relate to next. Keep direction consistent (e.g. content flows left to right, new topic enters from the right).
- **Spatial continuity:** carry shared elements continuously into the next beat; animate the transformation without an instantaneous match cut or reset.

## Camera and life
- A camera move on a finished still is insufficient: the explanation must visibly draw/build and transform step by step.
- Treat the scene as a camera shot: wrap it in a container with slow scale (1.00 to 1.04) or small pan over its duration so holds are not dead.
- Parallax: 2-3 depth layers moving at different rates for depth, not more.
- Push-ins land on the important thing. Pull-outs reveal context. Do not zoom randomly.
- Optional motion blur (`@remotion/motion-blur`) on fast moves, used lightly because it costs render time.

## Text animation
- Default: per-line mask reveal (line in an `overflow:hidden` wrapper, translateY from 100% to 0) with ease-out.
- Per-word stagger for emphasis lines. Per-letter only for one hero line.
- Do not animate everything; static text is allowed once it has arrived.
- Counting numbers: ease-out count, tabular figures, land 4-6 frames before the line ends.
- Highlights: draw-on underline or marker via SVG path length / clip, not a fade.

## Transitions
- Prefer continuing the drawing or transforming a shared object. Smooth reframing may reveal the next part of an already established world.
- No hard cuts, flash transitions, abrupt image replacements or blank-canvas resets by default. A crossfade between completed illustrations does not meet the continuous drawing requirement.
- Start bridges around 18–30 frames at 30 fps, adapting to distance and reading time. Preserve carried-in/out visual states and consistent geometry through every boundary.
- Scene components and `TransitionSeries` are implementation choices: they must preserve visible continuity. Preload/premount assets and keep shared artwork mounted when needed.
- Subtract any actual transition overlap from total duration; continuity does not require overlapping timelines when the same illustration persists.

## Rhythm
- Vary scene length and density: fast-slow-fast. Put the longest hold on the proof or the emotional beat.
- Align drawing emphasis and smooth bridges to music beats/bars or VO phrase starts. At 120 BPM a beat is 15 frames at 30 fps.
- Build to the signature moment, then give it space.
- End on a held, designed CTA frame.

## Sound design (even for "silent" videos, decide it)
- Music: low in the mix under VO (duck 6-12 dB), fade in/out 10-15 frames.
- UI and transition hits on key motions; keep them subtle, short and consistent in family.
- Silence before the signature moment can be the strongest sound choice.
- Always provide captions or on-screen text so it works sound-off.

## Remotion determinism and performance rules
- Drive all animation from `useCurrentFrame()` and `useVideoConfig()`; no CSS transitions/animations, no timers, no `Math.random()` (use `random('seed')`).
- Animate `transform` and `opacity`. Avoid animating `width/height/top/left`, large blurs, many box-shadows or filter chains on big layers.
- Use `<Sequence>` with `premountFor` for heavy scenes; `<Img>`/`<Video>` from Remotion, not raw tags; preload fonts and images.
- Use `interpolate(..., {extrapolateLeft:'clamp', extrapolateRight:'clamp'})` to avoid overshoot bugs.
- Keep every duration, easing and color in theme tokens.
