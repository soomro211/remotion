---
name: remotion-render
description: Export a Remotion video
version: 4.0.536
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout with continuous step-by-step drawing as the default across subjects and
languages. Avoid sudden scene/image swaps; carry the illustration forward smoothly.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


## General rendering strategy

Render a video using:

```
npx remotion render
```

Full list of options: https://www.remotion.dev/docs/cli/render.md

Render a still using:

```
npx remotion still
```

Full list of options: https://www.remotion.dev/docs/cli/still.md

To render several frames as images in one call, use `render --frames`:

```
npx remotion render [composition-id] out/frames --frames=0,30,90 --image-format=png
```

See https://www.remotion.dev/docs/cli/render.md#--frames for more options.

## Transparent videos

See [Transparent videos](./transparent-videos.md) for rendering out a video with transparency.
