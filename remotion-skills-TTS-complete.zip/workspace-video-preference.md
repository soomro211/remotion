
## Saved video theme

For video creation or visual editing, use the user's approved Notebook theme by default. Read `.agents/skills/remotion-best-practices/references/notebook-theme.md` and use the reusable assets beside it. Main headings use the earlier bold style; subtitles use the improved centered/lower treatment. The theme applies across topics and languages with verified script fonts and LTR/RTL support. For video production, include a ready-to-copy TTS prompt and exact narration with the content-plan approval request, then use the audio returned by the user. Do not generate TTS yourself. Explicit silent/text-only requests remain silent. A current user brief can override any default. This preference applies to video design tasks.

## Video approval workflow

Obtain approval of the content plan, then use the user-provided TTS result to finalize timing, build, inspect and render the full video. If audio is missing, request it and prepare independent assets while waiting. The user removed the second preview/style-frame approval stage. Perform visual preview checks internally; show a preview when explicitly requested. Do not stop production for another design approval after the plan is approved.

## Continuous drawing production

User update on 2026-10-19: make explanations smooth and draw them step by step. This is the default for all future subjects and languages unless the current user explicitly requests another motion style.

- Build one evolving illustration. Draw meaningful outlines, structures and details in explanatory order, then move or transform the subject to demonstrate the next step. Keep completed marks visible when they still provide context.
- Plan every beat as: carried-in visual state → drawing/action steps → carried-out visual state → continuous bridge. The next beat starts from the previous beat's visible state. Preserve object identity, position and scale through the bridge; animate changes instead of teleporting or replacing objects.
- Use actual SVG stroke reveals (`strokeDasharray`/`strokeDashoffset`), progressive masks, causal reveals and physically meaningful transformations. Pace each mark for its path length and allow readable holds. A drawing-hand prop is optional, never required.
- No hard cuts, flashes, abrupt full-frame replacements, repeated blank-canvas resets or slideshow sequences of finished illustrations by default. Crossfading finished pictures, or panning/zooming a still, does not satisfy this drawing requirement.
- Connect chapters by continuing a drawing, transforming shared objects, or smoothly panning/reframing across an established illustrated world. If an unrelated diagram must enter, motivate its drawn introduction with a shared visual bridge rather than replacing the entire canvas. Use restrained easing; 18–30 frames at 30 fps is a starting range for a bridge, adjusted to travel and reading time.
- Keep the title/paper stable where practical. Change subtitle cues with a brief, readable fade or mask in the approved centered lower position; preserve natural word shaping in every script. Do not animate text so slowly that reading time is lost.
- Drive all progress from Remotion frames, preload assets/fonts and retain shared artwork outside scene mounts where needed. Separate scene components must not cause visual resets.
- Internal QA must inspect drawing progress within each beat and frames immediately before, during and after every boundary, then play the full video at normal speed. Reject unexpected pops, blank gaps, teleports and completed-image swaps. Check meaningful drawing continuity, not just smooth opacity.

