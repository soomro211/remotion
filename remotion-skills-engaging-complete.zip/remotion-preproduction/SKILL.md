---
name: remotion-preproduction
description: Pre-production for Remotion videos. Use BEFORE writing any Remotion code whenever the user wants a video, promo, explainer, product demo, launch, motion graphic, kinetic type piece or social clip. Runs research, concept, art direction, script, storyboard, timing, assets and an anti-generic quality audit, and ends with an approved VIDEO_PLAN.md plus a theme spec that /remotion-create and /remotion-markup build from.
version: 2.0.0
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout across subjects and languages. Use step-by-step drawing where it helps
explain; use distinct scenes and optional, purposeful transitions where they fit.
Do not force every video into one continuously drawn frame.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


# Remotion Pre-production

Most bad AI video is bad because nobody decided anything before coding: generic
gradient, centered text, every element fading up the same way, copy that could
belong to any company. This skill forces the decisions first, specifically, and
audits them against a list of known generic patterns.

**Hard rule:** no Remotion code until the plan is approved. Exceptions: the user
supplies a finished plan, or says "just build it". In that case still run
Phases 1-3 quickly, state your assumptions in one short list, and proceed.

**Operating principles**
1. Specific beats generic. Every choice (color, font, word, motion) must be
   justified by this brand, audience or idea, not by habit.
2. One big idea per video. One hero per scene. One CTA.
3. Restraint reads as quality. Fewer elements, more contrast, better timing.
4. Design for sound off, thumb-scroll attention, and a paused frame that
   still looks designed.
5. Never invent facts, logos, UI, testimonials or numbers. Flag gaps.

Read the reference files when you reach the phase that needs them:

| File | Read at |
|---|---|
| `references/anti-slop.md` | Phase 2 and the final audit. Always. |
| `references/art-direction.md` | Phase 2 |
| `references/script-and-copy.md` | Phase 3 |
| `references/motion-principles.md` | Phase 4 and 5 |
| `references/storyboard-timing-specs.md` | Phase 4, 5, 6 |
| `references/templates-and-qa.md` | Phase 7, 8, 9 |

## Phase 0: Intake and research

Ask only what is missing, in one message, max 4 questions, each with a default
you will use if unanswered.

- Goal: what should the viewer believe, feel or do afterward? (default: understand it and click)
- Audience and where it plays: YouTube, site hero, Reels/TikTok/Shorts, LinkedIn, X, in-product (sets canvas, length, pacing, sound-off assumption)
- Source material: brand guide, logo (SVG), fonts, colors, screenshots or screen recordings, copy, music, VO, reference videos they like
- Length and tone (default: 20-30s, confident)

**Research before designing** (use WebSearch/WebFetch when available):
- If a brand, product or URL is given, look at its actual site and visuals first. Note its real colors, type, voice, and what competitors' videos look like so yours is distinct.
- If the user names reference videos or styles, extract what specifically they like (pace, type, color, camera), not just the label.
- Collect real facts and numbers with sources. Do not invent metrics.

Output of Phase 0: a 5-line **brief**: goal, audience, platform+canvas, length, tone, plus an **asset inventory** (have / need).

## Phase 1: Concept (the big idea)

Do this before any styling. Write:

- **Creative promise** (one sentence): "A [length] [tone] video that makes [audience] [feel/do] [outcome]."
- **The one thing**: the single message a viewer must remember.
- **Visual metaphor or device**: one repeatable idea that carries the video (e.g. everything is built from one growing line; a single camera push through layers; type as the only visual; a UI that assembles itself). Pick a device that fits the product, not a stock effect.
- **Signature moment**: the one shot people would remember or screenshot. Design backward from it.
- **Three distinct concept options** (2 lines each) when the user has not fixed a direction. They must differ in idea, not just color. Recommend one and say why.

Reject any concept that passes the **swap test**: if you replace the brand name
with a competitor and the video still works unchanged, it is too generic.

## Phase 2: Art direction and design tokens

Read `references/art-direction.md` and `references/anti-slop.md`.

Pick one direction (or a deliberate hybrid), then make it concrete. Output a
**theme spec** the build will turn into `src/theme.ts`:

- Palette (max 5 colors, hex), with roles: background, surface, text, muted text, accent, optional secondary. State contrast ratio of text on background (aim 7:1 or more for body, 4.5:1 minimum).
- Type: max 2 families, with weights, from the brand or Google Fonts. Type scale for the chosen canvas. Line-height and letter-spacing for display vs body.
- Layout: canvas, safe margins, 8px spacing scale, grid (columns and gutters), alignment rule (left, center, or asymmetrical, and why).
- Shape and surface language: radii, borders, shadows or none, grain, texture.
- Motion language: easing set, spring configs, durations, stagger, transition vocabulary (see `references/motion-principles.md`). One personality, used everywhere.
- Imagery rules: what is allowed (real screenshots, abstract shapes, photography) and what is not.

Every token needs a one-clause reason tied to the concept.

## Phase 3: Script and copy

Read `references/script-and-copy.md` and [Engagement and payoff](../video-scriptwriting/references/engagement-and-payoff.md). Develop the opening as words plus visible action, require causal progression and an earned payoff, and include justified optional scene changes in the storyboard.

- Pick the structure for the length and goal. Hook inside 2-3 seconds, result before logo.
- Write on-screen text and VO separately. VO is written for the ear and read aloud (2.5 words/second).
- Apply the banned-phrase list and specificity rules. Every line must pass: could only this brand say this?
- Facts and numbers carry a source.

## Phase 4: Storyboard and shot design

Read `references/motion-principles.md` and `references/storyboard-timing-specs.md`.

One **scene card** per scene (template in `references/templates-and-qa.md`):
purpose, hero element, supporting elements, layout with positions on the grid,
background, entrance, hold, exit, camera move, the transition into the next
scene, text, VO, sound cue, and required capability (maps, captions, 3D, chart, Lottie, video clip).

Rules:
- Vary scene length and scale of shot (wide, tight, abstract, UI) so the rhythm is not metronomic.
- Show the product doing the thing. Prefer demonstration to claims.
- No scene without a reason. Cut it if the video still works without it.
- Use an evolving drawing where it teaches the idea; use distinct shots when a new idea, proof, scale or contrast benefits from them. Each card must specify action, focal point, readable hold, outgoing/incoming state and transition choice (including none), with a narrative reason. Do not add effects to every boundary.

## Phase 5: Timing and rhythm

- Choose fps (30 default; 60 only for fast UI or fine type motion).
- Convert every scene to `from` and `durationInFrames`. Subtract transition overlaps. Totals must equal the target length within 0.1s.
- Reading-time floor per text block: `max(0.8s, 0.25s x words)` after the entrance finishes.
- If there is music: set BPM, put drawing emphasis and smooth bridges on beats or bars (`beat = 60 / BPM` seconds). If VO: align explanatory actions with phrases.
- End with 0.5-1.0s hold on the CTA frame. Avoid fade-to-black unless intentional.

## Phase 6: Assets, sound and technical spec

- Checklist, each item marked have / need / generate / replace-with-placeholder.
- Sound plan: music (licensed), VO, UI and transition sound hits, ducking, fades. Silent is a valid choice if intentional.
- Technical spec: composition id, size, fps, duration frames, codec, output name, props schema (what must be editable: text, colors, logo, language), fonts loading approach (`@remotion/google-fonts` or local), and any heavy-render risks.
- Licensing flags for fonts, music, footage, logos.

## Phase 7: Internal style-frame check

Plan a signature style frame. After the user approves the content plan, build
and render it first with `/remotion-create` and `npx remotion still`. Inspect
and refine it internally against the saved theme and plan, then continue with
the remaining scenes. There is no second user approval gate for a preview or
style frame. Show a preview when the user explicitly asks for one; do not pause
normal production to request preview approval. Record this internal check in
the build order.

## Phase 8: Self-audit, then present

Run the audit in `references/templates-and-qa.md` ("Plan audit"): score the plan
1-5 on Specificity, Hierarchy, Rhythm, Distinctiveness, Brand fit, Legibility,
Sound-off clarity. Fix anything under 4 and note what you changed. Run the
anti-slop checklist and remove every hit. Then present: concept, art
direction, storyboard table, timing, asset checklist, open questions each with
a recommended default. Include the complete ready-to-copy TTS prompt and exact narration from [User-provided TTS handoff](references/tts-handoff.md), then ask for plan approval/edits and the generated audio together. Skip the TTS request for explicitly silent videos or existing final audio.

## Phase 9: Handoff and build discipline

After content-plan approval, write `VIDEO_PLAN.md` (template provided) and a theme spec. Follow [User-provided TTS handoff](references/tts-handoff.md): wait for the user's TTS result before final narration timing and narrated export; prepare independent assets meanwhile. Once valid audio is supplied (or the brief is explicitly silent), complete production and export without a second preview approval:

1. `/remotion-create`: scaffold from the technical spec, create `src/theme.ts` from the theme spec, load fonts.
2. Build, render and inspect the style frame internally, then continue without a second approval request.
3. `/remotion-markup`: one scene at a time, all values from theme tokens (no hardcoded colors, sizes or easing in components).
4. `/remotion-studio`: preview each scene, render stills at key frames, run the build QA checklist.
5. Assemble, set transitions and audio, then `/remotion-render`.
6. Use `/remotion-docs` before any API call you are not sure about.
7. `VIDEO_PLAN.md` stays the source of truth. If you deviate, update it and tell the user.

Build constraints that protect quality: animate transforms and opacity, drive
everything from `useCurrentFrame()`, no CSS transitions or animations, no
unseeded randomness (use Remotion's `random('seed')`), no layout thrash, load
fonts before render, premount heavy sequences.

## Done means

- The plan is approved by the user, not just written.
- The anti-slop checklist has zero unresolved hits.
- Frame math adds up, every asset is accounted for, every fact has a source.
- A designer looking at any paused frame would not call it a template.

## Integrated specialist handoffs

- Phase 2: load [Video Themes Pack](../video-themes-pack/SKILL.md) when the user selects an alternate theme or asks for theme options. Keep Notebook otherwise. Resolve theme and motion separately and choose explanatory drawing and optional transitions per beat under the saved motion policy.
- Phase 3: load [Video Scriptwriting](../video-scriptwriting/SKILL.md) for angle, hooks, beat structure, drafting and craft checks alongside `references/script-and-copy.md`. Reuse the existing brief, facts, concept and approved decisions. Evaluate alternate angles and hooks internally; do not repeat intake or add a separate script approval before the content-plan review.
- Put the script table into `VIDEO_PLAN.md` section 4, preserving scene IDs, target timing, visuals, on-screen copy, optional VO, sources and sound cues. Extend scene cards with action, focal point, held proof, outgoing/incoming state and justified transition choice (including none). Reconcile script timing with Phase 5 frame math and transition overlap.
- Use user-provided TTS narration by default for video production, following [User-provided TTS handoff](references/tts-handoff.md); include its prompt with plan approval and wait for the returned audio. Mark VO as none for explicitly silent videos. Word budgets apply only to spoken narration; estimate localized reading time separately. Separate concise display copy from complete subtitle cues needed to understand a silent video.
- Preserve a supplied approved script; revise only for requested changes, factual errors or timing/readability problems and record any necessary changes. Do not send the script back into preproduction recursively when it was drafted within this workflow.
