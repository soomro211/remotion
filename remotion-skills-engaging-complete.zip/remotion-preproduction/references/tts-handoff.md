# User-provided TTS handoff

## Plan approval deliverable

For video-production requests, include a complete ready-to-copy TTS model prompt in the same response that presents the content plan for approval. This is the default narration workflow unless the current brief explicitly requests a silent/text-only video or supplies final narration audio. Do not generate speech or call a TTS service yourself. A standalone script-only request does not require audio delivery.

Provide these two clearly separated sections:

1. **TTS direction (instructions, not spoken):** language and locale, tone, pacing, pronunciation of names/abbreviations/numbers, intended audience, natural pauses, and target duration as a guide. Request clean dry speech without music, sound effects or added words. Request WAV when supported; accept other decodable audio. Prefer one continuous file; if multiple files are requested, give stable scene IDs and exact ordering. Explain that model duration targets are approximate.
2. **Exact narration (speak only this):** the full approved-plan script in the requested language, ready to paste with no placeholders, scene headings, timestamps, stage directions or citation markers that might be spoken. Keep sources and timing notes outside the spoken text. Use natural punctuation for pauses. Supply pronunciation guidance separately without changing the meaning of verified claims.

After presenting both, ask for content-plan approval/edits and ask the user to return the generated TTS audio. This is one plan-review step, not an additional approval gate. Record the exact narration, prompt, script revision and intended scene mapping in `VIDEO_PLAN.md`. If the plan changes the narration, provide a revised prompt at approval time and identify which existing audio would need replacing.

## Wait for the actual audio

If the plan is approved but audio is missing, acknowledge approval and request the TTS result. Prepare assets, project structure and reusable visuals where useful, but do not lock narration-dependent scene timing, fabricate audio, substitute synthetic speech, or export a final narrated video before the audio arrives. Asking for the required audio is an asset handoff, not renewed plan approval. If the user asks to proceed silently or requests a temporary silent preview, honor that instruction and label any temporary timing.

## Use the supplied result

- Preserve the user's original audio. Inspect that it decodes and contains the expected narration; measure its actual duration with the existing multimedia/audio tools. Check for missing sections, clipping, unexpected silence and a different script/language. Do not assume target seconds or words-per-second equal recorded duration.
- For supported transcription/alignment tools, derive phrase/word timestamps from this exact recording; otherwise align phrase boundaries by listening and inspecting the waveform. Do not invent precise timestamps. Use [Remotion Captions](../../remotion-captions/SKILL.md) for technical caption alignment and [audio guidance](../../remotion-markup/audio.md) for implementation.
- Map the supplied file(s) to stable scene IDs. Recompute `from`, duration frames, overlaps, reading holds and total composition length from measured audio at the chosen fps. Include intentional lead-in/tail and CTA holds, and keep drawing, scene edits and optional transitions synchronized with the spoken explanation. Extend visuals rather than arbitrarily speeding up, cutting or truncating the voice.
- Use the supplied narration as the video's audio source and preserve its meaning and order. Keep background music/SFX subordinate to intelligibility when requested. Caption the actual spoken words, with separate concise display headlines as needed, and retain correct language shaping and direction.
- If supplied speech differs materially from approved claims or omits content, identify the discrepancy and request a corrected recording or explicit acceptance of a revised script. Normal timing adjustments do not require another style-frame approval. A later replacement recording requires realignment and renewed timing/QA.
- Update `VIDEO_PLAN.md` with the actual audio path, script revision, duration, alignment method and final frame timings. Inspect sync throughout playback, transitions, end-of-audio and final hold before export. Continue production after approved plan plus valid audio without another preview approval.

For an explicit silent/text-only brief, omit the TTS request, mark VO as none and budget reading time. For existing final audio, use it directly; do not require regeneration just to follow this handoff.
