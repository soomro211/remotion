# Script format and checks

## Deliverable format
```
TITLE:            <working title>
CREATIVE PROMISE: A <length> <tone> video that makes <audience> <feel/do> <outcome>.
THE ONE THING:    <the sentence they should repeat>
VOICE:            <3 words>; never <x>
FORMAT:           <platform, canvas, length, sound on/off, VO or text-only>
COUNT:            <spoken words> words, <duration>s at ~2.5 words/s (plus pauses)

| # | Time | Visual direction | On-screen text | VO | Proof / source | Sound |
|---|------|------------------|----------------|----|----------------|-------|
| 1 | 0.0-2.5 | ... | ... | ... | ... | ... |

ALTERNATES:
- Hook B: ...
- CTA B: ...
- Shorter cut (15s): scenes 1, 3, 6

OPEN GAPS (need from you):
- Missing proof for scene 3; need a real number or customer
- Confirm pronunciation: <name>
```

Rules for the table:
- Times are targets; recompute with real VO audio once recorded.
- Visual direction is specific enough to storyboard ("report assembles from three tool windows, timer counts to 0:12"), not "dynamic visuals".
- On-screen text is 2-7 words, not a transcript.
- Mark `[beat]` for pauses and `(V.O.)`, `(SUPER)`, `(SFX)` where useful.
- Number scenes so they map to `VIDEO_PLAN.md` scene cards.

## Final checklist (all must pass)
Hook
- [ ] First 3 seconds state or imply the payoff; no logo, greeting or filler.
- [ ] Hook scored 4+ on every criterion; runner-up saved.
Message
- [ ] One thing, clearly stated; every scene serves it.
- [ ] A real tension exists; there is a turn, not just a list.
- [ ] Every claim has proof on screen or a source; no invented facts, customers or quotes.
Language
- [ ] Reads naturally aloud; contractions, short sentences, front-loaded keywords.
- [ ] No banned words or machine-sounding patterns.
- [ ] Specific nouns, numbers with unit, baseline and source.
- [ ] Passes the swap test: not usable by a competitor unchanged.
Craft
- [ ] VO adds meaning beyond the visuals; on-screen text is key phrases only.
- [ ] Pacing varies; strongest proof gets space; one moment of surprise.
- [ ] Works with sound off.
- [ ] One CTA, specific, with a visible URL or handle.
Logistics
- [ ] Word count fits the duration with pauses.
- [ ] Pronunciation notes, legal/claims flags and open gaps listed.
- [ ] Scene numbering ready for storyboard handoff.

## Revision loop
When the user gives feedback, change only what they asked plus anything it breaks; keep the table format; re-run the checklist; recount words and duration. Offer 15s and 6s cut-downs when relevant.

## Engagement and edit check
- [ ] Opening visual and line express a specific truthful promise.
- [ ] Each beat adds information, evidence or emotional movement; no repeated benefits.
- [ ] Every curiosity gap closes and the ending earns the hook.
- [ ] Drawing, scene changes and optional transitions follow meaning; effects are not automatic.
- [ ] Spoken narration excludes edit instructions and aligns to the user-provided TTS result.
