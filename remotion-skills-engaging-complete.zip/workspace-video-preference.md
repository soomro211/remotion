
## Saved video theme

For video creation or visual editing, use the user's approved Notebook theme by default. Read `.agents/skills/remotion-best-practices/references/notebook-theme.md` and use the reusable assets beside it. Main headings use the earlier bold style; subtitles use the improved centered/lower treatment. The theme applies across topics and languages with verified script fonts and LTR/RTL support. For video production, include a ready-to-copy TTS prompt and exact narration with the content-plan approval request, then use the audio returned by the user. Do not generate TTS yourself. Explicit silent/text-only requests remain silent. A current user brief can override any default. This preference applies to video design tasks.

## Video approval workflow

Obtain approval of the content plan, then use the user-provided TTS result to finalize timing, build, inspect and render the full video. If audio is missing, request it and prepare independent assets while waiting. The user removed the second preview/style-frame approval stage. Perform visual preview checks internally; show a preview when explicitly requested. Do not stop production for another design approval after the plan is approved.

## Continuous drawing production

Updated preference: use continuous step-by-step drawing where it explains a mechanism, process or worked example. Do not force the whole video onto one persistent canvas. Use distinct shots or scenes and optional transitions when they improve comprehension, emotional contrast or narrative rhythm.

- Choose motion per beat: draw/build for causal explanation; hold for proof and reading; reframe for detail; change scene for a new idea, time, location or deliberate contrast. Keep the Notebook visual identity consistent across scenes unless another theme is selected.
- Give every scene a purpose, focal point and readable hold. Record its action, outgoing/incoming state, transition choice (including none), narrative reason and duration in the storyboard. Preserve object identity when the same object continues; a deliberate new shot may establish a new composition.
- Use restrained match cuts/object morphs for related ideas, wipes/masks for a reveal, slides for spatial progression, page turns for a chapter, and short dissolves for time or mood. A clean cut is valid for a clear contrast or a completed beat. Effects are optional; use no transition effect when the edit already reads clearly.
- Prefer one or two transition families per video. Do not add an effect at every boundary or make cuts on a fixed timer. Avoid gratuitous flashes, random glitches, constant zooms and visual resets that obscure the explanation. Keep shared illustration state only where it helps the viewer follow.
- At 30 fps, try 6–12 frames for a crisp transition or 12–24 for a gentle one, adapting to scale, meaning and actual audio. Do not hide important words, proof or actions under a transition. Respect reading holds and subtract actual timeline overlaps from total duration.
- Drive drawing and transitions from Remotion frames. Preload/premount assets and fonts. A transition must not introduce accidental black frames, missing layers or a flash of unstyled text. Preserve script shaping and subtitle legibility.
- Align drawing, scene changes and emphasis to meaningful phrases in the supplied TTS recording. Inspect representative drawing progress, every edit boundary and full-speed playback; fix confusing spatial jumps, repetitive effects and lost reading time. Keep the existing content-plan approval and TTS handoff; no second preview approval.
