---
name: video-themes-pack
description: Select and adapt eight visual themes for Remotion videos using bundled style frames, palettes, typography and motion guidance. Use when the user names Blueprint Lab, Cut Paper, Swiss Poster, Midnight Editorial, Neo-Brutal Pop, Chalkboard, Riso Print or Terminal, requests theme options, or specifies an alternate video art direction.
---

# Video Themes Pack

Read [THEMES.md](THEMES.md) for all eight original specifications and the selection guide. Inspect [overview.png](overview.png) for the collection and the matching hook, content and CTA images in [images](images/) for a selected theme. All reference assets are bundled; do not ask the user to reattach them.

## Selection and precedence

- Read the [saved Notebook preference](../remotion-best-practices/references/notebook-theme.md) first for Remotion video work. Keep Notebook as the default; do not silently replace it with a theme from this pack.
- Apply an explicitly requested theme or supplied brand direction. When asked for options, recommend themes based on concept and audience without forcing a new selection for an already approved direction.
- Treat theme styling and motion as separate decisions. Use drawing for explanatory beats and optional scene transitions where they serve the story. Theme motion is a vocabulary, not a requirement to apply effects everywhere. Choose restrained effects suited to the concept; avoid gratuitous flashes and resets.
- Keep existing content-plan approval and internal visual QA. Do not introduce a second style-frame approval gate.

## Adapt and hand off

1. Reuse the brief and concept from [Remotion preproduction](../remotion-preproduction/SKILL.md); do not repeat intake or restart the workflow.
2. Select one theme and inspect its three images. Preserve its identity while replacing all sample topics, numbers and copy with verified project content.
3. Convert the documented colors, font roles, grid, surfaces and motion into the preproduction theme spec, then `src/theme.ts`. These are visual specifications and reference images, not ready-made React components or bundled fonts.
4. Fit the requested aspect ratio and destination safe areas; 1080x1920 examples are references, not a universal canvas. Verify contrast for actual text/background pairs; palette membership alone does not guarantee legibility.
5. Obtain licensed fonts with the required language coverage, preserve shaping and LTR/RTL behavior, and preload them before rendering. Use script-appropriate alternatives when the listed display fonts lack coverage.
6. Drive motion deterministically from Remotion frames; translate the motion descriptions into frame-based SVG masks, transforms and interpolation rather than CSS animation, timers or unseeded randomness.
7. Record selected theme, adaptations, motion choice and sources in `VIDEO_PLAN.md`. Hand off to [Remotion Create](../remotion-create/SKILL.md) and [Remotion Markup](../remotion-markup/SKILL.md).

For video production, include the TTS prompt with plan approval and use the returned user audio, following [User-provided TTS handoff](../remotion-preproduction/references/tts-handoff.md). Keep explicitly silent briefs silent. Use [Video Scriptwriting](../video-scriptwriting/SKILL.md) for script craft and [Remotion Captions](../remotion-captions/SKILL.md) for technical caption implementation.
