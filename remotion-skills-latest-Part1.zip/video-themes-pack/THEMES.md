# Video theme library (8 themes, 1080x1920, 9:16)

Each theme has 3 style frames in `images/`: **1 hook, 2 content/explainer, 3 CTA**.
Topics and text are placeholders to show the style. Swap the content, keep the system.
All fonts are free Google Fonts (OFL). Key content stays inside the Reels/Shorts safe
area (about 270px from the top, 420px from the bottom, 110px from the right).

How to use: tell the agent "use theme 03 Swiss Poster" and attach its images as the
visual reference. Have it turn the tokens below into `src/theme.ts`. Theme choice
should follow the idea and audience, not taste alone (see "Best for").

---
## 01 Blueprint Lab
Technical, trustworthy, "let me show you how it works".
- Best for: engineering, science, how-things-work, DIY, product mechanics
- Colors: bg `#0E2747`, line `#9CC9FF`, text `#EAF4FF`, accent `#FFD23F`, warning `#FF7A6B`
- Fonts: Space Grotesk 700 (headlines, uppercase, tight), JetBrains Mono (labels, letter-spaced)
- Look: blueprint grid (40px minor, 200px major), thin line drawings, dimension lines with ticks, drawing title block
- Motion: lines draw on (stroke-dashoffset), arrows grow along force paths, labels snap in with a 6-frame stagger. Crisp springs (damping 20, stiffness 200)
- Signature: drawing the diagram line by line; dimension lines measuring things

## 02 Cut Paper
Warm, tactile, friendly. Feels handmade.
- Best for: kids/family education, nature, storytelling, wellbeing, explainers
- Colors: paper `#F1E3C2`, sky `#6FB4DC`, sun `#F4A93B`, coral `#FF6B4A`, ink `#1E2A44`, green `#5E9B62`
- Fonts: Bricolage Grotesque 800 (headlines on paper slips, rotated -2 to +2 degrees)
- Look: torn-edge paper layers, hard drop shadow (0 9px 0 at 22% brown), paper grain, label tags with notches
- Motion: stop-motion feel. Animate at 12 fps steps (hold every 2-3 frames), slips slide in with slight rotation overshoot, layers parallax at different speeds
- Signature: paper strips as light rays; layers sliding over each other like a pop-up book

## 03 Swiss Poster
Confident, clear, authoritative. Big type as the picture.
- Best for: productivity, business, announcements, rules and lists, opinion
- Colors: bg `#EEEAE0`, ink `#121212`, red `#E4361B`
- Fonts: Inter Tight 800 (display, tracking -3 to -6%), 500-600 for labels
- Look: strict column grid with hairlines, one giant numeral or circle, a header rule with 3 labels, nothing decorative
- Motion: hard-edged wipes and slides on the grid, numerals scale up from baseline with expo-out, no bounce. Smooth-fast (18-frame moves)
- Signature: one oversized red numeral or circle that other type interacts with

## 04 Midnight Editorial
Quiet, premium, thoughtful. Reads like a magazine essay.
- Best for: history, psychology, finance, essays, brand films, luxury
- Colors: bg `#0B0A10` with soft violet glow `#231D3A`, text `#F1ECE1`, gold `#C9A45C`, muted `#8E8A9A`
- Fonts: Instrument Serif (display, italic for emphasis words), DM Sans caps letter-spaced (labels)
- Look: gold hairline rules, small-caps kicker, generous negative space, simple charts drawn in one gold line
- Motion: slow line-by-line mask reveals, 24-30 frame ease-out expo, gold lines draw on, subtle 1-3% push-in during holds
- Signature: one italic gold word per headline; the chart line drawing itself

## 05 Neo-Brutal Pop
Loud, funny, scroll-stopping. High energy.
- Best for: money tips, creators, consumer apps, youth, myth-busting, lists
- Colors: yellow `#FFE14A`, ink `#111`, pink `#FF4F8B`, blue `#3D5AFE`, white `#FFF`
- Fonts: Archivo Black (uppercase headlines), DM Sans 700 (body)
- Look: thick 7px black borders, hard 14px offset shadows, rotated stickers, star badges, dot-grid background
- Motion: playful springs with overshoot (damping 8-12), stickers slam in with a scale 1.2 to 1 settle, small rotation wobble, cuts every 1.5-3s
- Signature: stickers stamping onto the frame with a hit sound

## 06 Chalkboard
Classroom, human, instantly understood. Great for step-by-step.
- Best for: math, language, how-to, tips and tricks, quizzes, study content
- Colors: board `#173126` to `#2A4D3F`, chalk `#F4F1E6`, yellow `#FFE27A`, pink `#FF9BB5`, blue `#8FD3FF`
- Fonts: Caveat 700 (all text), sized very large for phone readability
- Look: roughened chalk edges (SVG turbulence displacement), faint eraser smudges, thin chalk frame
- Motion: text writes on left to right via clip/mask with a slight wobble, arrows and underlines draw on, each step revealed in sequence, pauses so viewers can think
- Signature: the worked example building step by step; "your turn" challenge that drives comments

## 07 Riso Print
Indie, graphic, young. Looks like a two-color print.
- Best for: health and lifestyle facts, culture, music and events, newsletters, listicles
- Colors: paper `#F3EAD3`, pink `#FF4D94`, blue `#2B50FF` (overprint with multiply gives indigo)
- Fonts: Anton (condensed uppercase headlines), DM Sans 700 (body in blue)
- Look: multiply overprint, slight misregistration (pink offset 9-10px), halftone dot fades, grain, sparkle stars
- Motion: layers land slightly out of sync (pink 3 frames after blue) then settle, halftone fades in, 12 fps stepped feel, sparkles twinkle
- Signature: misregistration shake on the hook; overlapping circles creating a third color

## 08 Terminal
Precise, geeky, credible. Process made visible.
- Best for: tech, AI, developer tools, step-by-step processes, "how X works"
- Colors: bg `#091016`, green `#5CFFB0`, amber `#FFB000`, text `#CFE9DD`, dim `#5E7F72`
- Fonts: JetBrains Mono (everything), weight 800 for the hero line
- Look: window chrome, faint 36px grid, command prompts, progress bars, check marks, blinking amber cursor
- Motion: typewriter text (2-3 chars per frame), progress bars fill with ease-in-out, blinking cursor (15-frame cycle), steps appear one per beat
- Signature: the typed command as the hook; progress bar completion as the payoff

---
## Picking a theme (fast guide)
| Your video is... | Use |
|---|---|
| Explaining how something works | 01 Blueprint, 08 Terminal |
| Warm story or gentle education | 02 Cut Paper, 06 Chalkboard |
| A rule, opinion, announcement | 03 Swiss |
| Thoughtful, premium, essay-like | 04 Midnight Editorial |
| Fast tips that must stop the scroll | 05 Neo-Brutal, 07 Riso |
| Math, steps, quizzes | 06 Chalkboard |
| Tech or AI process | 08 Terminal |

## Rules that keep them from looking generic
- Pick the theme from the idea, then customize: change the accent color, swap the display font weight, add one signature device.
- Keep one hero per frame. Max about 12 words on screen.
- Do not mix two themes in one video.
- Use real facts and real assets. The sample numbers and topics here are placeholders.
- Hold 30-50% of the frame as empty space. It reads as designed.
