# Saved Notebook video theme

Approved design: earlier bold main headings + improved centered, lower subtitles. Clean title/illustration/subtitle layout, original notebook paper, five-color base palette, topic-specific illustrations. No TTS/narration by default.

The theme applies to every topic and requested language. Latin examples use Bitter 800 with Source Sans 3 500. Arabic examples use bundled Noto Naskh Arabic 700 with Noto Sans Arabic 500, RTL. Other scripts require a matching licensed font with verified glyph coverage. Language, subject, duration and scene count follow the current brief.

## Already installed in this workspace

All 13 skills in /workspace/.agents/skills now point to remotion-best-practices/references/notebook-theme.md. Shared reusable assets are in remotion-best-practices/assets/notebook-theme/. Workspace AGENTS.md makes this preference discoverable in later video tasks.

## Reuse in another workspace

Extract remotion-skills-notebook.zip into that workspace's .agents/skills directory. It contains the same 13 skill folders with the shared theme. Read the included reference and copy the video preference from workspace-video-preference.md into that workspace's AGENTS.md if needed. Current user briefs can override the theme.

## Start a Remotion project with this layout

From remotion-best-practices:

    python assets/notebook-theme/install-theme.py /path/to/remotion-project

Import NotebookLayout from src/notebook/NotebookLayout. Pass language, titleLines, subtitleLines and an original illustration as children. Choose and load script fonts when the Latin defaults do not cover the text. See the shared reference for typography, RTL, line breaking and aspect-ratio requirements.

## Files

- approved-theme-preview.jpg and preview-*.png: actual rendered language examples.
- theme-tokens.json: approved design tokens.
- remotion-skills-notebook.zip: all 13 customized skills with reusable assets and licenses.
- remotion-skills-before-theme.zip: original skills before customization, retained for rollback.
- VALIDATION.json: preservation, font-coverage and preview checks.

These files persist in the current workspace. The ZIP provides a portable copy for another workspace; it does not change account-wide settings.

## Current approval workflow (updated)

Only content-plan approval is required. Once the plan is approved, build and inspect style frames/scenes internally, render and deliver the finished video. The user removed the second preview/style-frame approval stage. Show a preview when explicitly requested.

## Continuous drawing workflow (v1.2.0)

Use step-by-step drawing where it helps explain, distinct shots where the story benefits, and optional restrained transitions at meaningful changes. Do not force one canvas or effects at every boundary. Follow the current motion policy in remotion-best-practices/references/notebook-theme.md. Content-plan approval remains the only approval gate; use the supplied TTS audio for final timing.
