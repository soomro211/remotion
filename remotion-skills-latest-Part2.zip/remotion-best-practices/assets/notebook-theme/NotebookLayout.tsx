import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {loadFont} from '@remotion/fonts';
import tokens from './tokens.json';

// CSS-safe aliases avoid invalid unquoted names such as "Source Sans 3".
loadFont({family:'Bitter',url:staticFile('notebook/fonts/Bitter.ttf'),weight:'800'});
loadFont({family:'SourceSans3',url:staticFile('notebook/fonts/SourceSans3.ttf'),weight:'500'});

export const notebook=tokens;
export const directionForLanguage=(language:string):'ltr'|'rtl'=>
 /^(ar|fa|he|ur|ps|sd|ug|yi)(-|$)/i.test(language)||/(?:^|-)(Arab|Hebr)(?:-|$)/i.test(language)?'rtl':'ltr';

type NotebookLayoutProps={
 language:string;
 direction?:'ltr'|'rtl';
 titleLines:readonly string[];
 subtitleLines:readonly string[];
 children:React.ReactNode;
 headingCase?:'auto'|'preserve';
 displayFamily?:string;
 captionFamily?:string;
 displaySize?:number;
 captionSize?:number;
 displayWeight?:number;
 captionWeight?:number;
 displayLineHeight?:number;
 captionLineHeight?:number;
 illustrationTop?:number;
 illustrationScale?:number;
};

/** Portrait starter: choose script fonts and verify fitting before final rendering.
 * Reflow landscape/square layouts separately; do not stretch this artboard.
 */
export const NotebookLayout=({
 language,direction:directionOverride,titleLines,subtitleLines,children,
 headingCase='auto',displayFamily='Bitter',captionFamily='SourceSans3',
 displaySize=104,captionSize=52,displayWeight=800,captionWeight=500,
 displayLineHeight,captionLineHeight,illustrationTop=572,illustrationScale=.92,
}:NotebookLayoutProps)=>{
 const direction=directionOverride??directionForLanguage(language);
 const rtl=direction==='rtl';
 const lines=titleLines.map(line=>{
  if(headingCase==='preserve'||rtl)return line;
  try{return line.toLocaleUpperCase(language);}catch{return line;}
 });
 return <AbsoluteFill lang={language} dir={direction} style={{background:notebook.color.paper,color:notebook.color.ink}}>
  <Img src={staticFile('notebook/paper.png')} style={{position:'absolute',inset:0,width:'100%',height:'100%'}}/>
  <div style={{position:'absolute',left:80,right:80,top:316,fontFamily:displayFamily,fontWeight:displayWeight,fontSize:displaySize,lineHeight:displayLineHeight??(rtl?1.28:1.08),letterSpacing:rtl?0:'-.015em',textAlign:rtl?'right':'left'}}>
   {lines.map((line,i)=><div key={i} style={{color:i===0?notebook.color.ink:notebook.color.forest}}>{line}</div>)}
  </div>
  <div style={{position:'absolute',left:0,top:illustrationTop,width:1080,height:800,scale:illustrationScale,transformOrigin:'540px 0px'}}>{children}</div>
  <div style={{position:'absolute',left:110,right:110,top:1392,fontFamily:captionFamily,fontSize:captionSize,fontWeight:captionWeight,lineHeight:captionLineHeight??(rtl?1.5:1.35),letterSpacing:0,textAlign:'center',unicodeBidi:'plaintext'}}>
   {subtitleLines.map((line,i)=><div key={i}>{line}</div>)}
  </div>
 </AbsoluteFill>;
};
