"""Copy the approved Notebook starter into a Remotion project; preserve user edits."""
from pathlib import Path
import argparse,shutil
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('project',type=Path)
parser.add_argument('--overwrite',action='store_true',help='Replace existing theme files intentionally')
args=parser.parse_args();source=Path(__file__).resolve().parent;project=args.project.resolve()
files=[(source/'NotebookLayout.tsx',project/'src/notebook/NotebookLayout.tsx'),(source/'tokens.json',project/'src/notebook/tokens.json'),(source/'paper.png',project/'public/notebook/paper.png')]
files.extend((f,project/'public/notebook/fonts'/f.name) for f in (source/'fonts').iterdir() if f.is_file())
for src,dst in files:
 if dst.exists() and dst.read_bytes()!=src.read_bytes() and not args.overwrite:raise SystemExit(f'Preserving existing file: {dst}; review changes or pass --overwrite.')
for src,dst in files:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
print(f'Installed {len(files)} Notebook theme files in {project}.')
