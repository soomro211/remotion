# Notebook — saved default video theme

Approved by the user on 2026-10-19. Applies to all subjects and languages unless the current brief specifies another visual direction. Explicit user instructions always override this default.

## Final design choices

- Use the earlier bold, all-caps headings (“Tohumlar / Nasıl büyür?”): Bitter 800, left aligned for LTR scripts, ink first line and forest second line. Do not use the later sentence-case Lora/DM Sans/Fraunces heading experiments.
- Retain the improved subtitles: Source Sans 3 500, centered, slightly lower, with balanced semantic line breaks and at most two short lines. Load the CSS-safe alias `SourceSans3`.
- Main layers: title, one substantial original illustration, subtitle block. No running header, lesson badge, repeated topic tag, footer slogan, extra subtitle separator or decorative progress bar by default. Diagram labels/arrows should explain content.
- Warm ruled paper, restrained static grain, faint margin, ink outlines, flat considered color and purposeful diagram motion.
- Subtitles remain part of the default. For video production, provide the TTS model prompt and exact narration when asking for content-plan approval, then use the returned user audio. Do not generate speech yourself. Honor explicitly silent/text-only briefs.

## Assets and starter

From this skill's root directory, use `assets/notebook-theme/`: tokens, `NotebookLayout.tsx`, paper PNG, fonts/OFL notices, previews, and `install-theme.py`.

```sh
python assets/notebook-theme/install-theme.py /path/to/remotion-project
```

This copies the layout/tokens into `src/notebook/` and fonts/paper into `public/notebook/`. It refuses to overwrite differing user files unless `--overwrite` is supplied. Use matching Remotion packages including `@remotion/fonts`. Load required script fonts before rendering.

Portrait defaults at 1080×1920:

| Element | Setting |
|---|---|
| Title | x=80, y=316, width=920; Bitter 800, 104px, line-height 1.08; ink then forest |
| Illustration | nominal 1080×800 artboard, y=572, scale .92 from top center; frame for the subject |
| Subtitles | x=110, y=1392, width=860; Source Sans 3 500, 52px, line-height 1.35; centered, <=2 lines |
| Palette | paper #E9E3D7; ink #29251F; forest #214D3D; navy #25364F; burgundy #812B3E |
| Paper | 80px rules at 9% ink opacity, subtle grain, faint x=64 margin |

These positions are a starting layout. Fit real text/artwork, preserve diacritics and respect the destination's safe areas. Reflow other aspect ratios separately rather than stretching the portrait starter.

## Universal language support — required

Follow the requested language. Do not hardcode Turkish or another language. Subject, language, duration and scene count come from the current brief.

1. Set the correct BCP 47 language and text direction. LTR headings align left; RTL headings align right; subtitles remain centered. The starter resolves common RTL languages/scripts and accepts an explicit direction override.
2. Use locale-aware uppercase for cased scripts only. Turkish i/İ and ı/I must remain correct. Scripts without case retain natural forms; do not force uppercase or Latin letter spacing onto Arabic, Hebrew, CJK or other scripts. Preserve subtitle spelling/case.
3. Verify glyph coverage. Bitter and Source Sans 3 are the base pairing, not an assertion of complete Unicode coverage. Load explicit matching script fonts rather than accepting browser fallback or missing-glyph boxes. Preserve bold heading/readable caption hierarchy across scripts.
4. Bundled Arabic example: Noto Naskh Arabic 700 heading and Noto Sans Arabic 500 caption, aliases `NotoNaskhArabic`/`NotoSansArabic`, RTL, heading line-height about 1.28 and caption about 1.5. Use the appropriate script's type design while retaining the theme's hierarchy.
5. For other scripts, obtain a licensed family with verified coverage, e.g. the relevant Noto Serif/Sans family for Devanagari, Bengali, Hebrew, Thai or CJK; retain license notices. Those extra script families are not all bundled.
6. Shape full words naturally. Never split joined letters/graphemes for letter-by-letter animation. Check combining marks, vowel marks, punctuation, mixed numerals and bidirectional text. Balance subtitle lines at natural target-language phrase boundaries.
7. Inspect actual frames at phone size. Shorten/split a cue rather than shrinking subtitles to unreadable type. CJK wrapping, long compounds and Arabic marks can require different metrics; font families, sizes and line heights are configurable.

## Subject, motion and workflow

Create topic-specific original illustrations. Preview rivers/plants/eclipses are examples, not permanent backgrounds for unrelated subjects. Add subject colors only when they convey meaning. Exclude screenshot UI, account details and unrelated branding.

Use explanatory drawing, distinct shots and optional purposeful transitions according to the production rules below. Use deterministic frame-based motion and readable holds. Avoid decorative particles, generic gradients and gratuitous bounce/shake.

Keep factual research, timing, licensing and rendering discipline. Read this reference during preproduction before choosing art direction. The saved theme supplies an approved recurring direction: do not repeatedly ask the user to reselect the same palette/fonts. Content planning and any review gates still follow the current instructions; explicit user instructions take precedence.

## Saved approval workflow

User update on 2026-10-19: retain content-plan approval, remove the second stage of showing a preview for approval. After the content plan is approved, perform style-frame/scene previews internally, obtain the user-provided TTS audio, align visuals and captions to its actual duration, build the full video, run quality checks and export the deliverables. For explicitly silent videos, proceed without audio. Prepare independent assets while waiting for required audio. Do not stop to request style-frame approval. Show previews when the user requests them.

## Continuous drawing production

Updated preference: use continuous step-by-step drawing where it explains a mechanism, process or worked example. Do not force the whole video onto one persistent canvas. Use distinct shots or scenes and optional transitions when they improve comprehension, emotional contrast or narrative rhythm.

- Choose motion per beat: draw/build for causal explanation; hold for proof and reading; reframe for detail; change scene for a new idea, time, location or deliberate contrast. Keep the Notebook visual identity consistent across scenes unless another theme is selected.
- Give every scene a purpose, focal point and readable hold. Record its action, outgoing/incoming state, transition choice (including none), narrative reason and duration in the storyboard. Preserve object identity when the same object continues; a deliberate new shot may establish a new composition.
- Use restrained match cuts/object morphs for related ideas, wipes/masks for a reveal, slides for spatial progression, page turns for a chapter, and short dissolves for time or mood. A clean cut is valid for a clear contrast or a completed beat. Effects are optional; use no transition effect when the edit already reads clearly.
- Prefer one or two transition families per video. Do not add an effect at every boundary or make cuts on a fixed timer. Avoid gratuitous flashes, random glitches, constant zooms and visual resets that obscure the explanation. Keep shared illustration state only where it helps the viewer follow.
- At 30 fps, try 6–12 frames for a crisp transition or 12–24 for a gentle one, adapting to scale, meaning and actual audio. Do not hide important words, proof or actions under a transition. Respect reading holds and subtract actual timeline overlaps from total duration.
- Drive drawing and transitions from Remotion frames. Preload/premount assets and fonts. A transition must not introduce accidental black frames, missing layers or a flash of unstyled text. Preserve script shaping and subtitle legibility.
- Align drawing, scene changes and emphasis to meaningful phrases in the supplied TTS recording. Inspect representative drawing progress, every edit boundary and full-speed playback; fix confusing spatial jumps, repetitive effects and lost reading time. Keep the existing content-plan approval and TTS handoff; no second preview approval.
