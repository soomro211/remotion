---
name: remotion-captions
description: Transcribing, displaying and animating captions
version: 4.0.536
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout across subjects and languages. Use step-by-step drawing where it helps
explain; use distinct scenes and optional, purposeful transitions where they fit.
Do not force every video into one continuously drawn frame.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


All captions must be processed in JSON. The captions must use the [`Caption`](https://www.remotion.dev/docs/captions/caption.md) type which is the following:

```ts
import type { Caption } from "@remotion/captions";
```

This is the definition:

```ts
type Caption = {
  text: string;
  startMs: number;
  endMs: number;
  timestampMs: number | null;
  confidence: number | null;
  pageBreakAfter?: boolean;
};
```

## Generating captions

To transcribe video and audio files to generate captions, load the [transcribe-captions.md](transcribe-captions.md) file for more instructions.

## Displaying captions

To display captions in your video, load the [display-captions.md](display-captions.md) file for more instructions.

## Importing captions

To import captions from a .srt file, load the [import-srt-captions.md](import-srt-captions.md) file for more instructions.

## Post-creation

After you're done, load this skill: [Remotion Best Practices](../remotion-best-practices/SKILL.md)

If not alreay done, open the Remotion Studio, unless instructed otherwise.
