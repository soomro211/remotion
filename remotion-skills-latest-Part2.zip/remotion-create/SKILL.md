---
name: remotion-create
description: Create a new Remotion video
version: 4.0.536
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout across subjects and languages. Use step-by-step drawing where it helps
explain; use distinct scenes and optional, purposeful transitions where they fit.
Do not force every video into one continuously drawn frame.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


These are instructions for making a new Remotion project and composition.  
If this is not the next task, see [Remotion Best Practices](../remotion-best-practices/SKILL.md)

## Scaffold a project

If a project already exists, skip this.
Ensure Node.js and Git is installed, and the current folder is appropriate for starting a new project.

Inspect the current folder, including hidden files, before choosing where to scaffold.

### Empty folder

If it is empty, or contains only disposable operating-system metadata such as `.DS_Store`, create the project directly in the current folder.
Remove only those disposable metadata files first, since `create-video` rejects non-empty folders.
Do not treat all hidden files as disposable: files such as `.env` and directories such as `.git` are meaningful contents.

Scaffold in existing folder:

```bash
npx create-video@latest --yes --blank --no-tailwind .
npm i
```

### Non-empty folder

If the current folder contains meaningful contents and no project already exists, scaffold into a new subfolder.
Replace `my-video` with a suitable project name.

```bash
npx create-video@latest --yes --blank --no-tailwind my-video
cd my-video
npm i
```

## Open the preview before building the video

As soon as the project can run, open [Remotion Studio](../remotion-studio/SKILL.md) in the browser before writing or changing the composition. For a new project, do this immediately after scaffolding and installing dependencies. For an existing project, do it before editing the video. Keep Studio running while you work so the user can see changes as they appear and steer the result.

## Designing a video

Keep the scaffold and add React Markup.
Follow [Remotion React Markup Best Practices](../remotion-markup/SKILL.md) and [Video Layout Rules](video-layout.md) for video-first layout and text sizing guidance.

Before writing the root that registers `<Composition>` or `<Still>` elements,
follow [Compositions and stills](../remotion-markup/compositions.md).

## Is this a timeline of clips?

If the video arranges multiple video or audio clips on a timeline, follow
[Video editing](../remotion-markup/video-editing.md) before writing the
timeline. Give every clip that should be edited independently its own authored
JSX node.

## Is this a multi-scene video?

If this is a video with multiple subsequent scenes, follow guidance at [Multi-scene videos](../remotion-markup/multi-scene-video.md).

## Interactivity Best Practices

By structuring the React Markup following [Remotion Interactivity Best Practices](../remotion-interactivity/SKILL.md), you allow the user to make edits in the Studio which write back to code.

## TailwindCSS

If Tailwind is requested, see [tailwind.md](tailwind.md) for using TailwindCSS in Remotion.

## Follow-up

The video creation process has finished.
For follow-up prompts, use [Remotion Best Practices](../remotion-best-practices/SKILL.md)

## Integrated preproduction handoff

Before writing composition code, follow [Remotion Preproduction](../remotion-preproduction/SKILL.md), unless an approved plan already exists or its explicit fast-track exception applies. Reuse `VIDEO_PLAN.md` and the selected theme spec. Use [Video Scriptwriting](../video-scriptwriting/SKILL.md) for unresolved copy and [Video Themes Pack](../video-themes-pack/SKILL.md) for explicitly requested alternate themes. Do not restart approved creative decisions during scaffolding.

## TTS at plan approval

For video production, follow [User-provided TTS handoff](../remotion-preproduction/references/tts-handoff.md): present a complete TTS prompt plus exact narration when asking for content-plan approval, then use the audio returned by the user. Do not generate speech yourself or finalize narrated export before required audio arrives. Align timing and captions to the actual recording. Explicit silent briefs and existing final audio bypass the TTS request.

## Sound design and bundled effects

Use [Remotion Sound Design](../remotion-sound-design/SKILL.md) to plan sparse cues, synchronize them to final visual frames, mix beneath the returned user narration, and audit the export. Use [SFX Starter Library](../sfx-starter-library/SKILL.md) for the bundled effects and anchor manifest. Plan sound with the storyboard; finalize its timing after actual TTS audio alignment. Avoid effects on every motion/transition. Honor silent and voice-only briefs and preserve the existing single content-plan approval.
