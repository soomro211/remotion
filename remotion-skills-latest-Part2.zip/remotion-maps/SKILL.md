---
name: remotion-maps
description: Remotion Map animation knowledge
version: 4.0.536
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout across subjects and languages. Use step-by-step drawing where it helps
explain; use distinct scenes and optional, purposeful transitions where they fit.
Do not force every video into one continuously drawn frame.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


# Remotion Maps

Choose exactly one technique from the intended shot, then load only that technique's `TECHNIQUE.md`.
Every technique directory is self-contained and may be removed without breaking the others.

## [Static map](techniques/static-map/TECHNIQUE.md)

- Requires you grab a satellite image and mount it in a `<Img>` tag, and animate on top

## [Mapbox](techniques/mapbox/TECHNIQUE.md)

- Requires a Mapbox key
- Nicer styles by default
- Map can display a round globe when zoomed out
- Includes nice 3D buildings such as the Eiffel tower

## [MapLibre](techniques/maplibre/TECHNIQUE.md)

- Requires no API key, fully free
- Does not include 3D building

## [MapTiler](techniques/maptiler/TECHNIQUE.md)

- Uses MapTiler
- Annotations can be drawn on top of geographic features: borders, rivers, labels

## [CesiumJS](techniques/cesium/TECHNIQUE.md)

- Flythroughs through terrain and mountains
- "Flight simulator" perspective
