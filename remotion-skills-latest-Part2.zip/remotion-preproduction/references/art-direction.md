# Art direction library

Start from the brand. If the brand has a guide, use it and elevate it. If not,
choose one direction below, then customize at least three things (accent color,
display font, one signature motion or shape) so it is not the stock version.
Fonts are all on Google Fonts (load with `@remotion/google-fonts`); verify
availability and weights with `/remotion-docs`.

## Direction cards

**1. Editorial dark (premium, calm)**
- Palette: bg `#0B0B0C`, surface `#151517`, text `#F2EFE8`, muted `#8A8780`, accent one of `#D7FF3A` or `#FF6B35`
- Type: Instrument Serif or Fraunces for display, Inter or Geist for body
- Motion: smooth, ease-out expo, 18-30 frame moves, slow pushes, mask reveals
- Signature: big serif line revealing under a mask; thin hairline rules drawing in
- Good for: premium software, finance, design tools, brand films

**2. Swiss / International (clear, confident, light)**
- Palette: bg `#F1EFEA`, text `#0E0E0E`, accent `#FF3B1F`, one neutral `#CFCBC2`
- Type: Inter Tight, Archivo or Space Grotesk, large and tight, left aligned on a strict grid
- Motion: snappy, hard edge slides and wipes, modular grid reveals, minimal bounce
- Signature: oversized numerals, rules, grid lines that animate to structure the frame
- Good for: B2B, data, announcements, anything needing authority

**3. Neo-brutalist (loud, human, memeable)**
- Palette: bg `#FFE14A` or `#F4F0E6`, text `#000000`, accents `#FF4D8D` `#3D5AFE`, hard 3px black borders
- Type: Archivo Black, Space Grotesk or Bricolage Grotesque, heavy weights
- Motion: springs with visible overshoot (damping 8-12), stickers popping, offset hard shadows
- Signature: hard offset shadow `6px 6px 0 #000`, cut-out shapes, stamps
- Good for: consumer apps, creators, youth brands

**4. Kinetic type (type is the only visual)**
- Palette: near-black `#0A0A0A` + one saturated accent, or inverse
- Type: one variable-weight family at extreme sizes (Anton, Bricolage Grotesque, Archivo)
- Motion: scale, mask, weight and width changes, word-synced cuts every 6-18 frames, rhythmic
- Signature: words physically move to the beat; one word per frame in hook
- Good for: announcements, manifestos, VO-led pieces, social hooks

**5. Technical / terminal (precise, developer)**
- Palette: bg `#0A0E12`, grid lines `#1B232C`, text `#D6DEE7`, accent `#4DFFB0` or `#FFB000`
- Type: JetBrains Mono or IBM Plex Mono with a sans for headings
- Motion: typing, cursor, sharp stepped reveals, data streams that mean something, snappy 8-12 frame moves
- Signature: actual code or CLI output from the real product, grid overlays, measurement marks
- Good for: dev tools, APIs, infra, AI tooling

**6. Warm organic (human, trustworthy)**
- Palette: bg `#F6EFE4`, text `#2B2118`, accent `#C4532D`, secondary `#6B7F5E`
- Type: Fraunces or Playfair for display, DM Sans for body
- Motion: gentle springs with no bounce (damping 200), soft parallax, paper-like slides
- Signature: grain texture, hand-drawn underlines (SVG path draw-on), photo cutouts
- Good for: wellness, food, education, community brands

**7. Product-first (UI is the hero)**
- Palette: the product's own, plus a quiet backdrop that makes the UI pop
- Type: the product's UI font for UI, one display font for headlines
- Motion: camera moves across the interface (zoom to the exact control), cursor with intent, UI states changing in sync with VO
- Signature: smooth push-ins to the one control that matters, callouts that point precisely
- Good for: SaaS demos, feature launches. Use real screenshots or recordings, never invented UI

## Customization checklist (so it is not the stock version)
- Change the accent from the card default to one pulled from the brand or concept.
- Choose a distinctive display font, not just the body font enlarged.
- Add one signature device used 3+ times (a line that draws, a shape that morphs, a camera move).
- Add one imperfection or texture if it suits (grain, paper, subtle halftone), applied consistently.

## Color rules
- Max 5 colors. 60/30/10: background / surface+text / accent.
- Accent appears only where attention should go. If everything is accent, nothing is.
- Contrast: body text 7:1 or better on its background; large text 4.5:1 minimum. Check with a formula, do not eyeball.
- Dark backgrounds: avoid pure `#000` and pure `#FFF` text; use `#0B0B0C` and warm off-white to reduce harshness.
- Gradients only when they are a deliberate material (single hue family, 2 stops, subtle). Never a rainbow or default purple-to-blue.

## Typography rules
- Scale on a ratio (1.25 to 1.5). Example 1080p: caption 36, body 48, subtitle 64, title 96-160, hero numerals up to 320.
- Display: tight tracking (-1% to -4%), line-height 0.95-1.1. Body: line-height 1.3-1.5, tracking 0 to +1%.
- Max 2 families, max 3 weights. Use weight and size, not color, for hierarchy.
- Use `font-variant-numeric: tabular-nums` for counting numbers so they do not jitter.
- Line length for on-screen text: 2-4 words per line for headlines, max about 32 characters per caption line.
- Align to a baseline and an edge. Optical alignment for large type (pull punctuation and quotes outside the margin).

## Layout rules
- 8px spacing scale. Margins at least 6% of the short edge.
- 16:9: 12-column grid. 9:16: 6-column grid. 1:1 and 4:5: 6-column grid.
- 9:16 safe areas: keep key text out of roughly the top 14% and bottom 22% (platform UI covers these) and about 6% on the sides. Verify current platform UI before final.
- One dominant element per scene occupying a clear focal region; others subordinate by size and contrast.
- Use negative space deliberately; 30-50% of a frame empty is normal and reads premium.

## Imagery and UI
- Real screenshots and recordings of the real product, cropped and framed purposefully (device frames optional and consistent).
- When showing UI, animate what the user does (click, type, result), not a floating screenshot.
- Icons: one set, one stroke weight. Illustrations: one style.
- Never fabricate logos, customers, testimonials, stats or UI. Mark any placeholder clearly in the plan.
