# Motion principles for Remotion

All numbers assume 30 fps. At 60 fps double frame counts. Verify API details
with `/remotion-docs` before implementing (spring, interpolate, Easing,
Sequence, @remotion/transitions, @remotion/motion-blur).

## Saved Notebook default

Use step-by-step drawing for explanation, varied shots for narrative development and optional transitions where appropriate. Follow [the shared policy](../../remotion-best-practices/references/notebook-theme.md#continuous-drawing-production). Avoid both a forced single canvas and effects on every cut.

## Pick one motion personality and use it everywhere
| Personality | Entrance | Easing / spring | Feel |
|---|---|---|---|
| Crisp | 8-14 frames | `spring({config:{damping:20, stiffness:200}})`, no visible overshoot | Technical, precise, modern software |
| Smooth | 18-30 frames | `Easing.bezier(0.16, 1, 0.3, 1)` (expo-out feel) or spring `damping:200` | Premium, calm, editorial |
| Playful | 12-20 frames | spring `damping:8-12` with overshoot, small scale pops | Consumer, fun |
| Cinematic | 40-90 frames | long ease-in-out, slow pushes, parallax | Brand films, emotional |
Write the chosen values into the theme tokens and reuse them. Do not mix personalities.

## Easing rules
- Entrances ease-out (fast start, soft landing). Exits ease-in (soft start, accelerate away). Repositioning ease-in-out.
- Useful curves: ease-out `bezier(0.16,1,0.3,1)`; ease-in-out `bezier(0.65,0,0.35,1)`; ease-in `bezier(0.7,0,0.84,0)`.
- Never linear for UI motion. Linear only for constant-speed things (scrolling tickers, rotations, progress).
- Springs: `damping:200` = smooth, no bounce. Lower damping = more bounce. Use bounce sparingly and only if the personality is Playful.

## Durations
- Micro (icon, cursor, small UI): 6-10 frames.
- Standard element entrance: 12-20 frames.
- Hero or large move: 20-30 frames.
- Exits are about 60-70% as long as entrances.
- Scene minimum: about 1.0s unless it is a deliberate rapid-fire sequence.
- Everything needs settle time: do not start the exit before the reading-time floor is met.

## Choreography
- **Hierarchy of arrival:** hero first, then supporting, then ambient. Larger elements move slower and farther; smaller ones faster and shorter.
- **Stagger:** 3-5 frames between items in reading order; cap total stagger around 20 frames so lists do not drag.
- **Overlap:** begin the next scene's entrance 4-8 frames before the previous exit ends. Avoid a gap where the frame is empty.
- **Anticipation and follow-through:** a 2-4 frame counter-move before a big motion, and a small settle after. Subtle.
- **Secondary motion:** shadows, highlights and background layers respond to the hero with a slight delay.
- **Motion path logic:** things leave in the direction they will relate to next. Keep direction consistent (e.g. content flows left to right, new topic enters from the right).
- **Spatial continuity:** preserve shared elements when they connect ideas; a motivated match cut or new composition is valid for a deliberate change.

## Camera and life
- A camera move must reveal context or focus attention. Use drawing for causal explanation; a finished proof image or held result may stand on its own.
- Treat the scene as a camera shot: wrap it in a container with slow scale (1.00 to 1.04) or small pan over its duration so holds are not dead.
- Parallax: 2-3 depth layers moving at different rates for depth, not more.
- Push-ins land on the important thing. Pull-outs reveal context. Do not zoom randomly.
- Optional motion blur (`@remotion/motion-blur`) on fast moves, used lightly because it costs render time.

## Text animation
- Default: per-line mask reveal (line in an `overflow:hidden` wrapper, translateY from 100% to 0) with ease-out.
- Per-word stagger for emphasis lines. Per-letter only for one hero line.
- Do not animate everything; static text is allowed once it has arrived.
- Counting numbers: ease-out count, tabular figures, land 4-6 frames before the line ends.
- Highlights: draw-on underline or marker via SVG path length / clip, not a fade.

## Transitions and scene changes

Updated preference: use continuous step-by-step drawing where it explains a mechanism, process or worked example. Do not force the whole video onto one persistent canvas. Use distinct shots or scenes and optional transitions when they improve comprehension, emotional contrast or narrative rhythm.

- Choose motion per beat: draw/build for causal explanation; hold for proof and reading; reframe for detail; change scene for a new idea, time, location or deliberate contrast. Keep the Notebook visual identity consistent across scenes unless another theme is selected.
- Give every scene a purpose, focal point and readable hold. Record its action, outgoing/incoming state, transition choice (including none), narrative reason and duration in the storyboard. Preserve object identity when the same object continues; a deliberate new shot may establish a new composition.
- Use restrained match cuts/object morphs for related ideas, wipes/masks for a reveal, slides for spatial progression, page turns for a chapter, and short dissolves for time or mood. A clean cut is valid for a clear contrast or a completed beat. Effects are optional; use no transition effect when the edit already reads clearly.
- Prefer one or two transition families per video. Do not add an effect at every boundary or make cuts on a fixed timer. Avoid gratuitous flashes, random glitches, constant zooms and visual resets that obscure the explanation. Keep shared illustration state only where it helps the viewer follow.
- At 30 fps, try 6–12 frames for a crisp transition or 12–24 for a gentle one, adapting to scale, meaning and actual audio. Do not hide important words, proof or actions under a transition. Respect reading holds and subtract actual timeline overlaps from total duration.
- Drive drawing and transitions from Remotion frames. Preload/premount assets and fonts. A transition must not introduce accidental black frames, missing layers or a flash of unstyled text. Preserve script shaping and subtitle legibility.
- Align drawing, scene changes and emphasis to meaningful phrases in the supplied TTS recording. Inspect representative drawing progress, every edit boundary and full-speed playback; fix confusing spatial jumps, repetitive effects and lost reading time. Keep the existing content-plan approval and TTS handoff; no second preview approval.

## Rhythm
- Vary scene length and density: fast-slow-fast. Put the longest hold on the proof or the emotional beat.
- Align drawing emphasis and smooth bridges to music beats/bars or VO phrase starts. At 120 BPM a beat is 15 frames at 30 fps.
- Build to the signature moment, then give it space.
- End on a held, designed CTA frame.

## Sound design (even for "silent" videos, decide it)
- Music: low in the mix under VO (duck 6-12 dB), fade in/out 10-15 frames.
- UI and transition hits on key motions; keep them subtle, short and consistent in family.
- Silence before the signature moment can be the strongest sound choice.
- Always provide captions or on-screen text so it works sound-off.

## Remotion determinism and performance rules
- Drive all animation from `useCurrentFrame()` and `useVideoConfig()`; no CSS transitions/animations, no timers, no `Math.random()` (use `random('seed')`).
- Animate `transform` and `opacity`. Avoid animating `width/height/top/left`, large blurs, many box-shadows or filter chains on big layers.
- Use `<Sequence>` with `premountFor` for heavy scenes; `<Img>`/`<Video>` from Remotion, not raw tags; preload fonts and images.
- Use `interpolate(..., {extrapolateLeft:'clamp', extrapolateRight:'clamp'})` to avoid overshoot bugs.
- Keep every duration, easing and color in theme tokens.
