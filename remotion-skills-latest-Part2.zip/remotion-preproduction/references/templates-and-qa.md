# Templates and QA

## VIDEO_PLAN.md template
```md
# <Video title>
Status: draft | approved by <user> on <date>

## 1. Brief
Goal / Audience / Platform & canvas / Length / Tone
Creative promise: ...
The one thing: ...

## 2. Concept
Visual device: ...
Signature moment: ...
Why this and not the alternatives: ...
Swap test: pass/fail + note

## 3. Art direction and theme tokens
Direction: ... (customizations: ..., ..., ...)
Palette: bg #, surface #, text #, muted #, accent #   (contrast ratios: ...)
Type: Display <font/weights>, Body <font/weights>, scale: ...
Layout: canvas, margins, grid, spacing scale, alignment rule
Surface language: radii, borders, shadows, texture
Motion: personality, easing tokens, spring configs, durations, stagger, transitions (max 2)
Imagery rules: ...

## 4. Script
Scene-by-scene on-screen text + VO, with proof/source.

## 5. Storyboard
Scene cards (or summary table + cards for key scenes). Each specifies action, focal point, readable hold, outgoing/incoming state and optional transition with its narrative reason.

## 6. Timing
fps, scene from/duration, transition overlaps, total frames, music BPM/beat map, VO timing.

## 7. Assets and sound
Checklist (have/need/generate/placeholder), licensing flags, sound plan.

## 8. Technical spec
Composition id(s), size, fps, durationInFrames, codec, output name, props schema, font loading, risks.

## 9. Build order
1. Scaffold + theme.ts + fonts
2. Style frame (signature moment) -> internal quality check; continue without user preview approval
3. Build the planned drawing/shots through beats 1..N; inspect explanatory progress and every edit boundary internally
4. Transitions + audio
5. QA pass + render

## 10. Open questions (each with recommended default)

## 11. Audit scores and changes made
```

## theme spec (turn into src/theme.ts)
```ts
export const theme = {
  color: { bg:'#...', surface:'#...', text:'#...', muted:'#...', accent:'#...' },
  font:  { display:'<family>', body:'<family>' },
  type:  { caption:36, body:48, sub:64, title:120, hero:240 },   // px at the chosen canvas
  space: [8,16,24,32,48,64,96,128],                               // 8px scale
  radius:{ sm:8, md:16, lg:28 },
  motion:{
    ease:{ out:[0.16,1,0.3,1], inOut:[0.65,0,0.35,1], in:[0.7,0,0.84,0] },
    spring:{ crisp:{damping:20, stiffness:200}, smooth:{damping:200} },
    dur:{ micro:8, base:16, hero:26, exit:11 },                   // frames @30fps
    stagger: 4,
  },
};
```

## Plan audit (run before presenting)
Score 1-5. Anything below 4 must be revised and the change noted.
| Criterion | 5 means |
|---|---|
| Specificity | Every line, color and motion is tied to this brand/idea; passes swap test |
| Hierarchy | One clear hero per scene; 3x scale contrast; passes blur test |
| Rhythm | Varied scene lengths, beat or phrase aligned, signature moment given space |
| Distinctiveness | Customized beyond the stock direction; a designer would not call it a template |
| Brand fit | Uses real brand assets/voice; nothing invented |
| Legibility | Contrast and size verified; safe areas respected; reading time met |
| Sound-off clarity | Story clear with captions/visuals alone |
Then run the five tests and the full `anti-slop.md` checklist. Record hits and fixes.

## Build QA (after each scene and before final render)
- Render stills at: first frame, entrance end, mid-hold, exit start, last frame. Each should look intentional.
- Text: no clipping, no overlap, no orphan words, readable at phone size (view at 25% scale).
- Alignment: elements sit on the grid; margins consistent.
- Motion/edit QA: inspect drawing progress where used and frames before, during and after every edit. Accept deliberate cuts and justified effects; reject accidental blank frames, confusing jumps, repetitive transitions and obscured proof or captions.
- Motion: check easing feel by scrubbing; no pops, jumps, or gaps where the frame empties; no layout shift when fonts load.
- Timing: scene durations match plan; total frames match target; hold after reading floor.
- Audio: levels, ducking, fades, no clipping; captions synced.
- Determinism: no CSS transitions, no unseeded randomness; render twice and compare a frame.
- Performance: render time reasonable; remove heavy blurs/shadows if slow.
- Compare against `VIDEO_PLAN.md` and update it if anything changed.
- Final: watch it once at full speed, sound off, then sound on, as a first-time viewer.
