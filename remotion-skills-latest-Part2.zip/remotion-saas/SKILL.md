---
name: remotion-saas
description: Build an app with Remotion
version: 4.0.536
---

## Saved video design preference

For video creation or visual editing, first read
[the shared Notebook theme](../remotion-best-practices/references/notebook-theme.md).
Use the user-approved bold headings, centered lower subtitles, and clean notebook
layout across subjects and languages. Use step-by-step drawing where it helps
explain; use distinct scenes and optional, purposeful transitions where they fit.
Do not force every video into one continuously drawn frame.
Select fonts with complete
coverage of the requested script; adapt casing and LTR/RTL layout accordingly.
Explicit instructions in the current user brief override this default. For
non-design tasks, follow this skill's specialist workflow normally.


One can build apps with Remotion.  
It is possible to have a simple form and hook it up to a render, or have a complex video editor.

## Choosing a template or a framework

We have several templates for SaaS which can be cloned or used as a reference.
See [Choosing a framework](framework.md) for help choosing a template or framework.

## The `<Player>`

This component allows embedding a Remotion preview in a React app. See [Player](player.md) for more information about the Player.

## Rendering

There are client-side and server-side rendering options available. See [Rendering](rendering.md) for advice on how to choose, and about the Lambda, Vercel, Node.js and Cloudflare options.

## With Vue

See https://www.remotion.dev/docs/vue.md for how to use Remotion with Vue.

## Angular

See https://www.remotion.dev/docs/angular.md for how to use Remotion with Angular.

## Svelte

See https://www.remotion.dev/docs/svelte.md for how to use Remotion with Svelte.
