#!/usr/bin/env python3
"""Audio QA for SFX files and final mixes (wav/mp3/m4a/mp4).

  python3 audit_audio.py public/sfx/*.wav            # per-sound checks
  python3 audit_audio.py out/final.mp4 --mix         # final-mix checks (LUFS, true peak, clipping)
Exit code 1 if any FAIL. Needs ffmpeg + numpy.
"""
import argparse, re, subprocess, sys
import numpy as np
SR = 48000

def channels(path):
    p = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'a:0', '-show_entries', 'stream=channels', '-of', 'csv=p=0', path], capture_output=True, text=True)
    return int(p.stdout.strip() or 0)

def decode(path):
    af = ['-af', 'pan=stereo|c0=c0|c1=c0'] if channels(path) == 1 else ['-ac', '2']   # avoid ffmpeg's -3 dB mono upmix
    p = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-vn', *af, '-f', 'f32le', '-ar', str(SR), '-'], capture_output=True)
    if not p.stdout: return None
    return np.frombuffer(p.stdout, np.float32).reshape(-1, 2)

def loudness(path):
    p = subprocess.run(['ffmpeg', '-nostats', '-i', path, '-vn', '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True)
    s = p.stderr.split('Summary:')[-1]
    g = lambda pat: (lambda m: float(m.group(1)) if m else None)(re.search(pat, s))
    return g(r'I:\s+(-?[\d.]+) LUFS'), g(r'LRA:\s+(-?[\d.]+) LU'), g(r'Peak:\s+(-?[\d.]+) dBFS')

db = lambda v: 20 * np.log10(max(v, 1e-9))

def audit(path, mix):
    res = []; add = lambda lvl, msg: res.append((lvl, msg))
    x = decode(path)
    if x is None: return [('FAIL', 'no audio stream')]
    n = len(x); dur = n / SR; m = np.max(np.abs(x), axis=1); pk = m.max()
    if pk < 1e-4: return [('FAIL', 'silent')]
    clip = int(np.sum(m >= .999)); dc = float(abs(x.mean()))
    lead_ms = float(np.argmax(m > pk * .03) / SR * 1000); tail = float(m[-int(.002 * SR):].max() / pk)
    if clip: add('FAIL', f'{clip} clipped samples')
    if dc > .005: add('WARN', f'DC offset {dc:.4f}')
    if mix:
        I, LRA, TP = loudness(path)
        if I is None: add('WARN', 'could not measure loudness')
        else:
            add('PASS' if -16 <= I <= -12.5 else 'WARN', f'integrated {I:.1f} LUFS (target about -14)')
            add('PASS' if TP is not None and TP <= -1.0 else 'FAIL', f'true peak {TP} dBTP (must be <= -1.0)')
            add('PASS' if LRA is not None and LRA <= 12 else 'WARN', f'loudness range {LRA} LU (<= 12 for phones)')
        if n > SR:
            seg = np.array([m[i:i + SR].max() for i in range(0, n - SR, SR)])
            gaps = int(np.sum(seg < pk * .003))
            if gaps >= 3: add('WARN', f'{gaps} one-second stretches of near-silence (intentional?)')
        l, r = x[:, 0], x[:, 1]; c = np.corrcoef(l, r)[0, 1] if l.std() > 0 and r.std() > 0 else 1
        add('PASS' if c > .2 else 'WARN', f'L/R correlation {c:.2f} (low = may thin out in mono)')
    else:
        add('PASS' if -6 <= db(pk) <= -1 else 'WARN', f'peak {db(pk):.1f} dBFS (library files: -6..-1)')
        add('PASS' if (lead_ms < 80 or any(k in path for k in ('riser', 'whoosh', 'paper'))) else 'WARN', f'sound starts {lead_ms:.0f} ms in (normal for whooshes and risers; for hits trim it so sync is exact)')
        add('PASS' if (tail < .03 or 'riser' in path) else 'WARN', f'ends at {db(tail):.0f} dB relative (abrupt end can click; fade the tail)' + (' [riser: ends on purpose, the hit covers it]' if 'riser' in path else ''))
        add('PASS' if dur < 4 else 'WARN', f'{dur:.2f}s long')
    if not mix: add('PASS' if first_sample_ok(x, pk) else 'WARN', 'start is click-free' if first_sample_ok(x, pk) else 'non-zero first sample may click')
    return res

def first_sample_ok(x, pk): return np.max(np.abs(x[:2])) < .08 * pk

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('files', nargs='+'); ap.add_argument('--mix', action='store_true'); a = ap.parse_args()
    worst = 0
    for f in a.files:
        r = audit(f, a.mix); lv = 'FAIL' if any(l == 'FAIL' for l, _ in r) else 'WARN' if any(l == 'WARN' for l, _ in r) else 'PASS'
        print(f'[{lv}] {f}')
        for l, msg in r:
            if l != 'PASS' or a.mix or len(a.files) == 1: print(f'   {l:4s} {msg}')
        worst = max(worst, lv == 'FAIL')
    sys.exit(worst)
