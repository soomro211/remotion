---
name: video-scriptwriting
description: Write compelling, specific, non-generic scripts for short videos (promos, launches, explainers, product demos, social clips, brand films, tutorials). Use whenever a video needs a script, voiceover, on-screen copy, captions or a hook, or when an existing script feels flat, generic or AI-sounding. Outputs a scene-by-scene script ready for storyboarding or Remotion.
version: 1.0.0
---

# Video Scriptwriting

A video script is not an essay read aloud. It is a timed sequence of words and
pictures where each one carries part of the meaning. This skill produces scripts
that hook fast, say something specific, sound like a person, and leave room for
visuals to do work.

**Principles**
1. The viewer owes you nothing. Earn the next 3 seconds, then the next.
2. One video, one idea. One scene, one point.
3. Specific beats clever. Clever beats generic. Generic loses.
4. Words and pictures split the job: never narrate what the viewer can already see.
5. If it cannot be said out loud naturally, it is not finished.
6. Never invent facts, quotes, customers or numbers.

Reference files (read at the step that needs them):

| File | Read at |
|---|---|
| `references/hooks.md` | Step 3 |
| `references/structures-and-formats.md` | Step 2 and 4 |
| `references/voice-and-craft.md` | Step 4 and 5 |
| `references/rewrite-examples.md` | Step 5 (calibrate quality) |
| `references/script-format-and-checks.md` | Step 6 and 7 |

## Workflow

### Step 1: Brief (ask only what is missing, max 4 questions, offer defaults)
- **Outcome:** what should the viewer know, feel or do after? One sentence.
- **Audience:** who exactly, what they already believe, what they care about, what they are sick of hearing.
- **Where and how long:** platform, length, sound on or off, voiceover or text-only.
- **Proof and material:** real facts, numbers, features, quotes, screenshots, existing copy, brand voice, reference scripts or videos they like.
If a product, brand or URL is given, research it (WebSearch/WebFetch when available) before writing: what it actually does, how its customers talk about it, what competitors say. Use the audience's real words.

Read `references/engagement-and-payoff.md` before choosing an angle, developing hooks and performing the final engagement pass. Use its narrative-question, causal-beat and payoff checks alongside the existing references.

### Step 2: Find the angle
Before drafting, write down:
- **The one thing:** the single sentence the viewer should repeat to a friend.
- **The tension:** what is the problem, cost, belief or desire that makes this worth watching? No tension, no script.
- **The proof:** the most believable evidence you have (demo, number, before/after, result).
- **Three angles** (one line each) that differ in idea, not just wording: e.g. result-led, pain-led, contrarian, story-led, demo-led. Recommend one and say why. If the user is not available, choose and state your pick.
- **Voice in 3 words plus one "never"**: e.g. "dry, precise, warm; never hypey".
Choose the structure and format from `references/structures-and-formats.md`.

### Step 3: Develop and test stronger hooks
Read `references/hooks.md` and `references/engagement-and-payoff.md`. Draft eight distinct hook/visual concepts internally, shortlist three complete openings, then score clarity, relevance, specificity, curiosity, payoff fit and sound-off understanding. Make the topic visible immediately, give early value and avoid vague suspense. Choose the strongest truthful opening; retain the runner-up. Treat scores as editorial judgment, never predicted retention.

### Step 4: Outline beats, then draft
- Outline as causal beats: new information, purpose, proof, question resolved/raised, and why the next beat follows. Use tension, a genuine turn and an earned payoff where the material supports them. Cut repeated claims; avoid a list of benefits.
- Draft the script to the word budget for the length (see below). Write VO and on-screen text separately. Add visual direction for every beat, because the picture should carry half the meaning.
- Apply `references/voice-and-craft.md` while drafting, not after.

**Word budgets (voiceover is about 2.5 words per second, with pauses)**
| Length | Spoken words | Beats |
|---|---|---|
| 6-10s | 10-20 | hook, payoff |
| 15s | 25-35 | hook, value, CTA |
| 30s | 55-70 | hook, problem, solution, proof, CTA |
| 60s | 120-140 | hook, problem, solution, 2-3 proof beats, CTA |
| 90s+ | 190-220 | chapters, each with its own mini-hook |
Text-only videos: on-screen text 2-7 words per beat, max about 12 visible at once.

### Step 5: Edit like a different person
Run all of these passes and fix what they find:
1. **Cut pass:** delete the first sentence of every scene, then restore only if the scene breaks. Remove every word that carries no meaning.
2. **Specificity pass:** replace each abstract noun with a concrete one; add the number, name or visible result.
3. **Ear pass:** read it aloud (or sub-vocalize at speaking pace). Rewrite anything you stumble over, anything with three consecutive stressed syllables, or any sentence you would not say to a friend.
4. **Slop pass:** remove banned words and patterns listed in `voice-and-craft.md`.
5. **Show-don't-tell pass:** wherever the VO describes what is on screen, change the VO to add what the screen cannot show, or cut it.
6. **Proof pass:** every claim has proof on screen or a source. No proof, soften or cut.
7. **Sound-off pass:** can a viewer follow with the sound off? Add or fix on-screen text.
8. **First-3-seconds pass:** could someone mid-scroll tell what this is about and want the next second?
9. **Momentum/payoff pass:** each beat adds information or emotion; close promised questions, give the strongest evidence room, vary cadence, and ensure the ending fulfills the exact opening promise. Do not manufacture urgency or a twist.

### Step 6: Format the deliverable
Use the scene table in `references/script-format-and-checks.md`: per scene, time,
visual direction, on-screen text, VO, proof/source, sound cue. Include the one-line
creative promise, the voice note, the word and duration count, and alternates
(runner-up hook, alternate CTA).

### Step 7: Self-check and deliver
Run the checklist in `references/script-format-and-checks.md`. Fix everything that
fails. List any gaps honestly (missing proof, unsourced number, unclear audience).
Present the script and ask for edits. Offer a shorter cut (e.g. 15s from the 30s).

### Handoff
If the video will be built in Remotion, hand the script to `/remotion-preproduction`
(or paste it into `VIDEO_PLAN.md` section 4). Keep scene numbers and durations so
the storyboard maps one-to-one.

## Done means
- A stranger can state the one thing after one viewing.
- The hook works in the first 3 seconds without sound.
- No line could be pasted into a competitor's video unchanged.
- Every number and claim is sourced or shown.
- It sounds like a person talking, not a brochure.

## Remotion collection compatibility

- For a standalone script request, complete this skill without scaffolding a project or requiring video production. Keep the existing script-only feedback workflow.
- Inside [Remotion Preproduction](../remotion-preproduction/SKILL.md), use the current brief and concept, complete script craft in place, and return to its Phase 4. Do not repeat intake, restart preproduction or request a separate script approval. Present the script as part of the existing content-plan review.
- Read the [saved Notebook defaults](../remotion-best-practices/references/notebook-theme.md) for Remotion video production. For video-production handoffs, include separate style-only instructions and the full TTS script with optional angle-bracket vocal cues with plan approval, then use audio generated and returned by the user; do not generate speech yourself. Follow [User-provided TTS handoff](../remotion-preproduction/references/tts-handoff.md). A voice description alone does not authorize calling a speech service. Use VO = none for silent videos and budget subtitle reading time separately from spoken-word budgets.
- Keep concise display headlines separate from explanatory subtitle cues. The 2-7-word display-copy guideline does not require omitting information that silent viewers need. Use [Remotion Captions](../remotion-captions/SKILL.md) for technical caption timing, transcription and rendering.
- Choose step-by-step drawing, held proof shots or distinct scenes according to each beat. Specify optional transitions only where they clarify a reveal, contrast or chapter change; include the reason and maintain stable scene IDs into storyboarding.
- Use [Video Themes Pack](../video-themes-pack/SKILL.md) only for requested alternate themes or theme options. Keep the Notebook default otherwise, and verify language/font coverage for every chosen style.
- Preserve source-backed claims and approved copy. Recompute frame timing from the final script and actual recorded audio when narration is requested; do not invent speech duration from word count alone.
