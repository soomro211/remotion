# Engagement, hooks and earned payoff

## Build a reason to watch

Before writing, state: who cares, what they want, what blocks them, what evidence changes their mind, and what they will understand or do at the end. Use real stakes appropriate to the subject, not inflated danger or invented urgency. For education the engine can be a puzzle or surprising mechanism; for a story, a decision and consequence; for a demo, friction and visible resolution. A problem–solution sales pitch is not mandatory.

Choose one narrative question the video can actually answer. Write the answer first, then arrange the clearest path to it. Give useful information early; suspense does not justify hiding the topic, padding runtime or delaying all value until the CTA.

## Hook development

Draft 8 genuinely different hook + opening-shot pairs internally: demonstrated result, recognizable moment, visual puzzle, counterintuitive mechanism, consequential choice, sharp comparison, specific promise and story-in-progress. Use only techniques the material supports. Vary the idea, not just synonyms. For a tightly specified user opening, improve within that direction rather than replacing it.

Shortlist three. For each write the exact first spoken line, the immediately visible action/proof, short display copy, the viewer's likely question and the promised payoff. Ask:

- Can the target viewer understand the topic from the first frame/phrase?
- Is the unanswered question specific and worth resolving for this audience?
- Does the opening show something instead of merely claiming importance?
- Is the promise truthful and deliverable within this actual runtime?
- Does it still work if the exaggerated adjectives and dramatic music vanish?

Score clarity, relevance, specificity, curiosity, proof/payoff fit and sound-off understanding from 1–5. Reject any candidate below 4 in clarity or truth/payoff fit, then compare the strongest overall candidates. Scores are editorial judgments, not measured retention predictions. Keep the winner and a runner-up, iterate any weak criterion, and justify the choice in one sentence. No fabricated analytics or guarantees of virality.

## Write a beat engine, not a list

For each beat, write its new information, visual evidence, viewer question answered/raised, and reason the next beat follows. Prefer causal progression: observation → tension → attempt/mechanism → revealing proof → consequence/payoff. Short videos can compress this into two beats; do not force every stage into every format.

Vary the job of successive beats: question, demonstration, comparison, reaction, consequence or concise explanation. Each must add information. Cut duplicate claims and verbal bridges that merely announce the next section. Pay off minor questions along the way; at most one primary unresolved question plus one brief secondary question for a short clip. Resolve every promise you open.

Place a meaningful turn when the material has one: an assumption fails, a detail explains the outcome, or a comparison changes perspective. It must come from the facts. Do not manufacture a twist for a straightforward tutorial. Let the strongest proof breathe; a pause can earn more attention than another line.

## Make the words move

Use concrete verbs, visible details, natural contractions where the language allows, and changes of sentence length. Read aloud for cadence and emotional intent; remove repeated sentence openings, mechanical three-part lists and identical beat lengths. Do not force English idioms, punchlines or terse syntax onto another language. Write natively for the intended audience and pronunciation.

Replace empty intensifiers with a tangible detail. Replace vague suspense ("You won't believe what happens next") with the actual puzzle. Replace generic benefits with a supported example or demonstration. If proof is unavailable, narrow the claim rather than inventing a number.

Illustrative educational rewrite (adapt the wording to the audience):
- Flat: "Plants use water. Roots absorb it. Water moves upward."
- Stronger: "How does water climb a tree with no pump? Start at a leaf: as water evaporates, it pulls on the water behind it. Trace that connected column down to the roots."
- Payoff: show the linked path and explain the mechanism at the required accuracy; do not imply evaporation alone explains every plant or condition. Research subject-specific claims before using them.

Illustrative product rewrite, only if demonstrated by the actual product:
- Flat: "Our app makes organizing files easy."
- Stronger: "Three copies. Same filename. Which one did you send?" Pair with the real confusion, then show the actual resolution rather than another promise.

## Match the edit to the beat

Choose a new shot, crop, drawing step or transition because the information changes. A proof shot may hold; a causal diagram may draw continuously; a before/after comparison may use a match cut; a new chapter may use a page turn. Keep one focal action at a time. Do not prescribe a transition or pattern interrupt every few seconds. The script should remain interesting without decorative effects.

Record transition choice (including none), reason and target timing in visual directions. Final timing follows the supplied TTS recording and reading holds. Keep the TTS transcript free of scene labels, edit instructions, sources and hook scores. Optional angle-bracket vocal cues are permitted under the TTS handoff; sustained emotion belongs in the separate style block.

## Final engagement pass

Read just the opening and ending: does the ending fulfill the opening's exact promise? Read the middle without the opening: is there actual evidence and progression? Remove any beat whose deletion loses no meaning or emotional movement. Check that the CTA follows naturally from the payoff, or omit a sales CTA when the brief only needs explanation or story closure. Deliver the strongest script, not all internal drafts; include the runner-up hook and brief reasoning when useful.
