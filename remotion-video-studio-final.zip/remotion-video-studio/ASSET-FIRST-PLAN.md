# Approved asset-first workflow update — 1.4.0

User-approved scope: plan an asset-first production stage, create/review/save high-quality editable
art before scene assembly, preserve the growing library and refresh references. Clarification:
assets must also live inside the main workflow/skill-set assets directory so future skill/Git
updates do not need access to specific video projects.

Implemented:

- Required post-approval asset brief, distinctive layered source creation, actual visual/motion
  self-review, archive and readiness before scene assembly. Existing script approval remains the
  only routine user gate; supplied narration/actual-audio alignment remain intact.
- Permanent `skills/remotion-themes/themes/cut-paper/assets/library/<id>/<version>/` packages for
  topic-specific and universal artwork. Sources, dependencies, previews, metadata and review
  evidence are included with the skill set. Project copies are immutable versioned snapshots.
- Installed-path-aware create/archive/reuse/search/check/reindex/sync helper, conflict preservation,
  package/source hashes and portability checks. Finalization rechecks current productions.
- Archive merge before upgrades/Git/ZIP updates; packaging can merge an installed library and
  includes it in the normal release manifest. No source film is needed to restore saved art.
- Updated current/default authority, director/preproduction/theme/build/delivery/schema/QA guides,
  templates and all instructional reference routing; a real four-plane SVG source example and
  source-generated previews complement the existing 29 foundational entries.
- Regression, browser/gallery/link, relocated-skill source import/render, archive restoration and
  clean-package checks. See VALIDATION.md for performed checks and explicit limits.

This updates skills/assets/references only; no new channel film or voice take is created.
