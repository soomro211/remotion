# Approved asset-library plan

Approved by the user on 2026-10-23. Build a universal, editable Cut Paper library: people/hands, modular scenery, everyday props, explanatory parts, shared materials and motion. Build the improved walking rig first, review it against the previous sinusoidal drawing, then complete the library, representative scenes, catalog, selection installer, workflow integration and one finalized ZIP. No further approval gate is required for this scope.

Walking requirements: segmented joints, distance-based phase, stance-foot planting, heel/toe articulation, foot clearance, restrained counter-swing and body motion, left/right travel, smooth acceleration/deceleration and controlled landing at a stop. Include editable appearance and idle, pointing, reaching, carrying, sit/stand actions. Review movement and intermediate poses, not only settled stills.

Reuse requirements: self-contained local React/SVG components, deterministic explicit source time, searchable metadata, previews, attachment anchors, usage recipes, selective dependency installation preserving project edits, and fresh-project checks. Preserve the existing lower smooth subtitles, finite useful labels, original audio and single approved-script workflow. Cut Paper remains the only theme. No topic-specific film scenes become mandatory backgrounds.

## Completion

Implemented release 1.3.0: 29 catalog entries; improved jointed walking and actions; shared props/scenery/material/motion; selective installer; current primary production images; 100-reference audit; four silent encoded previews; fresh-source and browser/rig checks. The final single ZIP includes all 16 skills and the review studio. Validation evidence is in VALIDATION.md and the catalog's adjacent JSON reports.
