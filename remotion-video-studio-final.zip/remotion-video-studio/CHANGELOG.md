# 1.2.0 — 2026-10-23

- Consolidated all 16 skills with Cut Paper as the sole included theme. Removed the
  former map theme, its datasets, dedicated helper, sound palette and unused fonts.
- Established the Industrial Revolution film as a reference for camera direction,
  scale, foreground reveals, shared-object handoffs and continuous mechanism time.
- Added a camera guide, optional CameraRig, caption renderer and four approved
  production stills. Topic-specific backgrounds, subject animation and smooth
  subtitles are defaults; persistent main headings and template debris are excluded.
- Unified approval/export routing, duration rules, script paths and timing handoff.
- Preserved original voice bytes and portable public-relative media paths.
- Fixed explicit empty sound lists, empty TypeScript cue output, mono mix handling,
  short music fades, clipping rejection and silent font fallback.
- Added verified-master audio export, fast-start MP4, encoded-media checks and an
  evidence-based QA template. Caption alignment and artistic review remain authored work.
- Added a release manifest, bundle validator, regression tests and font notices.

The older split ZIPs predate this release and remain historical uploads.
