# 3.1.0 — 2026-10-24

- Removed every skill and reference that the 3.0.0 decision architecture did not
  route to, so the shipped package is exactly the current workflow: video-director
  plus the upstream Remotion implementation skills.
- Removed `video-scriptwriting` and `remotion-preproduction` (their phase is
  `video-director`; speech guidance is now stated there), `remotion-themes`
  (art direction is defined in `references/current-workflow.md`; the three bundled
  fonts and Cut Paper theme are no longer shipped), and `remotion-sound-design`
  (sound treatment is in `delivery-workflow.md`).
- Kept the two sound scripts the pipeline actually runs (`mix_preview.py`,
  `audit_audio.py`) beside the director scripts; deleted the unused
  `synth_sfx.py`, `SfxTrack.tsx`, `example-cues.json` and the five unreachable
  sound references.
- Deleted the 1.5.0 `PLAN.md`, `legacy_pause_estimator.py` and the schema<3 branch
  in `after_vo.py` (a legacy plan is no longer re-estimated), the undocumented
  `--no-sfx` flag, the unreferenced `doctor.py` and `light-leaks.md` (duplicated in
  `effects.md`), and the test-only `useProjectFonts.ts`.
- Bundled map data removed: the three duplicate `render-stability.md` copies
  became one shared reference; the 333 KB generated `country-meta.json`, its
  sample route and the demo components that hard-imported them are gone
  (`prep-geo.mjs` remains the documented way to generate project geometry).
- `tools/audit_references.py` now walks the link graph instead of testing for a
  boilerplate line, so an unrouted file fails the check.

# 1.2.1 — 2026-10-23

- Lowered the default subtitle plate from y=1346 to y=1500 at 1080×1920, keeping
  its 148px height and 272px of space below it.
- Updated the renderer, plan template, theme directions and QA guidance together.
  Subtitle placement is independent of the larger title/label margins.
- Kept the production film and historical reference stills unchanged; new caption
  placement takes precedence over their earlier higher subtitles.

# 1.2.0 — 2026-10-23

- Consolidated all 16 skills with Cut Paper as the sole included theme. Removed the
  former map theme, its datasets, dedicated helper, sound palette and unused fonts.
- Established the Industrial Revolution film as a reference for camera direction,
  scale, foreground reveals, shared-object handoffs and continuous mechanism time.
- Added a camera guide, optional CameraRig, caption renderer and four approved
  production stills. Topic-specific backgrounds, subject animation and smooth
  subtitles are defaults; persistent main headings and template debris are excluded.
- Unified approval/export routing, duration rules, script paths and timing handoff.
- Preserved original voice bytes and portable public-relative media paths.
- Fixed explicit empty sound lists, empty TypeScript cue output, mono mix handling,
  short music fades, clipping rejection and silent font fallback.
- Added verified-master audio export, fast-start MP4, encoded-media checks and an
  evidence-based QA template. Caption alignment and artistic review remain authored work.
- Added a release manifest, bundle validator, regression tests and font notices.

The older split ZIP packages predate this release.
