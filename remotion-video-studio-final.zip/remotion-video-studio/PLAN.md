# Universal library and workflow update — 1.5.0

Authorized: plan then execute without another approval. Preserve original film projects and user assets.

1. Add approximately 70 distinct assets/motion tools across home, work, transport, nature, food,
   places, technology, people and explanation. Use the existing matte paper material, editable
   shapes, clear anchors, finite controls and real moving parts; no topic-specific default scenery.
2. Add bounded timing, arc transfer, hinge, path draw, orbit, controlled pulse, stagger, pour and
   camera path helpers; extend purposeful gestures while retaining grounded distance-driven walking.
3. Fix observed angle wrapping, degenerate limb targets, archive validation and catalog scale issues.
4. Paginate the visual catalog, render every asset, review contact sheets and animated examples in
   varied contexts, test contacts/IDs/bounds/frame-rate invariance and selective fresh-project use.
5. Consolidate mandatory rules into one current workflow. Remove duplicated instructions, old
   topic-biased images/generator, obsolete plans and redundant report copies. Preserve useful API
   references, source licenses, immutable saved asset packages and meaningful QA evidence.
6. Refresh current images/catalog/recipes/tests, synchronize installed assets before updating skills,
   produce one integrity-checked ZIP and push the finalized release to soomro211/remotion.

Completion and performed evidence belong in VALIDATION.md; instructions/checklists alone do not
prove visual quality. Standalone assets/tests need no narration. The permanent skill archive and
original-voice/lower-caption/no-persistent-heading defaults remain mandatory for future films.
