# Remotion Video Studio — finalized 1.3.0

One complete package for producing finished Remotion explainers with an AI agent.
Includes all 16 skills, the sole Cut Paper theme, 29 reusable asset/catalog entries,
fonts and notices, current reference images, animation previews, helpers
and production checks. Released 2026-10-23. No second ZIP is needed.

## Install all 16 skills

1. Extract `remotion-video-studio-final.zip` once.
2. Copy the **contents** of `remotion-video-studio/skills/` into one supported
   skills location: Codex user `~/.codex/skills/`, Codex project `.agents/skills/`,
   or Claude Code `~/.claude/skills/`. Keep each skill as a direct child folder.
3. Keep all sibling skills together. Review and back up any locally customized
   versions before replacing them. Reload the agent session if required by the client.

Correct: `.agents/skills/video-director/SKILL.md` and
`.agents/skills/remotion-themes/SKILL.md`. Do not nest another `skills/` level.
Use one active copy of this set per project; avoid mixing old split-package
copies with this revision. Earlier split packages predate this finalized release.

## Use

> Use video-director. Make a 50-second video about [topic] in the cut-paper theme.

The agent reads the actual theme images, researches and plans the explanation,
then presents the storyboard, narration and TTS prompt for one approval. Send
the approved voice take. The agent aligns it, builds the scenes and captions,
reviews the result, renders, masters audio and delivers the MP4. Existing approval
or an explicit instruction to proceed carries forward; do not add another gate.

Start with [Video Director](skills/video-director/SKILL.md) and its
[production defaults](skills/video-director/references/production-quality.md).
The defaults now include:

- Topic-specific paper worlds and backgrounds, with actual animated explanations.
- Purposeful camera travel, depth, overscan and shared-object continuity.
- Smooth subject animation and motivated transitions with correct overlap timing.
- Accurate, smoothly changing subtitles on a stable lower backing above bottom controls
  (1080×1920 default: y=1500, height=148, leaving 272px below it).
- Optional brief opening titles; no persistent chapter headings or template debris.
- Original voice preservation, actual-audio alignment and final encoded-file QA.

The [current workflow](skills/video-director/references/current-workflow.md),
[asset catalog](skills/remotion-themes/themes/cut-paper/assets/README.md),
[camera guide](skills/video-director/references/camera-and-continuity.md),
[approved-film reference](skills/video-director/references/industrial-revolution-example.md),
[delivery workflow](skills/video-director/references/delivery-workflow.md) and
[QA template](skills/video-director/assets/qa-report.template.md) make those
requirements concrete. Optional camera/caption components are starting tools;
they do not automatically make the scenes or replace review.

## Requirements

- A supported Node runtime: 20.19+, 22.13+ or 24+, respecting the chosen project's
  engine constraints. Install project dependencies and Chromium for rendering.
- Python 3.9+ with `numpy` and `scipy`; FFmpeg and ffprobe on PATH.
- All `remotion` and `@remotion/*` packages pinned to the same compatible version.
  This release was checked with 4.0.538; upstream reference skills retain their
  original version metadata. Consult the Docs skill for APIs in another version.
- A way to inspect reference/rendered images and review motion. Playwright is
  optional for automated browser/layout checks and preview regeneration.
- Transcription or forced-alignment tools for actual-audio captions. No ASR
  weights, TTS service, generated voice, paid account or API key is bundled.

Resolve script paths from the installed skill directory. Run its helper scripts
with `python3`; do not assume they are in a new project's `scripts/` folder.
Run `video-director/scripts/doctor.py --project <project>` for dependency checks.

## Included skills

| Skill | Purpose |
|---|---|
| `video-director` | Plan, align, build, render and verify the finished film |
| `remotion-preproduction` | Visual storytelling, storyboard, motion direction and QA |
| `video-scriptwriting` | Specific narration, hooks, factual checks and TTS delivery |
| `remotion-themes` | Cut Paper materials, fonts, images and scaffold |
| `remotion-sound-design` | SFX, cue placement, mixing and loudness checks |
| `remotion-best-practices`, `remotion-create`, `remotion-markup`, `remotion-studio`, `remotion-render`, `remotion-captions`, `remotion-maps`, `remotion-multimedia`, `remotion-interactivity`, `remotion-docs`, `remotion-upgrade` | Remotion implementation references and client workflows |

## Validate the bundle

From the extracted `remotion-video-studio/` folder:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
```

The validator checks all skill entry points, local Markdown links, Python syntax,
JSON, required assets and the SHA-256 manifest. Regression tests exercise file
preservation, silence, voice timing, cue emission and export handling with FFmpeg.
The release's performed checks are recorded in [VALIDATION.md](VALIDATION.md).

## What the skills can promise

They provide the production instructions and reusable patterns learned from the
rainbow, communism, capitalism, rivers and Industrial Revolution films. Quality
still depends on the agent's visual judgment, factual work, available tools and
review of each render. A clean plan or passing script cannot certify a new film's
art direction, caption legibility or camera feel. Record the actual evidence and
limitations; never claim listening or playback that was not performed.

Cut Paper is the only included theme. The general Remotion Maps implementation
reference remains available for topic-specific paper maps; it adds no map theme.
The kit remains a scaffold. Third-party material retains its own terms; see
[THIRD_PARTY.md](THIRD_PARTY.md).

## Reusable assets and better character movement

Open the [visual catalog](skills/remotion-themes/themes/cut-paper/images/assets/catalog.html) locally.
It contains editable people/hands, scenery, everyday props, explanation parts and motion tools,
with per-asset PNG/SVG previews. The jointed walker uses distance-driven stride phase, planted
stance feet, heel/toe motion and controlled landing at a stop. Appearance and actions are editable.

```bash
python3 skills/remotion-themes/scripts/assets.py list --search walking
python3 skills/remotion-themes/scripts/assets.py copy /path/to/video --assets person,journey,tree,camera,captions
```

The selector installs required modules, a clean export barrel and relative version/hash metadata.
Local edits are protected. The [preview studio](examples/asset-studio/README.md) includes the
walking comparison, action reel, catalog and three scene contexts. Rendered demonstrations are
silent asset studies, not narrated channel videos. No new voice take is required to use the library.

The [reference audit](REFERENCE-AUDIT.md) records alignment of the full Markdown reference set.
The primary visual references now use the latest rig, current material components and lower
caption lane. Historical camera studies remain explicitly marked. See [release validation](VALIDATION.md)
for performed checks and limits; this update does not promise that future films pass automatically.
