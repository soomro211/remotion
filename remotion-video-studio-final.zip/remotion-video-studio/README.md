# Remotion Video Studio — 3.0.0

The workflow starts from the current brief. Sourced user requirements and technical contracts are separate from project-specific creative decisions. Speech and shots are independent structures. Artwork is prepared in the project before final assembly.

## Start
Use [video-director](skills/video-director/SKILL.md). Read [decision architecture](skills/video-director/references/current-workflow.md); load specialist/API guides when relevant. Sixteen skills are available resources, not a compulsory instruction stack.

Initialization creates empty schema-3 records. It injects no palette, font, narrator persona, duration, aspect ratio, scenes, artwork or sound. Resolve these from the request and evidence. CLI values are recorded as provisional configuration, with their actual source established in the plan.

```bash
python3 skills/video-director/scripts/init_video.py /path/to/project
```

For this channel's established preferences, explicitly select `--profile channel` when applicable. That profile records user requests for paper medium, lower smooth captions, purposeful display text and an engaging opening. It contains no colors, fonts, cast, locations or story structure. Other briefs can provide their own requirements.

## Production
Understand purpose/audience/scope → develop speech and independent shots → derive art direction from setting/material/light/context/tone → prepare/review project artwork → align speech and assemble → review creative results and engineering operation separately → deliver.

References have explicit roles and limits. A material example does not implicitly determine colors. Palette, type, illustration technique, captions and sound belong to the project. The shared package provides methods, optional licensed font resources and technical helpers. Original production art remains with its project.

The established plan/script approval applies when missing; authorization carries forward. Internal asset/review work adds no user gate. Feedback first corrects the affected project; broader process changes need evidence and an appropriate scope.

## Install and migration
Back up customizations, then replace the old studio-owned skill folders with the supplied siblings in `~/.codex/skills/`, `.agents/skills/`, or `~/.claude/skills/`. Keep unrelated skills and completed projects. Replacing rather than merging clears obsolete creative defaults and removed inventories. Reload the agent if needed.

Schema 3 uses `narration` and `shots`, with source-attributed requirements and project art direction. Existing film source/exports are untouched. Legacy scene-based audio estimation remains explicitly labeled for older plans; current helpers register speech without inferring cuts. The caption renderer now requires an explicit project style. See [schema/handoff](skills/video-director/references/plan-schema.md).

## Verification and limits
See [VALIDATION.md](VALIDATION.md), [reference audit](REFERENCE-AUDIT.json) and [fresh-project check](FRESH-PROJECT-CHECK.json). Run:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
python3 tools/check_fresh_project.py --node-modules /absolute/path/to/compatible/node_modules
python3 tools/package_release.py --out ../remotion-video-studio-final.zip
```

Tests verify explicit contracts and technical integration. Rendered evaluation studies examine contextual treatment choices; they are not templates, independent creative certification or a guarantee of future quality. Each film requires actual creative review. Evaluation projects/media stay outside the shared skills.

Runtime/font terms remain in [THIRD_PARTY.md](THIRD_PARTY.md). The package excludes production artwork, old reference images, films, narration, credentials, caches and node_modules.
