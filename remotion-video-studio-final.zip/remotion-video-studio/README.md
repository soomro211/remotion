# Remotion Video Studio — 1.5.0

One finalized ZIP: 16 skills, Cut Paper as the sole theme, **106 editable asset/tool entries**,
local fonts/notices, current visual references, four silent motion/scene studies, production helpers
and meaningful checks. The library includes 77 new universal entries across home, work, transport,
technology, nature, food, places, measurement, people, relationships and bounded animation.

## Install or update

1. Extract `remotion-video-studio-final.zip`.
2. Back up customized installed skills. Before replacing them, merge saved story packages into the
   extracted set with `asset_workflow.py sync --to-library <extracted-library>`.
3. Copy the contents of `remotion-video-studio/skills/` into Codex `~/.codex/skills/`, project
   `.agents/skills/`, or Claude Code `~/.claude/skills/`. Keep sibling skills and the merged archive
   together. Use one active copy per project and reload the agent if required.

Correct layout: `.../skills/video-director/SKILL.md` beside `.../skills/remotion-themes/SKILL.md`.
The [asset-first update guide](skills/video-director/references/asset-first-workflow.md) gives exact
archive/restore/sync commands. Do not replace a growing asset library with an older empty copy.

## Use

> Use video-director. Make a video about [topic] in the cut-paper theme.

The agent researches and proposes a human script/storyboard with a TTS prompt for one approval.
After approval it creates/reviews distinctive editable assets, saves ready versions in the **main
skill set**, aligns the supplied voice, assembles/animates scenes, adds smooth lower subtitles,
reviews the result and delivers the verified MP4. Existing authorization carries forward. Asset
self-review adds no user gate; standalone assets need no narration. Current defaults live in
[one workflow reference](skills/video-director/references/current-workflow.md).

Defaults include meaningful camera movement and transitions, coherent layered worlds, physical
contact, source-clock continuity, original-voice preservation and exact-audio caption timing.
Captions at 1080×1920 use x80/y1500/w890/h148. Optional opening titles leave; persistent scene
headings, counters, progress UI and unrequested outros are excluded.

## Find useful parts

Open the [visual catalog](skills/remotion-themes/themes/cut-paper/images/assets/catalog.html),
[core recipes](skills/remotion-themes/themes/cut-paper/assets/README.md) and
[universal object/motion recipes](skills/remotion-themes/themes/cut-paper/assets/UNIVERSAL.md).
Searchable PNG/SVG poses accompany the source; appearances are controls, not separate asset counts.
The [asset studio](examples/asset-studio/README.md) demonstrates varied environments, gestures,
opening/pouring/transfer, distance-linked wheels and grounded walking.

```bash
python3 skills/remotion-themes/scripts/assets.py list --search transport
python3 skills/remotion-themes/scripts/assets.py copy /path/to/video --assets person,journey,mug,car,arc-transfer,camera,captions
python3 skills/remotion-themes/scripts/asset_workflow.py search --query river
```

New/adapted story packages live in `skills/remotion-themes/themes/cut-paper/assets/library/` with
editable source, dependencies, previews, metadata and honest review evidence. Preserve topic-specific
art there too. They restore without the original video; the project's `assets/` contains a versioned
snapshot. Retain earlier versions and save reviewed improvements under new versions. Open the
[saved-art gallery](skills/remotion-themes/themes/cut-paper/assets/library/catalog.html).

## Requirements and verification

Use compatible Node 20.19+/22.13+/24+, React/Remotion dependencies, Python 3.9+, NumPy/SciPy,
FFmpeg/ffprobe, and Chromium for rendering. This release tests Remotion 4.0.538; pin all Remotion
packages together. API guides retain upstream metadata. Actual-audio transcription/alignment tools
are required for narrated films; no ASR weights, TTS service/key or supplied voice are bundled.
Archive helpers use the Python standard library; optional browser/reference tooling needs Playwright/Pillow.

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
python3 tools/check_fresh_project.py
python3 tools/package_release.py --out ../remotion-video-studio-final.zip --merge-library /path/to/installed/remotion-themes/themes/cut-paper/assets/library
```

[VALIDATION.md](VALIDATION.md) records performed checks/limits; [REFERENCE-AUDIT.json](REFERENCE-AUDIT.json)
inventories instructional references. Source/picture hashes flag stale previews. Passing scripts do
not certify future artistic quality, factual accuracy or listening; review each real film. Third-party
runtime/fonts retain their terms in [THIRD_PARTY.md](THIRD_PARTY.md). No private films, voice takes,
credentials, caches or node_modules enter the ZIP. Old topic-specific screenshots, duplicate plans,
redundant report prose and the deliberately bad legacy walker have been removed.
