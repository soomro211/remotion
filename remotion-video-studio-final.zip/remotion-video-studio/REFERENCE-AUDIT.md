# Reference audit — 1.4.0

The complete skill/reference Markdown corpus is aligned with the current production-default authority and asset workflow. This audit preserves task-specific API knowledge while making the studio defaults explicit.

Changes include mandatory create/review/archive before scene assembly, durable topic/universal packages inside the main skill set, immutable versions, restore/sync commands, asset readiness and finalization checks, and an actual layered-source example. Existing primary images, lower captions, articulated walking, canonical camera/source-time/contact rules and local fonts remain current. The Industrial Revolution study is explicitly historical.

Reference and preview source hashes are recorded. The bundle validator rejects stale preview sources/pictures; the release manifest protects the remaining file set. Changes to shared assets must update their examples, previews, guides and checks in the same release.

This is a production-default, example and link audit, not an independent execution of every advanced upstream API. The executable asset paths are tested against the pinned project.

| Reference | Disposition |
|---|---|
| [skills/remotion-best-practices/SKILL.md](skills/remotion-best-practices/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-captions/SKILL.md](skills/remotion-captions/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-captions/display-captions.md](skills/remotion-captions/display-captions.md) | Production examples/defaults revised |
| [skills/remotion-captions/import-srt-captions.md](skills/remotion-captions/import-srt-captions.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-captions/references/smooth-subtitles.md](skills/remotion-captions/references/smooth-subtitles.md) | Production examples/defaults revised |
| [skills/remotion-captions/transcribe-captions.md](skills/remotion-captions/transcribe-captions.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-create/SKILL.md](skills/remotion-create/SKILL.md) | Production examples/defaults revised |
| [skills/remotion-create/tailwind.md](skills/remotion-create/tailwind.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-create/video-layout.md](skills/remotion-create/video-layout.md) | Production examples/defaults revised |
| [skills/remotion-docs/SKILL.md](skills/remotion-docs/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-interactivity/SKILL.md](skills/remotion-interactivity/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-interactivity/inline-effects.md](skills/remotion-interactivity/inline-effects.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-interactivity/timeline-structure.md](skills/remotion-interactivity/timeline-structure.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/SKILL.md](skills/remotion-maps/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/cesium/TECHNIQUE.md](skills/remotion-maps/techniques/cesium/TECHNIQUE.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/cesium/references/3d-data-sources.md](skills/remotion-maps/techniques/cesium/references/3d-data-sources.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/cesium/references/3d-flyover-architecture.md](skills/remotion-maps/techniques/cesium/references/3d-flyover-architecture.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/cesium/references/3d-troubleshooting.md](skills/remotion-maps/techniques/cesium/references/3d-troubleshooting.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/mapbox/TECHNIQUE.md](skills/remotion-maps/techniques/mapbox/TECHNIQUE.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/mapbox/references/render-stability.md](skills/remotion-maps/techniques/mapbox/references/render-stability.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maplibre/TECHNIQUE.md](skills/remotion-maps/techniques/maplibre/TECHNIQUE.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maplibre/references/render-stability.md](skills/remotion-maps/techniques/maplibre/references/render-stability.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maptiler/TECHNIQUE.md](skills/remotion-maps/techniques/maptiler/TECHNIQUE.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maptiler/references/map-data-sources.md](skills/remotion-maps/techniques/maptiler/references/map-data-sources.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maptiler/references/map-explainer-architecture.md](skills/remotion-maps/techniques/maptiler/references/map-explainer-architecture.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maptiler/references/map-geo-prep.md](skills/remotion-maps/techniques/maptiler/references/map-geo-prep.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/maptiler/references/render-stability.md](skills/remotion-maps/techniques/maptiler/references/render-stability.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-maps/techniques/static-map/TECHNIQUE.md](skills/remotion-maps/techniques/static-map/TECHNIQUE.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/3d.md](skills/remotion-markup/3d.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/SKILL.md](skills/remotion-markup/SKILL.md) | Production examples/defaults revised |
| [skills/remotion-markup/arabic-text.md](skills/remotion-markup/arabic-text.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/audio-visualization.md](skills/remotion-markup/audio-visualization.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/audio.md](skills/remotion-markup/audio.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/calculate-metadata.md](skills/remotion-markup/calculate-metadata.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/color-correction.md](skills/remotion-markup/color-correction.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/compositions.md](skills/remotion-markup/compositions.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/connected-compositions.md](skills/remotion-markup/connected-compositions.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/cropping.md](skills/remotion-markup/cropping.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/effects.md](skills/remotion-markup/effects.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/embedding-videos.md](skills/remotion-markup/embedding-videos.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/ffmpeg.md](skills/remotion-markup/ffmpeg.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/gifs.md](skills/remotion-markup/gifs.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/google-fonts.md](skills/remotion-markup/google-fonts.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/html-in-canvas.md](skills/remotion-markup/html-in-canvas.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/images.md](skills/remotion-markup/images.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/light-leaks.md](skills/remotion-markup/light-leaks.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/local-fonts.md](skills/remotion-markup/local-fonts.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/lottie.md](skills/remotion-markup/lottie.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/measuring-dom-nodes.md](skills/remotion-markup/measuring-dom-nodes.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/measuring-text.md](skills/remotion-markup/measuring-text.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/motion-blur.md](skills/remotion-markup/motion-blur.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/multi-scene-video.md](skills/remotion-markup/multi-scene-video.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/parameters.md](skills/remotion-markup/parameters.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/sequencing.md](skills/remotion-markup/sequencing.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/sfx.md](skills/remotion-markup/sfx.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/silence-detection.md](skills/remotion-markup/silence-detection.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/text-highlights.md](skills/remotion-markup/text-highlights.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/timing-props.md](skills/remotion-markup/timing-props.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/timing.md](skills/remotion-markup/timing.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/transitions.md](skills/remotion-markup/transitions.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/video-editing.md](skills/remotion-markup/video-editing.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-markup/voiceover.md](skills/remotion-markup/voiceover.md) | Production examples/defaults revised |
| [skills/remotion-multimedia/SKILL.md](skills/remotion-multimedia/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-multimedia/get-audio-duration.md](skills/remotion-multimedia/get-audio-duration.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-multimedia/get-video-dimensions.md](skills/remotion-multimedia/get-video-dimensions.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-multimedia/get-video-duration.md](skills/remotion-multimedia/get-video-duration.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-preproduction/SKILL.md](skills/remotion-preproduction/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-preproduction/references/anti-slop.md](skills/remotion-preproduction/references/anti-slop.md) | Production examples/defaults revised |
| [skills/remotion-preproduction/references/design-rules.md](skills/remotion-preproduction/references/design-rules.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-preproduction/references/motion-principles.md](skills/remotion-preproduction/references/motion-principles.md) | Production examples/defaults revised |
| [skills/remotion-preproduction/references/qa.md](skills/remotion-preproduction/references/qa.md) | Production examples/defaults revised |
| [skills/remotion-preproduction/references/script-and-copy.md](skills/remotion-preproduction/references/script-and-copy.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-preproduction/references/storyboard-timing-specs.md](skills/remotion-preproduction/references/storyboard-timing-specs.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-render/SKILL.md](skills/remotion-render/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-render/transparent-videos.md](skills/remotion-render/transparent-videos.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-sound-design/SKILL.md](skills/remotion-sound-design/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-sound-design/references/mixing-and-loudness.md](skills/remotion-sound-design/references/mixing-and-loudness.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-sound-design/references/remotion-audio.md](skills/remotion-sound-design/references/remotion-audio.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-sound-design/references/sound-design-principles.md](skills/remotion-sound-design/references/sound-design-principles.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-sound-design/references/sources-and-licensing.md](skills/remotion-sound-design/references/sources-and-licensing.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-sound-design/references/why-it-sounds-bad.md](skills/remotion-sound-design/references/why-it-sounds-bad.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-studio/SKILL.md](skills/remotion-studio/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/remotion-themes/SKILL.md](skills/remotion-themes/SKILL.md) | Production examples/defaults revised |
| [skills/remotion-themes/themes/cut-paper/THEME.md](skills/remotion-themes/themes/cut-paper/THEME.md) | Production examples/defaults revised |
| [skills/remotion-themes/themes/cut-paper/assets/README.md](skills/remotion-themes/themes/cut-paper/assets/README.md) | Current canonical workflow / asset / QA reference |
| [skills/remotion-themes/themes/cut-paper/assets/library/README.md](skills/remotion-themes/themes/cut-paper/assets/library/README.md) | Current canonical workflow / asset / QA reference |
| [skills/remotion-themes/themes/cut-paper/assets/library/layered-river-valley/1.0.0/review/observations.md](skills/remotion-themes/themes/cut-paper/assets/library/layered-river-valley/1.0.0/review/observations.md) | Immutable asset-specific source/review record; current workflow applies through the enclosing archive guide |
| [skills/remotion-upgrade/SKILL.md](skills/remotion-upgrade/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-director/SKILL.md](skills/video-director/SKILL.md) | Production examples/defaults revised |
| [skills/video-director/assets/qa-report.template.md](skills/video-director/assets/qa-report.template.md) | Current canonical workflow / asset / QA reference |
| [skills/video-director/references/asset-first-workflow.md](skills/video-director/references/asset-first-workflow.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-director/references/camera-and-continuity.md](skills/video-director/references/camera-and-continuity.md) | Production examples/defaults revised |
| [skills/video-director/references/current-workflow.md](skills/video-director/references/current-workflow.md) | Current canonical workflow / asset / QA reference |
| [skills/video-director/references/delivery-workflow.md](skills/video-director/references/delivery-workflow.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-director/references/industrial-revolution-example.md](skills/video-director/references/industrial-revolution-example.md) | Production examples/defaults revised |
| [skills/video-director/references/plan-schema.md](skills/video-director/references/plan-schema.md) | Production examples/defaults revised |
| [skills/video-director/references/production-quality.md](skills/video-director/references/production-quality.md) | Production examples/defaults revised |
| [skills/video-scriptwriting/SKILL.md](skills/video-scriptwriting/SKILL.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-scriptwriting/references/hooks.md](skills/video-scriptwriting/references/hooks.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-scriptwriting/references/rewrite-examples.md](skills/video-scriptwriting/references/rewrite-examples.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-scriptwriting/references/script-format-and-checks.md](skills/video-scriptwriting/references/script-format-and-checks.md) | Production examples/defaults revised |
| [skills/video-scriptwriting/references/structures-and-formats.md](skills/video-scriptwriting/references/structures-and-formats.md) | Current production-default routing added; task-specific guidance retained |
| [skills/video-scriptwriting/references/voice-and-craft.md](skills/video-scriptwriting/references/voice-and-craft.md) | Current production-default routing added; task-specific guidance retained |
