# Third-party material

The Remotion implementation skills and icons were supplied with the original
studio package. They retain their upstream attribution and version metadata.
See [Remotion](https://www.remotion.dev/) and
[Remotion licensing](https://www.remotion.dev/license) for current terms.
This package does not grant a separate license to the Remotion runtime.

The shared font files identify the SIL Open Font License 1.1 in their metadata.
Corresponding upstream Google Fonts notices are included alongside the TTF files
in `skills/remotion-themes/themes/_shared/fonts/*-OFL.txt`: Bricolage Grotesque,
Caveat and DM Sans.
Keep these notices with redistributed fonts.

Optional geography implementation references describe external datasets and
provider services with their own access, attribution and licensing requirements.
The former map theme and its Natural Earth datasets are excluded from this release.
No provider credentials are included.

The four `production-*.png` images are frames from the Industrial Revolution
video created for this repository. They demonstrate the approved local production
standard. Original theme preview images and generators are retained as references.
No user narration files or complete video projects are included in this skill ZIP.
