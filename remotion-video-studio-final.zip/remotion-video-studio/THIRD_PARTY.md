# Third-party material

The Remotion implementation skills and icons were supplied with the original
studio package. They retain their upstream attribution and version metadata.
See [Remotion](https://www.remotion.dev/) and
[Remotion licensing](https://www.remotion.dev/license) for current terms.
This package does not grant a separate license to the Remotion runtime.

No font files are bundled. Font selection and its licence are project decisions;
see `skills/remotion-markup/local-fonts.md` and `google-fonts.md`.

Optional geography implementation references describe external datasets and
provider services with their own access, attribution and licensing requirements.
No dataset sample and no provider credentials are included; `prep-geo.mjs` and
`prep-cesium-path.mjs` generate project geometry from data the project supplies.

The previous reference image and reusable production artwork are absent from this release. Optional licensed font files retain their notices; selection is a project decision. Technical caption/font/timing helpers remain. No supplied narration, provider keys, ASR model weights, node_modules or private film projects enter the ZIP.

Separate evaluation projects use locally available DejaVu fonts under their own notices; neither those font files nor the evaluation artwork is included in the shared skill package.
