# Third-party material

The Remotion implementation skills and icons were supplied with the original
studio package. They retain their upstream attribution and version metadata.
See [Remotion](https://www.remotion.dev/) and
[Remotion licensing](https://www.remotion.dev/license) for current terms.
This package does not grant a separate license to the Remotion runtime.

The shared font files identify the SIL Open Font License 1.1 in their metadata.
Corresponding upstream Google Fonts notices are included alongside the TTF files
in `skills/remotion-themes/themes/_shared/fonts/*-OFL.txt`: Bricolage Grotesque,
Caveat and DM Sans.
Keep these notices with redistributed fonts.

Optional geography implementation references describe external datasets and
provider services with their own access, attribution and licensing requirements.
The former map theme and its Natural Earth datasets are excluded from this release.
No provider credentials are included.

The primary production images and silent preview videos are rendered from the original reusable asset code in this release. Static PNG/SVG poses are supplied for inspection and reuse; the React/SVG components provide editable motion.

The asset geometry, gait, props, scenery and review examples were authored for this workflow; no external stock characters or footage are embedded. Their use does not replace the runtime/font terms above. The ZIP includes a small public asset-review project and silent demonstrations. No supplied user narration, API keys, ASR model weights, node_modules or private film projects are included.
