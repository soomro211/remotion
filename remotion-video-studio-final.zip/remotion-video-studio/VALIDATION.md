# Release validation — 1.4.0

Performed on 2026-10-23 for the approved asset-first workflow and permanent skill-set archive update.
These checks verify production contracts and portability; each future film still needs factual,
visual, motion and audio review.

| Check | Result |
|---|---|
| All 16 skill entries, registrations, current-default routing; Cut Paper is the sole theme | PASS |
| 29 regression tests: 11 archive/workflow, 9 core installer, 9 production helper tests | PASS |
| Ready original asset copied into the main skill archive; source video deleted; restored into another project | PASS |
| Installed helper relocated: default archive remains inside that installed skill | PASS |
| Draft/missing review evidence, source changes, traversal, symlinks and external project imports rejected | PASS |
| Version collisions/local edits preserved; sync preflights conflicts before merging | PASS |
| New/adapt requirements cannot silently pass with a reused package | PASS |
| New-production finalization refuses missing asset readiness before creating a render/output | PASS |
| Existing audio preservation, alignment helpers, original-file integrity, mixing and encoded-export regressions | PASS |
| Relocated complete skills: fresh source project, core dependency closure and readiness before scene authoring | PASS |
| Saved SVG imported by relative path and rendered at 1440×1080 without original video access | PASS |
| Fresh project TypeScript compilation and actual 1080×1920 core/person/camera/caption render | PASS |
| New layered source composite/contact sheet actually opened, corrected and visually reviewed | PASS |
| 11 canonical React/math/gait/camera/caption sources compared with v1.3.0; identical | PASS |
| Core reference PNG/SVG/catalog regenerated from reviewed source renders; current source/picture hashes checked | PASS |
| Core and saved-story galleries: loaded thumbnails, local source/reference links and saved-art search | PASS; see ASSET-WORKFLOW-CHECK.json |
| 103 Markdown references/asset records inventoried with current-default authority and source hashes | PASS; see REFERENCE-AUDIT.json |
| JSON, Python 3.9 syntax, relative links, fonts/notices, shared-package hashes/index and complete release manifest | PASS; release gate |
| Single ZIP CRC/SHA-256 and clean-extraction validation including shared editable sources | PASS; release gate |

The source example `layered-river-valley@1.0.0` contains four editable SVG depth planes, a generated
composite, a layer/anchor recipe, PNG proofs and written review evidence. It is a static wide
source study, with honest coverage/control limits. No moving camera, independent parallax range,
portrait composition, narration or animation playback is claimed for it. Future adaptations must
review their actual framing and motion. No captions or headings are baked into the artwork.

The fresh-project check used only relocated skills for the saved source, imported the archived SVG
through Remotion's asset loader, and rendered it. It separately compiled/rendered the existing
person/material/camera/caption integration. The pinned local Node dependency tree was reused;
a clean network npm install is not claimed.

The existing v1.3.0 rig/browser/encoded-preview evidence is retained because its 11 canonical source
files are unchanged: 14,412 gait samples, 71 browser/contact/caption samples and four fully decoded
silent motion studies. Those are prior measured results, not a claim that all those checks were
repeated for this documentation/archive update. Current fresh-source compilation/rendering and
source hashes guard the unchanged integration. Old Industrial Revolution imagery stays historical.

The archive gate verifies files, review records, declared dependency paths and source hashes.
It cannot judge artistic quality or prove that an agent inspected an image merely because metadata
says so. The production instructions require actual image/motion review and honest evidence. Generic
API references remain task-specific guidance; not every advanced API was independently executed.

Repeat core checks after extraction:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
python3 tools/check_fresh_project.py
```

For gallery checks, serve the complete extracted folder and run `tools/check_asset_workflow_browser.py`.
Optional source-proof regeneration uses Playwright/Chromium and Pillow; the archive helpers use the
Python standard library. Production/audio tests require NumPy/SciPy and FFmpeg/ffprobe. Test environment:
Node 24.19, Python 3.12, React 19.2.3, Remotion 4.0.538, TypeScript 5.9.3, FFmpeg 7.1.5 and system Chromium.

No original user voice, ASR weights, credentials, node_modules or unrelated video projects enter
the ZIP. New original/adapted art does enter the main skill archive, including topic-specific art.
Merge installed additions before replacing skills or packaging; immutable versions protect earlier
films. See [asset-first production](skills/video-director/references/asset-first-workflow.md),
[archive gallery](skills/remotion-themes/themes/cut-paper/assets/library/catalog.html),
[fresh-project results](FRESH-PROJECT-CHECK.json), [unchanged-source check](CORE-SOURCE-CHECK.json),
and [reference audit](REFERENCE-AUDIT.md).
