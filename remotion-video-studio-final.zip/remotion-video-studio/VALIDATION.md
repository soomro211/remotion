# Workflow validation — 3.0.0

Performed 2026-10-24. This release changes process architecture and tool contracts.

## Engineering evidence
- **34 regression tests passed.** Coverage includes neutral initialization, explicit profile/provenance, CLI assumptions, many-to-many speech/shot relationships, reference roles, required project caption styles, actual-take registration without inferred cuts/effects, explicitly authored cue levels/overlap, original audio integrity, silent delivery, project-local asset dependency/copy/hash failures, art-direction review-context invalidation, path boundaries, migration and final export checks.
- **Relocated fresh project passed.** All skills were copied to an isolated location; the starter had empty creative/format choices and installed no art/font/sound treatment. Project-local asset preparation survived relocation. A component using explicit caption styling/font loading compiled and rendered 30 frames at 1080×1920 in H.264 yuv420p/BT.709 and fully decoded. Omitting caption style failed TypeScript as intended. See [fresh-project record](FRESH-PROJECT-CHECK.json).
- **Three six-second silent treatment studies rendered and decoded.** Each compiled with its own project decisions, sources, fonts, caption style and asset review record. Each passed schema-3 finalization and export checks. Native browser execution at 1x reached the end with 180 decoded frames per study.
- **99 skill Markdown references audited** for architecture routing and obsolete production prescriptions/dependencies. See [reference audit](REFERENCE-AUDIT.json). API examples remain implementation examples; not every advanced API was executed.
- Bundle validation checks local links, registrations/metadata, JSON/SVG/Python syntax, a neutral schema-3 starter, absent production visual inventories/scaffolds, file set and SHA-256 manifest. The release ZIP receives CRC and extracted-copy validation before installation/delivery.

## Creative evaluation observations and scope
The same subject, evaporation, was treated in a domestic kitchen and an industrial inspection setting. Material/light/observer context informed the palettes, typography and framing. A brass-lock mechanism supplied another subject under the same paper construction medium. These are agent-authored controlled evaluation briefs, not standing user preferences.

Actual source/context images and encoded sequence samples at 0, 1, 2, 3, 4, 5 and 5.97 seconds were inspected. The kitchen uses a continuous close-to-context camera move; the inspection and lock studies hold framing for mechanical readability. A pin/key support error in the lock study was corrected by deriving pin positions from the key profile. Review observations and technical results are separate in [the evaluation record](TREATMENT-EVALUATION.json).

The studies demonstrate explicit contextual treatment and integration; they are not complete channel films, universal visual examples or independent creative certification. Native browser execution and image-sequence inspection do not establish uninterrupted subjective screening; listening is not claimed for silent studies. Evaporation and lock details are illustrative schematics rather than calibrated simulations.

Evaluation projects, original artwork, full-size frames and clips stay in the workspace outside the shared skills. They are not startup references or a new reusable art inventory. Optional licensed fonts and technical caption/font/timing helpers remain in the package.

## Reproduce technical checks
```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
python3 tools/check_fresh_project.py --node-modules /absolute/path/to/compatible/node_modules
```
The compile/render check reuses a compatible dependency tree; a clean network package install is not claimed. Existing film projects and supplied speech are unchanged. Each new film still needs actual creative and engineering review using its own brief.
