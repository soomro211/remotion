# Release validation — 1.5.0

Performed 2026-10-24 for the authorized universal asset/animation expansion and workflow cleanup.
This records actual technical and visual evidence; future films still need their own review.

| Check | Observed result |
|---|---|
| 16 skills; Cut Paper is the sole theme; metadata, links, Python 3.9 syntax, JSON and SVG XML | PASS |
| 106 distinct asset/tool entries, including 77 new universal entries with source, controls and anchors | PASS |
| Source-generated PNG/SVG poses for every entry; paginated catalog, category/search and download links | PASS |
| 33 Python regressions: archive/restore/preservation, resource checks, selective installation and production/audio helpers | PASS |
| Complete asset studio TypeScript and ESLint | PASS |
| 14,412 gait samples: three proportions, four strides, planting, reach, bone lengths, loop continuity | PASS |
| 912 timed motion samples at 24/30/60 fps: endpoints, conserved pour volume, transfer, camera keys and seeking | PASS |
| 424 rendered catalog-state instances: finite geometry, positive visible bounds, unique IDs and no preview clipping | PASS |
| 31 new motion samples: actual SVG gesture reach, feet/floor, wheel/ground and distance-linked rotation | PASS |
| 72 core browser samples: physical contact, valid IDs/geometry and lower caption bounds/backing continuity | PASS |
| Studio execution at 1x: Actions, Character and MotionLab with sampled advancing frames and no browser errors | PASS |
| Relocated skills, restored story source without original video, selected core/new dependency closure, TypeScript and actual renders | PASS |
| Four new H.264 silent studies: 30 fps, exact frame counts, fast-start and complete decode | PASS |
| Reference pixels match current source stills; source/picture SHA-256 catches stale references | PASS |
| 103 instructional/reference records routed to one current authority; archive evidence stays immutable | PASS |
| Single ZIP CRC/SHA-256, complete manifest, clean extraction and installed-skill file agreement | PASS; release gate |

The 77 additions comprise 64 everyday/environment/transport objects, two people/gesture entries,
two data/relationship components and nine motion/tool entries. Colour choices and poses are controls,
not inflated asset counts. Object sources use the established matte paper, cream rims, fibre texture,
restrained double shadows and shared material stage. Actual contact sheets were opened for all new
families; the mug was also inspected in motion/context. Four scene contexts and physical-action stills
were reviewed, along with extracted encoded frames and walking poses. A cropped hinge/pouring preview,
closed pouring lids and pose clearance were corrected before the final checks.

Measured motion constraints include world-space stance error around 1e-13 units, bone-length error
below 1e-12, zero tested unreachable targets and volume-conservation error 2.22e-16. Browser wheel
rotation is checked within 0.0001 degree because SVG matrices use float storage. These limits test
real relationships rather than requiring impossible exact browser float equality.

The four encoded studies are Actions (300 frames/10s), Showcase (480/16s), MotionLab (240/8s), and
Character (180/6s). They are intentionally silent. Native-speed browser execution and DOM samples
are separate evidence from still inspection; uninterrupted subjective screening or audio listening
is not claimed. No new narrated channel video was created for this asset/workflow task.

Fixes cover shortest-angle wrapping across multiple turns, coincident/inner-unreachable limb targets,
nonfinite motion inputs, exact action endpoints, clipped container contents with removable lids,
CSS/glTF dependency checks, malformed/pending review records and still-first archive previews.
The catalog now scales beyond one page and derives counts/categories from its source metadata.

The four main director/theme/default/quality documents shrank from 4,904 to 1,771 words (63.9%).
One authority retains the production requirements; detailed API and asset recipes are read as needed.
Nineteen obsolete/redundant files were removed: old topic screenshots/thumbnail duplicates, drawing
generator, deliberately poor legacy walker, superseded plans and duplicate report prose. Useful
API references, source notices and immutable saved story packages remain.

The fresh-source check reused pinned local Node dependencies; a clean network npm install is not
claimed. It compiled and rendered selected new car/mug/arc tools plus the grounded person/camera/caption
integration, and imported/rendered a saved SVG from relocated skills. Source projects and original
voice takes were unavailable to that restored asset test and are not needed by the shared archive.
The retained river-valley package is an earlier reviewed static source example; its own stated
coverage/motion limits remain valid. It is not a mandatory setting or a claim of current animation QA.

Repeat after extraction:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
```

Install/prepare the example studio before source/browser/render checks. Its README documents the
commands. Archive helpers use the standard library; production/audio tests require NumPy/SciPy and
FFmpeg; optional reference/browser tooling requires Playwright/Pillow/Chromium. Tested with Node 24.19,
Python 3.12, React 19.2.3, Remotion 4.0.538, TypeScript 5.9.3 and FFmpeg 7.1.5.

See [reference inventory](REFERENCE-AUDIT.json), [gallery checks](ASSET-WORKFLOW-CHECK.json),
[fresh-source results](FRESH-PROJECT-CHECK.json), and the detailed JSON evidence beside the
[visual catalog](skills/remotion-themes/themes/cut-paper/images/assets/catalog.html).
No private narration/films, credentials, node_modules or caches enter the archive. Save new art and
reviewed improvements in the main skill-set archive and merge installed additions before updates.
Checks cannot certify artistic quality or facts from metadata; the workflow requires honest review.
