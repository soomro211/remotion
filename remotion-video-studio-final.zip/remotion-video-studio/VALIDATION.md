# Release validation — 1.6.0

Performed 2026-10-24. This records the asset/workflow release, not a new narrated channel film.

| Check | Observed result |
|---|---|
| Complete asset-studio TypeScript and ESLint | PASS |
| 33 Python regressions: archive preservation, resources, selective installer, production/audio helpers | PASS |
| 14,412 gait samples: three proportions, four strides, planting, reach and continuity | PASS |
| 912 existing timed-helper samples at 24/30/60 fps | PASS |
| 4,004 authored gesture poses: finite bone lengths, wave face clearance and continuity | PASS |
| 3,087 pouring states: horizontal source area, lip/mouth endpoints, conserved source/received/in-flight volume and settled return | PASS |
| 6,840 effect samples and 1,001 lift/reverse states: deterministic emission, cleared tails, bounded population and grip coordinates | PASS |
| 684 rendered catalog-state instances across all 171 entries: geometry, IDs, visible bounds and preview clipping | PASS |
| 183 rendered interaction/pouring/effect states: actual wrist reach/contact, finite geometry and volume sum | PASS |
| Core browser frames: planted feet and stable lower caption backing/lines across cuts | PASS |
| Studio execution at 1x: Actions, Character, MotionLab, InteractionStudy, EffectsStudy, PouringStudy; advancing frame samples, no browser errors | PASS |
| Relocated skills, restored saved source without original video, selected dependency closure, TypeScript and four actual renders | PASS |
| Eight silent H.264 studies: exact dimensions/frames, 30 fps, fast-start and complete decode | PASS |
| 171 current PNG/SVG pairs, six gallery pages, enlarged review pictures and source/picture hashes | PASS |
| Both galleries: loaded images, linked resources and saved-art search | PASS |
| 103 reference records routed to one current production authority | PASS |

The 65 additions are 13 buildings, 12 locations, 10 surfaces, 16 props/equipment, four contact actions,
a complete pouring interaction, six effects and three movement/transition tools. Existing gesture,
hand, bed, airplane and basic façade geometry was repaired. Appearance controls are not separate
asset counts. New art remains editable in the main skill set's assets directory; the existing
immutable saved river package is retained. Updated instructions preserve asset-first creation,
review, main-library archiving and conflict-preserving updates before scene assembly.

Enlarged architecture, location, equipment, gesture, pouring and interaction sheets were opened and
reviewed. Corrections include waving wrist/finger continuity, actual pouring lip and receiver-rim
occlusion, bed/airplane silhouettes, floating harbor geometry, low wall signage, book-stack spacing,
effect preview bounds and scene scale. The actual encoded contact sheet and walking poses were
inspected separately. Native browser execution and sampled DOM states are evidence of execution;
uninterrupted subjective screening or audio listening is not claimed. Studies are intentionally silent.

Gait world-plant error is about 1e-13 native units; tested unreachable targets are zero. The pouring
model conserves normalized source/receiver/in-flight volume within 1.12e-16. It is a stylized 2D model,
not calibrated fluid physics. Staged lift/trolley actions were reviewed at default proportions;
changed anatomy/items still require reach/contact review. Effects are bounded at up to 97 particles
per emitter in the density stress check. These measurements do not certify artistic quality.

The fresh-project check reused pinned local dependencies; a new network npm install is not claimed.
It rendered core person/camera/captions, restored saved SVG art, existing car/mug/arc tools, and new
architecture/location/equipment/lift/pouring/effect/transition source. Advanced API references retain
upstream metadata; not every API was independently executed. The old saved river package keeps its
own stated static/motion limits and is not a mandatory backdrop.

Repeat after extracting:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
python3 tools/check_fresh_project.py
```

Use the [asset studio](examples/asset-studio/README.md) for source/browser/render checks. Python 3.9+
is supported by archive helpers; optional review tools need Playwright/Pillow/Chromium. Production
tests also need NumPy/SciPy and FFmpeg. Tested with Node 24.19, Python 3.12, React 19.2.3,
Remotion 4.0.538, TypeScript 5.9.3 and FFmpeg 7.1.5.

Detailed evidence: [reference audit](REFERENCE-AUDIT.json), [gallery check](ASSET-WORKFLOW-CHECK.json),
[fresh-project proof](FRESH-PROJECT-CHECK.json), and JSON/media beside the
[visual catalog](skills/remotion-themes/themes/cut-paper/images/assets/catalog.html).
The final archive carries a complete SHA-256 manifest and ZIP checksum. Private films/voice takes,
credentials, caches and installed dependencies are excluded. Each future film still requires factual,
visual, motion and final-audio review.
