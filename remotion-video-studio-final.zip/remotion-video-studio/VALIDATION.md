# Release validation — 1.2.1

Performed on 2026-10-23 for the Cut Paper-only release. This records the performed
checks; it does not certify the quality of future generated videos.

| Check | Result |
|---|---|
| All 16 skill entry points, metadata and agent registrations | PASS |
| Relative Markdown links, JSON and Python 3.9-compatible syntax | PASS |
| Cut Paper as the sole packaged theme; three fonts and three font notices | PASS |
| Workflow, examples, prompts and sound palette free of removed-theme routes | PASS |
| Eight regression tests using temporary synthetic fixtures | PASS |
| Fresh Cut Paper scaffold, CameraRig and SmoothPaperCaptions TypeScript check | PASS |
| Chromium rendering with real loaded fonts | PASS |
| One- and two-line caption example renders and stable screen-space backing at y=1500 | PASS |
| Missing font deliberately rejected instead of silently using a fallback | PASS |
| SHA-256 file manifest, ZIP CRC and clean-extraction validation | PASS |

The eight regression checks cover existing entry/theme/font preservation;
invalid-plan diagnostics; camera direction and unrelated override warnings;
unchanged WAV/compressed voice and portable paths; explicitly silent cue lists;
mono amplitude and short music; noncanonical WAV headers; cue-only generation
without replacing a verified mix; and final mastering, complete decode and
original-source hash mismatch detection. Some checks cover multiple contracts.

Test environment: Node 24.19.0, Python 3.12, Remotion 4.0.538, TypeScript 5.9.3,
FFmpeg/ffprobe 7.1.5 and system Chromium. The upstream implementation skills keep
their original version metadata. A different Remotion version needs compatibility
checks and current API documentation.

Browser smoke checks rendered the fresh scaffold and frames 16, 32 and 40 of a
short camera/caption fixture. Rendered example stills were inspected for layout;
the one- and two-line pages share a fixed caption plate outside the moving world.
Revision 1.2.1 lowers that plate to y=1500, retaining 148px height and 272px below
it. Title/label margins remain separate. The reference film was not modified.
These checks do not constitute native-speed subjective playback or listening.
The approved Industrial Revolution film supplies the production reference; every
new film still requires its own factual, motion, subtitle and encoded-file QA.

To repeat portable checks after extraction:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
```

For browser/type checks, create a temporary Remotion project with matching
packages, run `video-director/scripts/init_video.py` against it, copy the optional
camera/caption examples into `src/`, run the project's TypeScript check and render
representative frames with its installed Chromium. Follow the skill's delivery
workflow for a full film. No dependencies, ASR weights, private narration files,
node_modules or generated video projects are packed in this release.
