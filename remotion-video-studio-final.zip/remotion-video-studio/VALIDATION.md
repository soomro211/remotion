# Release validation — 1.3.0

Performed on 2026-10-23 for the approved universal Cut Paper asset/workflow update. This records observed checks; future films still need factual, visual, motion and audio review.

| Check | Result |
|---|---|
| 16 skill entry points, metadata and registrations; Cut Paper is the only theme | PASS |
| 29 catalog entries with controls, anchors, bounds notes and PNG/SVG previews | PASS |
| TypeScript 5.9.3 and ESLint on the complete asset review project | PASS |
| 17 regression tests covering production helpers and selective installation | PASS |
| 14,412 gait samples: three leg proportions and four stride lengths | PASS |
| Bone lengths, stance planting, ground clearance, reach and loop continuity | PASS |
| Journeys at 24/30/60 fps and approximately uniform arc-length path travel | PASS |
| 71 actual-browser samples: SVG foot/floor contact, pose reach, IDs and geometry | PASS |
| Fixed lower caption backing at x80/y1500/w890/h148, actual glyph bounds and at most two lines | PASS |
| Native-speed Studio execution of Walking, Actions and Character; no browser errors | PASS |
| Relocated skills plus fresh source project: selected dependency closure compiles and renders | PASS |
| Local searchable catalog: 29 thumbnails, SVG download, selection command and preview metadata | PASS |
| Four actual encoded previews: H.264, 30 fps, exact frames/duration, fast-start, full decode | PASS |
| Source/picture hashes detect stale references after shared-component edits | PASS |
| 100 Markdown references audited for current routing and obsolete defaults | PASS |
| JSON, relative links, Python 3.9-compatible syntax, fonts/notices, ZIP integrity and clean extraction | PASS (release gate; see final packaging verification) |

The solver's largest world-space plant error is 1.14e-13 native units, largest bone-length error 7.11e-14, and unreachable target error zero in the tested gait samples. The actual actor/pose browser check also reports zero unreachable targets. Its heel/toe points were transformed through the rendered SVG to check the Actions floor at y920. These are scoped measurements, not a guarantee for arbitrary changed anatomy or staging.

Encoded preview durations are 11 seconds (walking comparison), 10 seconds (actions), 15 seconds (three scene contexts) and 6 seconds (tracking character). They are intentionally silent. Encoded walking/contact poses and representative scene frames were extracted and visually inspected. Native-speed Studio playback was executed and sampled separately; this is not a claim of uninterrupted subjective human screening or audio listening.

The fresh-source check relocated the skills into a new directory, used the production initializer/selector, compiled the chosen assets and rendered a real 1080×1920 frame. It reused the pinned local Node dependency tree; a clean network npm install is not claimed. All runtime font/material assets are local.

The nine asset-installer tests cover dependency closure, idempotent additions, atomic refusal on local edits, backup on an explicit force, unknown IDs, canonical caption/camera copying, downgrade refusal, destination symlink escape and dependency cycles/path traversal. The eight production regression tests retain checks for voice integrity, sound mixing/timing, preservation, plan diagnostics and final export handling.

Test environment: Node 24.19.0, Python 3.12, React 19.2.3, Remotion 4.0.538, TypeScript 5.9.3, FFmpeg/ffprobe 7.1.5 and system Chromium. Original upstream API metadata is retained; the complete reference audit does not claim execution of every optional advanced API. The image references are generated from the current asset source, with the earlier Industrial Revolution stills clearly separated as a historical camera study.

Repeat checks after extraction:

```bash
python3 tools/validate_bundle.py
python3 -m unittest discover -s tests -v
python3 tools/check_fresh_project.py
```

Prepare the documented preview studio's dependencies before the browser/type/rig checks. Inspect [the reference audit](REFERENCE-AUDIT.md), [fresh-project result](FRESH-PROJECT-CHECK.json), [catalog result](CATALOG-CHECK.json), and detailed JSON evidence beside the [visual catalog](skills/remotion-themes/themes/cut-paper/images/assets/catalog.html). No private user voice, ASR weights, credentials, node_modules or unrelated film projects enter the archive.
