# Asset review studio

This is an editable review harness for the reusable Cut Paper library. Its silent previews demonstrate motion/material, not a narrated channel video. Catalog/action labels identify assets; finished explainers keep the production text rules.

From this folder:

```bash
npm ci
npm run prepare:assets
npm run dev
npm run lint
npm run test:rig
npm run review -- Walking 60 66 72 78 84 90 96 102 210 240
npm run review -- Actions 30 60 90 120 180 240
npm run review -- Gallery 90
npm run review -- Showcase 90 210 390
npm run review -- Character 90
```

`prepare:assets` uses the production selection installer, selecting all assets for this harness and copying local fonts from the bundle. Generated `src/assets/` and `public/fonts/` are omitted from the ZIP because they regenerate from canonical sources. Edited generated components are protected by the same installer checks as a real project; develop library source first and prepare again. The full bundle retains its relative `skills/` and `examples/` layout.

Render with the pinned CLI:

```bash
npx remotion render src/Root.tsx Walking out/walking-comparison.mp4
npx remotion render src/Root.tsx Actions out/actions.mp4
npx remotion render src/Root.tsx Showcase out/showcase.mp4
npx remotion render src/Root.tsx Character out/character.mp4
```

The config prefers system Chromium when present. Set `REMOTION_BROWSER_EXECUTABLE` for a different browser location, or let Remotion acquire its compatible browser. Helpers require Node compatible with the pinned package and Python 3.9+. Pillow/Playwright are optional developer dependencies for regenerating the complete illustrated catalog.

After reviewing the rendered sources, regenerate thumbnails, SVG snapshots and current production frames from the bundle root:

```bash
python3 tools/build_asset_previews.py --studio-url http://localhost:3006
```

That command expects Studio running at the supplied URL and review PNGs under `out/review/`. The library and the guides explain anchors, timing and supported controls. Review starts/stops, matching floor motion, hands/items and silhouette; numerical gait tests do not certify visual feel or every possible adaptation.
