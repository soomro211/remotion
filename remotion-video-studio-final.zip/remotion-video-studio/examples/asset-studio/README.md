# Cut Paper asset studio

A standalone review harness for the reusable source, not a narrated channel film. Its catalog/cell
labels identify parts for review and are not finished-film headings. Generated `src/assets/` and
`public/fonts/` are excluded from the ZIP and prepared from canonical skill sources. Local edits
are protected; change source first, then prepare again. Reuse the full bundle's relative layout.

```bash
npm ci
npm run prepare:assets
npm run dev -- --no-open
npm run lint
npm run test:rig
npm run test:universal
npm run review -- --catalog
npm run review -- MotionLab 0 30 75 120 180 239
npm run review -- Showcase 60 180 300 420
```

Gallery/Gallery2… paginate all entries. `Character` demonstrates grounded travel; `Actions` covers
six poses; `MotionLab` tests gestures, hand close-up, pouring, pivots, actual lift and rolling; `Showcase`
uses a bakery, city street, coast and industrial yard. Render studies with `npx remotion render src/Root.tsx
<Composition> out/<name>.mp4`; use concurrency supported by the host. Run `scripts/check-browser.py`
and `scripts/check-universal-browser.py` against Studio on port 3006 for actual contact/caption/ID checks.

The complete bundle's `tools/build_asset_previews.py` builds current PNG/SVG catalog poses and primary
pictures after the corresponding stills are rendered. `tools/finalize_asset_media.py` checks/remuxes
encoded studies. `tools/check_fresh_project.py` restores saved source into relocated skills and
compiles/renders selected new/core assets without the original film. Actual review scope belongs in
[validation](../../VALIDATION.md), not a blanket PASS from this harness.

Enlarged review compositions: `GestureStudy`, `GestureDetails`, `PouringStudy`, `InteractionStudy`,
`EffectsStudy`, `Architecture1`–`Architecture4`, `Locations1`–`Locations3`, `Equipment1`–`Equipment4`.
Run `node scripts/check-gestures.mjs`, `node scripts/check-pouring.mjs`,
`node scripts/check-effects.mjs` and `python3 scripts/check-interactions.py` for the repaired/new contracts.
Review the actual pose/motion too; labels and study captions are QA content only.
