import os, shutil
"""Check actual rendered rig contacts, caption geometry, SVG IDs and native playback."""
from pathlib import Path
import json,time
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];errors=[];rows=[];caption=[]
with sync_playwright()as p:
 b=p.chromium.launch(executable_path=os.environ.get('REMOTION_BROWSER_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome'),args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000})
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:errors.append(m.text)if m.type=='error'else None)
 for comp in ['Actions','Showcase','Character']:
  page.goto('http://localhost:3006/'+comp,wait_until='domcontentloaded')
  page.wait_for_function('typeof window.remotion_setFrame==="function" && Boolean(document.querySelector("[data-paper-person], [data-caption-backing]")) && document.fonts.check("700 52px DM Sans")')
  if comp=='Showcase':page.evaluate('()=>window.qaCaption=document.querySelector("[data-caption-backing]")')
  frames=list(range(0,300,8))+[299]if comp=='Actions'else [0,8,30,60,90,118,119,120,121,180,238,239,240,241,300,358,359,360,361,420,478,479]if comp=='Showcase'else [0,15,30,45,60,75,90,120,150,170,179]
  for frame in frames:
   page.evaluate('([f,c])=>window.remotion_setFrame(f,c,0)',[frame,comp]);page.evaluate('()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');page.wait_for_timeout(45)
   r=page.evaluate('''()=>{
    const live=e=>{for(let a=e;a;a=a.parentElement){const s=getComputedStyle(a);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}return true;};
    const actors=[...document.querySelectorAll('[data-paper-person]')].filter(live),nodes=[...document.querySelectorAll('[data-ik-error]')].filter(live),roots=[...new Set(actors.map(e=>e.ownerSVGElement))],ids=roots.flatMap(r=>[...r.querySelectorAll('[id]')].map(e=>e.id));
    const feet=actors.flatMap((actor,i)=>[...actor.querySelectorAll('[data-person-foot]')].map(f=>{const p=f.ownerSVGElement.createSVGPoint(),r=f.ownerSVGElement.getBoundingClientRect(),scale=r.width/Number(f.ownerSVGElement.getAttribute('width'));return {actor:i,stance:f.dataset.stance==='true',points:[[-14,12],[29,12]].map(([x,y])=>{p.x=x;p.y=y;const q=p.matrixTransform(f.getScreenCTM());return {x:(q.x-r.x)/scale,y:(q.y-r.y)/scale};})};}));
    const e=document.querySelector('[data-caption-backing]');let cap=null;
    if(e){let root=e;while(root&&!(root.style.width==='1080px'&&root.style.height==='1920px'))root=root.parentElement;const c=root.getBoundingClientRect(),s=c.width/1080,r=e.getBoundingClientRect(),text=e.querySelector('[data-paper-caption]');let lines=0,glyph=null;if(text){const range=document.createRange();range.selectNodeContents(text);const a=range.getBoundingClientRect();lines=new Set([...range.getClientRects()].filter(r=>r.width>0).map(r=>Math.round((r.top-c.top)/s))).size;glyph={left:(a.left-c.left)/s,right:(a.right-c.left)/s,top:(a.top-c.top)/s,bottom:(a.bottom-c.top)/s};}cap={same:e===window.qaCaption,left:(r.left-c.left)/s,top:(r.top-c.top)/s,width:r.width/s,height:r.height/s,lines,glyph};}
    return {actors:actors.length,maxIK:Math.max(0,...nodes.map(e=>Number(e.dataset.ikError))),duplicateIDs:ids.length-new Set(ids).size,invalid:[...document.querySelectorAll('svg path')].filter(e=>/NaN|Infinity|undefined/.test(e.getAttribute('d')||'')).length,feet,cap};
   }''')
   assert r['maxIK']<1e-6 and not r['duplicateIDs'] and not r['invalid'],(comp,frame,r)
   if comp=='Actions':
    for foot in r['feet']:
     floor=max(q['y']for q in foot['points']);assert floor<=920.1,(frame,foot)
     if foot['stance']:assert abs(floor-920)<.1,(frame,foot)
   if comp=='Showcase':
    c=r['cap'];assert c['same']and abs(c['left']-80)<.1 and abs(c['top']-1500)<.1 and abs(c['width']-890)<.1 and abs(c['height']-148)<.1,(frame,c)
    assert c['lines']<=2,(frame,c)
    if c['glyph']:assert c['glyph']['left']>=101 and c['glyph']['right']<=949 and c['glyph']['top']>=1507 and c['glyph']['bottom']<=1641,(frame,c)
    caption.append({'frame':frame,**c})
   rows.append({'composition':comp,'frame':frame,'actors':r['actors'],'maxIK':r['maxIK'],'duplicateIDs':r['duplicateIDs'],'feet':r['feet']})
 # Native-speed Studio execution; visual assessment is recorded separately from these samples.
 playback={}
 for comp,seconds in [('Actions',10.5),('Character',6.5),('MotionLab',8.5)]:
  page.goto('http://localhost:3006/'+comp,wait_until='domcontentloaded');page.wait_for_function('typeof window.remotion_setFrame==="function" && Boolean(document.querySelector("[data-paper-person]"))');page.wait_for_timeout(250)
  page.evaluate('(c)=>window.remotion_setFrame(0,c,0)',comp)
  assert page.get_by_role('button',name='Playback rate',exact=True).inner_text()=='1x'
  page.get_by_role('button',name='Play',exact=True).click();samples=[];start=time.monotonic()
  while time.monotonic()-start<seconds:
   page.wait_for_timeout(150);samples.append(page.locator('button[aria-label="Show timeline ticks as frames"]').inner_text())
  pause=page.get_by_role('button',name='Pause',exact=True)
  if pause.count():pause.click()
  numeric=[int(n)for n in samples if n.isdigit()];assert len(set(numeric))>20,(comp,numeric)
  playback[comp]={'samples':len(samples),'max_frame':max(numeric),'unique_frames':len(set(numeric)),'rate':'1x','scope':'Browser execution and sampled DOM; no subjective audio listening.'}
 b.close()
assert not errors,errors
report={'status':'PASS','frames_checked':len(rows),'maxIK':max(r['maxIK']for r in rows),'actual_svg_floor_contact':'Actions: heel/toe points transformed to SVG world coordinates; no penetration and stance sole at y920.','caption_geometry':'x80 y1500 w890 h148; backing identity unchanged across scene cuts; measured at most two lines.','browser_errors':errors,'native_playback':playback,'frames':rows,'caption_samples':caption}
(R/'out/browser-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['frames','caption_samples']},indent=2))
