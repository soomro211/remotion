import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync,mkdirSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const temp=mkdtempSync(join(tmpdir(),'paper-poses-'));
try{
 execFileSync(resolve('node_modules/.bin/tsc'),['src/assets/cut-paper/characters/poses.ts','--outDir',temp,'--module','commonjs','--target','ES2020','--skipLibCheck','--noEmit','false']);
 const require=createRequire(import.meta.url),{sampleGestureArm,armPoints}=require(join(temp,'characters/poses.js'));
 let checked=0,maxStep=0;const shoulder={x:0,y:0};
 for(const gesture of ['wave','think','offer'])for(const near of [true,false]){
  let previous=null;
  for(let i=0;i<=1000;i++){
   const p=i/1000,pose=sampleGestureArm(gesture,p,near);if(!pose)continue;
   const {elbow,wrist}=armPoints(shoulder,pose);
   assert([elbow.x,elbow.y,wrist.x,wrist.y,pose.wristAngle].every(Number.isFinite));
   assert(Math.abs(Math.hypot(elbow.x,elbow.y)-60)<1e-7);assert(Math.abs(Math.hypot(wrist.x-elbow.x,wrist.y-elbow.y)-56)<1e-7);
   if(gesture==='wave'&&wrist.y<0)assert(wrist.x>60,'Wave wrist crossed into the face silhouette.');
   if(previous){const jump=Math.hypot(wrist.x-previous.x,wrist.y-previous.y);maxStep=Math.max(maxStep,jump);assert(jump<2.5,'Gesture wrist jumped between adjacent source phases.');}
   previous=wrist;checked++;
  }
 }
 const start=armPoints(shoulder,sampleGestureArm('wave',0)),end=armPoints(shoulder,sampleGestureArm('wave',1));assert.deepEqual(start,end);
 assert.throws(()=>sampleGestureArm('wave',NaN));
 const report={status:'PASS',pose_samples:checked,max_wrist_step_per_thousandth_phase:maxStep,scope:'Authored arm lengths, finite state, wave face clearance and phase continuity. Actual anatomy/hand silhouettes still require image and motion review.'};mkdirSync('out',{recursive:true});writeFileSync('out/gesture-check.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{rmSync(temp,{recursive:true,force:true});}
