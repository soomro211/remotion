"""Inspect authored interactions in the running Studio at actual source frames."""
from pathlib import Path
import json,shutil,math
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];rows=[];errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox']);page=b.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 for comp in ['InteractionStudy','PouringStudy','EffectsStudy']:
  page.goto('http://localhost:3006/'+comp);page.wait_for_function('typeof window.remotion_setFrame==="function"&&document.querySelector("svg")')
  for f in list(range(0,240,4))+[239]:
   page.evaluate('([f,c])=>window.remotion_setFrame(f,c,0)',[f,comp]);page.wait_for_timeout(20)
   state=page.evaluate('''()=>({ik:Math.max(0,...[...document.querySelectorAll('[data-ik-error]')].map(e=>Number(e.dataset.ikError))),invalid:[...document.querySelectorAll('svg path,svg g')].filter(e=>/NaN|Infinity/.test((e.getAttribute('d')||'')+(e.getAttribute('transform')||''))).length,particles:document.querySelectorAll('[data-particle]').length,grips:[...document.querySelectorAll('[data-paper-lift][data-attached="true"]')].flatMap(e=>{const box=e.querySelector('[data-lift-item]');return [...e.querySelectorAll('[data-person-arm]')].map(a=>{const near=a.dataset.personArm==='near';return Math.hypot(Number(a.dataset.wristX)-(near?65:80),Number(a.dataset.wristY)-(Number(box.dataset.bottom)-80));});}),volumes:[...document.querySelectorAll('[data-paper-pouring]')].map(e=>Number(e.dataset.sourceVolume)+Number(e.dataset.receivedVolume)+Number(e.dataset.flightVolume))})''')
   assert state['ik']<1e-6,(comp,f,state)
   assert not state['invalid'] and max(state['grips'],default=0)<1e-7,(comp,f,state)
   assert all(abs(v-.8)<1e-8 for v in state['volumes']),(comp,f,state)
   rows.append(dict(composition=comp,frame=f,**state))
 b.close()
assert not errors,errors
(root/'out/interactions-browser-check.json').write_text(json.dumps(dict(status='PASS',samples=rows,browser_errors=errors,scope='Actual SVG reach, grip coordinates, volume sum, finite geometry and particle counts; artistic assessment is separate.'),indent=2)+'\n')
print('PASS',len(rows),'actual frame states')
