import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
const dir = mkdtempSync(join(tmpdir(), "paper-rig-"));
try {
  execFileSync(resolve("node_modules/.bin/tsc"), [
    "src/assets/cut-paper/characters/gait.ts",
    "src/assets/cut-paper/motion/path.ts",
    "--outDir",
    dir,
    "--module",
    "commonjs",
    "--target",
    "ES2020",
    "--skipLibCheck",
    "--noEmit",
    "false",
  ]);
  const require = createRequire(import.meta.url),
    { sampleGait, sampleFoot, sampleJourney, heel, toe } = require(
      join(dir, "characters/gait.js"),
    ),
    { length, rotate } = require(join(dir, "core/math.js")),
    { preparePath, samplePath } = require(join(dir, "motion/path.js"));
  let samples = 0,
    maxPlantError = 0,
    maxLengthError = 0,
    maxReachError = 0,
    maxLoopJump = 0;
  for (const legRatio of [0.85, 1, 1.15])
    for (const stride of [120, 180, 240, 280]) {
      const anchors = new Map();
      for (let i = 0; i <= 1200; i++) {
        const distance = (i / 1200) * stride * 3,
          g = sampleGait({ distance, stride, legRatio });
        samples++;
        maxReachError = Math.max(maxReachError, g.targetError);
        assert(g.targetError < 1e-7);
        for (const [f, k, offset] of [
          [g.front, g.frontKnee, 0],
          [g.back, g.backKnee, 0.5],
        ]) {
          for (const p of [g.hip, k, f.ankle])
            assert(Number.isFinite(p.x) && Number.isFinite(p.y));
          maxLengthError = Math.max(
            maxLengthError,
            Math.abs(length(g.hip, k) - g.legLength),
            Math.abs(length(k, f.ankle) - g.legLength),
          );
          for (const p of [heel, toe]) {
            const r = rotate(p, f.angle);
            assert(f.ankle.y + r.y <= 1e-7, "A sole penetrated the floor");
          }
          if (f.stance) {
            assert(
              Math.abs(f.contact.y) < 1e-7,
              "Stance foot lost ground contact",
            );
            const cycle = Math.floor(distance / stride + offset + 1e-9),
              key = `${offset}-${cycle}`,
              worldAnchor = distance + f.flatX;
            if (anchors.has(key)) {
              const error = Math.abs(anchors.get(key) - worldAnchor);
              maxPlantError = Math.max(maxPlantError, error);
              assert(error < 1e-7, "A planted foot slid in world space");
            } else anchors.set(key, worldAnchor);
          }
        }
      }
      const a = sampleGait({ distance: stride - 1e-5, stride, legRatio }),
        b = sampleGait({ distance: stride + 1e-5, stride, legRatio });
      for (const key of ["hip", "frontKnee", "backKnee"])
        maxLoopJump = Math.max(maxLoopJump, length(a[key], b[key]));
      for (const key of ["front", "back"])
        maxLoopJump = Math.max(maxLoopJump, length(a[key].ankle, b[key].ankle));
    }
  assert(maxLengthError < 1e-6);
  assert(maxLoopJump < 0.001);
  for (const fps of [24, 30, 60])
    for (const durationSeconds of [2, 4, 8])
      for (const distance of [0, 250, 1170]) {
        const j = { startSeconds: 1, durationSeconds, distance };
        let prev = 0;
        for (let frame = 0; frame < (durationSeconds + 2) * fps; frame++) {
          const t = frame / fps,
            v = sampleJourney(t, j);
          assert(v.distance >= prev - 1e-7);
          assert(v.distance <= distance + 1e-7);
          assert(v.speed >= 0);
          prev = v.distance;
          if (t > 1 + durationSeconds + 0.28) {
            assert.equal(v.distance, distance);
            assert.equal(v.speed, 0);
            assert.equal(v.settle, 1);
          }
        }
        for (const t of [1.25, 1.5, 2])
          assert.deepEqual(
            sampleJourney(t, j),
            sampleJourney((t * fps) / fps, j),
          );
      }
  const curve = [
      { x: 0, y: 0 },
      { x: 250, y: -180 },
      { x: 260, y: 270 },
      { x: 600, y: 40 },
    ],
    path = preparePath(curve),
    steps = Array.from({ length: 81 }, (_, i) => samplePath(path, i / 80));
  const lengths = steps.slice(1).map((p, i) => length(p, steps[i]));
  assert(
    Math.max(...lengths) / Math.min(...lengths) < 1.02,
    "Path speed varies visibly",
  );
  const stopped = sampleFoot(270, 240, 0, 1);
  assert.equal(stopped.lift, 0);
  assert.equal(Math.abs(stopped.angle), 0);
  const report = {
    status: "PASS",
    gait_samples: samples,
    proportions: [0.85, 1, 1.15],
    strides: [120, 180, 240, 280],
    max_world_plant_error: maxPlantError,
    max_bone_length_error: maxLengthError,
    max_unreachable_target_error: maxReachError,
    max_loop_position_jump: maxLoopJump,
    journey_frame_rates: [24, 30, 60],
    path_max_min_step_ratio: Math.max(...lengths) / Math.min(...lengths),
  };
  mkdirSync("out", { recursive: true });
  writeFileSync("out/rig-check.json", JSON.stringify(report, null, 2) + "\n");
  process.stdout.write(JSON.stringify(report, null, 2) + "\n");
} finally {
  rmSync(dir, { recursive: true, force: true });
}
