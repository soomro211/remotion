import os, shutil
"""Sample every catalog state and actual motion/contact in Studio."""
from pathlib import Path
import json, math
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
catalog = json.loads((ROOT/'src/assets/cut-paper/catalog-preview.json').read_text())
rows=[]; errors=[]; bounds=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('REMOTION_BROWSER_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1600,'height':1000})
 page.on('pageerror',lambda error:errors.append(str(error)))
 for index in range(math.ceil(len(catalog)/30)):
  comp='Gallery' if index==0 else 'Gallery'+str(index+1)
  page.goto('http://localhost:3006/'+comp,wait_until='domcontentloaded')
  page.wait_for_function('(key)=>typeof window.remotion_setFrame==="function"&&Boolean(document.querySelector(`[data-catalog-entry="${key}"]`))',arg=catalog[index*30]['id'])
  for frame in [0,90,210,299]:
   page.evaluate('([f,c])=>window.remotion_setFrame(f,c,0)',[frame,comp]);page.wait_for_timeout(80)
   result=page.evaluate('''()=>{const ids=[...document.querySelectorAll('svg [id]')].map(e=>e.id);return {duplicates:ids.length-new Set(ids).size,invalid:[...document.querySelectorAll('svg path,svg g')].filter(e=>/NaN|Infinity|undefined/.test((e.getAttribute('d')||'')+(e.getAttribute('transform')||''))).length,actors:[...document.querySelectorAll('[data-ik-error]')].map(e=>Number(e.dataset.ikError)),boxes:[...document.querySelectorAll('[data-catalog-entry]')].map(e=>{const b=e.querySelector('g').getBBox();return {id:e.dataset.catalogEntry,x:b.x,y:b.y,width:b.width,height:b.height};})};}''')
   assert not result['duplicates'] and not result['invalid'] and max(result['actors'],default=0)<1e-6,(comp,frame,result)
   for box in result['boxes']:
    assert box['width']>0 and box['height']>0,(frame,box)
    if box['x'] < -302 or box['x']+box['width']>302 or box['y'] < -171 or box['y']+box['height']>177:
     bounds.append({'frame':frame,**box})
   rows.append({'composition':comp,'frame':frame,'assets':len(result['boxes'])})
 page.goto('http://localhost:3006/MotionLab',wait_until='domcontentloaded')
 page.wait_for_function('typeof window.remotion_setFrame==="function"&&Boolean(document.querySelector("[data-motion-cell]"))')
 motion=[]
 for frame in list(range(0,240,8))+[239]:
  page.evaluate('(f)=>window.remotion_setFrame(f,"MotionLab",0)',frame);page.wait_for_timeout(50)
  result=page.evaluate('''()=>{const svg=document.querySelector('[data-motion-cell]').ownerSVGElement,inv=svg.getCTM().inverse(),world=e=>inv.multiply(e.getCTM()),point=(m,x,y)=>({x:m.a*x+m.c*y+m.e,y:m.b*x+m.d*y+m.f});const ids=[...svg.querySelectorAll('[id]')].map(e=>e.id);return {duplicateIDs:ids.length-new Set(ids).size,maxIK:Math.max(0,...[...svg.querySelectorAll('[data-ik-error]')].map(e=>Number(e.dataset.ikError))),wheels:[...svg.querySelectorAll('[data-vehicle-wheel]')].map(e=>{const m=world(e),r=Number(e.dataset.radius),local=e.transform.baseVal.consolidate().matrix;return {floor:m.f+Math.hypot(m.c,m.d)*r,radius:r,distance:Number(e.dataset.distance),angle:Math.atan2(local.b,local.a)*180/Math.PI};}),feet:[...svg.querySelectorAll('[data-person-foot]')].map(e=>{const m=world(e);return {stance:e.dataset.stance==='true',floor:Math.max(point(m,-14,12).y,point(m,29,12).y)};}),invalid:[...svg.querySelectorAll('path,g')].filter(e=>/NaN|Infinity|undefined/.test((e.getAttribute('d')||'')+(e.getAttribute('transform')||''))).length};}''')
  assert not result['duplicateIDs'] and not result['invalid'] and result['maxIK']<1e-6,(frame,result)
  for wheel in result['wheels']:
   assert abs(wheel['floor']-1000)<.1,(frame,wheel)
   expected=wheel['distance']/wheel['radius']*180/math.pi
   delta=(wheel['angle']-expected+180)%360-180
   # SVGTransformList stores browser float matrices; 0.0001 degree is below
   # a thousandth of a pixel at these radii, unlike unrelated wheel timing.
   assert abs(delta)<1e-4,(frame,wheel)
  for foot in result['feet']:
   assert foot['floor']<=460.1,(frame,foot)
   if foot['stance']:assert abs(foot['floor']-460)<.1,(frame,foot)
  motion.append({'frame':frame,'maxIK':result['maxIK'],'wheels':len(result['wheels']),'feet':len(result['feet'])})
 browser.close()
assert not errors,errors
report={'status':'PASS' if not bounds else 'REVIEW','catalog_entries':len(catalog),'catalog_state_instances':sum(r['assets']for r in rows),'catalog_samples':rows,'motion_samples':motion,'potential_preview_clipping':bounds,'browser_errors':errors,'scope':'Actual SVG finite geometry, unique IDs, pose reach, foot/floor and wheel contact/rotation. Artistic review is separate.'}
(ROOT/'out/universal-browser-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['catalog_samples','motion_samples']},indent=2))
