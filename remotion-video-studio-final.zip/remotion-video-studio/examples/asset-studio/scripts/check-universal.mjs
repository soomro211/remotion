import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync,writeFileSync,mkdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const dir=mkdtempSync(join(tmpdir(),'paper-universal-'));
try{
 execFileSync(resolve('node_modules/.bin/tsc'),['src/assets/cut-paper/motion/choreography.ts','src/assets/cut-paper/characters/gait.ts','--outDir',dir,'--module','commonjs','--target','ES2020','--skipLibCheck','--noEmit','false']);
 const require=createRequire(import.meta.url),M=require(join(dir,'core/math.js')),A=require(join(dir,'motion/choreography.js')),P=require(join(dir,'motion/path.js')),G=require(join(dir,'characters/gait.js'));
 assert.equal(P.mixAngle(730,0,1),720);assert.equal(P.mixAngle(-730,0,1),-720);assert.equal(P.mixAngle(350,10,.5),360);assert.throws(()=>P.mixAngle(NaN,0,.5));
 for(const size of [1e-7,1,60,250]){const s=M.solveLimb({x:0,y:0},{x:0,y:0},size,size);assert(Math.abs(M.length({x:0,y:0},s.joint)-size)<Math.max(size*1e-6,1e-9));assert.equal(s.targetError,0);}
 assert.equal(M.solveLimb({x:0,y:0},{x:0,y:0},6,4).targetError,2);assert.throws(()=>M.solveLimb({x:0,y:0},{x:1,y:0},0,5));
 const timing={startSeconds:1,durationSeconds:4},from={x:12,y:90},to={x:320,y:140};
 assert.equal(A.sampleTween(-1,timing,10,20),10);assert.equal(A.sampleTween(8,timing,10,20),20);
 assert.deepEqual(A.sampleArc(0,timing,from,to,100),{...from,progress:0});assert.deepEqual(A.sampleArc(9,timing,from,to,100),{...to,progress:1});
 assert.equal(A.samplePulse(0,timing),1);assert.equal(A.samplePulse(9,timing),1);assert.equal(A.sampleStagger(0,timing,4),0);assert.equal(A.sampleStagger(20,timing,4),1);
 let samples=0,maxVolumeError=0;
 for(const fps of [24,30,60])for(let f=0;f<fps*8;f++){
  const time=f/fps,pour=A.samplePour(time,timing,1.3,.8),arc=A.sampleArc(time,timing,from,to,100),handoff=A.sampleHandoff(time,timing,from,to);
  maxVolumeError=Math.max(maxVolumeError,Math.abs(pour.sourceVolume+pour.receivedVolume-1.3));assert(maxVolumeError<1e-12);assert(pour.sourceVolume>=.5-1e-10&&pour.receivedVolume>=0&&pour.stream>=0&&pour.stream<=1);
  assert(Object.values(arc).every(Number.isFinite));assert(handoff.giverGrip>=0&&handoff.giverGrip<=1&&handoff.receiverGrip>=0&&handoff.receiverGrip<=1);
  if(time>=5){assert.equal(pour.stream,0);assert.equal(pour.angle,0);assert.equal(handoff.owner,'receiver');}
  assert.deepEqual(A.sampleArc((time*fps)/fps,timing,from,to,100),arc);samples++;
 }
 const keys=[{seconds:0,centerX:540,centerY:960,zoom:1},{seconds:3,centerX:800,centerY:900,zoom:1.3},{seconds:6,centerX:1000,centerY:1000,zoom:1.1}];
 assert.deepEqual(A.sampleCameraPath(-1,keys),keys[0]);assert.deepEqual(A.sampleCameraPath(8,keys),keys[2]);assert.throws(()=>A.sampleCameraPath(1,[keys[1],keys[0]]));
 assert.throws(()=>A.progressAt(2,{startSeconds:0,durationSeconds:Infinity}));assert.throws(()=>A.sampleArc(1,timing,{x:NaN,y:0},to));assert.throws(()=>A.samplePulse(2,timing,2,1.5));assert.throws(()=>G.sampleJourney(1,{startSeconds:0,durationSeconds:Infinity,distance:50}));
 const report={status:'PASS',samples,frame_rates:[24,30,60],max_volume_conservation_error:maxVolumeError,contracts:['shortest-angle wrapping including multiple turns','coincident/inner-unreachable limb targets','exact arc/tween/rest endpoints','finite motion inputs','pour conservation and end of stream','shared handoff ownership/grips','ordered camera keys','source-time invariance']};
 mkdirSync('out',{recursive:true});writeFileSync('out/universal-check.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{rmSync(dir,{recursive:true,force:true});}
