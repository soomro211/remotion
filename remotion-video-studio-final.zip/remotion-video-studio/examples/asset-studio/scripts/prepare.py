"""Prepare the gallery with exactly the installer used by a fresh video project."""
from pathlib import Path
import shutil,subprocess,sys
PROJECT=Path(__file__).resolve().parents[1]
ROOT=PROJECT.parents[1]
subprocess.run([sys.executable,str(ROOT/'skills/remotion-themes/scripts/assets.py'),'copy',str(PROJECT),'--assets','all'],check=True)
fonts=ROOT/'skills/remotion-themes/themes/_shared/fonts';target=PROJECT/'public/fonts';target.mkdir(parents=True,exist_ok=True)
for source in fonts.iterdir():
    if source.is_file() and not (target/source.name).exists():shutil.copy2(source,target/source.name)

import json
assets=json.loads((ROOT/'skills/remotion-themes/themes/cut-paper/assets/catalog.json').read_text())['assets']
(PROJECT/'src/assets/cut-paper/catalog-preview.json').write_text(json.dumps([{'id':a['id']}for a in assets]))
