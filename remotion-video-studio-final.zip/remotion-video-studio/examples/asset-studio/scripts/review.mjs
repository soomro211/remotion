import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderStill,
} from "@remotion/renderer";
import { resolve } from "node:path";
import { mkdirSync, existsSync } from "node:fs";
const executable =
  process.env.REMOTION_BROWSER_EXECUTABLE ??
  (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined);
const id = process.argv[2] || "Walking",
  frames = (
    process.argv.slice(3).length
      ? process.argv.slice(3)
      : ["30", "60", "90", "120", "180", "240", "285", "320"]
  ).map(Number);
const dir = resolve("out/review", id);
mkdirSync(dir, { recursive: true });
const serveUrl = await bundle({
  entryPoint: resolve("src/Root.tsx"),
  onProgress: () => {},
});
const browser = await openBrowser("chrome", { browserExecutable: executable });
const composition = await selectComposition({
  serveUrl,
  id,
  puppeteerInstance: browser,
  browserExecutable: executable,
});
for (const frame of frames) {
  await renderStill({
    serveUrl,
    composition,
    frame,
    output: resolve(dir, `${frame}.png`),
    imageFormat: "png",
    puppeteerInstance: browser,
    browserExecutable: executable,
    logLevel: "error",
  });
  process.stdout.write(`${id}: ${frame}\n`);
}
await browser.close({ silent: true });
