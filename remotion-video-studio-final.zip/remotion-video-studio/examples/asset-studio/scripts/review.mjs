import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderStill,
  getCompositions,
} from "@remotion/renderer";
import { resolve } from "node:path";
import { mkdirSync, existsSync } from "node:fs";
const executable =
  process.env.REMOTION_BROWSER_EXECUTABLE ??
  (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined);
const id = process.argv[2] || "Walking",
  frames = (
    process.argv.slice(3).length
      ? process.argv.slice(3)
      : ["30", "60", "90", "120", "180", "240", "285", "320"]
  ).map(Number);
const dir = resolve("out/review", id);
mkdirSync(dir, { recursive: true });
const serveUrl = await bundle({
  entryPoint: resolve("src/Root.tsx"),
  onProgress: () => {},
});
const browser = await openBrowser("chrome", { browserExecutable: executable });
const ids = id === "--catalog" ? (await getCompositions(serveUrl,{puppeteerInstance:browser})).filter(c=>c.id.startsWith("Gallery")).map(c=>c.id) : [id];
for(const selectedId of ids){
const selectedDir=resolve("out/review",selectedId);mkdirSync(selectedDir,{recursive:true});
const composition = await selectComposition({
  serveUrl,
  id:selectedId,
  puppeteerInstance: browser,
  browserExecutable: executable,
});
for (const frame of id === "--catalog" ? [90] : frames) {
  await renderStill({
    serveUrl,
    composition,
    frame,
    output: resolve(selectedDir, `${frame}.png`),
    imageFormat: "png",
    puppeteerInstance: browser,
    browserExecutable: executable,
    logLevel: "error",
  });
    process.stdout.write(`${selectedId}: ${frame}\n`);
}
}
await browser.close({ silent: true });
