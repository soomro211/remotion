import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import { smooth } from "./assets/cut-paper/core/math";
import { useFonts } from "./fonts";
export const Actions: React.FC = () => {
  useFonts();
  const t = useCurrentFrame() / useVideoConfig().fps,
    travel = A.sampleJourney(t, {
      startSeconds: 2,
      durationSeconds: 2,
      distance: 170,
    }),
    sit = t < 5 ? smooth((t - 1) / 2) : smooth((t - 5) / 2);
  const actions = [
    "Idle",
    "Point",
    "Reach",
    "Carry",
    "Sit / stand",
    "Left-facing",
  ];
  return (
    <AbsoluteFill style={{ background: "#EEE4CE" }}>
      <A.PaperStage width={1920} height={1080}>
        <A.PaperRect width={1920} height={1080} fill="#EEE4CE" shadow={false} />
        <A.PaperGround
          x={0}
          y={920}
          width={1920}
          height={160}
          rise={0}
          fill="#B6AA8A"
        />
        {actions.map((name, i) => (
          <g key={name}>
            <text
              x={160 + i * 320}
              y={320}
              textAnchor="middle"
              fill={A.palette.ink}
              fontFamily="DM Sans"
              fontSize="31"
              fontWeight="700"
            >
              {name}
            </text>
          </g>
        ))}
        <A.PaperPerson x={150} y={920} height={330} time={t} />
        <A.PaperPerson
          x={470}
          y={920}
          height={340}
          action="point"
          progress={smooth((t - 0.6) / 1)}
          look={A.personLooks.coral}
          time={t}
        />
        <A.PaperPerson
          x={790}
          y={920}
          height={320}
          action="reach"
          progress={smooth((t - 0.6) / 1)}
          look={A.personLooks.ochre}
          time={t}
        />
        <A.PaperPerson
          x={1030}
          y={920}
          height={330}
          action="carry"
          stride={180}
          travel={travel}
          look={{ ...A.personLooks.teal, coat: true }}
          time={t}
          item={<A.PaperBox width={70} height={60} />}
        />
        <A.PaperFurniture x={1410} y={920} scale={0.825} />
        <A.PaperPerson
          x={1410}
          y={920}
          height={330}
          action={t < 5 ? "sit" : "stand"}
          progress={sit}
          look={{ ...A.personLooks.coral, build: 1.15 }}
          time={t}
        />
        <A.PaperPerson
          x={1820}
          y={920}
          height={330}
          stride={180}
          travel={travel}
          facing="left"
          look={A.personLooks.ochre}
          time={t}
        />
      </A.PaperStage>
    </AbsoluteFill>
  );
};
