import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";
export const ArchitectureStudy: React.FC<{ page?: number }> = ({
  page = 0,
}) => {
  useFonts();
  const time = useCurrentFrame() / useVideoConfig().fps,
    q = A.sampleTween(time, { startSeconds: 0.4, durationSeconds: 5 });
  const buildings = [
    A.PaperFactory,
    A.PaperBakery,
    A.PaperBank,
    A.PaperWarehouse,
    A.PaperPharmacy,
    A.PaperCafe,
    A.PaperGrocery,
    A.PaperWorkshop,
    A.PaperApartments,
    A.PaperOffice,
    A.PaperStation,
    A.PaperFireStation,
    A.PaperLibrary,
    A.PaperHospitalBuilding,
    A.PaperShopBuilding,
    A.PaperSchoolBuilding,
  ];
  return (
    <AbsoluteFill style={{ background: "#E3DBC5" }}>
      <A.PaperStage width={1920} height={1080}>
        {buildings.slice(page * 4, page * 4 + 4).map((B, i) => (
          <g
            key={i}
            transform={`translate(${(i % 2) * 960} ${Math.floor(i / 2) * 540})`}
          >
            <B
              x={480}
              y={510}
              scale={1.03}
              open={q * 0.9}
              light={page === 2 ? 1 : 0}
            />
          </g>
        ))}
      </A.PaperStage>
    </AbsoluteFill>
  );
};
