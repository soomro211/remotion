import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";
export const Character: React.FC = () => {
  useFonts();
  const time = useCurrentFrame() / useVideoConfig().fps,
    travel = A.sampleJourney(time, {
      startSeconds: 0.4,
      durationSeconds: 5,
      distance: 1100,
    });
  return (
    <AbsoluteFill style={{ background: "#E5D8BD" }}>
      <A.PaperStage width={1080} height={1920}>
        <A.PaperRect width={1080} height={1920} fill="#E5D8BD" shadow={false} />
        <g transform={`translate(${-travel.distance} 0)`}>
          <A.PaperGround
            x={-400}
            y={1190}
            width={4000}
            height={1200}
            rise={65}
            fill="#A7B99A"
          />
          <A.PaperTree x={80} y={1410} height={480} time={time} />
          <A.PaperTree x={1050} y={1435} height={580} time={time} kind="pine" />
          <A.PaperTree x={1850} y={1435} height={520} time={time} />
          <A.PaperGround
            x={-400}
            y={1430}
            width={4000}
            height={1200}
            rise={0}
            fill="#C6AD86"
          />
          {Array.from({ length: 26 }, (_, i) => {
            const x = i * 135 - 270;
            return (
              <path
                key={i}
                d={`M${x} 1450l47-1M${x + 52} 1473h28`}
                stroke="#E5D2AC"
                strokeWidth="3"
              />
            );
          })}
          <A.PaperPerson
            x={510}
            y={1430}
            height={690}
            time={time}
            travel={travel}
            look={A.personLooks.coral}
          />
        </g>
      </A.PaperStage>
      <A.SmoothPaperCaptions
        pages={[
          {
            text: "Steps follow distance. Feet meet the ground.",
            startMs: 100,
            endMs: 5700,
            timestampMs: 0,
            confidence: null,
          },
        ]}
      />
    </AbsoluteFill>
  );
};
