import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
export const EffectsStudy: React.FC = () => {
  const time = useCurrentFrame() / useVideoConfig().fps;
  return (
    <AbsoluteFill style={{ background: "#507674" }}>
      <A.PaperStage width={1920} height={1080}>
        {[A.Steam, A.Smoke, A.Dust, A.Rain, A.Snow, A.Splash].map((E, i) => (
          <g
            key={i}
            transform={`translate(${(i % 3) * 640} ${Math.floor(i / 3) * 540})`}
          >
            <A.PaperRect
              x={10}
              y={10}
              width={620}
              height={520}
              fill={i === 0 || i === 4 ? "#527776" : "#CBBF9F"}
              shadow={false}
            />
            <E
              x={i === 3 || i === 4 ? 35 : 320}
              y={i === 3 || i === 4 ? 35 : 450}
              width={570}
              height={i === 3 || i === 4 ? 450 : 350}
              time={time}
              startSeconds={0.3}
              durationSeconds={5}
            />
          </g>
        ))}
      </A.PaperStage>
    </AbsoluteFill>
  );
};
