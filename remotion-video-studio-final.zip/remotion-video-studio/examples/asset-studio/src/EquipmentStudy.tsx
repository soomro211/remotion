import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
export const EquipmentStudy: React.FC<{ page?: number }> = ({ page = 0 }) => {
  const time = useCurrentFrame() / useVideoConfig().fps,
    q = A.sampleTween(time, { startSeconds: 0.3, durationSeconds: 5.7 });
  const objects = [
    A.PaperOven,
    A.PaperConveyor,
    A.PaperPallet,
    A.PaperForklift,
    A.PaperHandcart,
    A.PaperCashRegister,
    A.PaperMedicalBed,
    A.PaperMedicalCart,
    A.PaperStreetlamp,
    A.PaperMailbox,
    A.PaperBusStop,
    A.PaperTrashBin,
    A.PaperBench,
    A.PaperBooks,
    A.PaperWrench,
    A.PaperBucket,
  ];
  return (
    <AbsoluteFill style={{ background: "#E5DCC4" }}>
      <A.PaperStage width={1920} height={1080}>
        {objects.slice(page * 4, page * 4 + 4).map((O, i) => (
          <g
            key={i}
            transform={`translate(${(i % 2) * 960} ${Math.floor(i / 2) * 540})`}
          >
            <O x={480} y={495} scale={1.8} progress={q} level={0.8} />
          </g>
        ))}
      </A.PaperStage>
    </AbsoluteFill>
  );
};
