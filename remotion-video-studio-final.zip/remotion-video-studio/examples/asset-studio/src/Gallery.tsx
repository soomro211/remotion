import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import catalog from "./assets/cut-paper/catalog-preview.json";
import { useFonts } from "./fonts";
const curve: A.Cubic = [
  { x: -180, y: 30 },
  { x: -50, y: -150 },
  { x: 60, y: 170 },
  { x: 185, y: -20 },
];
export const Preview: React.FC<{ id: string; t: number }> = ({ id, t }) => {
  const journey = A.sampleJourney(t, {
    startSeconds: 0.3,
    durationSeconds: 6,
    distance: 800,
  });
  switch (id) {
    case "material":
      return (
        <>
          <A.PaperShape d="M-162-90L112-104L151 91L-153 110Z" fill="#CD9863" />
          <A.PaperDisc x={-30} y={-4} radius={78} fill={A.palette.teal} />
          <A.PaperRect x={40} y={10} width={130} height={88} />
        </>
      );
    case "person":
      return (
        <A.PaperPerson
          x={-journey.distance}
          y={137}
          height={275}
          time={t}
          travel={journey}
        />
      );
    case "hand":
      return (
        <>
          <A.PaperHand x={-105} y={0} scale={2.6} pose="open" />
          <A.PaperHand x={35} y={12} scale={2.7} pose="point" />
          <A.PaperHand x={138} y={8} scale={2.5} pose="grip" />
        </>
      );
    case "journey":
      return (
        <>
          <A.PaperPerson
            x={-125 - journey.distance}
            y={134}
            height={240}
            travel={journey}
            time={t}
          />
          <A.PaperPerson
            x={125 + journey.distance}
            y={134}
            height={240}
            travel={journey}
            time={t}
            facing="left"
            look={A.personLooks.coral}
          />
        </>
      );
    case "ground":
      return (
        <>
          <A.PaperGround
            x={-220}
            y={-50}
            width={440}
            height={190}
            fill="#A2B58C"
            rise={60}
          />
          <A.PaperGround x={-220} y={50} width={440} height={100} rise={40} />
        </>
      );
    case "path":
      return (
        <>
          <A.PaperGround x={-220} y={-100} width={440} height={250} />
          <A.PaperPath x={-220} y={-60} width={440} height={180} />
        </>
      );
    case "cloud":
      return (
        <>
          <A.PaperCloud x={-80} y={10} time={t} />
          <A.PaperCloud x={108} y={65} scale={0.68} time={t} />
        </>
      );
    case "tree":
      return (
        <>
          <A.PaperTree x={-125} y={135} height={250} time={t} />
          <A.PaperTree x={55} y={135} height={240} kind="pine" time={t} />
          <A.PaperTree x={170} y={135} height={190} kind="bare" />
        </>
      );
    case "water":
      return (
        <A.PaperWater x={-220} y={-100} width={440} height={230} time={t} />
      );
    case "building":
      return (
        <>
          <A.PaperBuilding x={-90} y={138} width={175} height={240} />
          <A.PaperBuilding
            x={110}
            y={138}
            width={170}
            height={195}
            roof="pitched"
            fill="#C28B69"
            rows={3}
          />
        </>
      );
    case "room":
      return (
        <g transform="translate(-220 -120)">
          <A.PaperRoom width={440} height={270} floorY={190} />
          <A.PaperFurniture x={270} y={248} scale={0.5} kind="table" />
          <A.PaperFurniture x={105} y={248} scale={0.55} />
        </g>
      );
    case "sun":
      return <A.PaperSun radius={100} />;
    case "box":
      return (
        <>
          <A.PaperBox x={-145} y={-60} width={150} height={145} />
          <A.PaperBox x={45} y={-20} width={110} height={100} open={0.7} />
        </>
      );
    case "container":
      return (
        <>
          <A.PaperContainer
            x={-170}
            y={-85}
            width={88}
            height={170}
            level={0.7}
          />
          <A.PaperContainer
            x={-30}
            y={-110}
            kind="bottle"
            width={65}
            height={195}
            level={0.5}
          />
          <A.PaperContainer
            x={90}
            y={-60}
            kind="bucket"
            width={105}
            height={145}
          />
        </>
      );
    case "document":
      return (
        <>
          <A.PaperDocument
            x={-130}
            y={-85}
            width={120}
            height={170}
            kind="book"
          />
          <A.PaperDocument x={40} y={-65} width={115} height={150} />
        </>
      );
    case "tokens":
      return (
        <>
          <A.PaperTokens x={-100} y={65} count={3} radius={49} />
          <A.PaperTokens x={80} y={65} count={8} radius={49} fill="#84A89C" />
        </>
      );
    case "furniture":
      return (
        <>
          <A.PaperFurniture x={-148} y={100} scale={0.7} />
          <A.PaperFurniture x={60} y={100} scale={0.8} kind="table" />
        </>
      );
    case "device":
      return (
        <>
          <A.PaperDevice x={-187} y={-68} kind="phone" width={65} />
          <A.PaperDevice x={-68} y={-68} kind="laptop" width={150} />
          <A.PaperDevice x={110} y={-68} kind="monitor" width={130} />
        </>
      );
    case "arrow":
      return <A.PaperArrow curve={curve} width={12} progress={1} />;
    case "flow":
      return <A.PaperFlow curve={curve} time={t} radius={13} count={8} />;
    case "connector":
      return (
        <>
          <A.PaperConnector curve={curve} width={8} />
          <A.PaperDisc x={-180} y={30} radius={23} fill="#C98B65" />
          <A.PaperDisc x={185} y={-20} radius={23} fill="#6E9B91" />
        </>
      );
    case "wheel":
      return <A.PaperWheel radius={107} angle={A.wheelAngle(t * 80, 107)} />;
    case "gear":
      return (
        <>
          <A.PaperGear x={-80} radius={75} angle={t * 30} />
          <A.PaperGear
            x={90}
            radius={95}
            teeth={15}
            angle={A.gearAngle(t * 30, 75, 95)}
          />
        </>
      );
    case "highlight":
      return (
        <>
          <A.PaperDocument x={-50} y={-70} width={100} height={140} />
          <A.PaperHighlight radius={110} />
        </>
      );
    case "motion-path":
      return (
        <>
          <A.PaperConnector curve={curve} dashed />
          {(() => {
            const p = A.samplePath(A.preparePath(curve), Math.min(1, t / 4));
            return (
              <g transform={`translate(${p.x} ${p.y}) rotate(${p.angle})`}>
                <A.PaperBox x={-22} y={-22} width={44} height={44} />
              </g>
            );
          })()}
        </>
      );
    case "camera":
      return (
        <>
          <A.PaperRect
            x={-180}
            y={-100}
            width={360}
            height={220}
            fill="#C6C3A4"
          />
          <g transform={`translate(${Math.sin(t * 0.5) * 16} 0) scale(1.12)`}>
            <A.PaperTree x={-75} y={100} height={180} />
            <A.PaperBuilding x={75} y={100} width={125} height={170} />
          </g>
          <rect
            x={-130}
            y={-75}
            width={260}
            height={160}
            fill="none"
            stroke={A.palette.ink}
            strokeWidth="3"
            strokeDasharray="12 9"
          />
        </>
      );
    case "reveal":
      return (
        <A.ObjectReveal
          x={-120}
          y={-100}
          width={240}
          height={220}
          progress={Math.min(1, t / 2)}
        >
          <A.PaperBuilding y={120} width={210} height={205} />
        </A.ObjectReveal>
      );
    case "follower":
      return (
        <>
          <A.PaperConnector curve={curve} dashed />
          <A.PathFollower
            path={A.preparePath(curve)}
            progress={Math.min(1, t / 4)}
            orient
          >
            <A.PaperDocument x={-30} y={-32} width={60} height={64} />
          </A.PathFollower>
        </>
      );
    case "captions":
      return (
        <foreignObject x={-220} y={-110} width={440} height={250}>
          <div
            style={{ position: "relative", height: 250, background: "#324A58" }}
          >
            <A.SmoothPaperCaptions
              pages={[
                {
                  text: "Smooth words on a steady paper strip.",
                  startMs: 0,
                  endMs: 30000,
                  timestampMs: 0,
                  confidence: null,
                },
              ]}
              x={15}
              y={130}
              width={410}
              height={90}
              fontSize={27}
            />
          </div>
        </foreignObject>
      );
    default:
      return null;
  }
};
export const Gallery: React.FC = () => {
  useFonts();
  const t = useCurrentFrame() / useVideoConfig().fps;
  return (
    <AbsoluteFill style={{ background: "#F2E9D4" }}>
      <A.PaperStage width={3840} height={2160}>
        <A.PaperRect width={3840} height={2160} fill="#F2E9D4" shadow={false} />
        {catalog.map((asset, i) => {
          const x = (i % 6) * 640,
            y = Math.floor(i / 6) * 432;
          return (
            <g
              key={asset.id}
              data-catalog-entry={asset.id}
              transform={`translate(${x} ${y})`}
            >
              <path
                d="M24 412H616M624 20V400"
                stroke="#D9CCB0"
                strokeWidth="2"
              />
              <text
                x="40"
                y="53"
                fontFamily="DM Sans"
                fontWeight="700"
                fontSize="28"
                fill={A.palette.ink}
              >
                {asset.id}
              </text>
              <g transform="translate(320 240)">
                <Preview id={asset.id} t={t} />
              </g>
            </g>
          );
        })}
      </A.PaperStage>
    </AbsoluteFill>
  );
};
