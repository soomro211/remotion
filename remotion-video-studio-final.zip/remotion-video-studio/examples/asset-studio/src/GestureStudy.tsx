import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";

export const GestureStudy: React.FC<{ detail?: boolean }> = ({
  detail = false,
}) => {
  useFonts();
  const time = useCurrentFrame() / useVideoConfig().fps;
  const phase = A.progressAt(time, { startSeconds: 0.5, durationSeconds: 6.5 });
  return (
    <AbsoluteFill style={{ background: "#E7DECA" }}>
      <A.PaperStage width={1920} height={1080}>
        <A.PaperRect width={1920} height={1080} fill="#E7DECA" shadow={false} />
        <path d="M70 995H1840" stroke="#A6A58C" strokeWidth={3} />
        {detail ? (
          (["think", "offer", "point", "reach"] as const).map(
            (action, index) => (
              <g key={action}>
                <A.PaperPerson
                  x={180 + index * 460}
                  y={995}
                  height={720}
                  action={action}
                  progress={phase}
                  time={time}
                  look={index % 2 ? A.personLooks.coral : A.personLooks.teal}
                />
                <text
                  x={100 + index * 460}
                  y={170}
                  fontFamily="DM Sans"
                  fontSize={28}
                  fill={A.palette.ink}
                >
                  {action}
                </text>
              </g>
            ),
          )
        ) : (
          <>
            <A.PaperPerson
              x={410}
              y={995}
              height={820}
              action="wave"
              progress={phase}
              time={time}
            />
            <A.PaperPerson
              x={1250}
              y={995}
              height={820}
              action="wave"
              progress={phase}
              time={time}
              facing="left"
              look={A.personLooks.coral}
            />
            <A.PaperPerson
              x={1730}
              y={995}
              height={600}
              action="nod"
              progress={phase}
              time={time}
              facing="left"
              look={A.personLooks.ochre}
            />
          </>
        )}
        <text
          x={70}
          y={66}
          fontFamily="DM Sans"
          fontSize={32}
          fontWeight={700}
          fill={A.palette.ink}
        >
          Gesture study · prepare, greet, return
        </text>
      </A.PaperStage>
    </AbsoluteFill>
  );
};
