import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
export const InteractionStudy: React.FC = () => {
  const time = useCurrentFrame() / useVideoConfig().fps;
  return (
    <AbsoluteFill style={{ background: "#E5DCC4" }}>
      <A.PaperStage width={1920} height={1080}>
        {[A.PaperLift, A.PaperPlace, A.PaperPush, A.PaperPull].map((C, i) => (
          <g
            key={i}
            transform={`translate(${(i % 2) * 960} ${Math.floor(i / 2) * 540})`}
          >
            <path d="M0 500H960" stroke="#A4A48A" strokeWidth={3} />
            <C
              x={i === 3 ? 510 : 300}
              y={500}
              height={430}
              time={time}
              startSeconds={0.3}
              durationSeconds={6.3}
            />
          </g>
        ))}
      </A.PaperStage>
    </AbsoluteFill>
  );
};
