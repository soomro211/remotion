import React from "react";
import { AbsoluteFill } from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";
export const LocationStudy: React.FC<{ page?: number }> = ({ page = 0 }) => {
  useFonts();
  const worlds = [
    A.CityStreet,
    A.OldTown,
    A.IndustrialYard,
    A.BakeryInterior,
    A.ShopInterior,
    A.HospitalCorridor,
    A.StationPlatform,
    A.Harbor,
    A.RockyCoast,
    A.Desert,
    A.DryCanyon,
    A.WinterValley,
  ];
  return (
    <AbsoluteFill>
      <A.PaperStage width={1920} height={1200}>
        {worlds.slice(page * 4, page * 4 + 4).map((W, i) => (
          <W
            key={i}
            x={(i % 2) * 960}
            y={Math.floor(i / 2) * 600}
            scale={0.6}
          />
        ))}
      </A.PaperStage>
    </AbsoluteFill>
  );
};
