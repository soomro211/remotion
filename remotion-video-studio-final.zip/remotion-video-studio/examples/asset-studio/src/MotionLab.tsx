import React from "react";
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from "remotion";
import * as A from "./assets/cut-paper";
import {useFonts} from "./fonts";
const Cell:React.FC<{index:number;label:string;children:React.ReactNode}>=({index,label,children})=><g data-motion-cell={label} transform={`translate(${index%4*480} ${Math.floor(index/4)*540})`}><A.PaperRect x={14} y={14} width={452} height={512} fill={index%2?'#E2D7BB':'#E9E1CC'} shadow={false}/><text x={34} y={54} fontFamily="DM Sans" fontSize={24} fontWeight={700} fill={A.palette.ink}>{label}</text>{children}</g>;
export const MotionLab:React.FC=()=>{
 useFonts();const time=useCurrentFrame()/useVideoConfig().fps,timing={startSeconds:.5,durationSeconds:6},q=A.sampleTween(time,timing),pour=A.samplePour(time,timing),travel=A.sampleJourney(time,{startSeconds:.5,durationSeconds:6,distance:230});
 const nodes=[{id:'a',x:95,y:300},{id:'b',x:240,y:170},{id:'c',x:370,y:320},{id:'d',x:220,y:420}];
 return <AbsoluteFill style={{background:'#E6DCC5'}}><A.PaperStage width={1920} height={1080}>
 <Cell index={0} label="Grounded gestures"><path d="M40 461H440" stroke="#A29F83" strokeWidth={3}/><A.PaperPerson x={135} y={460} height={340} action="wave" progress={q} time={time}/><A.PaperPerson x={340} y={460} height={340} action="nod" progress={q} time={time} facing="left" look={A.personLooks.coral}/></Cell>
 <Cell index={1} label="Join and shake"><A.PaperHandshake x={240} y={285} scale={.77} progress={q}/></Cell>
 <Cell index={2} label="Tilt, pour, return"><g transform={`translate(190 120) rotate(${-pour.angle}) translate(-190 -120)`}><A.PaperContainer x={90} y={120} width={100} height={145} level={pour.sourceVolume*.85} lid={false}/></g><A.PaperContainer x={300} y={285} width={110} height={175} level={pour.receivedVolume*.85} lid={false}/><A.LiquidStream from={{x:190,y:120}} to={{x:355,y:340}} flow={pour.stream} width={12}/></Cell>
 <Cell index={3} label="Draw relationships"><A.PaperNetwork nodes={nodes} edges={[["a","b"],["b","c"],["c","d"],["d","a"],["a","c"]]} progress={q}/></Cell>
 <Cell index={4} label="Shared pivots"><A.PaperDoor x={140} y={450} scale={.95} progress={q}/><A.PaperScissors x={340} y={430} scale={.82} progress={q}/></Cell>
 <Cell index={5} label="Distance drives rotation"><path d="M22 461H452" stroke="#9A9F84" strokeWidth={3}/><A.PaperCar x={90+travel.distance*.85} y={460} scale={.85} distance={travel.distance}/></Cell>
 <Cell index={6} label="Authored expression"><A.PaperPortrait x={145} y={450} scale={.8} emotion="happy" blink={Math.max(0,1-Math.abs(time-2.5)*12)} speaking={Math.sin(Math.PI*q*8)**2*.6}/><A.PaperPortrait x={350} y={450} scale={.8} skin="#E0B28A" hair="#5C4634" shirt="#B98B5C" emotion="thinking" blink={Math.max(0,1-Math.abs(time-4.3)*12)}/></Cell>
 <Cell index={7} label="Pick, carry, settle"><A.TracePath d="M70 425Q240 120 407 340" progress={1} stroke="#ACB09A" width={3}/><A.ArcTransfer time={time} {...timing} from={{x:75,y:430}} to={{x:400,y:350}} clearance={130}><A.PaperBackpack scale={.55}/></A.ArcTransfer><A.PaperRect x={343} y={351} width={106} height={20} fill="#A48962"/></Cell>
 </A.PaperStage></AbsoluteFill>;
};
