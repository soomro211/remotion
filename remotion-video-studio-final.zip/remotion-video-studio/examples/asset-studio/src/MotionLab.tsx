import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";
const Cell: React.FC<{
  index: number;
  label: string;
  children: React.ReactNode;
}> = ({ index, label, children }) => (
  <g
    data-motion-cell={label}
    transform={`translate(${(index % 4) * 480} ${Math.floor(index / 4) * 540})`}
  >
    <A.PaperRect
      x={14}
      y={14}
      width={452}
      height={512}
      fill={index % 2 ? "#E2D7BB" : "#E9E1CC"}
      shadow={false}
    />
    <text
      x={34}
      y={54}
      fontFamily="DM Sans"
      fontSize={24}
      fontWeight={700}
      fill={A.palette.ink}
    >
      {label}
    </text>
    {children}
  </g>
);
export const MotionLab: React.FC = () => {
  useFonts();
  const time = useCurrentFrame() / useVideoConfig().fps,
    timing = { startSeconds: 0.5, durationSeconds: 6 },
    q = A.sampleTween(time, timing),
    travel = A.sampleJourney(time, {
      startSeconds: 0.5,
      durationSeconds: 6,
      distance: 230,
    });
  const nodes = [
    { id: "a", x: 95, y: 300 },
    { id: "b", x: 240, y: 170 },
    { id: "c", x: 370, y: 320 },
    { id: "d", x: 220, y: 420 },
  ];
  return (
    <AbsoluteFill style={{ background: "#E6DCC5" }}>
      <A.PaperStage width={1920} height={1080}>
        <Cell index={0} label="Grounded gestures">
          <path d="M40 461H440" stroke="#A29F83" strokeWidth={3} />
          <A.PaperPerson
            x={135}
            y={460}
            height={340}
            action="wave"
            progress={q}
            time={time}
          />
          <A.PaperPerson
            x={340}
            y={460}
            height={340}
            action="nod"
            progress={q}
            time={time}
            facing="left"
            look={A.personLooks.coral}
          />
        </Cell>
        <Cell index={1} label="Join and shake">
          <A.PaperHandshake x={240} y={285} scale={0.77} progress={q} />
        </Cell>
        <Cell index={2} label="Tilt, pour, return">
          <A.PaperPouring
            x={25}
            y={100}
            visualScale={0.53}
            time={time}
            {...timing}
          />
        </Cell>
        <Cell index={3} label="Draw relationships">
          <A.PaperNetwork
            nodes={nodes}
            edges={[
              ["a", "b"],
              ["b", "c"],
              ["c", "d"],
              ["d", "a"],
              ["a", "c"],
            ]}
            progress={q}
          />
        </Cell>
        <Cell index={4} label="Shared pivots">
          <A.PaperDoor x={140} y={450} scale={0.95} progress={q} />
          <A.PaperScissors x={340} y={430} scale={0.82} progress={q} />
        </Cell>
        <Cell index={5} label="Distance drives rotation">
          <path d="M22 461H452" stroke="#9A9F84" strokeWidth={3} />
          <A.PaperCar
            x={90 + travel.distance * 0.85}
            y={460}
            scale={0.85}
            distance={travel.distance}
          />
        </Cell>
        <Cell index={6} label="Authored expression">
          <A.PaperPortrait
            x={145}
            y={450}
            scale={0.8}
            emotion="happy"
            blink={Math.max(0, 1 - Math.abs(time - 2.5) * 12)}
            speaking={Math.sin(Math.PI * q * 8) ** 2 * 0.6}
          />
          <A.PaperPortrait
            x={350}
            y={450}
            scale={0.8}
            skin="#E0B28A"
            hair="#5C4634"
            shirt="#B98B5C"
            emotion="thinking"
            blink={Math.max(0, 1 - Math.abs(time - 4.3) * 12)}
          />
        </Cell>
        <Cell index={7} label="Reach, grip, lift">
          <path d="M20 461H450" stroke="#9A9F84" strokeWidth={3} />
          <A.PaperLift x={180} y={460} height={340} time={time} {...timing} />
        </Cell>
      </A.PaperStage>
    </AbsoluteFill>
  );
};
