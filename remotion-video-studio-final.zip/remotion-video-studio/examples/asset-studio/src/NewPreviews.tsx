import React from "react";
import * as A from "./assets/cut-paper";
const objects: Record<string, React.ComponentType<A.ObjectProps>> = {
  oven: A.PaperOven,
  conveyor: A.PaperConveyor,
  pallet: A.PaperPallet,
  forklift: A.PaperForklift,
  handcart: A.PaperHandcart,
  "cash-register": A.PaperCashRegister,
  "medical-bed": A.PaperMedicalBed,
  "medical-cart": A.PaperMedicalCart,
  streetlamp: A.PaperStreetlamp,
  mailbox: A.PaperMailbox,
  "bus-stop": A.PaperBusStop,
  "trash-bin": A.PaperTrashBin,
  bench: A.PaperBench,
  books: A.PaperBooks,
  wrench: A.PaperWrench,
  bucket: A.PaperBucket,
  mug: A.PaperMug,
  teapot: A.PaperTeapot,
  lamp: A.PaperLamp,
  sofa: A.PaperSofa,
  bed: A.PaperBed,
  plant: A.PaperPlant,
  clock: A.PaperClock,
  door: A.PaperDoor,
  window: A.PaperWindow,
  umbrella: A.PaperUmbrella,
  pencil: A.PaperPencil,
  scissors: A.PaperScissors,
  ruler: A.PaperRuler,
  backpack: A.PaperBackpack,
  briefcase: A.PaperBriefcase,
  clipboard: A.PaperClipboard,
  folder: A.PaperFolder,
  envelope: A.PaperEnvelope,
  key: A.PaperKey,
  lock: A.PaperLock,
  magnifier: A.PaperMagnifier,
  "camera-prop": A.PaperCamera,
  bulb: A.PaperBulb,
  battery: A.PaperBattery,
  plug: A.PaperPlug,
  "solar-panel": A.PaperSolarPanel,
  "wind-turbine": A.PaperWindTurbine,
  microphone: A.PaperMicrophone,
  speaker: A.PaperSpeaker,
  server: A.PaperServer,
  headphones: A.PaperHeadphones,
  robot: A.PaperRobot,
  flower: A.PaperFlower,
  sprout: A.PaperSprout,
  leaf: A.PaperLeaf,
  rock: A.PaperRock,
  mountain: A.PaperMountain,
  moon: A.PaperMoon,
  fish: A.PaperFish,
  bird: A.PaperBird,
  "watering-can": A.PaperWateringCan,
  apple: A.PaperApple,
  bread: A.PaperBread,
  bowl: A.PaperBowl,
  plate: A.PaperPlate,
  carrot: A.PaperCarrot,
  cheese: A.PaperCheese,
  shop: A.PaperShop,
  school: A.PaperSchool,
  hospital: A.PaperHospital,
  bridge: A.PaperBridge,
  stairs: A.PaperStairs,
  fence: A.PaperFence,
  thermometer: A.PaperThermometer,
  balance: A.PaperBalance,
  gauge: A.PaperGauge,
  car: A.PaperCar,
  van: A.PaperVan,
  bus: A.PaperBus,
  train: A.PaperTrain,
  bicycle: A.PaperBicycle,
  boat: A.PaperBoat,
  airplane: A.PaperAirplane,
  "traffic-light": A.PaperTrafficLight,
};
export const NewPreview: React.FC<{ id: string; t: number }> = ({ id, t }) => {
  const q = A.sampleTween(t, { startSeconds: 0.2, durationSeconds: 6 });
  const architecture: Record<string, React.ComponentType<A.BuildingProps>> = {
    factory: A.PaperFactory,
    bakery: A.PaperBakery,
    bank: A.PaperBank,
    warehouse: A.PaperWarehouse,
    pharmacy: A.PaperPharmacy,
    cafe: A.PaperCafe,
    grocery: A.PaperGrocery,
    workshop: A.PaperWorkshop,
    apartments: A.PaperApartments,
    "office-building": A.PaperOffice,
    "station-building": A.PaperStation,
    "fire-station": A.PaperFireStation,
    "library-building": A.PaperLibrary,
  };
  const Building = architecture[id];
  if (Building) return <Building x={0} y={140} scale={0.58} open={q * 0.7} />;
  const worlds: Record<string, React.ComponentType<A.LocationProps>> = {
    "city-street": A.CityStreet,
    "old-town": A.OldTown,
    "industrial-yard": A.IndustrialYard,
    "bakery-interior": A.BakeryInterior,
    "shop-interior": A.ShopInterior,
    "hospital-corridor": A.HospitalCorridor,
    "station-platform": A.StationPlatform,
    harbor: A.Harbor,
    "rocky-coast": A.RockyCoast,
    desert: A.Desert,
    "dry-canyon": A.DryCanyon,
    "winter-valley": A.WinterValley,
  };
  const World = worlds[id];
  if (World) return <World x={-240} y={-150} scale={0.3} />;
  const surfaces: Record<string, React.ComponentType<A.SurfaceProps>> = {
    "asphalt-road": A.AsphaltRoad,
    "cobble-street": A.CobbleStreet,
    "dirt-track": A.DirtTrack,
    "gravel-ground": A.GravelGround,
    "railway-track": A.RailwayTrack,
    sidewalk: A.Sidewalk,
    "tile-floor": A.TileFloor,
    "wood-floor": A.WoodFloor,
    "sand-ground": A.SandGround,
    "snow-ground": A.SnowGround,
  };
  const Surface = surfaces[id];
  if (Surface) return <Surface x={-235} y={-86} width={470} height={175} />;
  const Object = objects[id];
  if (Object)
    return <Object x={0} y={135} scale={1.12} progress={q} level={0.7} />;
  const actors: Record<string, React.ComponentType<A.InteractionProps>> = {
    lift: A.PaperLift,
    place: A.PaperPlace,
    push: A.PaperPush,
    pull: A.PaperPull,
  };
  const Actor = actors[id];
  if (Actor)
    return (
      <Actor
        x={id === "pull" ? 0 : -100}
        y={140}
        height={270}
        time={t}
        startSeconds={0.1}
        durationSeconds={6}
      />
    );
  const effects: Record<string, React.ComponentType<A.EffectProps>> = {
    steam: A.Steam,
    smoke: A.Smoke,
    dust: A.Dust,
    rain: A.Rain,
    snow: A.Snow,
    splash: A.Splash,
  };
  const Effect = effects[id];
  if (Effect)
    return (
      <>
        <A.PaperRect
          x={-230}
          y={-140}
          width={460}
          height={280}
          fill={id === "steam" || id === "snow" ? "#527776" : "#D7CCAF"}
        />
        <Effect
          x={id === "rain" || id === "snow" ? -225 : 0}
          y={id === "rain" || id === "snow" ? -135 : 120}
          width={450}
          height={205}
          time={t}
          startSeconds={0}
          durationSeconds={8}
        />
      </>
    );
  if (id === "paper-occlusion")
    return (
      <g transform="translate(-230 -140)">
        <A.PaperOcclusion
          width={460}
          height={280}
          progress={q}
          from={<A.Desert scale={0.2875} />}
          to={<A.WinterValley scale={0.2875} />}
        />
      </g>
    );
  if (id === "depth-move")
    return (
      <>
        <A.DepthMove cameraX={q * 80} depth={0.2}>
          <A.PaperMountain x={110} y={110} scale={1.3} />
        </A.DepthMove>
        <A.DepthMove cameraX={q * 80} depth={0.8}>
          <A.PaperRock x={-80} y={130} scale={0.7} />
        </A.DepthMove>
      </>
    );
  if (id === "pivot-turn")
    return (
      <A.PivotTurn
        time={t}
        startSeconds={0.1}
        durationSeconds={6}
        pivot={{ x: 0, y: 0 }}
        to={45}
      >
        <A.PaperWrench y={120} scale={1.1} />
      </A.PivotTurn>
    );
  switch (id) {
    case "portrait":
      return (
        <A.PaperPortrait
          y={140}
          scale={1.0}
          emotion="happy"
          speaking={q * 0.4}
        />
      );
    case "handshake":
      return <A.PaperHandshake y={35} scale={0.85} progress={q} />;
    case "bar-chart":
      return (
        <A.PaperBarChart
          x={-170}
          y={120}
          width={340}
          height={225}
          values={[0.38, 0.72, 0.55, 0.91]}
          maximum={1}
          progress={0.4 + 0.6 * q}
        />
      );
    case "network":
      return (
        <A.PaperNetwork
          nodes={[
            { id: "a", x: -140, y: -60 },
            { id: "b", x: 0, y: -100 },
            { id: "c", x: 140, y: -30 },
            { id: "d", x: 60, y: 100 },
            { id: "e", x: -100, y: 90 },
          ]}
          edges={[
            ["a", "b"],
            ["b", "c"],
            ["c", "d"],
            ["d", "e"],
            ["e", "a"],
            ["a", "d"],
          ]}
          progress={q}
        />
      );
    case "arc-transfer":
      return (
        <>
          <A.TracePath
            d="M-170 90Q0-160 170 20"
            progress={1}
            stroke="#B2BA9C"
            width={3}
          />
          <A.ArcTransfer
            time={t}
            startSeconds={0.2}
            durationSeconds={6}
            from={{ x: -150, y: 100 }}
            to={{ x: 150, y: 30 }}
            clearance={100}
          >
            <A.PaperMug scale={0.48} />
          </A.ArcTransfer>
        </>
      );
    case "hinge":
      return (
        <>
          <A.PaperRect
            x={-160}
            y={-55}
            width={320}
            height={145}
            fill="#88A490"
          />
          <A.Hinge pivot={{ x: -135, y: 95 }} progress={q} openAngle={-65}>
            <A.PaperRect
              x={-135}
              y={65}
              width={270}
              height={30}
              fill="#B69363"
            />
          </A.Hinge>
          <A.PaperDisc x={-135} y={95} radius={8} />
        </>
      );
    case "trace-path":
      return (
        <A.TracePath
          d="M-180 100C-130-120 50 145 180-90"
          progress={q}
          underlay="#B5C1A9"
          stroke="#D79C60"
        />
      );
    case "pulse":
      return (
        <A.Pulse
          time={t}
          startSeconds={0.2}
          durationSeconds={6}
          amplitude={0.12}
        >
          <A.PaperBulb y={130} scale={1.1} />
        </A.Pulse>
      );
    case "orbit":
      return (
        <>
          <A.PaperDisc radius={68} fill="#D9B973" />
          <circle r={135} stroke="#B1BAA3" strokeWidth={2} fill="none" />
          <A.Orbit
            time={t}
            startSeconds={0.2}
            durationSeconds={6}
            center={{ x: 0, y: 0 }}
            radius={135}
          >
            <A.PaperDisc radius={25} fill="#6D9B97" />
          </A.Orbit>
        </>
      );
    case "stagger":
      return (
        <>
          {[0, 1, 2, 3].map((i) => (
            <A.Stagger
              key={i}
              time={t}
              startSeconds={0.4}
              durationSeconds={1.5}
              index={i}
              delaySeconds={0.8}
              travel={50}
            >
              <A.PaperPlant
                x={-160 + i * 105}
                y={125}
                scale={0.48}
                fill={i % 2 ? "#7F9C73" : "#689790"}
              />
            </A.Stagger>
          ))}
        </>
      );
    case "liquid-stream":
      return (
        <>
          <A.LiquidStream
            from={{ x: -120, y: -100 }}
            to={{ x: 55, y: 30 }}
            flow={Math.sin(Math.PI * q)}
            width={8}
          />
          <A.PaperContainer
            x={0}
            y={30}
            width={110}
            height={110}
            level={q * 0.55}
            lid={false}
          />
        </>
      );
    case "pouring":
      return (
        <A.PaperPouring
          x={-190}
          y={-150}
          visualScale={0.4}
          time={t}
          startSeconds={0.1}
          durationSeconds={6}
        />
      );
    case "object-settle":
      return (
        <A.ObjectSettle
          time={t}
          startSeconds={0.2}
          durationSeconds={6}
          from={{ x: -150, y: -40 }}
          anticipation={9}
        >
          <A.PaperBackpack y={135} scale={1.05} />
        </A.ObjectSettle>
      );
    case "choreography":
      return (
        <>
          {[0, 1, 2].map((i) => {
            const p = A.sampleArc(
              t,
              { startSeconds: i * 0.2, durationSeconds: 6 },
              { x: -160, y: 90 - i * 50 },
              { x: 160, y: 50 - i * 50 },
              80,
            );
            return (
              <g key={i}>
                <A.TracePath
                  d={`M-160 ${90 - i * 50}Q0 ${-70 - i * 50} 160 ${50 - i * 50}`}
                  progress={1}
                  width={2}
                  stroke="#B9B99B"
                />
                <A.PaperDisc
                  x={p.x}
                  y={p.y}
                  radius={17}
                  fill={["#C38B63", "#789A8C", "#D5B364"][i]}
                />
              </g>
            );
          })}
        </>
      );
    default:
      return null;
  }
};
