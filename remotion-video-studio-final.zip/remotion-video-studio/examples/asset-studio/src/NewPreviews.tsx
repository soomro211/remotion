import React from "react";
import * as A from "./assets/cut-paper";
const objects:Record<string,React.ComponentType<A.ObjectProps>>={
"mug":A.PaperMug,
"teapot":A.PaperTeapot,
"lamp":A.PaperLamp,
"sofa":A.PaperSofa,
"bed":A.PaperBed,
"plant":A.PaperPlant,
"clock":A.PaperClock,
"door":A.PaperDoor,
"window":A.PaperWindow,
"umbrella":A.PaperUmbrella,
"pencil":A.PaperPencil,
"scissors":A.PaperScissors,
"ruler":A.PaperRuler,
"backpack":A.PaperBackpack,
"briefcase":A.PaperBriefcase,
"clipboard":A.PaperClipboard,
"folder":A.PaperFolder,
"envelope":A.PaperEnvelope,
"key":A.PaperKey,
"lock":A.PaperLock,
"magnifier":A.PaperMagnifier,
"camera-prop":A.PaperCamera,
"bulb":A.PaperBulb,
"battery":A.PaperBattery,
"plug":A.PaperPlug,
"solar-panel":A.PaperSolarPanel,
"wind-turbine":A.PaperWindTurbine,
"microphone":A.PaperMicrophone,
"speaker":A.PaperSpeaker,
"server":A.PaperServer,
"headphones":A.PaperHeadphones,
"robot":A.PaperRobot,
"flower":A.PaperFlower,
"sprout":A.PaperSprout,
"leaf":A.PaperLeaf,
"rock":A.PaperRock,
"mountain":A.PaperMountain,
"moon":A.PaperMoon,
"fish":A.PaperFish,
"bird":A.PaperBird,
"watering-can":A.PaperWateringCan,
"apple":A.PaperApple,
"bread":A.PaperBread,
"bowl":A.PaperBowl,
"plate":A.PaperPlate,
"carrot":A.PaperCarrot,
"cheese":A.PaperCheese,
"shop":A.PaperShop,
"school":A.PaperSchool,
"hospital":A.PaperHospital,
"bridge":A.PaperBridge,
"stairs":A.PaperStairs,
"fence":A.PaperFence,
"thermometer":A.PaperThermometer,
"balance":A.PaperBalance,
"gauge":A.PaperGauge,
"car":A.PaperCar,
"van":A.PaperVan,
"bus":A.PaperBus,
"train":A.PaperTrain,
"bicycle":A.PaperBicycle,
"boat":A.PaperBoat,
"airplane":A.PaperAirplane,
"traffic-light":A.PaperTrafficLight};
export const NewPreview:React.FC<{id:string;t:number}>=({id,t})=>{
 const q=A.sampleTween(t,{startSeconds:.2,durationSeconds:6});
 const Object=objects[id];
 if(Object)return <Object x={0} y={135} scale={1.12} progress={q} level={.7}/>;
 switch(id){
 case "portrait":return <A.PaperPortrait y={140} scale={1.0} emotion="happy" speaking={q*.4}/>;
 case "handshake":return <A.PaperHandshake y={35} scale={.85} progress={q}/>;
 case "bar-chart":return <A.PaperBarChart x={-170} y={120} width={340} height={225} values={[.38,.72,.55,.91]} maximum={1} progress={.4+.6*q}/>;
 case "network":return <A.PaperNetwork nodes={[{id:'a',x:-140,y:-60},{id:'b',x:0,y:-100},{id:'c',x:140,y:-30},{id:'d',x:60,y:100},{id:'e',x:-100,y:90}]} edges={[["a","b"],["b","c"],["c","d"],["d","e"],["e","a"],["a","d"]]} progress={q}/>;
 case "arc-transfer":return <><A.TracePath d="M-170 90Q0-160 170 20" progress={1} stroke="#B2BA9C" width={3}/><A.ArcTransfer time={t} startSeconds={.2} durationSeconds={6} from={{x:-150,y:100}} to={{x:150,y:30}} clearance={100}><A.PaperMug scale={.48}/></A.ArcTransfer></>;
 case "hinge":return <><A.PaperRect x={-160} y={-55} width={320} height={145} fill="#88A490"/><A.Hinge pivot={{x:-135,y:95}} progress={q} openAngle={-65}><A.PaperRect x={-135} y={65} width={270} height={30} fill="#B69363"/></A.Hinge><A.PaperDisc x={-135} y={95} radius={8}/></>;
 case "trace-path":return <A.TracePath d="M-180 100C-130-120 50 145 180-90" progress={q} underlay="#B5C1A9" stroke="#D79C60"/>;
 case "pulse":return <A.Pulse time={t} startSeconds={.2} durationSeconds={6} amplitude={.12}><A.PaperBulb y={130} scale={1.1}/></A.Pulse>;
 case "orbit":return <><A.PaperDisc radius={68} fill="#D9B973"/><circle r={135} stroke="#B1BAA3" strokeWidth={2} fill="none"/><A.Orbit time={t} startSeconds={.2} durationSeconds={6} center={{x:0,y:0}} radius={135}><A.PaperDisc radius={25} fill="#6D9B97"/></A.Orbit></>;
 case "stagger":return <>{[0,1,2,3].map(i=><A.Stagger key={i} time={t} startSeconds={.4} durationSeconds={1.5} index={i} delaySeconds={.8} travel={50}><A.PaperPlant x={-160+i*105} y={125} scale={.48} fill={i%2?'#7F9C73':'#689790'}/></A.Stagger>)}</>;
 case "liquid-stream":return <><A.PaperContainer x={15} y={-55} width={112} height={178} kind="jar" level={q*.6} lid={false}/><A.LiquidStream from={{x:-75,y:-70}} to={{x:65,y:30}} flow={Math.sin(Math.PI*q)} width={10}/><g transform="translate(-75 -70) rotate(25) translate(75 70)"><A.PaperContainer x={-140} y={-70} width={65} height={110} level={.75} lid={false}/></g></>;
 case "object-settle":return <A.ObjectSettle time={t} startSeconds={.2} durationSeconds={6} from={{x:-150,y:-40}} anticipation={9}><A.PaperBackpack y={135} scale={1.05}/></A.ObjectSettle>;
 case "choreography":return <>{[0,1,2].map(i=>{const p=A.sampleArc(t,{startSeconds:i*.2,durationSeconds:6},{x:-160,y:90-i*50},{x:160,y:50-i*50},80);return <g key={i}><A.TracePath d={`M-160 ${90-i*50}Q0 ${-70-i*50} 160 ${50-i*50}`} progress={1} width={2} stroke="#B9B99B"/><A.PaperDisc x={p.x} y={p.y} radius={17} fill={['#C38B63','#789A8C','#D5B364'][i]}/></g>;})}</>;
 default:return null;
 }
};
