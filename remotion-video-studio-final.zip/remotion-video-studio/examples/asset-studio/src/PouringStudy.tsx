import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
export const PouringStudy: React.FC = () => {
  const time = useCurrentFrame() / useVideoConfig().fps;
  return (
    <AbsoluteFill style={{ background: "#E6DCC5" }}>
      <A.PaperStage width={1920} height={1080}>
        <A.PaperRect x={0} y={950} width={1920} height={130} fill="#B99B73" />
        <A.PaperPouring
          x={420}
          y={70}
          visualScale={1.22}
          time={time}
          startSeconds={0.3}
          durationSeconds={6.5}
        />
      </A.PaperStage>
    </AbsoluteFill>
  );
};
