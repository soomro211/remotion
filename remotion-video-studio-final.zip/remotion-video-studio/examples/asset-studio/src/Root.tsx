import React from "react";
import { Composition, registerRoot } from "remotion";
import { Gallery } from "./Gallery";
import { Actions } from "./Actions";
import { Showcase } from "./Showcase";
import { Character } from "./Character";
import { MotionLab } from "./MotionLab";
import { InteractionStudy } from "./InteractionStudy";
import { EffectsStudy } from "./EffectsStudy";
import { EquipmentStudy } from "./EquipmentStudy";
import { LocationStudy } from "./LocationStudy";
import { ArchitectureStudy } from "./ArchitectureStudy";
import { PouringStudy } from "./PouringStudy";
import { GestureStudy } from "./GestureStudy";
import catalog from "./assets/cut-paper/catalog-preview.json";
export const Root: React.FC = () => (
  <>
    <Composition
      id="InteractionStudy"
      component={InteractionStudy}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={240}
    />
    <Composition
      id="EffectsStudy"
      component={EffectsStudy}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={240}
    />
    {[0, 1, 2, 3].map((page) => (
      <Composition
        key={page}
        id={`Equipment${page + 1}`}
        component={EquipmentStudy}
        defaultProps={{ page }}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={240}
      />
    ))}
    {[0, 1, 2].map((page) => (
      <Composition
        key={page}
        id={`Locations${page + 1}`}
        component={LocationStudy}
        defaultProps={{ page }}
        width={1920}
        height={1200}
        fps={30}
        durationInFrames={240}
      />
    ))}
    {[0, 1, 2, 3].map((page) => (
      <Composition
        key={page}
        id={`Architecture${page + 1}`}
        component={ArchitectureStudy}
        defaultProps={{ page }}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={240}
      />
    ))}
    <Composition
      id="PouringStudy"
      component={PouringStudy}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={240}
    />
    <Composition
      id="GestureStudy"
      component={GestureStudy}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={240}
    />
    <Composition
      id="GestureDetails"
      component={GestureStudy}
      defaultProps={{ detail: true }}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={240}
    />
    <Composition
      id="Actions"
      component={Actions}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={300}
    />
    {Array.from({ length: Math.ceil(catalog.length / 30) }, (_, page) => (
      <Composition
        key={page}
        id={page === 0 ? "Gallery" : `Gallery${page + 1}`}
        component={Gallery}
        defaultProps={{ page }}
        width={3840}
        height={2160}
        fps={30}
        durationInFrames={300}
      />
    ))}
    <Composition
      id="Showcase"
      component={Showcase}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={480}
    />
    <Composition
      id="MotionLab"
      component={MotionLab}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={240}
    />
    <Composition
      id="Character"
      component={Character}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={180}
    />
  </>
);
registerRoot(Root);
