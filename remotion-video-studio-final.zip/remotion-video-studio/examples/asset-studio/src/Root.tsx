import React from "react";
import { Composition, registerRoot } from "remotion";
import { Walking } from "./Walking";
import { Gallery } from "./Gallery";
import { Actions } from "./Actions";
import { Showcase } from "./Showcase";
import { Character } from "./Character";
export const Root: React.FC = () => (
  <>
    <Composition
      id="Walking"
      component={Walking}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={330}
    />
    <Composition
      id="Actions"
      component={Actions}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={300}
    />
    <Composition
      id="Gallery"
      component={Gallery}
      width={3840}
      height={2160}
      fps={30}
      durationInFrames={300}
    />
    <Composition
      id="Showcase"
      component={Showcase}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={450}
    />
    <Composition
      id="Character"
      component={Character}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={180}
    />
  </>
);
registerRoot(Root);
