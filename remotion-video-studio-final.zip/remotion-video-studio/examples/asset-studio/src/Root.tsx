import React from "react";
import { Composition, registerRoot } from "remotion";
import { Gallery } from "./Gallery";
import { Actions } from "./Actions";
import { Showcase } from "./Showcase";
import { Character } from "./Character";
import {MotionLab} from "./MotionLab";
import catalog from "./assets/cut-paper/catalog-preview.json";
export const Root: React.FC = () => (
  <>
    <Composition
      id="Actions"
      component={Actions}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={300}
    />
    {Array.from({length:Math.ceil(catalog.length/30)},(_,page)=><Composition key={page} id={page===0?"Gallery":`Gallery${page+1}`} component={Gallery} defaultProps={{page}} width={3840} height={2160} fps={30} durationInFrames={300}/>)}
    <Composition
      id="Showcase"
      component={Showcase}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={480}
    />
    <Composition id="MotionLab" component={MotionLab} width={1920} height={1080} fps={30} durationInFrames={240}/>
    <Composition
      id="Character"
      component={Character}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={180}
    />
  </>
);
registerRoot(Root);
