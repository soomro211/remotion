import React from "react";
import {
  AbsoluteFill,
  Sequence,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";
const Street: React.FC<{ time: number }> = ({ time }) => {
  const travel = A.sampleJourney(time, {
    startSeconds: 0.2,
    durationSeconds: 4.3,
    distance: 370,
  });
  return (
    <AbsoluteFill style={{ background: "#B4CFC3" }}>
      <A.CameraRig
        from={{ centerX: 540, centerY: 960, zoom: 1 }}
        to={{ centerX: 590, centerY: 950, zoom: 1.05 }}
        startSeconds={0}
        durationSeconds={5}
      >
        <A.PaperStage width={1600} height={2200}>
          <A.PaperRect
            x={-400}
            y={-300}
            width={2400}
            height={3000}
            fill="#B4CFC3"
            shadow={false}
          />
          <A.PaperSun x={800} y={460} radius={112} />
          <A.PaperCloud x={330} y={430} time={time} scale={0.9} />
          <A.PaperCloud x={1110} y={610} time={time} scale={1.1} />
          <A.PaperGround
            x={-400}
            y={1110}
            width={2400}
            height={1800}
            fill="#93AB87"
            rise={85}
          />
          {[200, 530, 870, 1230].map((x, i) => (
            <A.PaperBuilding
              key={x}
              x={x}
              y={1170}
              width={230 + i * 18}
              height={360 + (i % 2) * 150}
              fill={i % 2 ? "#82988B" : "#B19C78"}
              roof={i === 2 ? "pitched" : "flat"}
            />
          ))}
          <A.PaperGround
            x={-400}
            y={1330}
            width={2400}
            height={1500}
            rise={70}
          />
          <A.PaperPath x={-400} y={1380} width={2400} height={230} />
          <A.PaperFurniture x={845} y={1450} kind="bench" scale={1.15} />
          <A.PaperTree x={70} y={1415} height={560} time={time} />
          <A.PaperTree x={1180} y={1490} height={680} time={time} />
          <A.PaperPerson
            x={270}
            y={1435}
            height={520}
            travel={travel}
            time={time}
          />
        </A.PaperStage>
      </A.CameraRig>
    </AbsoluteFill>
  );
};
const Room: React.FC<{ time: number }> = ({ time }) => {
  const travel = A.sampleJourney(time, {
    startSeconds: 0,
    durationSeconds: 3.8,
    distance: 280,
  });
  return (
    <AbsoluteFill style={{ background: "#E2D3B6" }}>
      <A.CameraRig
        from={{ centerX: 540, centerY: 960, zoom: 1 }}
        to={{ centerX: 565, centerY: 965, zoom: 1.04 }}
        startSeconds={0}
        durationSeconds={5}
      >
        <A.PaperStage width={1600} height={2200}>
          <A.PaperRoom
            width={1600}
            height={2200}
            floorY={1180}
            window={{ x: 650, y: 360, width: 310, height: 390 }}
          />
          <A.PaperDocument
            x={150}
            y={468}
            width={95}
            height={140}
            kind="book"
          />
          <A.PaperDocument
            x={260}
            y={498}
            width={80}
            height={110}
            kind="book"
          />
          <A.PaperContainer
            x={375}
            y={485}
            width={75}
            height={130}
            kind="bottle"
          />
          <A.PaperRect x={130} y={615} width={350} height={18} fill="#9B7E58" />
          <A.PaperFurniture x={930} y={1440} kind="table" scale={1.35} />
          <A.PaperDevice x={800} y={1069.5} width={170} kind="laptop" />
          <A.PaperDocument
            x={1020}
            y={1122}
            width={95}
            height={68}
            kind="book"
          />
          <A.PaperFurniture x={1220} y={1440} scale={1.2} />
          <A.PaperPerson
            x={160}
            y={1435}
            height={520}
            travel={travel}
            action="carry"
            look={A.personLooks.coral}
            time={time}
            item={<A.PaperBox width={70} height={60} />}
          />
          <A.PaperPerson
            x={760}
            y={1435}
            height={500}
            facing="left"
            action="point"
            progress={1}
            look={A.personLooks.ochre}
            time={time}
          />
          <A.PaperShape
            d="M-300 1755Q500 1620 1900 1740V2400H-300Z"
            fill="#967F62"
            shadow={false}
          />
        </A.PaperStage>
      </A.CameraRig>
    </AbsoluteFill>
  );
};
const Process: React.FC<{ time: number }> = ({ time }) => {
  const top: A.Cubic = [
      { x: 240, y: 600 },
      { x: 340, y: 390 },
      { x: 850, y: 480 },
      { x: 830, y: 800 },
    ],
    bottom: A.Cubic = [
      { x: 800, y: 1100 },
      { x: 780, y: 1310 },
      { x: 350, y: 1360 },
      { x: 250, y: 1150 },
    ];
  return (
    <AbsoluteFill style={{ background: A.palette.navy }}>
      <A.PaperStage width={1080} height={1920}>
        <A.PaperRect
          width={1080}
          height={1920}
          fill={A.palette.navy}
          shadow={false}
        />
        <A.PaperBox x={140} y={620} width={200} height={160} />
        <A.PaperContainer
          x={765}
          y={835}
          width={140}
          height={205}
          level={0.65}
        />
        <A.PaperArrow curve={top} fill="#E6B763" width={7} />
        <A.PaperFlow curve={top} time={time} track={false} count={7} />
        <A.PaperGear
          x={440}
          y={1005}
          radius={112}
          teeth={14}
          angle={time * 34}
        />
        <A.PaperGear
          x={656}
          y={1005}
          radius={104}
          teeth={13}
          angle={A.gearAngle(time * 34, 112, 104)}
          fill="#B59660"
        />
        <A.PaperArrow curve={bottom} fill="#83ACA0" width={7} />
        <A.PaperFlow
          curve={bottom}
          time={time}
          period={4}
          track={false}
          count={6}
          fill="#C0C9A8"
        />
        <A.PaperTokens x={230} y={1110} count={7} radius={65} />
        <A.PaperHighlight
          x={836}
          y={920}
          radius={140}
          progress={Math.min(1, time / 1.2)}
        />
      </A.PaperStage>
    </AbsoluteFill>
  );
};
const pages = [
  {
    text: "Reusable worlds, with room for the story.",
    startMs: 200,
    endMs: 4700,
    timestampMs: 0,
    confidence: null,
  },
  {
    text: "People and props share the same material.",
    startMs: 5200,
    endMs: 9700,
    timestampMs: 0,
    confidence: null,
  },
  {
    text: "Motion makes a relationship visible.",
    startMs: 10200,
    endMs: 14600,
    timestampMs: 0,
    confidence: null,
  },
];
export const Showcase: React.FC = () => {
  useFonts();
  const frame = useCurrentFrame(),
    { fps } = useVideoConfig(),
    t = frame / fps;
  return (
    <AbsoluteFill>
      <Sequence durationInFrames={5 * fps} name="Street">
        <Street time={t} />
      </Sequence>
      <Sequence
        from={5 * fps}
        durationInFrames={5 * fps}
        name="Indoor interaction"
      >
        <Room time={t - 5} />
      </Sequence>
      <Sequence from={10 * fps} durationInFrames={5 * fps} name="Process">
        <Process time={t - 10} />
      </Sequence>
      <A.SmoothPaperCaptions pages={pages} />
    </AbsoluteFill>
  );
};
