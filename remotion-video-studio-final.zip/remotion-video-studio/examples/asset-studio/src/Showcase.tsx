import React from "react";
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from "remotion";
import * as A from "./assets/cut-paper";
import {useFonts} from "./fonts";
const Everyday:React.FC<{time:number}>=({time})=>{
 const q=A.sampleTween(time,{startSeconds:.4,durationSeconds:2.6});
 return <A.PaperStage width={1600} height={2200}><A.PaperRoom width={1600} height={2200} floorY={1250} window={false}/><A.PaperShape d="M-400-300H2200V460Q900 550-400 385Z" fill="#78998B" shadow={false}/><A.PaperWindow x={760} y={890} scale={2.6}/><A.PaperClock x={273} y={695} scale={1.1} progress={.22}/><A.PaperSofa x={300} y={1430} scale={2.25} fill="#648F86" accent="#A7B195"/><A.PaperLamp x={69} y={1430} scale={2.4} progress={q}/><A.PaperFurniture x={800} y={1410} scale={1.65} kind="table"/><A.PaperMug x={835} y={1113} scale={.6}/><A.PaperPlant x={694} y={1113} scale={.75}/><A.PaperDocument x={913} y={1041} width={96} height={72} kind="book"/><A.PaperBackpack x={585} y={1430} scale={1.05}/><A.PaperShape d="M-300 1720Q700 1650 2000 1780V2500H-300Z" fill="#8C8E72" shadow={false}/></A.PaperStage>;
};
const Transit:React.FC<{time:number}>=({time})=>{
 const trip=A.sampleJourney(time,{startSeconds:.1,durationSeconds:3.5,distance:190});
 return <A.PaperStage width={1700} height={2300}><A.PaperRect x={-400} y={-300} width={2800} height={3000} fill="#B3C8BC" shadow={false}/><A.PaperCloud x={210} y={390} time={time}/><A.PaperSun x={790} y={360} radius={88}/><A.PaperGround x={-400} y={1130} width={2800} height={1800} rise={25} fill="#91AB88"/><A.PaperShop x={210} y={1170} scale={2.0}/><A.PaperBuilding x={720} y={1170} width={290} height={500} fill="#A69B79" rows={4}/><A.PaperSchool x={1110} y={1170} scale={2.0}/><A.PaperGround x={-400} y={1250} width={2800} height={1500} rise={0} fill="#BDAE8E"/><A.PaperRect x={-400} y={1320} width={2800} height={265} fill="#687D76" shadow={false}/>{Array.from({length:12},(_,i)=><A.PaperRect key={i} x={i*160-400} y={1484} width={74} height={8} fill="#D9D5B7" shadow={false}/>)}<A.PaperBus x={285+trip.distance*1.8} y={1460} scale={1.8} distance={trip.distance}/><A.PaperTrafficLight x={980} y={1460} scale={1.5}/><A.PaperTree x={-30} y={1320} height={420} time={time}/></A.PaperStage>;
};
const Garden:React.FC<{time:number}>=({time})=>{
 const q=A.sampleTween(time,{startSeconds:.4,durationSeconds:2.8});
 return <A.PaperStage width={1700} height={2300}><A.PaperRect x={-400} y={-300} width={2800} height={3000} fill="#CFD5BA" shadow={false}/><A.PaperMountain x={850} y={1030} scale={4.0} fill="#9FAC8B"/><A.PaperMountain x={200} y={1080} scale={3.2} fill="#A9B294"/><A.PaperGround x={-400} y={1050} width={2800} height={1700} rise={70} fill="#91A77D"/><A.PaperFence x={235} y={1260} scale={2.6} fill="#BCA87C"/><A.PaperFence x={759} y={1260} scale={2.6} fill="#BCA87C"/><A.PaperGround x={-400} y={1330} width={2800} height={1300} rise={30} fill="#687F61"/><A.PaperPlant x={260} y={1440} scale={2} progress={.6+.4*q} fill="#6F9B77"/><A.PaperFlower x={530} y={1440} scale={2.0} accent="#D6AA6B"/><A.PaperWateringCan x={835} y={1440} scale={1.8} fill="#6F9992"/><A.PaperBird x={805} y={725} scale={1.1} progress={q}/><A.PaperRock x={-10} y={1480} scale={1.2}/><A.PaperSprout x={670} y={1450} scale={.9} progress={q}/></A.PaperStage>;
};
const Conversation:React.FC<{time:number}>=({time})=>{
 const q=A.sampleTween(time,{startSeconds:.4,durationSeconds:3});
 return <A.PaperStage width={1600} height={2300}><A.PaperRect x={-400} y={-300} width={2800} height={3000} fill="#324D57" shadow={false}/><A.PaperShape d="M-400 1400Q650 1280 1900 1470V2400H-400Z" fill="#718A80" shadow={false}/><A.PaperNetwork nodes={[{id:'a',x:260,y:490,radius:43},{id:'b',x:770,y:430,radius:43},{id:'c',x:550,y:735,radius:43}]} edges={[["a","b"],["b","c"],["c","a"]]} progress={q} fill="#D6B26B"/><A.PaperPortrait x={290} y={1260} scale={1.4} emotion="happy" speaking={Math.sin(q*Math.PI*6)**2*.6}/><A.PaperPortrait x={830} y={1260} scale={1.4} skin="#D8AA81" hair="#574636" shirt="#B78B60" emotion="thinking"/></A.PaperStage>;
};
const captions=["A familiar room, built from useful parts.","Travel and wheel rotation share one clock.","Materials stay coherent as the setting changes.","Expressions and gestures make people readable."].map((text,i)=>({text,startMs:i*4000+150,endMs:(i+1)*4000-200,timestampMs:0,confidence:null}));
export const Showcase:React.FC=()=>{
 useFonts();const time=useCurrentFrame()/useVideoConfig().fps,index=Math.min(3,Math.floor(time/4)),local=time-index*4;
 const Scene=[Everyday,Transit,Garden,Conversation][index];
 return <AbsoluteFill><A.CameraRig from={{centerX:540,centerY:960,zoom:1}} to={{centerX:565,centerY:950,zoom:1.035}} sourceSeconds={local} startSeconds={0} durationSeconds={4}><Scene time={local}/></A.CameraRig><A.SmoothPaperCaptions pages={captions}/></AbsoluteFill>;
};
