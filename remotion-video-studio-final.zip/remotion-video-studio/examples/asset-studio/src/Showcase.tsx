import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import * as A from "./assets/cut-paper";
import { useFonts } from "./fonts";
const Bakery: React.FC<{ time: number }> = ({ time }) => (
  <A.PaperStage width={1800} height={2300}>
    <A.PaperRect
      x={-500}
      y={-400}
      width={3000}
      height={3000}
      fill="#D8D1BA"
      shadow={false}
    />
    <A.WoodFloor x={-500} y={1063} width={3000} height={1500} />
    <A.BakeryInterior x={-480} y={170} scale={1.25} />
    <A.PaperPerson
      x={600}
      y={1420}
      height={700}
      action="carry"
      item={<A.PaperBread x={35} y={58} scale={0.33} />}
    />
    <A.Steam
      x={235}
      y={952}
      time={time}
      startSeconds={0}
      durationSeconds={4}
      height={100}
      density={0.4}
    />
  </A.PaperStage>
);
const Street: React.FC<{ time: number }> = ({ time }) => (
  <A.PaperStage width={1800} height={2300}>
    <A.PaperRect
      x={-500}
      y={-400}
      width={3000}
      height={3000}
      fill="#D5DED0"
      shadow={false}
    />
    <A.AsphaltRoad
      x={-500}
      y={1370}
      width={3000}
      height={1200}
      markings={false}
    />
    <A.CityStreet x={-120} y={100} scale={1.5} />
    <A.PaperStreetlamp x={930} y={1300} scale={2.5} />
    <A.PaperPush
      x={100}
      y={1460}
      height={430}
      time={time}
      startSeconds={0.1}
      durationSeconds={3.4}
      distance={110}
    />
  </A.PaperStage>
);
const Coast: React.FC<{ time: number }> = ({ time }) => (
  <A.PaperStage width={1800} height={2300}>
    <A.PaperRect
      x={-500}
      y={-400}
      width={3000}
      height={3000}
      fill="#6E9792"
      shadow={false}
    />
    <A.RockyCoast x={-230} y={-50} scale={1.9} />
    <A.PaperBird
      x={710 + time * 35}
      y={540}
      scale={0.7}
      progress={0.5 + 0.35 * Math.sin(time * 3)}
    />
    <A.PaperRock x={150} y={1750} scale={2.2} />
  </A.PaperStage>
);
const Industry: React.FC<{ time: number }> = ({ time }) => {
  const trip = A.sampleJourney(time, {
    startSeconds: 0.1,
    durationSeconds: 3.4,
    distance: 140,
  });
  return (
    <A.PaperStage width={1800} height={2300}>
      <A.PaperRect
        x={-500}
        y={-400}
        width={3000}
        height={3000}
        fill="#D5DED0"
        shadow={false}
      />
      <A.AsphaltRoad
        x={-500}
        y={1278}
        width={3000}
        height={1300}
        markings={false}
      />
      <A.IndustrialYard x={0} y={180} scale={1.4} />
      <A.Smoke
        x={202}
        y={334}
        time={time}
        startSeconds={-0.5}
        durationSeconds={5}
        height={240}
        density={0.55}
      />
      <A.PaperForklift
        x={330 + trip.distance * 1.7}
        y={1490}
        scale={1.7}
        distance={trip.distance}
        progress={0.1}
      />
      <A.PaperPallet x={880} y={1485} scale={1.4} />
    </A.PaperStage>
  );
};
const captions = [
  "Warm interiors with room for the action.",
  "Hands, feet and wheels share the movement.",
  "The setting changes; the paper stays tactile.",
  "Useful details give each place its character.",
].map((text, i) => ({
  text,
  startMs: i * 4000 + 150,
  endMs: (i + 1) * 4000 - 200,
  timestampMs: 0,
  confidence: null,
}));
export const Showcase: React.FC = () => {
  useFonts();
  const time = useCurrentFrame() / useVideoConfig().fps,
    index = Math.min(3, Math.floor(time / 4)),
    local = time - index * 4;
  const Scene = [Bakery, Street, Coast, Industry][index];
  return (
    <AbsoluteFill>
      <A.CameraRig
        from={{ centerX: 540, centerY: 960, zoom: 1 }}
        to={{ centerX: 565, centerY: 950, zoom: 1.035 }}
        sourceSeconds={local}
        startSeconds={0}
        durationSeconds={4}
      >
        <Scene time={local} />
      </A.CameraRig>
      <A.SmoothPaperCaptions pages={captions} />
    </AbsoluteFill>
  );
};
