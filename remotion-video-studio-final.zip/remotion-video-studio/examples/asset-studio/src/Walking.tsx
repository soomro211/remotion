import React from "react";
import { useFonts } from "./fonts";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import {
  PaperStage,
  PaperShape,
  PaperRect,
  ContactShadow,
  palette,
} from "./assets/cut-paper/core/material";
import { PaperPerson, personLooks } from "./assets/cut-paper/characters/Person";
import { sampleJourney } from "./assets/cut-paper/characters/gait";
// Deliberately preserves the old film's one-piece legs and timer-driven feet for comparison only.
const Legacy: React.FC<{ x: number; y: number; time: number }> = ({
  x,
  y,
  time,
}) => {
  const a = Math.sin(time * 4.2);
  return (
    <g transform={`translate(${x} ${y}) scale(1.36)`}>
      <PaperShape
        d={`M-18-102L-1-100L${-9 + a * 17}-51L${-21 + a * 22}-6L${-41 + a * 22}-6L-31-57Z`}
        fill="#506572"
      />
      <PaperShape
        d={`M5-102L25-107L${32 - a * 17}-55L${43 - a * 22}-7L${24 - a * 22}-7L7-56Z`}
        fill="#506572"
      />
      <PaperShape
        d={`M${-41 + a * 22}-11L${-20 + a * 22}-10L${-10 + a * 22} 0L${-48 + a * 22} 0Z`}
        fill="#343D43"
      />
      <PaperShape
        d={`M${25 - a * 22}-10L${43 - a * 22}-11L${57 - a * 22} 0L${23 - a * 22} 0Z`}
        fill="#343D43"
      />
      <PaperShape
        d="M-33-214L-10-230L19-229L37-211L32-102L-29-103Z"
        fill="#548E87"
      />
      <PaperShape d="M-5-232L14-231L13-209L-6-209Z" fill="#C58C66" />
      <PaperShape
        d="M-23-275Q0-294 24-275L23-245L10-229L-10-233L-24-248Z"
        fill="#C58C66"
      />
      <PaperShape
        d="M-25-261Q-32-284-5-294L19-282L27-266L12-277L-4-277L-20-260Z"
        fill="#43372F"
      />
      <PaperShape
        d={`M-31-207L-42-192L${-42 - a * 18}-151L${-24 - a * 14}-122L-12-131L-28-160Z`}
        fill="#548E87"
      />
      <PaperShape
        d={`M34-207L44-190L${42 + a * 16}-150L${61 + a * 17}-128L${49 + a * 17}-117L${24 + a * 15}-144Z`}
        fill="#548E87"
      />
    </g>
  );
};
export const Walking: React.FC = () => {
  useFonts();
  const frame = useCurrentFrame(),
    { fps } = useVideoConfig(),
    t = frame / fps,
    travel = sampleJourney(t, {
      startSeconds: 1,
      durationSeconds: 6,
      distance: 1170,
    });
  return (
    <AbsoluteFill style={{ background: "#EEE4CE", fontFamily: "DM Sans" }}>
      <PaperStage width={1920} height={1080}>
        <PaperRect width={1920} height={1080} fill="#EEE4CE" shadow={false} />
        <PaperShape
          d="M0 700Q450 660 960 700Q1400 660 1920 700V1080H0Z"
          fill="#ADB99A"
          shadow={false}
        />
        <PaperShape d="M0 892H1920V1080H0Z" fill="#BCA881" shadow={false} />
        {[0, 960].map((offset) => (
          <g key={offset}>
            {Array.from({ length: 16 }, (_, i) => {
              const x =
                offset + ((((i * 100 - travel.distance) % 1000) + 1000) % 1000);
              return (
                <g key={i}>
                  <path d={`M${x} 912v18`} stroke="#826F56" strokeWidth="3" />
                  <path
                    d={`M${x + 4} 940h40`}
                    stroke="#DAC9A8"
                    strokeWidth="2"
                  />
                </g>
              );
            })}
          </g>
        ))}
        <path d="M960 128V1005" stroke="#D6C8AE" strokeWidth="2" />
        <ContactShadow x={470} y={892} />
        <Legacy x={470} y={892} time={t} />
        <PaperPerson
          x={1430 - travel.distance}
          y={892}
          height={400}
          travel={travel}
          time={t}
          look={personLooks.teal}
        />
      </PaperStage>
      <div
        style={{
          position: "absolute",
          left: 100,
          top: 94,
          color: palette.ink,
          fontSize: 42,
          fontWeight: 700,
        }}
      >
        Earlier motion
      </div>
      <div
        style={{
          position: "absolute",
          left: 1060,
          top: 94,
          color: palette.ink,
          fontSize: 42,
          fontWeight: 700,
        }}
      >
        Grounded walking rig
      </div>
      <div
        style={{
          position: "absolute",
          left: 1060,
          top: 158,
          color: "#56665D",
          fontSize: 26,
        }}
      >
        Planted feet · articulated joints · distance-based steps
      </div>
    </AbsoluteFill>
  );
};
