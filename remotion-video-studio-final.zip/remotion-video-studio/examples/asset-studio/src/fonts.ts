import { useEffect, useState } from "react";
import {
  cancelRender,
  continueRender,
  delayRender,
  staticFile,
} from "remotion";
export const useFonts = () => {
  const [handle] = useState(() => delayRender("Asset reference fonts"));
  useEffect(() => {
    new FontFace("DM Sans", `url(${staticFile("fonts/DMSans.ttf")})`, {
      weight: "100 1000",
    })
      .load()
      .then((f) => {
        document.fonts.add(f);
        continueRender(handle);
      })
      .catch(cancelRender);
  }, [handle]);
};
