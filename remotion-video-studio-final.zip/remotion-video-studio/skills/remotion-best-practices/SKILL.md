---
name: remotion-best-practices
description: "Router for all Remotion skills"
version: 4.0.536
---

<!-- studio-reference:1.5.0 -->
Production defaults: [current workflow](../video-director/references/current-workflow.md).

## Studio production workflow and quality defaults

For this installed studio's finished explainers, load [Video Director](../video-director/SKILL.md)
and its [production quality defaults](../video-director/references/production-quality.md) first.
These add smooth motion, purposeful transitions, topic-specific scenery, smooth theme-matched
subtitles and no persistent per-scene main headings. Explicit user preferences take precedence.
Keep Studio open while building. In the Video Director workflow, the approved plan and supplied
voiceover authorize the finished export; the preview-only default below applies to standalone work
outside that workflow. Do not add a second approval gate.

## Preserve user changes

Users may make edits in the code outside of the conversation.

If you detect a surprising change made in the meanwhile, don't overwrite it, assume it was intentional or ask for confirmation.

## Creating a video

If the user asks to make, create, or build a new video or composition, load [Create a new Remotion video](../remotion-create/SKILL.md), whether or not a Remotion project already exists.

## New project setup

If no Remotion project currently exists, load [Create a new Remotion project](../remotion-create/SKILL.md)

## React Markup Best Practices

If you are writing Remotion React Markup, load [Remotion Markup Best Practices](../remotion-markup/SKILL.md)

## Maps

For static maps, animated routes and markers, geographic explainers, Mapbox, MapLibre, MapTiler, GeoJSON, or 3D geographic flyovers, load [Remotion Maps](../remotion-maps/SKILL.md).

## Multimedia

For achieving multimedia tasks in the browser, such as trimming, cropping videos, or getting metadata from them, load [Remotion Multimedia](../remotion-multimedia/SKILL.md)

## Improving Interactivity

By structuring the Remotion markup well, we can allow users to interactively change things in the Studio and write back to code. If relevant: [Interactivity Best Practices](../remotion-interactivity/SKILL.md)

## Open the preview

For standalone composition work outside Video Director, start with an interactive preview and
render when requested. In the Video Director workflow, the approved plan and supplied voiceover
authorize the finished MP4; continue through export without another confirmation.
As soon as the project can run, start Studio and open the preview in the browser before building or editing the composition. Keep it open while you work so the user can watch progress and steer.

### If you are using Cursor

Run Studio without `--no-open` so it opens the browser automatically:

```bash
npx remotion studio
```

### If you are using another agent client with an in-app browser

You can use the command above to let Studio open the browser, or run:

```bash
npx remotion studio --no-open
```

This will start a long-running process and print the server URL for the preview.  
If the server is already started, it will print the URL.
If you use `--no-open`, open the exact printed URL in the in-app browser and verify that Studio loads. Once a composition exists, verify that its video preview loads. If you cannot open it there, run Studio without `--no-open`.
You can visit a specific composition by navigating to `/[composition-id]`, for example `http://localhost:3000/MapAnimation`.

:::note
The Studio supports WebMCP tools.
:::

### If you do not have an in-app browser

This will open the Studio in the browser or refocus it if it is already open.

```bash
npx remotion studio
```

### More options

To launch a project in Remotion Studio, open its exact local URL, or configure Studio CLI flags, load [Remotion Studio](../remotion-studio/SKILL.md).

## Render the video

Render when requested explicitly, or as the authorized delivery step of Video Director.
The latter does not require the user to repeat "export" after approving the plan.

The preview also has a more intuitive rendering interface, so consider using it instead of the command line for rendering.

```
npx remotion render
```

For more options, see [Rendering](../remotion-render/SKILL.md).

For advanced rendering beyond simple `npx remotion render`, see: [Rendering Best Practices](../remotion-render/SKILL.md)

## Captions

When working with Captions, load [Remotion Captions](../remotion-captions/SKILL.md).

## Creating a SaaS, automation or application

This bundle focuses on finished videos and does not include the separate SaaS skill. For
Remotion-powered applications, Player or hosted rendering, consult the
[Remotion documentation](https://www.remotion.dev/docs/) and use the Docs skill to resolve current APIs.

## Looking up Remotion APIs and documentation

To find and read current Remotion documentation, load [Remotion Docs](../remotion-docs/SKILL.md).

## Upgrading

To upgrade Remotion, related packages, compatible Mediabunny packages, and installed Remotion Agent Skills, load [Remotion Upgrade](../remotion-upgrade/SKILL.md).
