---
name: remotion-captions
description: Transcribing, displaying and animating captions
version: 4.0.536
---

All captions must be processed in JSON. The captions must use the [`Caption`](https://www.remotion.dev/docs/captions/caption.md) type which is the following:

```ts
import type { Caption } from "@remotion/captions";
```

This is the definition:

```ts
type Caption = {
  text: string;
  startMs: number;
  endMs: number;
  timestampMs: number | null;
  confidence: number | null;
  pageBreakAfter?: boolean;
};
```

## Generating captions

For this studio's narrated explainers, subtitles are enabled by default unless the user opts out.
Read [smooth subtitle defaults](references/smooth-subtitles.md) before choosing the renderer: short
semantic phrases, at most two lines, a stable lower safe lane, theme-matched backing that stays mounted,
and gentle text changes. This is a precise display specification permitting a custom renderer.
Scene titles are separate and must not replace subtitles. Align to the actual recording.

To transcribe video and audio files to generate captions, load the [transcribe-captions.md](transcribe-captions.md) file for more instructions.

## Displaying captions

To display captions in your video, load the [display-captions.md](display-captions.md) file for more instructions.

## Importing captions

To import captions from a .srt file, load the [import-srt-captions.md](import-srt-captions.md) file for more instructions.

## Post-creation

After you're done, load this skill: [Remotion Best Practices](../remotion-best-practices/SKILL.md)

If not alreay done, open the Remotion Studio, unless instructed otherwise.
