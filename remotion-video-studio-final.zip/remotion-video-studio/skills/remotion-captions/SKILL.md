---
name: remotion-captions
description: "Transcribing, displaying and animating captions"
version: 4.0.536
---

<!-- studio-reference:3.0.0 -->
Process and authority: [decision architecture](../video-director/references/current-workflow.md).

All captions must be processed in JSON. The captions must use the [`Caption`](https://www.remotion.dev/docs/captions/caption.md) type which is the following:

```ts
import type { Caption } from "@remotion/captions";
```

This is the definition:

```ts
type Caption = {
  text: string;
  startMs: number;
  endMs: number;
  timestampMs: number | null;
  confidence: number | null;
  pageBreakAfter?: boolean;
};
```

## Generating captions

Choose caption behavior/styling from the project and applicable user requirements. Read [project caption treatment](references/smooth-subtitles.md); exact speech/timing and measured readability are technical contracts. The renderer takes explicit project style values.

To transcribe video and audio files to generate captions, load the [transcribe-captions.md](transcribe-captions.md) file for more instructions.

## Displaying captions

To display captions in your video, load the [display-captions.md](display-captions.md) file for more instructions.

## Importing captions

To import captions from a .srt file, load the [import-srt-captions.md](import-srt-captions.md) file for more instructions.

## Post-creation

After you're done, load this skill: [Remotion Best Practices](../remotion-best-practices/SKILL.md)

If not alreay done, open the Remotion Studio, unless instructed otherwise.
