// Technical phrase renderer. All visible treatment is supplied by the project.
import React from 'react';
import type {Caption} from '@remotion/captions';
import {useCurrentFrame,useVideoConfig} from 'remotion';
export type CaptionStyle={x:number;y:number;width:number;height:number;padding:number;fontFamily:string;fontSize:number;fontWeight:number;lineHeight:number;color:string;surface:React.CSSProperties;inMs:number;outMs:number;travelPx:number};
const unit=(v:number)=>Math.max(0,Math.min(1,v));
const ease=(v:number)=>{const p=unit(v);return p*p*(3-2*p);};
export const SmoothPaperCaptions:React.FC<{pages:readonly Caption[];style:CaptionStyle}>=({pages,style})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 if(!style||!style.fontFamily||!style.color)throw new Error('Supply the explicit project caption style.');
 if(!pages.length)return null;
 const ms=frame/fps*1000,first=pages[0].startMs,last=pages[pages.length-1].endMs,page=pages.find(p=>ms>=p.startMs&&ms<p.endMs);
 const fade=(elapsed:number,duration:number)=>duration>0?ease(elapsed/duration):Number(elapsed>=0);
 const plate=fade(ms-first+style.inMs,style.inMs)*(1-fade(ms-last,style.outMs));
 const length=page?page.endMs-page.startMs:1,enter=page?fade(ms-page.startMs,Math.min(style.inMs,length*.2)):0,exit=page?fade(ms-page.endMs+Math.min(style.outMs,length*.2),Math.min(style.outMs,length*.2)):1;
 return <div data-caption-backing style={{position:'absolute',left:style.x,top:style.y,width:style.width,height:style.height,opacity:plate}}>
  <div data-caption-surface style={{position:'absolute',inset:0,...style.surface}}/>
  <div style={{position:'absolute',inset:style.padding,overflow:'hidden'}}>{page?<div data-paper-caption style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',textAlign:'center',fontFamily:style.fontFamily,fontSize:style.fontSize,fontWeight:style.fontWeight,lineHeight:style.lineHeight,color:style.color,whiteSpace:'pre-line',textWrap:'balance',opacity:enter*(1-exit),translate:`0 ${(1-enter)*style.travelPx-exit*style.travelPx/2}px`}}>{page.text}</div>:null}</div>
 </div>;
};
