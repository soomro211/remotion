// Optional starting renderer, not an auto-transcriber. Copy to src/ and load
// DM Sans before rendering. Supply already grouped, non-overlapping Caption pages.
import React from 'react';
import type {Caption} from '@remotion/captions';
import {useCurrentFrame, useVideoConfig} from 'remotion';

const unit = (v: number) => Math.max(0, Math.min(1, v));
const ease = (v: number) => { const p = unit(v); return p * p * (3 - 2 * p); };

export const SmoothPaperCaptions: React.FC<{
  pages: readonly Caption[];
  x?: number; y?: number; width?: number; height?: number; fontSize?: number;
}> = ({pages, x = 80, y = 1346, width = 890, height = 148, fontSize = 52}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (!pages.length) return null;
  const ms = frame / fps * 1000;
  const first = pages[0].startMs;
  const last = pages[pages.length - 1].endMs;
  const page = pages.find(p => ms >= p.startMs && ms < p.endMs);
  const plate = ease((ms - first + 100) / 260) * (1 - ease((ms - last) / 300));
  const length = page ? page.endMs - page.startMs : 1;
  const fadeIn = Math.min(160, length * .16);
  const fadeOut = Math.min(120, length * .16);
  const enter = page ? ease((ms - page.startMs) / fadeIn) : 0;
  const exit = page ? ease((ms - page.endMs + fadeOut) / fadeOut) : 1;
  // The backing is always the same node and box, including short silent gaps.
  // End/remount this group deliberately for an extended silent passage.
  return <div data-caption-backing style={{position: 'absolute', left: x, top: y,
    width, height, opacity: plate, filter: 'drop-shadow(0 5px 0 #442e242b) drop-shadow(0 9px 9px #442e2426)'}}>
    <div style={{position: 'absolute', inset: 0, background: '#F4EBD8',
      border: '5px solid #F7EFDF',
      clipPath: 'polygon(0 3%,2% 0,47% 1%,100% 0,99% 49%,100% 98%,51% 100%,1% 98%,0 53%)'}}/>
    <div style={{position: 'absolute', inset: '8px 22px', overflow: 'hidden'}}>
      {page ? <div data-paper-caption style={{position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center',
        fontFamily: 'DM Sans', fontWeight: 700, fontSize, lineHeight: 1.1,
        whiteSpace: 'pre-line', textWrap: 'balance', color: '#1B2845',
        opacity: enter * (1 - exit), translate: `0 ${(1 - enter) * 6 - exit * 3}px`}}>{page.text}</div> : null}
    </div>
  </div>;
};
