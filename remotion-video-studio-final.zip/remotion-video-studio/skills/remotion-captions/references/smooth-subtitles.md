<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Smooth, theme-matched subtitle defaults

Use for this studio's narrated explainers unless the user asks otherwise. These
are the precise display specifications for the custom caption renderer allowed
by `display-captions.md`; a generic Basic Captions treatment is not the default
for a cut-paper explainer.

## Transcript and data

- Save captions as JSON using the `Caption` type. Keep the exact spoken words,
  spelling, punctuation and language; compare recognition with the approved
  script and the supplied take. Correct ASR mistakes only after checking the
  recording. Do not conceal a different take by overwriting the transcript.
- Obtain word or phrase timings from the actual recording (transcription,
  forced alignment or verified manual alignment). Do not divide duration evenly
  or infer final subtitle timing from word counts.
- Prefer semantic pages of roughly 4–7 words. Allow a shorter or longer phrase
  when grammar, pauses or reading speed justify it. Avoid isolated articles,
  one-word flashes and a new page at every scene cut.
- Keep at most two balanced lines. Start with about 32–42 characters per line,
  then use the loaded font and real available width to decide line breaks. Do
  not shrink the font until an overlong page fits; split it intelligently.
- Use `pageBreakAfter` where useful to preserve page boundaries. Save any derived
  page grouping alongside the original timing JSON; offer an SRT when useful.

## Layout and material

- Use a stable lower caption lane with breathing room above the bottom controls,
  outside the main action. At 1080×1920, use x=80, y=1500, width=890,
  height=148 as the default plate. This leaves 272px below the backing and moves
  it clearly into the lower part of the frame without touching the bottom edge.
  Keep the plate fixed across phrases; its text centers around y=1574.
- This subtitle lane is intentionally lower than the conservative 420px bottom
  margin used for titles and object labels. Do not clamp captions to that title
  margin or copy the older, higher placement from production reference stills.
  Check actual destination controls and shadows; adjust upward only as needed
  for a real overlap. Re-layout for other aspect ratios instead of stretching
  these coordinates.
- For cut paper, use a softly textured cream strip, ink text and a restrained
  paper edge/shadow. Optional tape remains fixed, subtle and clear of glyphs.
  Use about 52px DM Sans, medium/semibold, line-height about 1.1. Adjust after
  measuring actual glyphs. Preserve strong contrast over every background.
- Keep backing width, height, position and baseline consistent across phrases.
  Center the one- and two-line text blocks intentionally within the same plate.
  The plate must not jump as phrase length changes.
- Cut Paper is the bundled theme. A user-authorized different art direction needs its own material/type treatment. No universal neon
  karaoke, word highlighting, large bounce, typewriter or per-letter effects.

## Motion and continuity

- Mount the plate once for the continuous narration passage. Keep it present
  across phrase replacements, brief speech pauses and art transitions. Fade it
  in/out only at the passage beginning/end or a deliberate extended silent beat.
- Ease text in over about 160ms and out over about 120ms, scaling to fps. Optional
  vertical movement is at most 6px. Keep a long fully readable hold between them.
  For a very short page, reduce the fades rather than consuming its reading time.
- Avoid simultaneous fully visible old/new phrases. Use sequential soft changes
  or a carefully checked crossfade without double-exposed glyphs. Do not remount
  the backing or replay tape/card entrances whenever the active page changes.
- Do not reset caption time at an illustration cut. Put the voice and its
  captions in a shared source group. A continuous voiceover may span a separate
  `TransitionSeries` for illustrations; independently edited voice/video clips
  each need captions in their own shared timing parent.
- When trimming or changing speed is requested, apply timing to the shared source
  group so audio and captions stay together. Preserve the original user voice
  and speed unless the user authorized a change.

## Remotion implementation and checks

- The canonical reusable renderer is [SmoothPaperCaptions.tsx](../assets/SmoothPaperCaptions.tsx).
  Supply already grouped, sorted, positive-duration, non-overlapping Caption pages and load fonts.
  It is not a transcriber or automatic two-line layout validator.
- Use `useCurrentFrame()` / `useVideoConfig()`; convert source-relative milliseconds
  deterministically. No timers, CSS animation or independent browser playback.
- Wait for fonts with Remotion's loading mechanism before rendering or measuring.
  Keep actual caption text in JSON; a custom renderer can consume that data.
  Basic Captions source editing instead requires its inline source array as
  documented in `display-captions.md`.
- Measure the longest pages after fonts load. Verify actual rendered line count
  and glyph bounds, safe margins, plate padding and legibility at phone scale.
- Sample several frames immediately before, during and after every page change.
  Check plate continuity, baseline stability, no text collision or ghosting and
  no blank-frame flash. Check sync against the real voice source at beginning,
  middle and end, then inspect the final encoded MP4.

## Reuse and current examples

Use `remotion-themes/scripts/assets.py copy <project> --assets captions` to install the canonical renderer and dependency metadata. The current production images in the theme show the lower lane; historical Industrial Revolution stills remain a camera study. Do not maintain another competing default renderer or infer placement from an old image.
