# Project caption treatment

Process: [decision architecture](../../video-director/references/current-workflow.md).

Use exact spoken words and actual word/phrase timestamps. Save JSON using the `Caption` type. Group into readable semantic pages according to grammar, speech rhythm and available space. Measure loaded glyphs and line breaks at actual viewing size.

The project defines font, size/weight, color, backing/surface, padding, box and motion using its art direction and applicable user requirements. Sourced lower placement or smooth phrase-change preferences carry forward for the relevant user. Adapt geometry to aspect ratio and actual destination controls.

Keep the caption source clock synchronized with speech and independent of illustration cuts/camera transforms. If a backing is chosen for a continuous passage, stable geometry can support smooth phrase replacement. Test actual page changes for readable holds, collisions or ghosted text at normal speed.

[The technical renderer](../assets/SmoothPaperCaptions.tsx) accepts explicit project style values and aligned pages. It supplies timing/rendering mechanics, not a visual palette, font or placement prescription. Copy it into the project when useful. Use a different renderer when the treatment needs it.

Check beginning/middle/end sync and actual encoded pages. Distinguish text measurements, image inspection, playback and listening in QA.
