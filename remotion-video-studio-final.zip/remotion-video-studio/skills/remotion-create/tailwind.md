---
name: tailwind
description: Using TailwindCSS in Remotion.
metadata:
---

<!-- studio-reference:3.1.0 -->
Process and authority: [decision architecture](../video-director/references/current-workflow.md).

You can and should use TailwindCSS in Remotion, if TailwindCSS is installed in the project.

Don't use `transition-*` or `animate-*` classes - always animate using the `useCurrentFrame()` hook.

Tailwind must be installed and enabled first in a Remotion project - see https://www.remotion.dev/docs/tailwind.
