# Video layout for the current studio

Build around one meaningful visual action. Reusable assets supply consistent materials and geometry; the subject still determines the scene and camera.

At 1080×1920:

- Titles/object labels: conservative top270, bottom420, left60, right110 margins. Titles are optional and finite; use about 84px or larger for a necessary headline and 44px or larger for important labels, then measure loaded glyphs.
- Captions: separate lower plate x80, y1500, width890, height148, with 272px below it. Begin near 52px DM Sans and at most two balanced lines. Do not force captions upward into title margins.
- Keep important action clear of that caption lane. Set the object's ground/contact baseline deliberately, then frame the world around it.
- Re-layout other formats and inspect actual destination controls; these vertical coordinates are not a universal aspect-ratio formula.
- Cover the camera's complete view, including pullbacks and shadows. Keep captions outside world transforms.

Read [current defaults](../video-director/references/current-workflow.md), [asset placement/anchors](../remotion-themes/themes/cut-paper/assets/README.md), and [caption checks](../remotion-captions/references/smooth-subtitles.md). No persistent chapter slogans, counters or progress bars.
