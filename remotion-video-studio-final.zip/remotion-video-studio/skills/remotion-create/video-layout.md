# Project layout

Process: [decision architecture](../video-director/references/current-workflow.md).

Choose the frame, subject scale, action, text hierarchy and space according to the treatment and destination. Create project artwork for planned camera coverage before final assembly. Measure actual text and inspect viewing-size compositions.

Caption placement/type/surface follow the project's explicit style and sourced user requirements; re-layout each delivered format. Keep its clock tied to speech and its placement independent of world camera transforms. The layout is a project decision, not a diagram of universal margins.
