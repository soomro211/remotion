import {useEffect,useState} from 'react';
import {cancelRender,continueRender,delayRender,staticFile} from 'remotion';
export type ProjectFont={family:string;file:string;weight?:string};
export const useProjectFonts=(fonts:readonly ProjectFont[])=>{
 const [handle]=useState(()=>delayRender('project fonts'));
 useEffect(()=>{
  Promise.all(fonts.map(f=>new FontFace(f.family,`url(${staticFile(f.file)})`,{weight:f.weight}).load().then(font=>document.fonts.add(font))))
   .then(()=>continueRender(handle)).catch((error:unknown)=>cancelRender(error instanceof Error?error:new Error(String(error))));
 },[handle,fonts]);
};
