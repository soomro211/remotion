---
name: remotion-preproduction
description: Planning rules for Remotion videos: concept, script, storyboard, timing and an anti-generic audit. Use inside /video-director (or alone) before any Remotion code whenever the user wants a video, explainer, promo, product demo or social clip. Produces the contents of video/plan.json.
version: 3.2.1
---

# Remotion Pre-production

Bad AI video is bad because nobody decided anything first: generic gradient, centered text, everything fading up
the same way, copy any brand could say. This skill makes the decisions specific, and audits them.
`/video-director` runs this skill as its planning step; the output is `video/plan.json`, not a prose document.

**One approval gate.** Ask at most one batch of questions (max 4, each with a default), then produce the plan and
present `PLAN.md` (made by `plan_docs.py`) for a single approval. Do not build before that. If the user says
"just build it", state assumptions in one short list and continue.

Read [production quality defaults](../video-director/references/production-quality.md) first. They are part of
the brief even when the user does not repeat them: topic-specific scenery, smooth motion/transitions,
theme-matched subtitles, and no persistent main headings.

**Principles:** specific beats generic; one idea, one hero per scene, at most one useful CTA; restraint reads as quality;
design for sound-off thumb-scroll and for a paused frame that still looks designed; never invent facts,
logos, UI or numbers (use `proof` fields or flag as open questions).

| File | Read at |
|---|---|
| `references/anti-slop.md` | Phase 2 and the audit. Always. |
| `references/script-and-copy.md` | Phase 2 (and use `/video-scriptwriting` for depth) |
| `references/motion-principles.md`, `references/storyboard-timing-specs.md` | Phase 3 |
| `references/design-rules.md` | when extending the paper art direction |
| `references/qa.md` | Phase 4 audit, and build QA |

## Phase 0: Intake and research (one message, silent where possible)
Needed: goal (what should the viewer believe/do), audience and platform (default 9:16 Reels/Shorts, 20-30 s),
source material (facts, brand assets), tone, narration language and accent. Anything the user did not say gets a
stated default. Research real facts first (WebSearch/WebFetch) and note a source for every number.

## Phase 1: Concept
- **Creative promise** (one sentence) and **the one thing** the viewer must remember.
- One repeatable visual device and one signature moment. Pass the swap test (replace the topic with another
  and the video still works = too generic).
- Theme: `cut-paper` (the sole included theme). Design paper scenery for the subject,
  including maps or diagrams when useful. Read `design-rules.md` when extending the art direction.
- Inspect actual theme images. Preserve their material/type/palette rules while designing scenery and
  backgrounds for the topic; the example landscape and title-card layout are not compulsory.

## Phase 2: Script
Hook in 2-3 s, a visual payoff, and one idea per scene. A CTA is optional for educational videos.
Write narration for the ear (about 2.5 words/second). Plan accurate smooth subtitles separately from
optional title/label text. Most explanatory scenes need no main heading (`onscreen: []`). An optional
opening title exits after a brief readable introduction. Apply `script-and-copy.md`.

## Phase 3: Storyboard and timing
Scene list with: id, internal name, type (`hook` | `explain` | `list` | `route` | `payoff` | `cta`), narration,
optional onscreen lines with text role/window, topic-specific visual action, motion/camera direction,
transition reason, entrance (`slide` | `pop` | `stamp` | `drop` | `none`), and `events` (sound cues at seconds from
scene start: transition, whoosh, land, pop, reveal, tick, cta, riser, zoom, route). Vary scene length and
entrance; no two neighbouring scenes identical. Do not compute frames: the narration audio decides timing later
(`after_vo.py`). Record quality settings in `production`; caption defaults are enabled, lower-safe,
theme-matched and smooth. Scene names are never visible automatically. Avoid repeated stock scenery
and reserve no permanent heading area. Plan caption space and camera overscan.

## Phase 4: Audit, then present
Score the plan with `references/qa.md` (fix anything below 4), run the anti-slop checklist, then run
`python3 plan_docs.py video/plan.json`. It validates the plan and writes `PLAN.md` with the storyboard, narration
script, **TTS style prompt** and a paste-ready prompt for the user's TTS (Gemini). Show the user the contents
of PLAN.md and ask for approval and the audio.

## After approval
The user sends the audio. Continue with `/video-director` (timing, sound, build, render).

## Done means
Approved plan, zero unresolved anti-slop hits, every fact sourced, no invented assets.
