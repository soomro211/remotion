---
name: remotion-preproduction
description: "Establish the current film's purpose, audience, evidence, scope and treatment; design speech and shots independently, then derive contextual art direction and an asset specification."
version: 3.0.0
---

# Preproduction
Use [decision architecture](../video-director/references/current-workflow.md).

Start from the current request and sourced standing user requirements. Record inferred scope/constraints as assumptions; resolve material ambiguity using context, evidence or a concise question when necessary. Research the mechanism and acknowledge claim limits.

Develop the explanatory approach before artwork. Consider alternatives when they clarify an uncertainty; record why the chosen treatment fits this brief. The opening should establish an appropriate reason to watch, through the form the subject supports.

Write speech with [scriptwriting](../video-scriptwriting/SKILL.md). Author shots separately: purpose, visual action, framing, camera, outgoing connection and links to spoken cues. Shot boundaries follow visual/editorial decisions, later aligned to actual speech.

Art direction uses setting/material/light/context/tone and readable hierarchy. Assign references their roles and limits; derive palette/type/method in the project. [Art-direction guide](references/design-rules.md) supports this step. Style frames test the intended result during preparation.

Build the project asset specification from the shots. After the established script/storyboard approval when missing, create/review all required artwork before final assembly using [asset preparation](../video-director/references/asset-first-workflow.md). Internal review adds no user gate. Keep creative and engineering findings separate.
