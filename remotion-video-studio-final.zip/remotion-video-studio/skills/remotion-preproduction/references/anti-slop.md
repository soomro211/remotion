<!-- studio-reference:1.3.0 -->
Studio production defaults: [current workflow and asset rules](../../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Anti-slop: what makes AI video look generic, and what to do instead

"Slop" is the default output you get when nothing was decided. Check the plan
against every section. Each hit must be removed or consciously justified in the plan.

## Visual slop
| Generic default | Why it reads as AI | Do instead |
|---|---|---|
| Purple/blue/pink gradient on near-black | The single most common AI palette | Derive palette from the brand; use one confident accent on a considered neutral |
| Glassmorphism cards and glow everywhere | Effect with no meaning | Flat or tactile surfaces; use blur only to separate real depth |
| Floating blobs, orbs, particles, sparkles | Decoration to fill space | Empty space is fine; use shapes that belong to the concept |
| Three feature cards with icons in a row | Website template, not motion | One feature per scene, shown working |
| Emoji or stock icon packs as visuals | Cheap and inconsistent | One consistent icon set, or typography and real UI |
| Invented dashboards ("1,234", "+12%", lorem) | Fake data is obvious | Use the user's real screenshots; if none, ask, or abstract the UI honestly |
| Everything centered, same size | No hierarchy | Pick an alignment system; one dominant element; scale contrast of 3x or more between levels |
| Tiny text, low contrast, text over busy image | Unreadable on phones | Min 40px body on 1080p (larger on 9:16); scrim or solid plate behind text |
| Default Tailwind blue/indigo, Arial/system font | Nobody chose it | Named palette, intentional type pairing |
| 3+ font families, many weights | Visual noise | Max 2 families; hierarchy through size and weight |
| Heavy blurry drop shadows, neon outlines | Dated template look | Crisp borders, subtle shadow with a defined light direction, or none |
| Stock-footage montage, fake logos, fake testimonials | Dishonest and generic | Only supplied or licensed assets; label placeholders |
| Unaligned elements, inconsistent margins | Looks accidental | 8px scale, one grid, consistent margins |
| Logo first, logo last, logo everywhere | Brand ego, no hook | Hook first, logo as payoff, once or twice |
| Large chapter heading pinned over every explanation | Presentation slides instead of visual storytelling | Internal scene names stay hidden; an optional brief opening title leaves; use contextual labels only where needed |
| Same hills/sky/cards behind every topic | Stock layout with new copy | Inspect theme images, preserve material/type/palette and build topic-specific scenery |
| Frame counters, progress bars, scene numbers and generic follow cards | Unrequested template debris | Remove unless the brief explicitly needs them |

## Motion slop
| Generic default | Do instead |
|---|---|
| Every element fades up 20px with the same ease | Different roles get different motion: hero (larger, slower), supporting (smaller, faster), UI (snappiest) |
| Linear easing, or one bounce on everything | Ease-out for entrances, ease-in for exits, springs tuned to the motion personality |
| All elements enter simultaneously | Stagger 3-5 frames in reading order; hero first |
| Same transition between every scene | A small vocabulary (usually two) used with logic: one for continuation, one for a hard topic change |
| Constant motion, nothing ever rests | Rhythm: move, land, hold; moments of stillness make motion land |
| Dead-still holds | Purposeful secondary action or parallax; a still camera is valid. Avoid obligatory scale drift |
| Per-letter animation on every headline | Reserve for one hero line; otherwise per-line mask reveals or per-word |
| Slow fade in from black at frame 0 | First frame must already show something; start mid-action |
| Identical scene durations | Vary durations, fast-slow-fast, land beats |
| Zoom, shake, glitch used because available | Each effect needs a narrative reason |
| Fade-to-black ending | Hold the CTA, or end on a designed final frame |
| Motion that never overlaps | Start the next entrance 4-8 frames before the previous exit ends |
| Paper texture interpreted as mandatory choppy motion | Smooth continuous frame-driven motion; step frames only for an explicitly chosen stop-motion treatment |
| Caption card/tape pops in again for every short phrase | Keep the plate mounted; use soft text changes in a stable lower safe lane |
| Camera zoom hides a static poster | Animate the process or relationship the narration explains; give moves a narrative purpose |

## Copy slop
Banned or heavily suspect words and patterns: *revolutionize, unlock, supercharge,
elevate, seamless, effortless, cutting-edge, next-generation, game-changing,
harness, leverage, empower, transform your, take X to the next level, in today's
fast-paced world, imagine a world where, say goodbye to, introducing the future of,
all-in-one solution, powerful yet simple.* Also:
- Triplets of adjectives ("Fast. Simple. Powerful.") unless each is proven in the shot.
- Questions as hooks that the viewer answers "no" to ("Tired of slow workflows?").
- Rhetorical grandeur with no claim ("The future is here").
- Excess em dashes and parallel "not X, but Y" constructions.
- Vague nouns: solution, platform, ecosystem, experience, journey, workflow (unless that is the literal product).
Replace with: a concrete verb, a concrete object, a number or a visible result.

## Structural slop
- No hook in the first 3 seconds.
- More than one idea per scene or more than about 12 words of non-caption display copy on screen.
- A forced CTA in an educational explainer, or a vague CTA where an action is actually required.
- Claims without a credible source or evidence; source notes can remain in the project rather than becoming permanent display text.
- Scenes that exist only to hit a target duration.
- Video that only works with sound on (no captions or visual carry).

## The five tests (all must pass)
1. **Swap test:** replace the brand with a competitor. If it still works, it is generic.
2. **Pause test:** pause on any random frame. Does it look like a designed poster?
3. **Blur test:** squint or blur the frame. Is the hero element still obvious?
4. **Sound-off test:** is the story clear with no audio?
5. **Remove test:** delete any element or scene. If nothing is lost, delete it for real.

Also scrub the sequence: a well-designed paused frame is necessary, but a series
of static posters is not a finished motion explainer. Check title exits, actual
visual action, transition continuity and smooth subtitle changes.

## Asset reuse without repeated videos

Reuse the tested person rig, material and object geometry. Change staging, action, framing and scenery to fit the explanation. Do not turn every film into the same park, room, box/arrow loop or gallery. The catalog is a building-block reference, not a scene template. Correct sliding feet, floating carried objects and missing floor contact before adding decorative movement.
