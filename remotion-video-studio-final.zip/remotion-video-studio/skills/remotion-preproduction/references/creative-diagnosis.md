# Diagnose the actual result

Process: [decision architecture](../../video-director/references/current-workflow.md).

Begin with an observed problem in this film and identify why it affects the intended viewer. A dull composition may involve hierarchy, lighting, color relationships or subject scale; an awkward join may involve focal discontinuity, timing or inconsistent action. Inspect the relevant evidence before choosing a correction.

Treat a correction as a testable project revision. Revisit the frame/sequence and record what changed. A particular palette, layout or transition is neither successful nor unsuccessful by category alone. Scope any lesson according to the evidence and applicable user requirements.
