# Contextual art direction

Process: [decision architecture](../../video-director/references/current-workflow.md).

Establish the real or illustrative setting, materials, lighting, period/scientific context and intended tone. Use these to choose color relationships, value/saturation range, typography and production technique. Record the reason and relevant evidence. A subject can support several treatments depending on audience and context.

References have stated roles: material, lighting, depth, composition, typography, motion or palette. Record what each contributes and what remains undecided. A palette role is selected explicitly; other roles do not silently provide color values.

Evaluate actual style frames at viewing size. Ask what draws attention, whether foreground/subject/background separate, whether material/light treatment supports the atmosphere, and whether text remains legible. Adjust the treatment from what is visible. Rich or restrained color can work when it serves the scene.

Prepare layers, views, pose controls and coverage required by the shot plan. Choose vector illustration, generated/painted layers, supplied material or another method according to the intended result and provenance. A flattened image has different animation/editing limits from layered source; record them honestly.

Type and caption surfaces follow the project treatment and applicable user requirements. Load the chosen licensed fonts and measure actual glyphs/layout against destination controls. Layout values belong to that format/project, with any carried preference identified by source.
