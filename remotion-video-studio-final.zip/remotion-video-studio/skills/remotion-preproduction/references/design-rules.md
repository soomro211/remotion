<!-- studio-reference:1.3.0 -->
Studio production defaults: [current workflow and asset rules](../../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Design rules (for custom looks)

Use these when extending the Cut Paper art direction or fulfilling a user-requested custom look.
Cut Paper is the only packaged theme; a new background or visual does not require another theme.

## Customization checklist (so it is not the stock version)
- Change the accent from the card default to one pulled from the brand or concept.
- Choose a distinctive display font, not just the body font enlarged.
- Add one signature device used 3+ times (a line that draws, a shape that morphs, a camera move).
- Add one imperfection or texture if it suits (grain, paper, subtle halftone), applied consistently.

## Color rules
- Max 5 colors. 60/30/10: background / surface+text / accent.
- Accent appears only where attention should go. If everything is accent, nothing is.
- Contrast: body text 7:1 or better on its background; large text 4.5:1 minimum. Check with a formula, do not eyeball.
- Dark backgrounds: avoid pure `#000` and pure `#FFF` text; use `#0B0B0C` and warm off-white to reduce harshness.
- Gradients only when they are a deliberate material (single hue family, 2 stops, subtle). Never a rainbow or default purple-to-blue.

## Typography rules
- Scale on a ratio (1.25 to 1.5). Example 1080p: caption 36, body 48, subtitle 64, title 96-160, hero numerals up to 320.
- Display: tight tracking (-1% to -4%), line-height 0.95-1.1. Body: line-height 1.3-1.5, tracking 0 to +1%.
- Max 2 families, max 3 weights. Use weight and size, not color, for hierarchy.
- Use `font-variant-numeric: tabular-nums` for counting numbers so they do not jitter.
- Line length for on-screen text: 2-4 words per line for headlines, max about 32 characters per caption line.
- Align to a baseline and an edge. Optical alignment for large type (pull punctuation and quotes outside the margin).

## Layout rules
- 8px spacing scale. Margins at least 6% of the short edge.
- 16:9: 12-column grid. 9:16: 6-column grid. 1:1 and 4:5: 6-column grid.
- 9:16 titles/labels: start with conservative margins of roughly the top 14%, bottom 22% and about 6% on the sides.
  Subtitles use the studio's separate lower lane: at 1080x1920, x=80, y=1500, w=890, h=148,
  with 272px below the plate. Do not apply the larger title margin to captions. Verify the
  actual destination UI and adjust for observed overlaps.
- One dominant element per scene occupying a clear focal region; others subordinate by size and contrast.
- Use negative space deliberately; 30-50% of a frame empty is normal and reads premium.

## Imagery and UI
- Real screenshots and recordings of the real product, cropped and framed purposefully (device frames optional and consistent).
- When showing UI, animate what the user does (click, type, result), not a floating screenshot.
- Icons: one set, one stroke weight. Illustrations: one style.
- Never fabricate logos, customers, testimonials, stats or UI. Mark any placeholder clearly in the plan.
