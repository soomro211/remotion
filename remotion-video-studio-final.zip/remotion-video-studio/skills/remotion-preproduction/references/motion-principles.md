# Motion decisions

Process: [decision architecture](../../video-director/references/current-workflow.md).

Motion communicates an action, relationship, change or editorial emphasis. Choose its behavior for that purpose and for the physical/illustrative model. Camera holds and motion are both available. Decide how outgoing and incoming focus connect using [camera/continuity](../../video-director/references/camera-and-continuity.md).

Prepare articulated parts and necessary contact ranges during project asset production. Frame-driven timing makes playback deterministic. Select easing and durations from the intended movement; test readable preparation, action and settling at actual speed.

Where relevant, link wheels/foot phase to distance, use explicit hand/item anchors and respect joint reach/hinges. Extend layers for the whole camera view. Caption timing remains tied to speech independently of visual motion.

Inspect stills for geometry/contact/coverage and moving sequences for perceived action and joins. Record each kind of evidence separately. Implementation guidance is available in [Remotion markup](../../remotion-markup/SKILL.md).
