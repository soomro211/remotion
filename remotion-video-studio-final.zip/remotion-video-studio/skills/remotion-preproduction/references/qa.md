# Plan audit and build QA

## Plan audit (run before presenting)
Score 1-5. Anything below 4 must be revised and the change noted.
| Criterion | 5 means |
|---|---|
| Specificity | Every line, color and motion is tied to this brand/idea; passes swap test |
| Hierarchy | One clear hero per scene; 3x scale contrast; passes blur test |
| Rhythm | Varied scene lengths, beat or phrase aligned, signature moment given space |
| Distinctiveness | Customized beyond the stock direction; a designer would not call it a template |
| Brand fit | Uses real brand assets/voice; nothing invented |
| Legibility | Contrast and size verified; safe areas respected; reading time met |
| Sound-off clarity | Story clear with captions/visuals alone |
| Text purpose | Scene names hidden; optional opening title exits; labels justify their presence; no persistent chapter slogans |
| Visual explanation | Topic-specific scenery and animated cause/process/result, beyond stock layouts or camera drift |
| Subtitle continuity | Accurate phrases, two-line limit, stable lower safe lane, persistent backing and soft text changes |
Then run the five tests and the full `anti-slop.md` checklist. Record hits and fixes.

## Build QA (after each scene and before final render)
- Render stills at: first frame, entrance end, mid-hold, exit start, last frame. Each should look intentional.
- Text: no clipping, no overlap, no orphan words, readable at phone size (view at 25% scale).
  Wait for actual fonts; measure glyph bounds and rendered line count, not just container boxes.
  For DOM checks, exclude hidden/premounted scenes and elements whose own or ancestor
  opacity/visibility makes them invisible; they are not visible collisions. Wait for the authored composition and fonts before seeking test frames.
- Main headings: optional opening title leaves after its reading window; internal scene names never
  render. Most explanations have no main heading. No empty template header area remains.
- Labels: attached to the relevant action/object and cleared when no longer useful. Essential diagram
  labels/data may remain while needed. No frame counters, progress bars, debug text or filler.
- Theme: actual reference images inspected; material/type/palette preserved; backgrounds and visual
  objects suit this topic. The stock scene kit alone is not a finished explainer.
- Alignment: elements sit on the grid; margins consistent.
- Motion: check easing feel by scrubbing; no pops, jumps, or gaps where the frame empties; no layout shift when fonts load.
  Inspect several intermediate frames of every transition and the maximum camera position. No exposed
  image rectangles, clipped SVGs, path caps/joins, velocity resets or unintended duplicate objects.
  Motion must demonstrate the explanation, not only move a camera across a poster.
- Timing: scene durations match plan; total frames match target; hold after reading floor.
- Audio: levels, ducking, fades, no clipping; captions synced.
- Subtitles: exact spoken transcript, semantic phrases, at most two balanced lines, theme-matched
  backing above bottom controls. At 1080x1920, start with the lower plate at y=1500,
  height=148 (272px below it); do not reuse the larger title bottom margin for subtitles.
  Check actual destination controls and every phrase change before/during/after for flashing backing,
  jumps in plate dimensions, ghost text and baseline shifts. Plate stays mounted through short pauses
  and illustration cuts; verify beginning/middle/end sync against the actual voice source.
- Determinism: no CSS transitions, no unseeded randomness; render twice and compare a frame.
- Performance: render time reasonable; remove heavy blurs/shadows if slow.
- Compare against `video/plan.json` and update it if anything changed.
- Final: play it at full speed, sound off, then sound on when playback/listening is available. Record
  what was actually checked; do not claim listening when only measurements were possible.
- Verify the actual encoded MP4: complete duration/ending, frame count, resolution, fps, playable
  video/audio, assets and caption transitions. Measure final loudness (about -14 LUFS) and true peak
  (at or below -1 dBTP, normally target -1.5). Preserve the original user voice file and speed.
- Record results, evidence and limitations in `video/qa-report.md`. A template setting is not evidence.
