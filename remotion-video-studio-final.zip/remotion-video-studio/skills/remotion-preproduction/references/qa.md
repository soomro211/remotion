# Planning and review

Process: [decision architecture](../../video-director/references/current-workflow.md).

Review the current brief, source of carried requirements, factual scope and audience needs. Assess treatment, script comprehension, opening intent, reference roles and contextual art decisions. Use actual style frames during preparation and moving sequences during assembly.

[Creative review](../../video-director/references/production-quality.md) and engineering checks have independent evidence and statuses in the [QA record](../../video-director/assets/qa-report.template.md). A plan describes an intention; rendered output determines what was achieved.
