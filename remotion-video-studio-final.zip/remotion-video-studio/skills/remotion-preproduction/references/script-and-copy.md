# Script and copy

## Principles
- Write for the ear and the eye. Read every line aloud. If you stumble, rewrite.
- Specific over abstract: a concrete verb, a concrete object, a number or visible result.
- One claim per scene. Show proof on screen when you make the claim.
- Front-load. The most important word comes first on screen and in VO.
- Short words, active voice, contractions. No filler, no throat-clearing.
- Optional display copy supports the picture; it need not repeat VO. Subtitles are separate and must
  faithfully reproduce the spoken words. Do not put a main heading on every explanation scene.

## Hooks (first 2-3 seconds)
Pick one and commit:
1. **Result first:** open on the outcome ("Invoices that file themselves.") then show how.
2. **Demo first:** open on the product doing the impressive thing, no words yet.
3. **Specific pain:** a concrete, recognizable moment, not a generic question.
4. **Contrarian:** a claim that challenges a belief the audience holds, then proves it.
5. **Curiosity with payoff:** a visual or statement that creates a gap and resolves within the video.
Avoid: logo intros, "Introducing...", greetings, slow build-ups, and rhetorical questions the viewer answers "no" to.

## Structures by length
- **6-10s loop:** Hook, one payoff, brand. Loops cleanly (last frame leads into first).
- **15s:** Hook (0-3), value shown (3-11), CTA (11-15).
- **30s:** Hook (0-3), problem or context (3-8), solution demo (8-20), proof (20-26), CTA (26-30).
- **60s:** Hook, problem, solution, 2-3 feature beats each with proof, social proof or numbers, CTA.
- **90s+ explainer:** chapter it. Each chapter has its own mini-hook and resolves in under 25 seconds.

These CTA structures suit promotions. Educational explainers may end on a resolved visual payoff,
without a follow prompt or outro slogan. Their opening hook may also be visual; a title is optional.

## Word budgets
- VO: 2.5 words/second (150 wpm). Leave pauses: a 30s video holds about 60-65 spoken words, not 75.
- Optional headline/label: 2-7 words; normally at most about 12 words of non-caption display text visible.
  Most explanatory scenes use no main heading. A short opening title leaves after its readable intro;
  object labels appear for the relevant beat and clear when finished.
- Captions: max 2 lines, about 32-42 characters per line, appear in sync with speech.
- Reading time per text block: at least `max(0.8s, 0.25s x words)` after it has fully entered.

## Proof and numbers
- Every number has a source, date and unit. Round honestly ("about 40%" not "40.3%" unless precision matters).
- Show the number big, animate it counting with an ease-out, use tabular figures.
- Comparisons need a baseline ("from 6 hours to 20 minutes").
- If you do not have a real number, do not invent one. Use a qualitative proof shown on screen, or flag as a gap.

## CTA
- Optional for educational explainers; use only when the brief needs an action.
- One action, specific, low friction: "Try it free at acme.com/start" beats "Learn more".
- Visible for at least 1.5s, URL or handle large and legible, on a calm frame.
- Match the platform: link in bio, URL, search term, or QR only for screen contexts that support it.

## Voice and tone
- Define the brand voice in 3 words and 1 "never": e.g. "dry, precise, warm; never hypey".
- Keep one point of view (we / you) throughout.
- Humor only if it fits the brand and can be shown visually.

## Copy self-check (run on every line)
- Could only this brand say this? If not, rewrite.
- Any banned or suspect word from `anti-slop.md`? Remove.
- Is it a claim without proof? Add proof or cut.
- Can a word be cut without loss? Cut it.
- Does the line work with the sound off?

## Output format for the script
Table or list per scene: `scene #`, `on-screen text`, `VO`, `purpose`, `proof shown`, `source`.
