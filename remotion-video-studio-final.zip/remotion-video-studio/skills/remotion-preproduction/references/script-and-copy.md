# Speech and visual explanation

Process: [decision architecture](../../video-director/references/current-workflow.md).

Use [scriptwriting](../../video-scriptwriting/SKILL.md) to define scope, speakable language and causal clarity for the current audience. The opening, structure and ending follow the purpose. Keep narration paragraphs separate from the shot list and exact subtitles separate from display copy.

The treatment records how words, pictures and sound contribute. Evidence supports claims; illustrative scenarios are identified as such. Write a concrete handoff for approval, then align the actual supplied take before assigning final shot cues.
