<!-- studio-reference:1.3.0 -->
Studio production defaults: [current workflow and asset rules](../../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Storyboard, timing and platform specs

## Platform specs (verify current limits before final delivery)
| Platform / use | Canvas | fps | Typical length | Notes |
|---|---|---|---|---|
| YouTube, site hero, decks | 1920x1080 (16:9) | 30 | 20-90s | Narrated explainers default to captions; adapt to context |
| Reels / TikTok / Shorts | 1080x1920 (9:16) | 30 | 7-45s | Sound-off friendly, captions, hook in 1-2s, respect UI safe areas |
| LinkedIn, feeds | 1080x1350 (4:5) or 1080x1080 | 30 | 10-45s | Mostly sound-off, text-forward |
| X / Twitter | 1920x1080 or 1080x1080 | 30 | 10-45s | Hook fast, captions |
| In-product / loops | match UI | 30 or 60 | 5-15s | Seamless loop, small file |
Default codec h264 MP4. Use `Composition` ids like `Promo16x9`, `Promo9x16` when delivering multiple formats; plan the responsive layout rules up front (what reflows, what is hidden, what scales) rather than stretching.

## Pacing by purpose
- Social hook video: cut or major change every 1.5-3s, hook by 1s.
- Product promo: scene length 2-4s, one proof moment held 3-5s.
- Explainer: scene length 4-8s, each chapter resolves cleanly.
- Brand film: longer holds, fewer elements, music-led.

## Scene card (one per scene)
```
Scene N — <name>            Time: 0.0-3.0s   Frames: 0-89   Duration: 90f
Purpose:           what this scene must make the viewer understand/feel
Hero element:      the one dominant thing
Supporting:        secondary items (max 3)
Layout:            grid placement (cols/rows), alignment, margins
Background:        color/texture/camera layer behavior
Text on screen:    optional title/labels, purpose and appearance/removal cue; [] is normal
Subtitles:         exact spoken phrases, source-relative timing, stable lower safe lane
VO:                exact line (or none)
Entrance:          which element, motion type, frames, easing token
Hold:              what has subtle life, duration
Exit / transition: type, frames, overlap
Camera:            push/pan/parallax values
Continuity:        shared objects, transition reason, camera overscan requirements
Sound:             hit/music cue
Capability:        none | maps | captions | 3D | chart | Lottie | video clip
Proof/source:      fact shown and its source
```

## Storyboard table (summary view)
| # | Time | Frames | Visual | Text | VO | Motion | Transition |
|---|---|---|---|---|---|---|---|

## Timing math
1. `frames = seconds x fps`. Round to whole frames.
2. Per scene: `from` (start frame) and `durationInFrames`.
3. With a `TransitionSeries`, total = sum(scene durations) - sum(transition durations).
4. Check: the encoded frame count matches the final authored timeline (within one frame).
   Separately check the requested length and explicit user tolerance; a draft target is not an
   instruction to force the prerecorded voice into a 0.1-second window.
5. Reading floor: `max(0.8s, 0.25s x words)` after the text has fully arrived.
6. Music: `beatFrames = (60 / BPM) x fps`. Snap cuts and hits to multiples when possible.
7. Voiceover: draft with natural breathing room. Replace estimates with actual source-relative
   speech boundaries; do not append extra silence to every scene of an unchanged continuous take.
8. Loops: the final frame must visually lead into frame 0.
9. Check the requested duration and explicit tolerance. A prerecorded take decides speech timing;
   do not truncate or speed up the voice to force a round duration. Do not invent duration tolerance.
10. Scene names are internal editing metadata. Main headings are not required per scene. Plan an
    optional brief opening title and useful object labels with exits; end on a visual payoff.

## Animatic check (before building polish)
List every scene with its duration and the first and last frame description. Read the
list as a rhythm: does the pacing vary, does the hook land in 3s, is the longest scene the most important one?

## Multi-format delivery
If 16:9 and 9:16 are both needed, decide per scene: reflow (re-layout), crop (re-frame), or replace (different shot). Do not scale a landscape layout into portrait. Keep one shared set of tokens and a layout function per aspect ratio.
