# Storyboard and source timing

Process: [decision architecture](../../video-director/references/current-workflow.md).

Keep narration paragraphs and visual shots separate. A shot records purpose, subject action, framing, camera, starting/ending focus, outgoing connection and relevant spoken cues. Rough storyboards/motion blocks can test the idea before final artwork. Prepare actual layers/poses/coverage before final assembly.

After actual speech alignment, assign shot start/duration in frames. A narration cue may occur within a shot or be shared by several shots. For `TransitionSeries`, composition duration is the sum of sequence durations minus overlaps; preserve the continuous voice/caption timeline independently. See [camera/timing implementation](../../video-director/references/camera-and-continuity.md).

Choose dimensions, frame rate and delivery duration from the brief and platform. Verify actual encoded frames/duration and any explicit user tolerance. Recorded speech remains intact unless an edit is authorized. Resolve an actual conflict rather than forcing round timing by changing the take.
