---
name: remotion-sound-design
description: Sound design for Remotion videos. Use whenever a video needs sound effects, UI sounds, whooshes, risers, impacts, music bed, voiceover ducking or a final audio mix, or when existing audio sounds cheap, harsh, too loud, off-sync or meme-like. Plans a cue sheet from the storyboard, generates or sources clean sounds, syncs them to exact frames, mixes to loudness targets, and audits the result.
version: 1.0.0
---

<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Remotion Sound Design

Resolve this skill's installed `scripts/` directory from this file. Examples using
`python3 scripts/...` refer to that directory, not a new video project's scripts.
Keep command input/output paths relative to the project root or use absolute paths.

Bad video sound is almost never about missing effects. It is too many sounds, the
wrong sounds, thin or harsh sounds, sounds a few frames late, clipping, and levels
that fight the voice. Good sound design is fewer, better, exactly-synced sounds from
one consistent family, mixed under a clear hierarchy.

**Principles**
1. Sound supports the picture. Every sound must mark a real visual event.
2. Hierarchy: voiceover > key hit > music > UI sounds > texture. Never let a lower layer mask a higher one.
3. Silence is a tool. A beat of quiet before the signature moment beats another effect.
4. One sound family per video (same palette, same brightness, same reverb space).
5. Layer and shape: transient (the click), body (the weight), tail (the space). Thin single-layer sounds sound cheap.
6. Sync is everything: land on the exact frame, or at most one frame early. Never late.
7. Never clip. Final mix about -14 LUFS integrated, true peak at or below -1 dBTP.
8. No meme sounds, no unlicensed audio, unless the brand is intentionally a meme and the license is clear.

Files (read at the step that needs them):

| File | Read at |
|---|---|
| `references/why-it-sounds-bad.md` | Step 0 and Step 7. Always. |
| `references/sound-design-principles.md` | Steps 1-3 |
| `references/remotion-audio.md` | Step 5 |
| `references/mixing-and-loudness.md` | Step 6 |
| `references/sources-and-licensing.md` | Step 2 |
| `scripts/synth_sfx.py` | Step 2 (generate a clean starter library) |
| `scripts/mix_preview.py` | Steps 4 and 6 (place sounds on frames, duck music, emit cue list) |
| `scripts/audit_audio.py` | Step 7 (loudness, peak, clipping, click checks) |
| `assets/SfxTrack.tsx`, `assets/example-cues.json` | Step 5 |

## Workflow

### Step 0: Sound brief
From `VIDEO_PLAN.md` (or the user), pin down:
- Voiceover? Music? Sound-on or mostly sound-off platform? (Always design so it also works muted.)
- Motion personality and theme (Crisp, Smooth, Playful, Cinematic; or the chosen visual theme). Pick the **sound palette** from `references/sound-design-principles.md`.
- Final delivery: platform and loudness target (default about -14 LUFS, TP <= -1 dBTP).
Write the brief in 4 lines at the top of the cue sheet.

### Step 1: Cue sheet (what deserves a sound)
Make a table from the storyboard, one row per sound:
`# | frame | event | sound type | layer | level | note`
Rules for choosing cues:
- Give sound to: the hero entrance, the landing/impact of the signature moment, scene transitions that change topic, key number reveals, UI clicks that the viewer should notice, CTA.
- Do not give sound to: every fade, ambient drift, every line of text, constant motion. If three things move together, one sound covers them.
- Density: at most about one cue per 0.75s on average; at most 2 simultaneous; allow rapid UI sequences (typing, ticks) only when the visual is rapid.
- With voiceover: place hits in pauses, keep whooshes short and away from key words, keep everything 6+ dB under the voice.
- Mark the signature moment and design its sound as a small combo (riser into impact, or impact plus chime), not a single sample.

### Step 2: Get clean sounds
Order of preference:
1. **Generate** with `scripts/synth_sfx.py`: `python3 scripts/synth_sfx.py --out public/sfx`. It builds a layered starter library (whooshes, impacts, pops, clicks, ticks, keys, risers, chimes, sparkle, paper, chalk, typing, blips) with variants and a `manifest.json` of sync anchors and recommended volumes. Adjust presets or params for the palette (pitch, length, brightness).
2. **Licensed library** (see `references/sources-and-licensing.md`) for realistic foley the synth cannot match (real doors, cloth, footsteps, ambiences). Record every source and license in `CREDITS.md`.
3. **AI text-to-SFX** if the user has an API/tool for it. Treat output as a raw sample: trim, EQ, normalize, check license terms.
Then customize: pitch chimes and dings to the music key, shorten tails, high-pass anything that does not need bass (80-150 Hz), pick 3+ variants for any sound used more than twice, and keep every sound's start at or near 0 ms.
Do not use the stock meme sounds from `remotion.media` (vine-boom, bruh and the like) unless the user explicitly wants that style.

### Step 3: Match palette to personality and theme
Use the table in `references/sound-design-principles.md`. Rule of thumb: crisp visuals get short dry sounds; smooth/editorial visuals get soft whooshes and long gentle tails; playful visuals get pitched pops and bright chimes; cinematic visuals get low impacts, risers and space.

### Step 4: Sync to frames
- For each cue choose the **visual frame** (the frame the thing lands, clicks or pops).
- Place with the anchor: `from = round((hitFrame / fps - anchor_ms / 1000) * fps)`. `anchor_ms` comes from `manifest.json`: impacts/pops/clicks anchor on their first transient; whooshes anchor on their loudest point (align with the frame of fastest motion, roughly 35-45% into an ease-out entrance); risers anchor on their end (that frame is the hit).
- Put it in a cue sheet JSON (see `assets/example-cues.json`) and run `python3 scripts/mix_preview.py cues.json --out preview.wav --emit src/sfxCues.ts`. This writes the preview mix and the Remotion cue list with exact `from` frames.
- If the sound feels late or loose, move it earlier by one frame, never later.

### Step 5: Integrate in Remotion
Read `references/remotion-audio.md`. Put audio files in `public/sfx/`, use `<Audio>` from `@remotion/media` with `staticFile`, drive timing from the generated cues (`assets/SfxTrack.tsx`), and keyframe music volume with `interpolate` for fades and ducking. Verify API details with `/remotion-docs`.

### Step 6: Mix
Read `references/mixing-and-loudness.md`. Set levels by role, duck music under voiceover, EQ so sounds do not mask the voice, keep it mono-compatible, and normalize the final render to the platform target with ffmpeg (`loudnorm`) while copying the video stream.

### Step 7: QA, then fix
1. Run `python3 scripts/audit_audio.py public/sfx/*.wav` (library health) and `python3 scripts/audit_audio.py out/final.mp4 --mix` (final mix).
2. Walk the "why it sounds bad" table in `references/why-it-sounds-bad.md` and fix every hit.
3. Listen in three conditions: headphones, laptop/phone speaker, and at low volume. Check the first 3 seconds, the signature moment and the CTA twice.
4. Mute test: does the video still make sense with no sound? Solo test: does the sound-only track feel rhythmic and intentional?
5. State honestly what was verified by measurement versus by ear. If you cannot listen, say so and give the user the listening checklist.

### Deliverables
`public/sfx/*.wav`, `src/sfxCues.ts`, `SfxTrack.tsx` wired into the composition, `CREDITS.md`, the cue sheet, and a short note listing levels and anything the user should check by ear.

## Done means
- Every sound maps to a visual event and lands on the exact frame.
- No clipping, true peak <= -1 dBTP, integrated loudness about -14 LUFS, voice clearly intelligible.
- One consistent sound family, with variants so repeats do not sound mechanical.
- All sources licensed and credited.
- The audit passes and the "why it sounds bad" checks are clear.
