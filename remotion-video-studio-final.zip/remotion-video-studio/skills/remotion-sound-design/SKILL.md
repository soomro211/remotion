---
name: remotion-sound-design
description: "Sound design for Remotion videos. Use whenever a video needs sound effects, UI sounds, whooshes, risers, impacts, music bed, voiceover ducking or a final audio mix, or when existing audio sounds cheap, harsh, too loud, off-sync or meme-like. Plans a cue sheet from the storyboard, generates or sources clean sounds, syncs them to exact frames, mixes to loudness targets, and audits the result."
version: 1.0.0
---

# Sound design

Process: [decision architecture](../video-director/references/current-workflow.md).

Choose narration, ambience, music, effects or silence from the film's purpose and treatment. Record why sounds help the actual action/editorial intent. Author cue times after visual timing and verify synchronization. Source/generate needed project audio with provenance; the optional synthesis tool creates technical sample sounds when explicitly chosen.

`video-director/scripts/auto_sfx.py` emits only authored file/level events; it does not select a sound by theme or scene index. Review the mix for intelligibility and intended impact. Use a verified timeline-aligned mix to replace rendered audio once in final mastering.

Retain original speech unless an edit is authorized. Measure encoded loudness/true peak against the chosen delivery target and inspect clipping/sync. Measurement and listening are separate review evidence. See [delivery](../video-director/references/delivery-workflow.md) and the available sound scripts/references as needed.
