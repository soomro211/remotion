<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Mixing and loudness

## Targets
- Final: about -14 LUFS integrated, true peak <= -1.0 dBTP, loudness range <= 12 LU. Most social platforms normalize to a similar level; confirm the platform's spec for the project.
- Voiceover: the loudest consistent element. Roughly -16 to -14 LUFS on its own, peaks about -6 dBFS.
- Music: about 12-18 dB under the voice while speaking (start at volume 0.15-0.25, duck 8-10 dB under VO); lifts into gaps and the intro/outro.
- SFX peaks (relative to full scale): impacts -8 to -6, whooshes -14 to -12, chimes -16 to -14, pops -16, clicks -18, ticks/keys -22 to -20. `manifest.json` already holds the matching Remotion `volume`.

## EQ roles
- High-pass SFX at 80-150 Hz unless they are deliberate low impacts (then 30-40 Hz).
- Keep the 1-4 kHz speech band clear when voice is playing: move SFX into pauses, lower them, or choose darker/brighter variants.
- Cut mud (200-400 Hz) from stacked layers; gentle high shelf for air only when the family sounds dull.
- Tails low-passed around 5-8 kHz to avoid hiss.

## Dynamics and space
- Normalize the library low (-3 dBFS) and set level per role in the mix. Do not push everything to 0 dBFS.
- Do not use heavy limiting to be loud. If the mix clips, lower the SFX/music, not the voice.
- Reverb: one shared space per video. Short (0.2-0.6 s) for UI, longer (0.9-1.5 s) for cinematic hits; keep wet 10-30%.

## Checking
```bash
# loudness + true peak of a render
ffmpeg -nostats -i out/video.mp4 -vn -af ebur128=peak=true -f null - 2>&1 | tail -12
# or: python3 scripts/audit_audio.py out/video.mp4 --mix
```
Two-pass normalize to -14 LUFS without touching the picture:
```bash
ffmpeg -i out/video.mp4 -vn -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2> m.txt
# read input_i, input_tp, input_lra, input_thresh, target_offset from m.txt, then:
ffmpeg -i out/video.mp4 -c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=<input_i>:measured_TP=<input_tp>:measured_LRA=<input_lra>:measured_thresh=<input_thresh>:offset=<target_offset>:linear=true -c:a aac -b:a 256k out/video-norm.mp4
```
For supplied narration, preserve the original bytes, content, start and speed unless the user
authorizes an edit. Analysis/decoded copies may be temporary. Prefer the verified uncompressed
full-timeline mix as the final audio master to avoid an extra AAC generation.

For effects or explicitly authorized source edits only, other helpers include: trim leading silence `-af silenceremove=start_periods=1:start_threshold=-50dB`; fade out `-af afade=t=out:st=<s>:d=0.01`; mono check `-af pan=mono|c0=0.5*c0+0.5*c1`.

## Listening checklist
- Headphones, laptop speaker, phone speaker, and low volume.
- Is the voice always clear? Does any effect jump out as louder than its importance?
- Do hits land exactly on the picture? Is the signature moment clean and a little quieter before it than after?
- No clicks at starts/ends, no clipping, no hiss in tails, no sudden loudness change at cuts.
