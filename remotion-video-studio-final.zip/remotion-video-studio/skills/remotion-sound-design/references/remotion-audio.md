<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Remotion audio integration

Verify current API with `/remotion-docs` (and `remotion-markup/audio.md` and `sfx.md`). Needs `npx remotion add @remotion/media`.

## Basics
```tsx
import { Audio } from "@remotion/media";
import { staticFile } from "remotion";

<Audio src={staticFile("sfx/impact-light-01.wav")} from={30} volume={0.56} />
```
- `from`: frame to start playing (delays the audio). `trimBefore`: frames to skip at the start of the file (use when `from` would be negative). `durationInFrames`: stop early. `volume`: 0-1, or keyframed via `interpolate`. `playbackRate`: speed/pitch (for variation use 0.97-1.04). `loop`, `muted` also exist.
- Keep audio in `public/` and use `staticFile`. Prefer local files over remote URLs for reliable renders.
- Place SFX inside the scene `<Sequence>` they belong to, or use one global `SfxTrack` driven by absolute frames.

## Generated cue list
`scripts/mix_preview.py cues.json --emit src/sfxCues.ts` outputs `{file, from, trimBefore, volume}` per cue with the anchor offset already applied. Render them all with `assets/SfxTrack.tsx` inside the root composition. If the video is split into `<Sequence>`s, keep cues global (absolute frames) outside the sequences so offsets stay correct.

## Music with fades and ducking
```tsx
const frame = useCurrentFrame();
const { fps, durationInFrames } = useVideoConfig();
// voRanges: [startFrame, endFrame] where voiceover is speaking
const duck = (f: number, ranges: [number, number][], base = 0.2, ducked = 0.07, atk = 3, rel = 12) => {
  let v = base;
  for (const [a, b] of ranges) {
    const down = interpolate(f, [a - atk, a], [base, ducked], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
    const up = interpolate(f, [b, b + rel], [ducked, base], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
    if (f >= a - atk && f < b) v = Math.min(v, down);
    else if (f >= b && f <= b + rel) v = Math.min(v, up);
  }
  return v;
};
const fadeIn = interpolate(frame, [0, 0.4 * fps], [0, 1], { extrapolateRight: "clamp" });
const fadeOut = interpolate(frame, [durationInFrames - 1.2 * fps, durationInFrames], [1, 0], { extrapolateLeft: "clamp" });
<Audio src={staticFile("music.mp3")} volume={duck(frame, voRanges) * fadeIn * fadeOut} />
```
Get `voRanges` from the voiceover (known line timings, or silence detection; see `remotion-markup/silence-detection.md` and `voiceover.md`).

## Voiceover timing
Set scene durations from the real audio length (calculateMetadata) plus 0.3-0.6 s of breathing room, then place cues after that is final. Re-run the cue sheet after any timing change.

## Gotchas
- Do not rely on CSS or HTML audio elements; use Remotion's `<Audio>`.
- Cues placed before frame 0 need `trimBefore`; the generated list handles it.
- Studio preview can differ slightly from the render; judge sync on a rendered MP4.
- Normalize loudness after rendering (see mixing file); Remotion does not loudness-normalize.
