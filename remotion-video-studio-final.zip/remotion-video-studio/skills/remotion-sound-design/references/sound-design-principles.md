<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Sound design principles for video

## Anatomy of a good sound
- **Transient** (first 1-20 ms): the attack that locks to the picture. Short, bright, clean.
- **Body** (20-300 ms): the weight and character. Low-mid for impacts, mid for pops, noise band for whooshes.
- **Tail** (100 ms-2 s): the space. A short reverb (rt60 0.2-1.4 s) gives size; keep the tail low-passed (5-8 kHz) so it does not hiss.
- Add saturation to low hits so phones can hear the harmonics of the sub.

## Motion-to-sound map
| Visual event | Sound | Anchor |
|---|---|---|
| Panel/title slides in | `whoosh-soft` or `whoosh-fast` | peak on fastest-motion frame |
| Object slides out / exits | `whoosh-down` (shorter, quieter) | peak at mid-exit |
| Element lands / slams in | `impact-light`, `stamp` | first transient on landing frame |
| Signature reveal / logo hit | `riser-short` into `impact-heavy` | riser end on the hit frame |
| Scale pop, sticker, icon appears | `pop`, `pop-low` | first frame of scale-up |
| Button press, cursor click | `click`, `click-sharp` | cursor-down frame |
| Counter / list ticks | `tick` (vary pitch up with value) | each step frame |
| Typing | `typing` or `key` per character | per keystroke |
| Success, completion, CTA | `chime-success`, `ding` | frame it appears |
| Sparkle / highlight / reveal | `sparkle` | frame it begins |
| Paper, cut-out slide | `paper-slide` | mid-slide |
| Chalk or marker writing | `chalk-write` | first stroke frame |
| Terminal output | `blip`, `blip-arp`, `typing` | line appears |
| Error / wrong | `error` | frame it appears |

## Sound palettes (choose one per video)
| Personality / theme | Sound character | Library picks |
|---|---|---|
| Crisp (Blueprint, Terminal) | Short, dry, precise; blips, ticks, soft clicks; tiny whooshes | `blip`, `tick`, `click`, `whoosh-fast`, `typing`, `chime-success` |
| Smooth (Midnight Editorial, Swiss) | Soft whooshes, gentle tails, restrained low impacts, sparse | `whoosh-soft/long`, `impact-light`, `ding`, `riser-long` |
| Playful (Neo-Brutal, Riso) | Pitched pops, stamps, bright chimes, small stingers | `pop`, `stamp`, `sparkle`, `chime-success`, `whoosh-fast` |
| Tactile (Cut Paper, Chalkboard) | Physical textures, soft thumps, light bells | `paper-slide`, `chalk-write`, `pop-low`, `ding` |
| Cinematic / brand film | Low impacts, long risers, space, silence | `impact-heavy`, `riser-long`, `whoosh-long`, `sparkle` (sparingly) |

## Keep it musical
- Match chimes and dings to the music key (transpose by changing `notes` or `freq`).
- Land hits on beats or bars of the music when possible; `beat = 60 / BPM` seconds.
- Do not stack more than two "bright" sounds in the same half second.

## Variation and density
- Use 3+ variants of any sound used more than twice; add +/- 3-6% pitch (playbackRate 0.97-1.04) and +/- 1.5 dB volume.
- Roughly one cue per 0.75 s; two simultaneous maximum; leave 0.3-0.6 s of near-silence before the signature moment.
- Quiet sounds for frequent events (ticks, keys), larger sounds for rare ones (impact, riser).

## Shaping the generator
Edit `PRESETS` in `scripts/synth_sfx.py`: change `f0/f1` (sweep range, brighter or darker), `dur`, `rt60` and `wet` (space), `punch` (transient). Use `--only name --variants N` to regenerate one sound. Always re-run `audit_audio.py`.
