# Sound decisions and construction

Process: [decision architecture](../../video-director/references/current-workflow.md).

Choose sound from the actual scene, intended atmosphere and editorial purpose. A visible event can support a physical sound, a stylized emphasis or silence. The project defines the sound's role, source, level and cue; a named visual medium does not select its audio automatically.

A sample's attack, body and tail influence perceived contact, weight and space. Shape those properties for the action and mix. Align the meaningful transient with its authored visual cue and inspect the encoded result. Consider voice intelligibility, frequency masking, accumulated density and audible tails through listening when available.

The optional synthesizer exposes frequency, duration, envelope, reverberation and other controls. Choose/generate source sounds when useful and inspect/audit the results. `auto_sfx.py` emits explicit project file/level events; there is no theme palette, variant rotation or automatic cue quota.
