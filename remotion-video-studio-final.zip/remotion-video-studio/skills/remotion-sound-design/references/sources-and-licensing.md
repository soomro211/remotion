# Sources and licensing

Check the license of every file before use. Terms change; verify on the source page.

## Generate (best default)
`scripts/synth_sfx.py` produces original sounds with no license issues, consistent in tone and level.

## Free libraries (verify each file's license)
- Freesound.org: mixed licenses; prefer CC0, and CC-BY only if you add attribution. Avoid non-commercial licenses for commercial videos.
- Pixabay sound effects: free under the Pixabay content license; check current terms.
- Mixkit: free sound effects under its own license; check terms.
- Kenney.nl audio packs: CC0 game UI and impact sounds.
- Sonniss GDC game audio bundles: royalty-free; read the bundle license.
- YouTube Audio Library: for YouTube use; check the per-track rules.

## Paid libraries
Epidemic Sound, Artlist, Splice, Soundly/BOOM-style libraries: use when the project needs a large professional library; follow subscription terms for client work.

## AI text-to-sound
Tools such as ElevenLabs sound effects can produce samples from text. Treat the result as a raw sample: trim silence, EQ, normalize to -3 dBFS, check the provider's commercial terms.

## Music
Use licensed or original music only. Keep the license text and track ID. Do not use commercial tracks without rights.

## Memes and well-known sounds
Do not use famous clips, game sounds, TV sounds or "meme" packs unless the license is clear and the style calls for them.

## Record keeping
Create `CREDITS.md`: file, source URL, license, author, attribution text, date checked. Keep it with the project.

## Network note
In sandboxed environments the shell may not reach these sites. Ask the user to download needed files, or generate with the script.
