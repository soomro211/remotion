<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](../../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Why it sounds bad (symptom, cause, fix)

| Symptom | Likely cause | Fix |
|---|---|---|
| Harsh, fatiguing, "crunchy" | Clipping or limiter abuse; effects normalized to 0 dBFS then stacked | Normalize library to -3 dBFS, set volume per role, check true peak <= -1 dBTP, lower the sum not the master |
| Thin, tinny, "cheap" | Single-layer sound with no body or tail; only highs | Layer transient + body + tail; add low-mid weight; add a short reverb tail |
| Muddy, boomy on laptop/phone | Sub energy that small speakers cannot play, stacked lows | High-pass non-impacts at 80-150 Hz; use saturation so low hits have audible harmonics |
| Sounds late or "floaty" | Placed at the visual frame without the anchor offset; whoosh start aligned instead of peak | Use `anchor_ms`; whoosh peak on fastest-motion frame; move earlier by 1 frame, never later |
| Mechanical, repetitive | Same sample repeated | 3+ variants, pitch/volume jitter of a few percent, skip some repeats |
| Cluttered, exhausting | A sound on every motion | Cue sheet density rule; one sound per group of motions; leave silence before the signature moment |
| Voice is hard to understand | SFX/music masking 1-4 kHz, no ducking | Duck music 8-10 dB under VO, keep SFX 6+ dB under voice, move hits into pauses, shorten whooshes under words |
| Music too loud or pumping | No ducking or too fast release | Music about 12-18 dB under voice while speaking, attack 80 ms, release 400 ms |
| Clicks and pops | Sound starts or ends mid-waveform, cuts at a non-zero sample | Fade 0.3 ms in, 5-10 ms out; run `audit_audio.py` |
| Meme/cheesy feel | Vine-boom, bruh, stock "swoosh" packs | Use a designed palette; only meme sounds if the brand voice is meme and the license is clear |
| Inconsistent, "stitched together" | Sounds from different sources, brightness and reverb mismatch | One family: match brightness (EQ), reverb size and level, and loudness; generate from the same script |
| Different loudness between clips | Normalized by peak, not perceived level | Set volume by role (see mixing file), check with LUFS on the final |
| Mono/phasey in some players | Wide stereo with out-of-phase content | Check mono fold-down; keep the correlation above 0.2 |
| Sounds fine in studio, bad on phone | Mixed on headphones only | Check on a phone speaker; make sure key sounds have energy at 1-5 kHz |
| Emotional mismatch | Playful pops on a serious topic, heavy hits on gentle content | Choose the palette from the tone before choosing sounds |
