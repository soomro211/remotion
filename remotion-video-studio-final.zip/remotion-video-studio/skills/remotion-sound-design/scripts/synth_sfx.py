#!/usr/bin/env python3
"""Procedural sound-effect generator for video (48 kHz, 16-bit WAV).

Builds a designed starter library: whooshes, impacts, UI pops/clicks/ticks,
risers, chimes, sparkles, textures. Each sound is layered (transient + body + tail),
filtered, de-clicked and peak-normalised to -3 dBFS. A manifest.json records, for
every file, the sync anchor (ms) and a recommended Remotion volume.

Usage:
  python3 synth_sfx.py --out public/sfx                  # whole library
  python3 synth_sfx.py --out public/sfx --only whoosh-soft,impact-light --variants 4
  python3 synth_sfx.py --list
Requires: numpy, scipy.
"""
import argparse, json, os
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
rng = lambda seed: np.random.default_rng(seed)

# ---------- building blocks ----------
def taxis(d): return np.arange(int(d * SR)) / SR
def phase(freq): return 2 * np.pi * np.cumsum(freq) / SR
def _sos(kind, fc, order): return signal.butter(order, fc, btype=kind, fs=SR, output='sos')
def lp(x, fc, order=4): return signal.sosfilt(_sos('lowpass', min(fc, SR * .45), order), x, axis=0)
def hp(x, fc, order=4): return signal.sosfilt(_sos('highpass', fc, order), x, axis=0)
def bp(x, lo, hi, order=3): return signal.sosfilt(_sos('bandpass', [lo, min(hi, SR * .45)], order), x, axis=0)
def sat(x, drive=1.5): return np.tanh(x * drive) / np.tanh(drive)
def fade(x, in_ms=0.0, out_ms=5.0):
    x = x.copy(); n = len(x)
    fi, fo = int(SR * in_ms / 1000), int(SR * out_ms / 1000)
    if fi > 1: x[:fi] *= (0.5 - 0.5 * np.cos(np.linspace(0, np.pi, fi)))[(slice(None),) + (None,) * (x.ndim - 1)]
    if fo > 1: x[-fo:] *= (0.5 + 0.5 * np.cos(np.linspace(0, np.pi, fo)))[(slice(None),) + (None,) * (x.ndim - 1)]
    return x

def reverb(x, rt60=0.6, wet=0.25, predelay_ms=8, lp_fc=6000, seed=1):
    """Synthetic-IR reverb with a decorrelated tail per channel (adds width)."""
    chans = [x] if x.ndim == 1 else [x[:, 0], x[:, 1]]
    n_ir = int(rt60 * 1.1 * SR); pd = int(predelay_ms / 1000 * SR)
    out = []
    for i, c in enumerate(chans):
        t = np.arange(n_ir) / SR
        ir = rng(seed + i).standard_normal(n_ir) * np.exp(-6.91 * t / rt60)
        ir = lp(ir, lp_fc, 2); ir = np.concatenate([np.zeros(pd), ir]); ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
        cp = np.concatenate([c, np.zeros(len(ir))])
        out.append(cp + wet * signal.fftconvolve(cp, ir)[:len(cp)])
    return out[0] if x.ndim == 1 else np.stack(out, axis=1)

def sweep_noise(dur, fc_fn, bw_oct, env_fn, seed):
    """Noise filtered by a moving Gaussian band (STFT mask): smooth whoosh/riser core."""
    n = int(dur * SR); x = rng(seed).standard_normal(n); nper = 1024
    f, tt, Z = signal.stft(x, fs=SR, nperseg=nper, noverlap=nper * 3 // 4, boundary='zeros')
    fc = np.array([fc_fn(min(max(v / dur, 0), 1)) for v in tt])
    mask = np.exp(-0.5 * ((np.log2(f[:, None] + 1) - np.log2(fc[None, :])) / bw_oct) ** 2)
    _, y = signal.istft(Z * mask, fs=SR, nperseg=nper, noverlap=nper * 3 // 4)
    y = np.pad(y, (0, max(0, n - len(y))))[:n]
    return y * env_fn(np.arange(n) / SR / dur)

# ---------- sound generators (return mono or stereo float arrays) ----------
def whoosh(dur=.55, f0=250, f1=3500, pk=.45, bw=.8, seed=0):
    env = lambda u: np.where(u < pk, (u / pk) ** 2.0, ((1 - u) / (1 - pk)) ** 1.6)
    fc = lambda u: f0 * (f1 / f0) ** u
    pan = lambda u: (0.42 + 0.16 * u) * np.pi / 2 if f1 > f0 else (0.58 - 0.16 * u) * np.pi / 2
    n = int(dur * SR); u = np.arange(n) / n
    body = sweep_noise(dur, lambda v: fc(v) / 3.5, bw * 1.3, env, seed + 9) * .45
    L = sweep_noise(dur, fc, bw, env, seed + 1) + body
    R = sweep_noise(dur, fc, bw, env, seed + 2) + body
    st = np.stack([L * np.cos(pan(u)) * 1.35, R * np.sin(pan(u)) * 1.35], axis=1)
    return hp(st, 90, 2)

def impact(dur=1.2, f_start=150, f_end=48, rt60=.8, wet=.25, punch=.9, seed=0):
    t = taxis(dur); r = rng(seed)
    freq = f_end + (f_start - f_end) * np.exp(-t / .055)
    sub = np.sin(phase(freq)) * np.exp(-t / .42)
    body = lp(r.standard_normal(len(t)), 420, 3) * np.exp(-t / .13) * .55
    crack = hp(r.standard_normal(len(t)), 1800, 2) * np.exp(-t / .009) * punch
    snap = bp(r.standard_normal(len(t)), 500, 2500, 2) * np.exp(-t / .03) * .35
    x = sat(sub * 1.25 + body + crack + snap, 1.8)      # saturation adds harmonics so phones can hear the low hit
    x = fade(x, 0, 160)                                 # taper before the reverb so the tail never starts with a hard cut
    x = reverb(x, rt60, wet, 6, 5000, seed + 3)
    return hp(x, 28, 2)

def pop(f0=420, f1=980, tau=.045, dur=.2, seed=0):
    t = taxis(dur); r = rng(seed)
    freq = f0 + (f1 - f0) * (1 - np.exp(-t / .012))
    x = np.sin(phase(freq)) * np.exp(-t / tau) * (1 - np.exp(-t / .0008))
    x += .25 * np.sin(2 * phase(freq)) * np.exp(-t / (tau * .6))
    x += hp(r.standard_normal(len(t)), 3000, 2) * np.exp(-t / .002) * .25
    return lp(x, 8000, 2)

def click(kind='soft', seed=0):
    t = taxis(.07); r = rng(seed)
    if kind == 'soft':
        x = bp(r.standard_normal(len(t)), 1800, 5500, 2) * np.exp(-t / .004) + .5 * np.sin(2 * np.pi * 1500 * t) * np.exp(-t / .012)
    else:
        x = bp(r.standard_normal(len(t)), 3000, 9000, 2) * np.exp(-t / .0025) + .45 * np.sin(2 * np.pi * 2600 * t) * np.exp(-t / .006)
    return x

def tick(freq=2200, seed=0):
    t = taxis(.045); r = rng(seed)
    return (np.sin(2 * np.pi * freq * t) * np.exp(-t / .006) + .6 * bp(r.standard_normal(len(t)), 2500, 7000, 2) * np.exp(-t / .002))

def key(freq=180, seed=0):
    t = taxis(.09); r = rng(seed)
    thump = np.sin(2 * np.pi * freq * t) * np.exp(-t / .016)
    clack = bp(r.standard_normal(len(t)), 1500, 5000, 2) * np.exp(-t / .010)
    return .8 * thump + clack

def stamp(f_start=240, f_end=70, seed=0):
    t = taxis(.42); r = rng(seed)
    freq = f_end + (f_start - f_end) * np.exp(-t / .05)
    x = np.sin(phase(freq)) * np.exp(-t / .09) + lp(r.standard_normal(len(t)), 1300, 3) * np.exp(-t / .05) * .8
    x += hp(r.standard_normal(len(t)), 2500, 2) * np.exp(-t / .006) * .5
    return reverb(fade(sat(x, 1.6), 0, 110), .25, .12, 3, 4500, seed + 2)

def riser(dur=1.4, f0=180, f1=7000, seed=0):
    n = int(dur * SR)
    env = lambda u: 0.04 + 0.96 * u ** 2.2
    core = sweep_noise(dur, lambda u: f0 * (f1 / f0) ** u, .7, env, seed + 1)
    t = taxis(dur); u = t / dur
    tone = np.sin(phase(220 * (4.0 ** u))) * u ** 3 * .12 + np.sin(phase(440 * (4.0 ** u))) * u ** 3 * .06
    return hp(core + tone, 120, 2)

def _bell(f, tau, partials=((1, 1), (2.01, .42), (2.76, .25), (4.07, .12), (5.4, .06)), dur=1.2):
    t = taxis(dur); y = np.zeros_like(t)
    for k, (ratio, amp) in enumerate(partials):
        y += amp * np.sin(2 * np.pi * f * ratio * t) * np.exp(-t / (tau / (1 + .55 * k)))
    return y * (1 - np.exp(-t / .0015))

def chime(notes=(659.26, 830.61, 987.77), gap=.085, tau=.45, dur=1.5, seed=0):
    y = np.zeros(int(dur * SR))
    for i, f in enumerate(notes):
        b = _bell(f, tau, dur=dur - i * gap); o = int(i * gap * SR); y[o:o + len(b)] += b * (1 - .12 * i)
    return reverb(fade(y, 0, 260), .9, .22, 12, 7000, seed + 5)

def sparkle(n=14, dur=1.3, seed=0):
    r = rng(seed); y = np.zeros(int(dur * SR))
    scale = np.array([1046.5, 1174.7, 1318.5, 1568.0, 1760.0, 2093.0, 2349.3, 2637.0])
    for _ in range(n):
        f = r.choice(scale); st = int(r.uniform(0, .6) * SR); a = r.uniform(.25, 1)
        p = _bell(f, .16, partials=((1, 1), (2.0, .3), (3.0, .1)), dur=.7); end = min(len(y), st + len(p)); y[st:end] += a * p[:end - st]
    return reverb(fade(hp(y, 600, 2), 0, 220), 1.0, .3, 15, 9000, seed + 7)

def paper(dur=.45, seed=0):
    r = rng(seed); n = int(dur * SR); t = np.arange(n) / SR; u = t / dur
    env = np.sin(np.pi * np.clip(u, 0, 1)) ** 1.3
    x = bp(r.standard_normal(n), 1400, 7500, 2) * env * .8
    imp = (r.random(n) < 70 / SR) * r.uniform(.3, 1, n)
    x += hp(signal.lfilter([1, -.6], [1], imp), 1500, 2) * 1.2 * env
    return x

def chalk(dur=.9, seed=0):
    r = rng(seed); n = int(dur * SR); t = np.arange(n) / SR; u = t / dur
    mod = np.clip(lp(r.standard_normal(n), 22, 2) * 3.2 + .8, 0, 1.4)
    env = np.clip(u / .04, 0, 1) * np.clip((1 - u) / .12, 0, 1)
    return bp(r.standard_normal(n), 2200, 7500, 2) * mod * env * .8 + bp(r.standard_normal(n), 400, 1200, 2) * mod * env * .15

def blip(freq=1500, n=1, step=1.25, seed=0):
    out = []
    for i in range(n):
        t = taxis(.055); f = freq * step ** i
        sq = np.sign(np.sin(2 * np.pi * f * t)); x = lp(sq, 5200, 2) * np.exp(-t / .022)
        out.append(np.pad(x, (0, int(.03 * SR))))
    return np.concatenate(out)

def error(seed=0):
    t = taxis(.12); pulse = lp(signal.sawtooth(2 * np.pi * 115 * t), 900, 2) * np.exp(-t / .07)
    return np.concatenate([pulse, np.zeros(int(.06 * SR)), pulse * .9])

def typing(n=12, cps=13, seed=0):
    r = rng(seed); out = np.zeros(int((n / cps + .3) * SR)); pos = 0.0
    for _ in range(n):
        k = key(r.uniform(150, 230), int(r.integers(1e6))) * r.uniform(.6, 1); s = int(pos * SR)
        out[s:s + len(k)] += k[:len(out) - s]; pos += r.uniform(.6, 1.4) / cps
    return out

# ---------- presets ----------
# name, fn, params, category, anchor, target peak dBFS in the final mix, variants
PRESETS = [
    ('whoosh-soft', whoosh, dict(dur=.55, f0=250, f1=3500, pk=.45, bw=.8), 'whoosh', 'peak', -13, 3),
    ('whoosh-fast', whoosh, dict(dur=.3, f0=500, f1=7000, pk=.4, bw=.7), 'whoosh', 'peak', -13, 3),
    ('whoosh-long', whoosh, dict(dur=.95, f0=200, f1=4500, pk=.55, bw=.9), 'whoosh', 'peak', -13, 2),
    ('whoosh-down', whoosh, dict(dur=.5, f0=5000, f1=300, pk=.4, bw=.8), 'whoosh', 'peak', -14, 2),
    ('impact-light', impact, dict(dur=.9, f_start=160, f_end=55, rt60=.6, wet=.2, punch=.8), 'impact', 'start', -8, 3),
    ('impact-heavy', impact, dict(dur=2.0, f_start=130, f_end=38, rt60=1.4, wet=.3, punch=1.0), 'impact', 'start', -6, 2),
    ('stamp', stamp, dict(), 'impact', 'start', -9, 3),
    ('pop', pop, dict(f0=420, f1=980), 'ui', 'start', -16, 4),
    ('pop-low', pop, dict(f0=250, f1=620, tau=.06), 'ui', 'start', -16, 3),
    ('click', click, dict(kind='soft'), 'ui', 'start', -18, 4),
    ('click-sharp', click, dict(kind='sharp'), 'ui', 'start', -19, 3),
    ('tick', tick, dict(freq=2200), 'ui', 'start', -22, 4),
    ('key', key, dict(freq=180), 'ui', 'start', -20, 5),
    ('blip', blip, dict(freq=1500, n=1), 'ui', 'start', -18, 3),
    ('blip-arp', blip, dict(freq=1200, n=3, step=1.26), 'ui', 'start', -18, 2),
    ('error', error, dict(), 'ui', 'start', -14, 1),
    ('riser-short', riser, dict(dur=1.2), 'riser', 'end', -14, 2),
    ('riser-long', riser, dict(dur=2.6, f0=150), 'riser', 'end', -14, 2),
    ('chime-success', chime, dict(), 'chime', 'start', -14, 2),
    ('ding', chime, dict(notes=(1318.5,), tau=.6, dur=1.6), 'chime', 'start', -16, 2),
    ('sparkle', sparkle, dict(), 'chime', 'start', -18, 3),
    ('paper-slide', paper, dict(), 'texture', 'peak', -17, 3),
    ('chalk-write', chalk, dict(), 'texture', 'start', -18, 2),
    ('typing', typing, dict(n=12, cps=13), 'texture', 'start', -20, 3),
]
JIT = ('f0', 'f1', 'f_start', 'f_end', 'freq')

def finalize(x, peak_db=-3.0):
    x = hp(x, 20, 2)
    thr = 10 ** (-60 / 20) * np.max(np.abs(x))
    idx = np.where(np.max(np.abs(x.reshape(len(x), -1)), axis=1) > thr)[0]
    if len(idx): x = x[:idx[-1] + 1]
    x = fade(x, 0.3, 6)
    return x / (np.max(np.abs(x)) + 1e-12) * 10 ** (peak_db / 20)

def anchor_ms(x, how):
    m = np.max(np.abs(x.reshape(len(x), -1)), axis=1); pk = m.max()
    if how == 'peak':
        env = lp(m, 60, 2); return float(np.argmax(env) / SR * 1000)
    if how == 'end': return float(np.where(m > pk * .03)[0][-1] / SR * 1000)
    return float(np.where(m > pk * .03)[0][0] / SR * 1000)

def to_int16(x, seed=0):
    d = (rng(seed).random(x.shape) - rng(seed + 1).random(x.shape)) / 32768  # TPDF dither
    return np.clip(np.round((x + d) * 32767), -32768, 32767).astype(np.int16)

def build(out, only=None, variants=None, seed=11):
    os.makedirs(out, exist_ok=True); manifest = []
    for name, fn, params, cat, anchor, level, nv in PRESETS:
        if only and name not in only: continue
        for v in range(1, (variants or nv) + 1):
            r = rng(seed * 1000 + v * 17 + len(name)); p = dict(params)
            for k in JIT:
                if k in p: p[k] = p[k] * (1 + r.uniform(-.06, .06) * (1 if v > 1 else 0))
            p['seed'] = int(seed * 100 + v) if 'seed' in fn.__code__.co_varnames else None
            if p['seed'] is None: p.pop('seed')
            x = finalize(fn(**p)); fname = f"{name}-{v:02d}.wav"
            wavfile.write(os.path.join(out, fname), SR, to_int16(x, v))
            manifest.append(dict(file=fname, name=name, category=cat, duration_ms=round(len(x) / SR * 1000),
                                 anchor=anchor, anchor_ms=round(anchor_ms(x, anchor)), peak_dbfs=-3.0,
                                 target_peak_dbfs=level, volume=round(10 ** ((level + 3) / 20), 3),
                                 channels=1 if x.ndim == 1 else 2))
    json.dump(manifest, open(os.path.join(out, 'manifest.json'), 'w'), indent=1)
    return manifest

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--out', default='sfx'); ap.add_argument('--only')
    ap.add_argument('--variants', type=int); ap.add_argument('--seed', type=int, default=11); ap.add_argument('--list', action='store_true')
    a = ap.parse_args()
    if a.list:
        for n, _, p, c, an, lv, nv in PRESETS: print(f"{n:14s} {c:8s} anchor={an:5s} target={lv} dBFS variants={nv}")
        raise SystemExit
    m = build(a.out, set(a.only.split(',')) if a.only else None, a.variants, a.seed)
    print(f"wrote {len(m)} files + manifest.json to {a.out}")
