---
name: remotion-themes
description: "Cut Paper art direction, universal assets, source/motion recipes and a permanent versioned story-art archive. Use to design, inspect, reuse and preserve scenery, people, objects and animations."
version: 1.5.0
---

Production defaults: [current workflow](../video-director/references/current-workflow.md).

# Cut Paper

The sole theme is a matte, layered paper world. Open the [overview](themes/cut-paper/images/overview.png)
and native production street/interior/process/character images. Read [THEME.md](themes/cut-paper/THEME.md).
Preserve fibres, cut edges, cream rims, restrained shadows and palette/type relationships; design
settings for the story. Reference scenery is optional. No repeated title-card layout is required.

## Find and install useful foundations

Open the [visual catalog](themes/cut-paper/images/assets/catalog.html) and read
[anchors and core recipes](themes/cut-paper/assets/README.md), plus [universal object/motion recipes](themes/cut-paper/assets/UNIVERSAL.md).
Resolve the commands below from this installed skill's `scripts/` directory:

```bash
python3 /path/to/remotion-themes/scripts/assets.py list --search walking
python3 /path/to/remotion-themes/scripts/assets.py copy /path/to/video --assets person,journey,mug,car,arc-transfer,camera,captions
python3 /path/to/remotion-themes/scripts/asset_workflow.py search --query river
```

The selector installs the dependency closure under project `src/assets/cut-paper/`, protects local
edits and records versions/hashes. Use one `PaperStage` for shared SVG materials. Props have explicit
anchors/states; motion is driven by seconds and source distance. See each catalog entry's controls.
Charts need caller-supplied data; illustrative gauges/gears are not physical instruments/simulators.

## Create and preserve distinctive story art

Follow [asset-first production](../video-director/references/asset-first-workflow.md): brief → create/adapt
editable layers → inspect actual still/motion proofs → archive ready versions in this skill's
`themes/cut-paper/assets/library/` → pass readiness → assemble the film. Preserve topic-specific art
there too. Its [archive guide](themes/cut-paper/assets/library/README.md) explains search/restore/sync.
The updated skill set must work without the original video. Save later improvements as new reviewed
versions and merge growing installed archives before upgrades or ZIP/Git updates.

`init_video.py` copies the theme `kit/` and `entry/`, and local fonts. This is a scaffold, not a film.
Use the complete bundle's asset studio to inspect source-generated catalogs, gesture/physical-motion
studies and varied scene contexts. Existing plan authorization covers routine asset creation/review;
standalone asset work needs no narration or extra approval.
