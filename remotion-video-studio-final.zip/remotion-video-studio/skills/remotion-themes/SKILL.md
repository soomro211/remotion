---
name: remotion-themes
description: "Develop art direction from setting, material, light, context, tone and readability; use selected references for explicit roles and prepare original project artwork. Cut Paper construction guidance is available."
version: 3.0.0
---

# Art direction
Use [decision architecture](../video-director/references/current-workflow.md) and [contextual art direction](../remotion-preproduction/references/design-rules.md).

The project chooses palette, typography, composition and production method from its brief and evidence. References enter with explicit roles and limits. The package supplies construction knowledge, technical tools and optional licensed font resources.

For a requested paper medium, read [Cut Paper construction](themes/cut-paper/THEME.md). It describes material/depth possibilities rather than scenery or hue selection. Create and review artwork inside the project before assembly. The package contains no production visual inventory.
