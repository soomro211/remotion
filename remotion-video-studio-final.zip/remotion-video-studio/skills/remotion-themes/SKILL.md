---
name: remotion-themes
description: Art direction, reference images and reusable components for Cut Paper Remotion videos. Use when designing topic-specific scenery, motion, text and transitions, or inspecting theme previews. Kits are scaffolds rather than finished video templates.
version: 1.2.1
---

# Remotion Themes

| Theme | Use for | Look |
|---|---|---|
| `cut-paper` | explainers, how-things-work, facts, stories, education, any topic | full-bleed layered paper worlds; cut edges, soft shadows, warm colors, paper typography; smooth motion and restrained grain |

The Cut Paper folder has `images/` (original preview frames + overview, plus approved production stills for Cut Paper), `THEME.md` (palette, type, rules), `kit/` (TS components),
`entry/` (Remotion root), `generator/` (Python that regenerates the preview PNGs; needs `playwright` + Chromium; optional).

Cut Paper is the sole included theme. Use its material system for each topic, including paper
maps when useful; no separate map theme or automatic switch is included.

## Using the theme
First open the actual overview and representative images with an image viewer and read `THEME.md`.
For Cut Paper, also open `images/production-factory.png`, `production-steam.png`,
`production-harbor.png` and `production-cotton.png`: these show the current animated-scene
composition and subtitle treatment. Original heading-heavy previews demonstrate materials,
not a requirement to repeat that layout.
Follow [production quality defaults](../video-director/references/production-quality.md). Preserve the
material, type and palette relationships; create backgrounds and visual objects suited to the story.
The reference's hills, sun, sky, title slips and CTA are examples, not required scenery or layout.

`python3 ../video-director/scripts/init_video.py <project> --theme cut-paper` copies `kit/` to `src/theme/`, `entry/` to `src/`, and the shared
fonts to `public/fonts`. `PaperVideo` provide a timing/font scaffold from `video/plan.json`.
Build topic-specific scenes before delivery; the stock scaffold is not a finished explainer. Scene `type`
selects the scaffold layout (see `video-director/references/plan-schema.md`).

## Customizing (edit the copies in the project's `src/theme/`)
- Cut Paper: components `Piece` (any sheet of paper), `Slip` (title text on a slip, auto-sized), `Card`, `Tape`, `Sun`, `Cloud`, `Tree`, `Bird`,
  `PaperBackground` (variants `day` `sunset` `dusk` `mint`), `PaperWipe` (scene transition), `Texture`. Entrances: `slide` `pop` `stamp` `drop`.
  Motion is smooth at the composition frame rate by default; stepped stop motion is opt-in. Add scenery
  using `Piece`, custom SVG or layered assets; use camera continuity and motivated transitions.
- At 1080x1920, titles/labels use conservative margins (top 270, bottom 420, right 110 px).
  Subtitles use a separate lower plate: x=80, y=1500, w=890, h=148, with 272px below it.
  Do not force subtitles into the title margins; check actual controls and re-layout other formats.
  The approved production stills retain their historical higher subtitles; follow this current
  placement and the caption renderer for new videos.
- No persistent per-scene main headings. Scene names are internal; most `onscreen` arrays are empty.
  Optional opening titles are brief; object labels/data remain only while useful. Theme-matched smooth
  subtitles occupy a stable lower safe lane, with backing that persists through phrase changes.
- New scenery within the chosen material system is normal theme use and needs no extra approval.
  For a genuinely different art direction, read `remotion-preproduction/references/design-rules.md`.

## Regenerating preview images
`cd themes/cut-paper/generator && python3 paper_frames.py`. Output goes to `out/` (or `OUT_DIR=...`).
