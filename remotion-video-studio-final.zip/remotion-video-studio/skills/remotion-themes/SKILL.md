---
name: remotion-themes
description: Art direction, reference images and reusable components for Cut Paper Remotion videos. Use when designing topic-specific scenery, motion, text and transitions, or inspecting theme previews. Kits are scaffolds rather than finished video templates.
version: 1.4.0
---

<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Remotion Themes

| Theme | Use for | Look |
|---|---|---|
| `cut-paper` | explainers, how-things-work, facts, stories, education, any topic | full-bleed layered paper worlds; cut edges, soft shadows, warm colors, paper typography; smooth motion and restrained grain |

The Cut Paper folder has `images/` (current production frames, asset catalog/previews and clearly marked historical camera studies), `THEME.md` (palette, type, rules), `kit/` (TS components),
`assets/` (versioned reusable components and catalog), `entry/` (Remotion root), `generator/` (Python that regenerates the preview PNGs; needs `playwright` + Chromium; optional).

Cut Paper is the sole included theme. Use its material system for each topic, including paper
maps when useful; no separate map theme or automatic switch is included.

## Using the theme
First open `images/overview.png` and the current `production-street.png`,
`production-interior.png`, `production-process.png` and `production-character.png`.
Read `THEME.md`, then inspect the [reusable asset catalog](themes/cut-paper/assets/README.md).
Search before rebuilding common people, props, scenery, camera or captions. The images are
regenerated from the reviewed asset source; historical studies are explicitly separated.
Follow [production quality defaults](../video-director/references/production-quality.md). Preserve the
material, type and palette relationships; create backgrounds and visual objects suited to the story.
The reference's hills, sun, sky, title slips and CTA are examples, not required scenery or layout.

`python3 ../video-director/scripts/init_video.py <project> --theme cut-paper` copies `kit/` to `src/theme/`, `entry/` to `src/`, and the shared
fonts to `public/fonts`. `PaperVideo` provides a timing/font scaffold from `video/plan.json`.
Build topic-specific scenes before delivery; the stock scaffold is not a finished explainer. Scene `type`
selects the scaffold layout (see `video-director/references/plan-schema.md`).

## Create, review and archive story assets before assembly

Follow [asset-first production and permanent storage](../video-director/references/asset-first-workflow.md).
The main skill-set archive is `themes/cut-paper/assets/library/`: searchable topic/universal
packages with editable source, previews, review evidence and immutable versions. Create the
story's distinctive artwork in project `assets/packages/`, review it, then archive it here before
assembling scenes. Existing core geometry can be reused. Save both topic-specific and broadly
reusable art; a future agent must not need the originating video. The archive is included when
copying these skills or building the single ZIP. Merge installed/checkout libraries before upgrades.

Resolve `scripts/asset_workflow.py` from this skill directory:

```bash
python3 /path/to/skills/remotion-themes/scripts/asset_workflow.py search --query river
python3 /path/to/skills/remotion-themes/scripts/asset_workflow.py init /path/to/project
python3 /path/to/skills/remotion-themes/scripts/asset_workflow.py new /path/to/project --id river-cross-section
# Author sources and inspect proofs; complete metadata/review before archive.
python3 /path/to/skills/remotion-themes/scripts/asset_workflow.py archive /path/to/project --package assets/packages/river-cross-section/1.0.0 --requirement hero
python3 /path/to/skills/remotion-themes/scripts/asset_workflow.py check /path/to/project
```

Open the [saved-asset reference archive](themes/cut-paper/assets/library/README.md).
`new` creates a deliberately incomplete draft, never an automatic quality PASS. Isolated asset
proofs are allowed before scene assembly. Preserve the latest shared sources when reviewing the
finished film; runtime copies alone do not update the skill set.

## Select foundational components after plan approval

Resolve `scripts/assets.py` from this skill directory:

```bash
python3 /path/to/skills/remotion-themes/scripts/assets.py list --search walking
python3 /path/to/skills/remotion-themes/scripts/assets.py copy /path/to/project --assets person,journey,tree,camera,captions
```

Read [anchors, controls and recipes](themes/cut-paper/assets/README.md). Components install into
`src/assets/cut-paper/` with dependency closure and edit-preserving version metadata. They use one
shared material stage. Use distance-driven steps, planted feet, controlled joints/held items,
explicit source time and separate screen-space captions. Review actual motion after adaptation.
The catalog is a building-block library; author the explanation and scene staging for each topic.

## Customizing the scaffold (copies in the project's `src/theme/`)
- Cut Paper: components `Piece` (any sheet of paper), `Slip` (title text on a slip, auto-sized), `Card`, `Tape`, `Sun`, `Cloud`, `Tree`, `Bird`,
  `PaperBackground` (variants `day` `sunset` `dusk` `mint`), `PaperWipe` (scene transition), `Texture`. Entrances: `slide` `pop` `stamp` `drop`.
  Motion is smooth at the composition frame rate by default; stepped stop motion is opt-in. Add scenery
  using `Piece`, custom SVG or layered assets; use camera continuity and motivated transitions.
- At 1080x1920, titles/labels use conservative margins (top 270, bottom 420, right 110 px).
  Subtitles use a separate lower plate: x=80, y=1500, w=890, h=148, with 272px below it.
  Do not force subtitles into the title margins; check actual controls and re-layout other formats.
  The primary current production images use this placement. Historical studies are not layout defaults.
- No persistent per-scene main headings. Scene names are internal; most `onscreen` arrays are empty.
  Optional opening titles are brief; object labels/data remain only while useful. Theme-matched smooth
  subtitles occupy a stable lower safe lane, with backing that persists through phrase changes.
- New scenery within the chosen material system is normal theme use and needs no extra approval.
  For a genuinely different art direction, read `remotion-preproduction/references/design-rules.md`.

## Regenerating references

From the complete extracted bundle, prepare `examples/asset-studio`, render its current compositions,
then run `tools/build_asset_previews.py`. The complete extracted bundle contains `examples/asset-studio/README.md`; that developer harness is not required in a skills-only installation.
Keep source, metadata, rendered references and validation in the same release. The older Python
material generator remains a drawing utility; its stock layouts are not the current film reference.
