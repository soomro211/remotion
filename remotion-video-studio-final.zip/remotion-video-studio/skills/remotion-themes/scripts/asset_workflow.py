#!/usr/bin/env python3
"""Create, review, archive and restore self-contained story assets before scene assembly.

The default library lives inside this installed skill, so copying/updating the skills
preserves artwork without the original video projects. Python standard library only.
"""
import argparse
import hashlib
import html
import json
import math
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path
from urllib.parse import unquote

HERE = Path(__file__).resolve().parent
CORE = HERE.parent / 'themes' / 'cut-paper' / 'assets'
LIBRARY = CORE / 'library'
CHECKS = ('theme_fit', 'silhouette', 'scale', 'layers', 'edges_shadows', 'motion')
SLUG = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
SEMVER = re.compile(r'^\d+\.\d+\.\d+$')
ART = {'.svg', '.png', '.jpg', '.jpeg', '.webp', '.ts', '.tsx', '.js', '.jsx', '.glb', '.gltf', '.blend'}
PREVIEWS = {'.svg', '.png', '.jpg', '.jpeg', '.webp', '.mp4', '.webm', '.gif'}


def digest(body):
    return hashlib.sha256(body).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def encoded(data):
    return (json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True) + '\n').encode()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError('Preserving an existing metadata symlink: ' + str(path))
    handle, name = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(handle, 'wb') as stream:
            stream.write(encoded(data))
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def inside(root, relative):
    """Portable paths only; reject traversal and symlinks even when they point inward."""
    if not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative:
        raise ValueError('Unsafe relative asset path: ' + str(relative))
    parts = Path(relative).parts
    if Path(relative).is_absolute() or '..' in parts:
        raise ValueError('Unsafe relative asset path: ' + relative)
    target = root / relative
    for parent in (target, *target.parents):
        if parent == root.parent:
            break
        if parent.is_symlink():
            raise ValueError('Asset symlink is not portable: ' + relative)
    if not target.resolve().is_relative_to(root.resolve()):
        raise ValueError('Asset path escapes root: ' + relative)
    return target


def identity(key, version):
    if not SLUG.fullmatch(key) or not SEMVER.fullmatch(version):
        raise ValueError('Use a lowercase hyphenated asset ID and a numeric x.y.z version.')
    return key + '/' + version


def files_in(root):
    files = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root).as_posix()
        inside(root, relative)
        if path.is_file():
            if path.name.startswith('.env') or path.suffix in {'.pyc', '.zip'} or '__pycache__' in path.parts:
                raise ValueError('Exclude credentials, caches and archives from asset packages: ' + relative)
            files[relative] = path.read_bytes()
    return files


def resolve_reference(root, owner, reference):
    reference = unquote(reference.split('#')[0].split('?')[0])
    if not reference or reference.startswith('data:'):
        return
    if reference.startswith(('/', '\\')) or ':' in reference or '\\' in reference:
        raise ValueError('Asset depends on an external or absolute path: ' + reference)
    target = (owner.parent / reference).resolve()
    if not target.is_relative_to(root.resolve()):
        raise ValueError('Asset depends on the original project: ' + reference)
    variants = [target, *[target.with_suffix(s) for s in ('.ts', '.tsx', '.js', '.jsx')], target / 'index.ts', target / 'index.tsx']
    if not any(p.is_file() for p in variants):
        raise ValueError('Missing packaged dependency: ' + reference)


def validate_package(root, sealed=False):
    root = root.resolve()
    if not (root / 'asset.json').is_file():
        raise ValueError('Missing asset.json: ' + str(root))
    data = read(root / 'asset.json')
    if not isinstance(data, dict):
        raise ValueError('asset.json must be an object.')
    identity(data.get('id', ''), data.get('version', ''))
    if data.get('schema_version') != 1 or data.get('theme') != 'cut-paper':
        raise ValueError('Expected schema_version 1 and theme cut-paper.')
    for field in ('title', 'description', 'category', 'tags', 'anchor', 'controls', 'dependencies', 'canvas'):
        if not data.get(field):
            raise ValueError('Asset metadata is incomplete: ' + field)
    if data.get('scope') not in {'universal', 'topic'}:
        raise ValueError('Asset scope must be universal or topic.')
    if not isinstance(data['tags'], list) or not all(isinstance(x, str) and x.strip() for x in data['tags']):
        raise ValueError('Asset tags must be nonempty strings.')
    canvas = data['canvas']
    if not isinstance(canvas, dict) or any(type(canvas.get(k)) not in (float, int) or not math.isfinite(canvas[k]) or canvas[k] <= 0 for k in ('width', 'height')):
        raise ValueError('Asset canvas needs positive width and height.')
    provenance = data.get('provenance', {})
    if not isinstance(provenance, dict):
        raise ValueError('Asset provenance must be an object.')
    if provenance.get('origin') not in {'original', 'supplied', 'licensed'} or not provenance.get('creator') or not provenance.get('license'):
        raise ValueError('Record asset origin, creator and license.')
    if provenance.get('redistribution') != 'allowed':
        raise ValueError('Shared asset packages require recorded redistribution rights.')
    review = data.get('review', {})
    if not isinstance(review, dict) or not isinstance(review.get('checks'), dict):
        raise ValueError('Asset review/checks must be objects.')
    if data.get('status') != 'ready' or review.get('status') != 'passed':
        raise ValueError('Asset is not ready: review the actual sources/previews and record evidence first.')
    for check in CHECKS:
        row = review.get('checks', {}).get(check, {})
        if not isinstance(row, dict) or row.get('status') not in {'pass', 'not-applicable'} or not isinstance(row.get('evidence'), str) or not row['evidence'].strip() or re.match(r'^(pending|todo|tbd)\b', row['evidence'], re.I):
            raise ValueError('Missing asset review evidence: ' + check)
        if row.get('status') == 'not-applicable' and check != 'motion':
            raise ValueError('Only motion may be not-applicable, with a static-asset explanation.')
    files = files_in(root)
    if not any(Path(p).suffix.lower() in ART for p in data.get('source_files', [])):
        raise ValueError('Package actual editable artwork, not only notes or prompts.')
    for field, extensions in (('source_files', ART | {'.json', '.css'}), ('preview_files', PREVIEWS), ('review_files', None)):
        if not isinstance(data.get(field), list) or not data[field]:
            raise ValueError('Asset needs ' + field)
        for relative in data[field]:
            target = inside(root, relative)
            if relative not in files or not files[relative]:
                raise ValueError('Missing or empty packaged file: ' + relative)
            if extensions and target.suffix.lower() not in extensions:
                raise ValueError('Unsupported ' + field + ' file: ' + relative)
    if Path(data['preview_files'][0]).suffix.lower() in {'.mp4', '.webm'}:
        raise ValueError('The first preview must be a still image for the visual catalog; put motion proofs after it.')
    if not isinstance(data['dependencies'], dict) or not isinstance(data['dependencies'].get('packages', []), list):
        raise ValueError('Dependencies must declare a packages array.')
    packages = data['dependencies'].get('packages', [])
    if not all(isinstance(p, str) and p.strip() for p in packages):
        raise ValueError('Declared packages must be nonempty strings.')
    for relative, body in files.items():
        owner = root / relative
        if owner.suffix.lower() in {'.ts', '.tsx', '.js', '.jsx'}:
            text = body.decode('utf-8')
            # Literal imports, re-exports, require(), import() and new URL() dependencies.
            refs = re.findall(r'(?:\bfrom\s*|\bimport\s*|\brequire\s*\(\s*|\bimport\s*\(\s*|\bnew\s+URL\s*\(\s*)[\'\"]([^\'\"]+)[\'\"]', text)
            for ref in refs:
                if ref.startswith('.'):
                    resolve_reference(root, owner, ref)
                elif ref.startswith(('/', '\\')) or ':' in ref or not any(ref == p or ref.startswith(p + '/') for p in packages):
                    raise ValueError('Undeclared/nonportable asset import: ' + ref)
            if re.search(r'\bstaticFile\s*\(', text):
                raise ValueError('Package asset URLs as relative imports; staticFile() depends on the video project.')
        if owner.suffix.lower() == '.svg':
            import xml.etree.ElementTree as ET
            tree = ET.fromstring(body)
            for node in tree.iter():
                for name, value in node.attrib.items():
                    if name.split('}')[-1] in {'href', 'src'}:
                        resolve_reference(root, owner, value)
                for ref in re.findall(r'url\([\'\"]?([^\)\'\"]+)', ' '.join(node.attrib.values()) + (node.text or '')):
                    resolve_reference(root, owner, ref)
        if owner.suffix.lower() == '.css':
            text = body.decode('utf-8')
            for ref in re.findall(r'url\(\s*[\'\"]?([^\)\'\"]+)|@import\s+[\'\"]([^\'\"]+)', text):
                resolve_reference(root, owner, (ref[0] or ref[1]).strip())
        if owner.suffix.lower() == '.gltf':
            def resources(value):
                if isinstance(value, dict):
                    for key, item in value.items():
                        if key == 'uri' and isinstance(item, str):
                            resolve_reference(root, owner, item)
                        else:
                            resources(item)
                elif isinstance(value, list):
                    for item in value:
                        resources(item)
            resources(json.loads(body))
        if owner.suffix.lower() in {'.json', '.css', '.ts', '.tsx', '.svg', '.md'}:
            if re.search(rb'/(?:workspace|home|tmp/codex-remote-attachments)/|file://', body):
                raise ValueError('Absolute original-project path in package: ' + relative)
    hashes = {p: digest(b) for p, b in files.items() if p != 'asset.json'}
    if (sealed or data.get('files')) and data.get('files') != hashes:
        raise ValueError('Asset files changed after sealing; create a reviewed new version: ' + data['id'])
    data['files'] = hashes
    return data


def package_bytes(root, data):
    result = files_in(root)
    result['asset.json'] = encoded(data)
    return result


def preflight(target, bodies):
    if target.exists() and files_in(target) != bodies:
        raise ValueError('Version collision/local edits preserved; use a new version: ' + str(target))


def put_package(target, bodies):
    preflight(target, bodies)
    if target.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix='.asset-', dir=target.parent))
    try:
        for relative, body in bodies.items():
            dest = inside(temporary, relative)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(body)
        os.rename(temporary, target)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def library_packages(library):
    rows = []
    for path in sorted(library.glob('*/*/asset.json')):
        inside(library, path.relative_to(library).as_posix())
        data = validate_package(path.parent, sealed=True)
        if path.parent.relative_to(library).as_posix() != identity(data['id'], data['version']):
            raise ValueError('Archive folder/identity mismatch: ' + str(path))
        rows.append(data)
    return rows


def reindex(library):
    rows = library_packages(library)
    index = {'schema_version': 1, 'packages': [{k: d[k] for k in ('id', 'version', 'title', 'description', 'category', 'scope', 'tags', 'preview_files')} for d in rows]}
    write_json(library / 'index.json', index)
    cards = []
    for data in rows:
        base = identity(data['id'], data['version']) + '/'
        label = html.escape(data['title'] + ' · ' + data['version'])
        terms = html.escape(json.dumps(data['tags'] + [data['title'], data['description']]).lower(), quote=True)
        preview = html.escape(base + data['preview_files'][0], quote=True)
        cards.append('<article data-search="' + terms + '"><a href="' + base + 'asset.json"><h2>' + label + '</h2></a><img src="' + preview + '" alt="' + label + '"><p>' + html.escape(data['description']) + '</p><a href="' + html.escape(base + data['source_files'][0], quote=True) + '">Editable source</a></article>')
    page = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Saved Cut Paper story assets</title><style>body{background:#eee5d1;color:#24384a;font:17px/1.5 system-ui;margin:32px auto;padding:0 24px;max-width:1200px}input{font:inherit;padding:10px;width:90%;max-width:600px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;margin-top:24px}article{background:#fbf3e3;padding:20px;border:1px solid #cbbca3}img{width:100%;height:230px;object-fit:contain}h2{font-size:21px}a{color:#23666a}[hidden]{display:none!important}</style><h1>Saved story assets</h1><p>Self-contained, reviewed, versioned sources. No original video project is required. Read <a href="../README.md">asset recipes</a> and <a href="../../../../../video-director/references/asset-first-workflow.md">the asset-first workflow</a>.</p><input id="search" type="search" aria-label="Search saved assets" placeholder="Search subject, material, category…"><main>'''
    page += '\n'.join(cards) + '''</main><script>document.querySelector('#search').addEventListener('input',e=>{const q=e.target.value.toLowerCase().split(/\\s+/).filter(Boolean);document.querySelectorAll('article').forEach(c=>c.hidden=!q.every(w=>c.dataset.search.includes(w)));});</script></html>'''
    (library / 'catalog.html').write_text(page, encoding='utf-8')
    return index


def init(project):
    root = inside(project, 'assets')
    brief = root / 'brief.json'
    if not brief.exists():
        write_json(brief, {'schema_version': 1, 'reference_review': '', 'visual_direction': '', 'reuse_only_reason': '', 'requirements': [{'key': 'hero', 'kind': 'new', 'purpose': '', 'scene_ids': []}]})
    manifest = root / 'manifest.json'
    if not manifest.exists():
        write_json(manifest, {'schema_version': 1, 'assets': []})
    return root


def new_package(project, key, version, scope):
    relative = 'assets/packages/' + identity(key, version)
    root = inside(project, relative)
    if root.exists():
        raise ValueError('Package already exists; preserve it or choose a new version.')
    data = {'schema_version': 1, 'id': key, 'version': version, 'theme': 'cut-paper', 'title': key.replace('-', ' ').title(), 'description': '', 'category': '', 'scope': scope, 'tags': [], 'status': 'draft', 'canvas': {'width': 1080, 'height': 1920}, 'anchor': '', 'controls': [], 'dependencies': {'packages': []}, 'source_files': [], 'preview_files': [], 'review_files': [], 'provenance': {'origin': 'original', 'creator': '', 'license': '', 'redistribution': 'allowed', 'sources': []}, 'review': {'status': 'pending', 'checks': {k: {'status': 'pending', 'evidence': ''} for k in CHECKS}}}
    write_json(root / 'asset.json', data)
    for name in ('source', 'previews', 'review'):
        (root / name).mkdir()
    return root


def binding_record(project, requirement, key, version, bodies, origin):
    root = inside(project, 'assets')
    brief = read(root / 'brief.json')
    if requirement not in {r['key'] for r in brief['requirements'] if r['kind'] != 'core'}:
        raise ValueError('Add this non-core requirement to assets/brief.json before binding it: ' + requirement)
    record = read(root / 'manifest.json')
    row = {'requirement': requirement, 'id': key, 'version': version, 'origin': origin, 'package': 'packages/' + identity(key, version), 'shared': identity(key, version), 'manifest_sha256': digest(bodies['asset.json'])}
    previous = next((r for r in record['assets'] if r['requirement'] == requirement), None)
    if previous and previous != row:
        raise ValueError('Requirement already bound; explicitly edit the project manifest to select a new reviewed version.')
    record['assets'] = sorted([r for r in record['assets'] if r['requirement'] != requirement] + [row], key=lambda r: r['requirement'])
    return root / 'manifest.json', record


def archive(project, relative, requirement, library=LIBRARY):
    source = inside(project, relative)
    data = validate_package(source)
    canonical_relative = 'assets/packages/' + identity(data['id'], data['version'])
    if source != inside(project, canonical_relative):
        raise ValueError('Author packages under project/' + canonical_relative)
    bodies = package_bytes(source, data)
    target = inside(library, identity(data['id'], data['version']))
    library_packages(library)  # Refuse a damaged archive before any writes.
    preflight(target, bodies)
    record_path, record = binding_record(project, requirement, data['id'], data['version'], bodies, 'created')
    put_package(target, bodies)
    write_json(source / 'asset.json', data)  # Seal metadata after successful preservation.
    write_json(record_path, record)
    reindex(library)
    return target


def reuse(project, key, version, requirement, library=LIBRARY):
    source = inside(library, identity(key, version))
    data = validate_package(source, sealed=True)
    bodies = package_bytes(source, data)
    target = inside(project, 'assets/packages/' + identity(key, version))
    record_path, record = binding_record(project, requirement, key, version, bodies, 'reused')
    preflight(target, bodies)
    put_package(target, bodies)
    write_json(record_path, record)
    return target


def check(project, library=LIBRARY):
    root = inside(project, 'assets')
    if not (root / 'brief.json').is_file() or not (root / 'manifest.json').is_file():
        raise ValueError('Asset-first stage missing. Run asset_workflow.py init, create/review/archive assets, then check.')
    brief = read(root / 'brief.json')
    if brief.get('schema_version') != 1 or not brief.get('reference_review', '').strip() or not brief.get('visual_direction', '').strip():
        raise ValueError('Complete the asset brief: actual reference review and concrete visual direction.')
    requirements = brief.get('requirements', [])
    keys = [r.get('key') for r in requirements]
    if not keys or len(keys) != len(set(keys)) or not all(keys):
        raise ValueError('Asset requirements need unique nonempty keys.')
    if not any(r.get('kind') in {'new', 'adapt'} for r in requirements) and not brief.get('reuse_only_reason', '').strip():
        raise ValueError('Explain why existing art fully serves this story in reuse_only_reason; otherwise create bespoke assets.')
    rows = read(root / 'manifest.json').get('assets', [])
    if len({r['requirement'] for r in rows}) != len(rows) or any(r['requirement'] not in keys for r in rows):
        raise ValueError('Project asset bindings are duplicate or absent from the brief.')
    resolved = []
    for requirement in requirements:
        kind = requirement.get('kind')
        if kind not in {'new', 'adapt', 'reuse', 'core'} or not requirement.get('purpose', '').strip():
            raise ValueError('Complete asset requirement kind and purpose: ' + requirement['key'])
        if kind == 'core':
            install = read(inside(project, 'src/assets/cut-paper/asset-install.json'))
            ids = requirement.get('asset_ids', [])
            if not ids or not set(ids).issubset(install['selected']):
                raise ValueError('Install all selected core IDs for: ' + requirement['key'])
            for relative, expected in install['files'].items():
                target = inside(project / 'src/assets/cut-paper', relative)
                if not target.is_file() or digest(target.read_bytes()) != expected:
                    raise ValueError('Core asset changed; preserve the adaptation as a reviewed story package: ' + relative)
            resolved.append({'requirement': requirement['key'], 'core_ids': ids, 'version': install['version']})
            continue
        row = next((r for r in rows if r['requirement'] == requirement['key']), None)
        if not row:
            raise ValueError('Create/review/archive or restore the asset for: ' + requirement['key'])
        if kind in {'new', 'adapt'} and row.get('origin') != 'created':
            raise ValueError('New/adapted asset requirements need newly reviewed and archived source: ' + requirement['key'])
        shared_key = identity(row['id'], row['version'])
        if row.get('package') != 'packages/' + shared_key or row.get('shared') != shared_key:
            raise ValueError('Noncanonical asset binding: ' + requirement['key'])
        local = inside(root, row['package'])
        shared = inside(library, shared_key)
        for location in (local, shared):
            validate_package(location, sealed=True)
            if digest((location / 'asset.json').read_bytes()) != row['manifest_sha256']:
                raise ValueError('Asset manifest changed after binding: ' + requirement['key'])
        if files_in(local) != files_in(shared):
            raise ValueError('Project/shared asset copies differ: ' + requirement['key'])
        resolved.append({'requirement': requirement['key'], 'id': row['id'], 'version': row['version'], 'shared': shared_key})
    return {'status': 'PASS', 'schema_version': 1, 'stage': 'assets-ready-before-scene-assembly', 'assets': resolved, 'scope': 'Sources, review records, dependency paths, hashes and shared preservation checked. Artistic quality requires actual visual review.'}


def sync(source, destination):
    if source.resolve() == destination.resolve():
        return reindex(source)
    incoming = library_packages(source)
    library_packages(destination)
    planned = []
    for data in incoming:
        relative = identity(data['id'], data['version'])
        bodies = package_bytes(inside(source, relative), data)
        target = inside(destination, relative)
        preflight(target, bodies)
        planned.append((target, bodies))
    for target, bodies in planned:
        put_package(target, bodies)
    return reindex(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--library', type=Path, default=LIBRARY, help='authoritative skill assets/library; default is this installed skill')
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('init', 'check'):
        p = sub.add_parser(name); p.add_argument('project', type=Path)
        if name == 'check': p.add_argument('--report', help='optional report path relative to the project')
    p = sub.add_parser('new'); p.add_argument('project', type=Path); p.add_argument('--id', required=True); p.add_argument('--version', default='1.0.0'); p.add_argument('--scope', choices=['topic', 'universal'], default='topic')
    p = sub.add_parser('archive'); p.add_argument('project', type=Path); p.add_argument('--package', required=True); p.add_argument('--requirement', required=True)
    p = sub.add_parser('reuse'); p.add_argument('project', type=Path); p.add_argument('--id', required=True); p.add_argument('--version', required=True); p.add_argument('--requirement', required=True)
    p = sub.add_parser('search'); p.add_argument('--query', default=''); p.add_argument('--json', action='store_true')
    sub.add_parser('reindex')
    p = sub.add_parser('sync'); p.add_argument('--to-library', type=Path, required=True)
    args = parser.parse_args()
    library = args.library.resolve()
    if hasattr(args, 'project'): args.project = args.project.resolve()
    if args.command == 'init': result = {'assets': str(init(args.project))}
    elif args.command == 'new': result = {'package': str(new_package(args.project, args.id, args.version, args.scope))}
    elif args.command == 'archive': result = {'saved_in_skill_library': str(archive(args.project, args.package, args.requirement, library))}
    elif args.command == 'reuse': result = {'restored': str(reuse(args.project, args.id, args.version, args.requirement, library))}
    elif args.command == 'check':
        result = check(args.project, library)
        if args.report: write_json(inside(args.project, args.report), result)
    elif args.command == 'reindex': result = reindex(library)
    elif args.command == 'sync': result = sync(library, args.to_library.resolve())
    else:
        rows = library_packages(library)
        words = args.query.lower().split()
        rows = [d for d in rows if all(q in json.dumps(d).lower() for q in words)]
        if not args.json:
            for data in rows: print(data['id'] + '@' + data['version'] + '  ' + data['description'])
            print(str(len(rows)) + ' saved packages. Core components: assets.py list --search QUERY')
            return
        result = rows
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError, SyntaxError) as exc:
        sys.exit(str(exc))
