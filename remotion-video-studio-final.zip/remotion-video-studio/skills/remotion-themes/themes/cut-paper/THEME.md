# Cut Paper

Full-screen layered paper craft. Warm, tactile, friendly; works for any subject (science, history, money, health, tutorials, stories).

- Palette: cream #F4EBD8, ink navy #1B2845, orange #F26A41, yellow #F2B83B, teal #2FB5A0, pink #E8658A; skies day / sunset / dusk / mint; four hill greens or purples per variant.
- Type: Bricolage 800 uppercase for slips (tight tracking -2), Caveat for handwritten asides (optional), DM Sans for small text.
- Surface: every element is a sheet of paper: hand-cut irregular edges, two-layer shadow (tight + soft), lighter rim, fibre texture, grain and vignette over the whole frame.
- Motion: smooth frame-driven animation, eased entrances/exits, purposeful camera travel and restrained parallax. Stop-motion stepping is opt-in. Prefer shared-object continuity and motivated reveals; a cream paper wipe is an option, not a requirement at every cut.
- Layout: full-bleed, topic-specific paper scenery. Change backgrounds, palettes and shot scale to explain the subject while preserving the material system. The example sun and hills are not mandatory.
- Text: most explanation scenes have no main heading. Scene names are internal. An optional short opening title leaves after roughly 1–2.5 seconds; useful labels attach to objects and disappear when finished. Do not leave a permanent title area.
- Subtitles: default for narration; DM Sans on a restrained textured paper strip, stable lower safe lane, at most two balanced lines, soft text changes and persistent backing. See `remotion-captions/references/smooth-subtitles.md`.
- At 1080x1920, titles and object labels use the conservative top 270 / bottom 420 / right 110 px margins. Subtitles have their own lower lane: x=80, y=1500, w=890, h=148, leaving 272px below the backing. Do not apply the title bottom margin to captions. Check actual platform controls, measure loaded glyphs and re-layout other formats.
- Do: one clear visual action/idea per beat, strong contrast, coherent paper objects and enough overscan for camera travel. Don't: shiny gradients, glow, shadows on glyphs, repeated poster layouts, frame counters or progress bars.
- Current previews: `images/frame-1..4.png` and `overview.png` show the street, interior, process and articulated character, with lower captions and no persistent main headings. Open the visual asset catalog for individual reusable parts; plan the story separately.

- Current production references: `images/production-street.png`, `production-interior.png`, `production-process.png`, `production-character.png`. They are generated from the versioned asset source. The material is consistent while environments change.
- Reuse: inspect `assets/README.md` and `assets/catalog.json`; select/edit suitable components. The distance-driven person/journey replaces timer-driven limb drawings. Keep feet/floor and hands/props in contact, source time continuous, and captions outside the world camera.
- Historical reference images live under `images/history/`. They document camera lessons and must not override current character, caption or layout defaults.
- Regenerate current references from the complete bundle's `examples/asset-studio` and `tools/build_asset_previews.py`. The older generator is a paper-drawing utility, not a current finished-film template.

- Preview sizing: `frame-1..4.png` are compact 540×960 previews; `production-*.png` retain native 1080×1920 framing. Caption coordinates refer to the native composition, not thumbnail pixel positions.

- Asset-first order: after plan approval, create/review distinctive editable layers and save every ready story package in this theme’s `assets/library/` before film scene assembly. Include topic-specific art. Project snapshots support the film; the main skill archive supports future agents. Search both catalogs and preserve reviewed new versions with current previews. See the current workflow for full commands.
