# Cut Paper construction

Process: [decision architecture](../../../video-director/references/current-workflow.md).

Paper is a construction medium. Its visible characteristics can include cut silhouettes, layered thickness, fibres, edge highlights, folds and shadows. Select their treatment in relation to the story, scale, lighting and intended tone.

Choose colors through the project's setting, materials, context, light and visual hierarchy. Typography, cast, environment, framing and motion remain project decisions. A selected reference contributes only its stated roles.

Plan separate layers and hidden geometry where depth, camera motion, joints or occlusion require them. Create project artwork using the production technique that can achieve the intended look. Test actual style frames and necessary movement ranges before assembly.

Caption styling comes from project art direction and sourced user preferences. Measure the loaded fonts, contrast, line breaks and destination-safe placement. Keep caption timing connected to actual speech independently of world/camera transforms.
