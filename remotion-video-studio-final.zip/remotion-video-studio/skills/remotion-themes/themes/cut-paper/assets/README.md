# Cut Paper reusable assets — 1.3.0

29 searchable entries provide editable people, props, scenery, explanation parts and motion tools. Open [the visual catalog](../images/assets/catalog.html), [the overview](../images/assets/overview.png), and [current production references](../../../../video-director/references/current-workflow.md) before choosing. Components share paper fibres, cream cut rims, tight/soft shadows and a restrained palette. They are building blocks for authored scenes, not compulsory backgrounds.

## Search and install

Resolve `remotion-themes/scripts/assets.py` from the installed skill, keeping sibling skills together:

```bash
python3 /path/to/skills/remotion-themes/scripts/assets.py list --search walking
python3 /path/to/skills/remotion-themes/scripts/assets.py copy /path/to/video --assets person,journey,tree,building,camera,captions
```

The installer copies the dependency closure into `src/assets/cut-paper/`, generates a barrel and records relative file hashes/version in `asset-install.json`. Material primitives are included automatically with SVG assets. Rerunning is safe: unchanged generated files can update; local edits cause an atomic refusal before any writes. Review conflicts before using `--force`; it keeps numbered backups. Newer installations cannot be silently downgraded. Avoid changing a generated barrel manually; import an adapted component directly or give it a new module.

The core assets need React only; camera/captions use Remotion. Captions import the `Caption` type from `@remotion/captions`. Use compatible pinned versions (reviewed with React 19.2.3 and Remotion 4.0.538). Geometry, colours and source time are explicit. No remote images, API keys, runtime downloads or physics engine are needed.

## One SVG stage

Put SVG assets inside one `PaperStage`. It owns collision-free material IDs. Assets return SVG groups, not absolutely positioned HTML. Use a world stage large enough for the camera's entire view; origin is top-left, x points right and y down. Scene backgrounds are authored separately. Put captions outside the SVG/camera world.

```tsx
import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {PaperStage, PaperGround, PaperPerson, sampleJourney} from './assets/cut-paper';

export const Street = () => {
  const time = useCurrentFrame() / useVideoConfig().fps;
  const travel = sampleJourney(time, {
    startSeconds: .5, durationSeconds: 4, distance: 600,
  });
  return <AbsoluteFill style={{background: '#B6D2C8'}}>
    <PaperStage width={1600} height={2200}>
      <PaperGround x={-200} y={1400} width={2000} height={1000}/>
      <PaperPerson x={160} y={1400} height={480} time={time} travel={travel}/>
    </PaperStage>
  </AbsoluteFill>;
};
```

This is an asset-usage example, not a complete film. Plan topic-specific actions, loaded-font captions, narration and camera coverage separately.

## People and gait

`PaperPerson` uses a 400-unit design scale; `height` sets scale relative to that design, not a measured glyph-style bounding box. Its `x,y` anchor is the ground baseline before travel. Travel distance/speed are world pixels; stride is native rig units (default 240, supported 80–280). Keep actor height, stride and facing constant during a stride. Use camera/world transforms for shot-scale changes. For leftward travel, set `facing="left"` and keep cumulative distance positive.

Use `sampleJourney(sourceSeconds, config)` so distance, speed, acceleration and deceleration share one analytic clock. `rampSeconds` defaults to at most .45 seconds. Reserve the default .28-second settling tail after the journey for an airborne foot to land. A standstill stays alive with restrained breathing. Manual `Travel` values must have speed consistent with the derivative of distance; `settle` is 0 while walking and 1 after landing. Do not add another independent x animation to an already moving character. If a camera follows the actor, move the world/camera coherently rather than sliding the feet against an unrelated floor.

The walk uses stance/heel contact, toe-off, an airborne return and analytic hip/knee/ankle solving. The stance foot stays in world space while the body advances. Arm counter-swing and body height follow stride phase. Phase derives from distance, so it does not reset at scene cuts. Pass global/source time from the parent across continuous shots. The rig is a stylized profile; mirror for the opposite direction. Author a deliberate turn at a stop or an occluded cut rather than flipping a moving body instantaneously.

Appearance: `look` accepts `skin`, `shirt`, `trousers`, `shoes`, `hair`, `hairStyle` (`short`, `bob`, `curls`), `coat`, `build` (.8–1.3) and `legRatio` (.85–1.15). Three neutral presets are exported as `personLooks`. These are editable clothing/shape choices, not named roles or historical costumes.

Actions:

- `idle`: quiet standing, no travel required.
- `walk`: selected automatically when `travel` is present.
- `point` / `reach`: use `progress` 0→1 for the near-arm action.
- `carry`: retains the gait; `item` attaches in a 70×60 native-unit region. Use a settled grip while holding an item; author pickup/release timing explicitly.
- `sit` / `stand`: `progress` 0→1 lowers/raises the pelvis with planted feet. Match a chair/bench at the same baseline and `scale={personHeight/400}`. The default seat is 104 native units above the floor. Use matching leg proportions or adapt seat height.

```tsx
<PaperPerson x={220} y={1400} height={480} action="carry"
  time={time} travel={travel} look={personLooks.coral}
  item={<PaperBox width={70} height={60}/>}/>
```

`PaperHand` offers `open`, `point`, `grip`, `relaxed`; its anchor is the wrist. A carried item and hand details stay inside the mirrored actor. A standalone ground shadow stays in world coordinates. `debug` exposes joint markers for QA only; never leave these visible in a finished film.

## Scenery and props

- `PaperGround`: top-left baseline, width/height, rise, fill. Size it for overscan.
- `PaperPath`: curved road/path strip in an authored bounding region.
- `PaperTree`: trunk-base anchor, height, leafy/bare/pine, leaf/trunk colours and explicit time.
- `PaperCloud` / `PaperSun`: center anchors, scale/radius and editable fill.
- `PaperWater`: top-left bounded plane with source-time surface flow.
- `PaperBuilding`: bottom-center, width/height, roof, facade and window layout.
- `PaperRoom`: top-left, world width/height, floorY, wall/floor colours; `window` is false, true, or an explicit `{x,y,width,height}` rectangle.
- `PaperBox`: top-left front face, width/height, fill and open-lid fraction.
- `PaperContainer`: top-left, jar/bucket/bottle, fill, contents colour/level.
- `PaperDocument`: top-left, sheet/book, width/height and paper colour.
- `PaperTokens`: stack-bottom center, count/radius/fill. Unmarked discs can stand for quantities only when the explanation establishes their meaning.
- `PaperFurniture`: feet-baseline, chair/bench/table and scale. Seat/table contact must be checked with the actual actor/prop placement.
- `PaperDevice`: top-left screen, phone/laptop/monitor and screen colour. No brand or invented UI facts.

## Explanation and motion

`PaperArrow`, `PaperConnector`, `PaperFlow` take four cubic control points. `preparePath` builds an arc-length table; `samplePath` and `PathFollower` move at uniform distance speed, with optional tangent orientation. Prepare reusable paths outside a per-frame loop or memoize them. Continuous particles can re-enter from their source; a single object should arrive/hold or restart behind an occluder, not teleport on an open path.

`PaperWheel` takes an axle center/radius/angle. Link rotation using `wheelAngle(distance,radius)`. For geared illustrative mechanisms, `gearAngle(driverAngle,driverRadius,followerRadius)` supplies the opposite ratio; keep tooth spacing/centers compatible. `PaperGear` is a stylized graphic silhouette, not a precision involute gear or engineering simulator. `PaperHighlight` is a controlled emphasis ring; use only when it identifies something the viewer needs.

`ObjectReveal` clips one object's declared rectangle from an explicit starting edge (`from`: left/right/top/bottom). Author timing/easing and enough bounds for shadows. It is not an automatic scene-boundary wipe. `CameraRig` takes from/to world centers/zoom, start/duration seconds and optional `sourceSeconds`; use one shared clock for continuing shots. `useSourceSeconds(actualSequenceStartSeconds)` includes visual overlap in that start. The rig cannot create missing overscan or parallax artwork.

`SmoothPaperCaptions` is installed from its single canonical source in `remotion-captions`. It retains the current x80/y1500/w890/h148 lower plate at 1080×1920. Load DM Sans before rendering. Supply aligned, semantic `Caption` pages; independently verify loaded glyph bounds and at most two lines. Illustration cuts do not reset a continuous voice/caption group.

## Preserve each video’s story assets in this skill set

The [permanent story archive](library/README.md) sits beside these foundational modules, under
`assets/library/`. Store topic-specific art there too: editable source, previews, honest review
records, metadata and dependency files. See [asset-first production](../../../../video-director/references/asset-first-workflow.md).
Create/review/archive before assembling scenes; project `assets/` snapshots alone are insufficient.
Search both catalogs, restore saved packages without the old video, use immutable versions, and
merge installed-library additions into the main checkout before upgrading or packaging skills.
Only mature broadly useful components need promotion into the core `catalog.json`; preserve
ordinary story artwork directly as packages. Rebuild each changed asset’s previews and recipes.

## Review and extend

The bundle's `examples/asset-studio` demonstrates walking comparison, actions, the catalog and three unrelated scene contexts. Its rig tests measure planting, bone lengths, reach, loop continuity, source-time invariance and motion-path speed. Inspect native-speed movement and poses too: technical checks cannot certify feel. Test floor contact, silhouettes, item attachment, shadows, mirrored travel, starts/stops and the delivered encode.

To add an asset: create a local module using shared materials, record dependencies/exports/tags/anchors in `catalog.json`, add a gallery preview and usage recipe, test its meaningful motion constraints, then regenerate references and the bundle manifest. Prefer adapting one canonical component to keeping competing copies. Original geometry is authored for this library; React/Remotion and supplied OFL fonts retain their own terms.
