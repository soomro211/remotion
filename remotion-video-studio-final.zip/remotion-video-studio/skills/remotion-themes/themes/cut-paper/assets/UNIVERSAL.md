Production defaults: [current workflow](../../../../video-director/references/current-workflow.md).

# Universal object and motion recipes

The catalog contains 171 building-block entries. The 65 additions in 1.6 extend architecture, locations, surfaces, equipment, contact actions, pouring and effects.
Use them across subjects; neither the example environments nor their prop combinations are templates.
All components are editable SVG/React source. Select only what the scene needs with `assets.py`.

## Objects, anchors and state

New `objects/*` components share `ObjectProps`: `x`, `y`, positive `scale`, `fill`, `accent`, `ink`,
optional `angle`, `progress` and `level`. The origin is native **(120,220)**: bottom centre in a
240×240 design region. An instance at `(x,y)` places that anchor there. `angle` rotates the whole
object around that anchor; use `Hinge` with a deliberate pivot for a held/tilting part. Inspect state
extrema and allow room for shadows. Only the controls listed for an entry affect its appearance/state; other generic optional props
have no effect. Source geometry is the authority when adapting a silhouette.

| Family | Assets and useful states |
|---|---|
| Home | mug, teapot, lamp (light state), sofa, bed, plant (growth), clock (one-hour hand movement), door (hinged foreshortening), window, umbrella (canopy opening) |
| Work | pencil, scissors (shared rivet), ruler, backpack, briefcase, clipboard, folder, envelope, key (true hole), lock (shackle), magnifier, camera-prop (aperture) |
| Technology | bulb (filament), battery (`level`), plug, solar-panel, wind-turbine (one rotor turn), microphone, speaker (cone state), server, headphones, robot (arm poses) |
| Nature | flower, sprout (growth), leaf, rock, mountain, moon, fish (tail pose), bird (wing pose), watering-can |
| Food | apple, bread, bowl, plate, carrot, cheese |
| Places | shop, school, hospital, bridge, stairs, fence |
| Measurement | thermometer (`level`), balance (beam angle), gauge (needle sweep) |
| Transport | car, van, bus, train, bicycle (`distance`); boat, airplane, traffic-light |
| People | existing grounded person plus wave/think/offer/nod; portrait with emotions/blink/speaking; finite join-and-shake hand close-up |
| Data | bar-chart with caller-supplied values; network with explicit unique nodes/edges |

`progress` is normally a bounded authored pose/state (0..1), not an automatic loop. Use a timed
helper to animate it. Fish/bird/turbine are stylized controls; add truthful subject-specific anatomy
for a close explanation. Gauges, balance and gears illustrate relationships; they are not calibrated
instruments/engineering simulations. Charts invent no facts: supply sourced values/domain and labels.
No film progress UI is created by these assets. Care buildings use an ordinary coloured plus, not
protected branding. Shadows and colours are source-editable; appearances are not separate asset counts.

## Travel and contact

Vehicles take cumulative `distance` in **native units**. Move the root by `distance * scale` in world
pixels and pass the same native distance to the wheels. Ground is native y220; do not animate root
travel and wheel angle on unrelated timers. Mirroring should include the whole vehicle/ground relation.
For walking use the existing `sampleJourney`/`PaperPerson` convention: journey distance is world pixels,
which the person normalizes internally. Keep these two documented unit systems distinct.

```tsx
const trip = sampleJourney(seconds, {startSeconds: 1, durationSeconds: 4, distance: 240});
const scale = 1.5;
<PaperCar x={startX + trip.distance * scale} y={floorY} scale={scale} distance={trip.distance} />
```

All new object parts stay together under the root transform. The open `PaperContainer` uses `lid={false}`;
its contents are clipped to the body. Use explicit support/hand anchors when staging, and inspect
both endpoints and the actual intermediate poses. Portrait speaking/blink are authored scalar controls,
not automatic lip-sync or random blinking. The hand close-up is not a full two-person interaction rig.

## Bounded actions on one source clock

| Tool | Use and contract |
|---|---|
| `sampleTween` | Eased scalar movement with exact endpoints; explicit start/duration seconds |
| `ArcTransfer` / `sampleArc` | Object-only transfer along a finite clearance arc; this does not attach hands |
| `Hinge` | Rotate a part around its fixed `pivot`; does not move the surrounding frame |
| `TracePath` | Reveal an authored SVG stroke by normalized length; no browser draw timer |
| `Pulse` | Brief attention movement that returns to scale 1; use sparingly |
| `Orbit` | Fixed-centre motion, optional tangent orientation, finite turns |
| `Stagger` | Group entrance with per-item delay; final item ends after its delay plus duration |
| `ObjectSettle` | Arrival and gentle follow-through which ends at rest |
| `sampleHandoff` | One world position and ownership/grip clocks for both hands and their shared object |
| `PaperPouring` | Complete pitcher interaction, moving lip, horizontal free surface, finite falling stream, delayed transfer and front-rim occlusion |
| `samplePour` / `LiquidStream` | Legacy scalar/general stream helpers. These alone do not stage correct vessel contact |
| `sampleCameraPath` | Ordered finite time/centre/zoom keys, eased stops at keys; renderer still needs overscan |
| `sampleTurn` | Shortest-angle interpolation, including angles beyond a single revolution |

These helpers use explicit source seconds; call them with frame/fps from the actual timeline. They
are deterministic under seeking and different frame rates. They do not stage a scene, supply physics
or attach an object to a hand automatically. For a handoff, both hand targets and the item must use
the same sampled position; inspect reach. Pouring illustrates volume transfer, not fluid simulation.

## Review and extend

Open each selected asset's PNG/SVG and the silent motion study. Test changed colours/scales, state
ends, joints/pivots, clipping, IDs, contact, source-clock continuity and camera bounds. `MotionLab`
is a labelled asset-review harness; those labels do not belong in finished films. The scene study
shows a bakery, city street, rocky coast and industrial yard without persistent headings. Captions remain in their
lower screen-space lane. Create distinctive topic artwork where the library cannot explain the story.
Archive reviewed new/adapted story sources and proofs in the permanent library before assembly;
keep versions and refresh previews/tests with meaningful source changes.

## Architecture, locations and surfaces

Buildings use bottom centre `(x,y)`, native ground `(300,460)`, 600×480 design area. Listed `open`
controls a door/shutter; `light` switches window paper. `label` is physical signage; load DM Sans
and remeasure long replacements. `PaperShop`, `PaperSchool`, `PaperHospital` keep their old object
API; full-size `*Building` exports use building units. The catalog lists controls that affect each asset.

Locations are editable 1600×1000 top-left worlds: city, old town, industry, bakery/shop/hospital
interiors, station, harbor, coast, desert, canyon and winter. These are starting art; stage the shot,
crop deliberately and extend layers for camera overscan. Choose the actor's floor at the intended
depth. Separate asphalt, cobbles, dirt, gravel, rails, sidewalk, tile, timber, sand and snow patches
use `x,y,width,height`. Align visible joins and pattern phase. No green setting is compulsory.

Equipment keeps the (120,220) object anchor. Forklift/handcart/medical wheels and conveyors use
native cumulative `distance`. Fork `progress` does not supply collision/load ownership. Oven opening
is hinge foreshortening. An opaque bucket shows water through its opening only near full. Inspect
supports, grips, opening states and shadows at the actual scene scale.

## Human contact, pouring and effects

`PaperLift`, `PaperPlace`, `PaperPush`, `PaperPull` take source `time`, `startSeconds`,
`durationSeconds`, feet `x,y`, `height`, `facing`, `look`. Staging is reviewed at default 400-unit
proportions; adapt/recheck reach before changing leg proportions. Lift/place own a parcel; push/pull
own a trolley. Wrists share object contacts; the near hand renders in front. A lift ends holding its
load. Place starts held, lowers, releases, and stands. These are finite authored interactions, not
arbitrary-object manipulation. Custom interactions can use native person `handTargets`,
`foregroundItem`, `crouch`, `lean`; inspect anatomy, contact and occlusion throughout.

Wave progress is a complete raise/wave/lower action and returns to rest at 1. Think/offer hold their
authored end pose. Wrist orientation follows the forearm; do not independently spin a hand.

```tsx
<PaperPouring time={seconds} startSeconds={.3} durationSeconds={6.5}
  x={180} y={100} visualScale={1.1} initialVolume={.8} amount={.45}/>
<PaperPush time={seconds} startSeconds={1} durationSeconds={4}
  x={120} y={900} height={400} distance={150}/>
```

`PaperPouring` occupies about 800×740 native units. `source` places the pitcher; `scale` scales it;
`mouth` is receiver top-centre; `visualScale` scales the whole interaction. Keep the mouth below the
lip during flow. The source surface is horizontal in world space. Emitted/received/in-flight amounts
conserve normalized 2D volume with `flightSeconds` delay. Receiver perspective is stylized, not a
calibrated fluid simulation. Impossible overflow is rejected. The stream starts at the moving lip,
falls into the opening, clears its finite tail and respects the front rim. Use this composed scene
instead of expecting the legacy scalar `samplePour` or generic `LiquidStream` to stage the vessels.

Steam/smoke/dust/rain/snow/splash have finite source-time emission, deterministic `seed`, native
pixels/second `wind`, `density` in (0,3]. Steam/smoke/dust/splash use an emitter anchor; rain/snow
use a clipped top-left `width,height` field. Existing particles finish their bounded lifetime after
emission ends. Check the tail and put effects at a motivated source/contact. Keep them restrained.

`PaperOcclusion` reveals `to` over `from` with an irregular paper edge and exact endpoints.
`DepthMove` multiplies one explicit camera displacement by a 0..1 layer depth; allow overscan.
`PivotTurn` rotates an object about a world pivot. Keep captions outside these world transforms.
A human direction change still needs an authored turn or motivated occlusion at a stop; never
flatten/flip a walking person to imitate one.
