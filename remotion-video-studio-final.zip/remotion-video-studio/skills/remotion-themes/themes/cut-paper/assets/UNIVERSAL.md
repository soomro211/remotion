Production defaults: [current workflow](../../../../video-director/references/current-workflow.md).

# Universal object and motion recipes

The catalog contains 106 distinct building-block entries, including 77 additions in this release.
Use them across subjects; neither the example environments nor their prop combinations are templates.
All components are editable SVG/React source. Select only what the scene needs with `assets.py`.

## Objects, anchors and state

New `objects/*` components share `ObjectProps`: `x`, `y`, positive `scale`, `fill`, `accent`, `ink`,
optional `angle`, `progress` and `level`. The origin is native **(120,220)**: bottom centre in a
240×240 design region. An instance at `(x,y)` places that anchor there. `angle` rotates the whole
object around that anchor; use `Hinge` with a deliberate pivot for a held/tilting part. Inspect state
extrema and allow room for shadows. Only the controls listed for an entry affect its appearance/state; other generic optional props
have no effect. Source geometry is the authority when adapting a silhouette.

| Family | Assets and useful states |
|---|---|
| Home | mug, teapot, lamp (light state), sofa, bed, plant (growth), clock (one-hour hand movement), door (hinged foreshortening), window, umbrella (canopy opening) |
| Work | pencil, scissors (shared rivet), ruler, backpack, briefcase, clipboard, folder, envelope, key (true hole), lock (shackle), magnifier, camera-prop (aperture) |
| Technology | bulb (filament), battery (`level`), plug, solar-panel, wind-turbine (one rotor turn), microphone, speaker (cone state), server, headphones, robot (arm poses) |
| Nature | flower, sprout (growth), leaf, rock, mountain, moon, fish (tail pose), bird (wing pose), watering-can |
| Food | apple, bread, bowl, plate, carrot, cheese |
| Places | shop, school, hospital, bridge, stairs, fence |
| Measurement | thermometer (`level`), balance (beam angle), gauge (needle sweep) |
| Transport | car, van, bus, train, bicycle (`distance`); boat, airplane, traffic-light |
| People | existing grounded person plus wave/think/offer/nod; portrait with emotions/blink/speaking; finite join-and-shake hand close-up |
| Data | bar-chart with caller-supplied values; network with explicit unique nodes/edges |

`progress` is normally a bounded authored pose/state (0..1), not an automatic loop. Use a timed
helper to animate it. Fish/bird/turbine are stylized controls; add truthful subject-specific anatomy
for a close explanation. Gauges, balance and gears illustrate relationships; they are not calibrated
instruments/engineering simulations. Charts invent no facts: supply sourced values/domain and labels.
No film progress UI is created by these assets. Care buildings use an ordinary coloured plus, not
protected branding. Shadows and colours are source-editable; appearances are not separate asset counts.

## Travel and contact

Vehicles take cumulative `distance` in **native units**. Move the root by `distance * scale` in world
pixels and pass the same native distance to the wheels. Ground is native y220; do not animate root
travel and wheel angle on unrelated timers. Mirroring should include the whole vehicle/ground relation.
For walking use the existing `sampleJourney`/`PaperPerson` convention: journey distance is world pixels,
which the person normalizes internally. Keep these two documented unit systems distinct.

```tsx
const trip = sampleJourney(seconds, {startSeconds: 1, durationSeconds: 4, distance: 240});
const scale = 1.5;
<PaperCar x={startX + trip.distance * scale} y={floorY} scale={scale} distance={trip.distance} />
```

All new object parts stay together under the root transform. The open `PaperContainer` uses `lid={false}`;
its contents are clipped to the body. Use explicit support/hand anchors when staging, and inspect
both endpoints and the actual intermediate poses. Portrait speaking/blink are authored scalar controls,
not automatic lip-sync or random blinking. The hand close-up is not a full two-person interaction rig.

## Bounded actions on one source clock

| Tool | Use and contract |
|---|---|
| `sampleTween` | Eased scalar movement with exact endpoints; explicit start/duration seconds |
| `ArcTransfer` / `sampleArc` | Pick/place or transfer along a finite clearance arc; children keep a local origin |
| `Hinge` | Rotate a part around its fixed `pivot`; does not move the surrounding frame |
| `TracePath` | Reveal an authored SVG stroke by normalized length; no browser draw timer |
| `Pulse` | Brief attention movement that returns to scale 1; use sparingly |
| `Orbit` | Fixed-centre motion, optional tangent orientation, finite turns |
| `Stagger` | Group entrance with per-item delay; final item ends after its delay plus duration |
| `ObjectSettle` | Arrival and gentle follow-through which ends at rest |
| `sampleHandoff` | One world position and ownership/grip clocks for both hands and their shared object |
| `samplePour` / `LiquidStream` | Tilt/pour/return and conserved source/received volume; author the real lip/receiver anchors |
| `sampleCameraPath` | Ordered finite time/centre/zoom keys, eased stops at keys; renderer still needs overscan |
| `sampleTurn` | Shortest-angle interpolation, including angles beyond a single revolution |

These helpers use explicit source seconds; call them with frame/fps from the actual timeline. They
are deterministic under seeking and different frame rates. They do not stage a scene, supply physics
or attach an object to a hand automatically. For a handoff, both hand targets and the item must use
the same sampled position; inspect reach. Pouring illustrates volume transfer, not fluid simulation.

## Review and extend

Open each selected asset's PNG/SVG and the silent motion study. Test changed colours/scales, state
ends, joints/pivots, clipping, IDs, contact, source-clock continuity and camera bounds. `MotionLab`
is a labelled asset-review harness; those labels do not belong in finished films. The scene study
shows a home, street, garden and conversation without persistent headings. Captions remain in their
lower screen-space lane. Create distinctive topic artwork where the library cannot explain the story.
Archive reviewed new/adapted story sources and proofs in the permanent library before assembly;
keep versions and refresh previews/tests with meaningful source changes.
