import React from "react";
import { PaperPerson, type PersonLook } from "./Person";
import { sampleJourney } from "./gait";
import { sampleLift } from "../motion/interaction";
import {
  PaperShape as P,
  PaperRect as R,
  ContactShadow,
} from "../core/material";
import { VehicleWheel } from "../objects/Transport";
import type { Timed } from "../motion/choreography";
export type InteractionProps = Timed & {
  time: number;
  x?: number;
  y?: number;
  height?: number;
  facing?: "left" | "right";
  look?: PersonLook;
};
export const PaperLift: React.FC<
  InteractionProps & { mode?: "lift" | "place" }
> = ({
  time,
  x = 0,
  y = 0,
  height = 400,
  facing = "right",
  look,
  mode = "lift",
  ...timing
}) => {
  const state = sampleLift(time, timing, mode),
    dir = facing === "right" ? 1 : -1;
  const box = (
    <g
      data-lift-item
      data-bottom={state.bottom}
      transform={`translate(60 ${state.bottom - 94})`}
    >
      <P d="M0 8L55 0L72 14L17 23Z" fill="#D9B578" />
      <P d="M0 8L17 23V94L0 79Z" fill="#A7865D" />
      <P d="M17 23L72 14V85L17 94Z" fill="#C6A16B" />
      <R x={37} y={20} width={12} height={66} fill="#E6C38A" />
    </g>
  );
  return (
    <g
      data-paper-lift={mode}
      data-attached={state.attached}
      transform={`translate(${x} ${y}) scale(${(dir * height) / 400} ${height / 400})`}
    >
      <ContactShadow x={93} y={0} width={83} depth={10} />
      <PaperPerson
        time={0}
        handTargets={{ near: state.near, far: state.far }}
        crouch={state.crouch}
        lean={state.lean}
        look={look}
        foregroundItem={box}
      />
    </g>
  );
};
export const PaperPlace: React.FC<InteractionProps> = (p) => (
  <PaperLift {...p} mode="place" />
);
export const PaperPush: React.FC<
  InteractionProps & { mode?: "push" | "pull"; distance?: number }
> = ({
  time,
  x = 0,
  y = 0,
  height = 400,
  facing = "right",
  look,
  mode = "push",
  distance = 150,
  ...timing
}) => {
  const travel = sampleJourney(time, { ...timing, distance }),
    scale = height / 400,
    sign = facing === "right" ? 1 : -1,
    pull = mode === "pull",
    grip = pull ? -75 : 100,
    cart = pull ? -180 : 168;
  return (
    <g
      data-paper-cart-action={mode}
      transform={`translate(${x} ${y}) scale(${sign * scale} ${scale})`}
    >
      <PaperPerson
        time={time}
        travel={travel}
        action="walk"
        look={look}
        lean={pull ? -8 : 16}
        handTargets={{
          near: { x: grip, y: -235 },
          far: { x: grip - 8, y: -242 },
        }}
      />
      <g data-interaction-cart transform={`translate(${travel.distance} 0)`}>
        <ContactShadow x={cart} y={0} width={138} depth={12} />
        <path
          d={`M${grip} -235V-71H${cart + 57}`}
          fill="none"
          stroke="#496E6A"
          strokeWidth={9}
          strokeLinejoin="round"
        />
        <R x={cart - 54} y={-82} width={110} height={14} fill="#7F9B89" />
        <P
          d={`M${cart - 41} -83V-154L${cart + 31} -164L${cart + 47} -148V-83Z`}
          fill="#C6A16B"
        />
        <path
          d={`M${cart - 40} -154l17 17 70-11m-70 11v54`}
          stroke="#E0BF84"
          strokeWidth={3}
          fill="none"
        />
        <VehicleWheel
          x={cart - 36}
          y={-17}
          radius={17}
          distance={travel.distance}
        />
        <VehicleWheel
          x={cart + 37}
          y={-17}
          radius={17}
          distance={travel.distance}
        />
        <R x={cart - 42} y={-68} width={10} height={45} fill="#5D8078" />
        <R x={cart + 31} y={-68} width={10} height={45} fill="#5D8078" />
      </g>
    </g>
  );
};
export const PaperPull: React.FC<InteractionProps & { distance?: number }> = (
  p,
) => <PaperPush {...p} mode="pull" />;
