import React from "react";
import { ContactShadow, PaperShape } from "../core/material";
import {
  clamp,
  lerpPoint,
  limbPath,
  mix,
  pt,
  solveLimb,
  type Point,
} from "../core/math";
import { sampleGait, type Travel } from "./gait";
export type PersonAction =
  | "idle"
  | "walk"
  | "point"
  | "reach"
  | "carry"
  | "sit"
  | "stand";
export type PersonLook = {
  skin?: string;
  shirt?: string;
  trousers?: string;
  shoes?: string;
  hair?: string;
  hairStyle?: "short" | "bob" | "curls";
  build?: number;
  legRatio?: number;
  coat?: boolean;
};
export const personLooks = {
  teal: {
    skin: "#C58C66",
    shirt: "#548E87",
    trousers: "#506572",
    hair: "#43372F",
  },
  coral: {
    skin: "#8A5B43",
    shirt: "#C57D59",
    trousers: "#344F61",
    hair: "#2C292B",
    hairStyle: "curls",
  },
  ochre: {
    skin: "#E0B18A",
    shirt: "#C79D50",
    trousers: "#67725C",
    hair: "#574233",
    hairStyle: "bob",
  },
} satisfies Record<string, PersonLook>;
export type PersonProps = {
  x?: number;
  y?: number;
  height?: number;
  facing?: "left" | "right";
  time?: number;
  travel?: Travel;
  stride?: number;
  action?: PersonAction;
  progress?: number;
  look?: PersonLook;
  item?: React.ReactNode;
  shadow?: boolean;
  debug?: boolean;
};
const shoe =
  "M-14-3Q-20-5-18-13L-10-18L2-17L8-8Q22-9 29-2L29 12L-14 12Q-20 9-19 3Z";
export const PaperHand: React.FC<{
  x?: number;
  y?: number;
  scale?: number;
  angle?: number;
  pose?: "relaxed" | "open" | "point" | "grip";
  fill?: string;
}> = ({
  x = 0,
  y = 0,
  scale = 1,
  angle = 0,
  pose = "relaxed",
  fill = "#C58C66",
}) => {
  const paths = {
    relaxed: "M-7-8L5-8L9 1L7 16L1 20L-5 17L-9 5Z",
    open: "M-8 6L-17-3Q-18-9-13-8L-8-4L-9-20Q-7-26-4-20L-1-8L0-26Q4-31 5-24L6-8L10-22Q15-25 15-18L12-4L17-14Q23-17 22-10L17 9L7 22L-4 20Z",
    point: "M-8 6L-9-6L-5-13L3-13L7-6L28-7Q37-6 32-1L10 3L10 13L3 21L-6 17Z",
    grip: "M-9-7Q2-15 10-6L13 9Q11 20-2 20L-10 10L-12 1Q-10-4-5-1L-1 5L0 0Z",
  };
  return (
    <g transform={`translate(${x} ${y}) rotate(${angle}) scale(${scale})`}>
      <PaperShape d={paths[pose]} fill={fill} rim={0.9} shadow={false} />
      {pose === "grip" ? (
        <path
          d="M1-5L3 8M6-4L7 7"
          stroke="#76503D"
          strokeWidth="1"
          opacity=".4"
          fill="none"
        />
      ) : null}
    </g>
  );
};
export const PaperPerson: React.FC<PersonProps> = ({
  x = 0,
  y = 0,
  height = 400,
  facing = "right",
  time = 0,
  travel,
  stride = 240,
  action = travel ? "walk" : "idle",
  progress = 1,
  look = {},
  item,
  shadow = true,
  debug = false,
}) => {
  if (!(height > 0) || !Number.isFinite(height))
    throw new Error("PaperPerson height must be positive and finite.");
  const scale = height / 400,
    dir = facing === "right" ? 1 : -1,
    skin = look.skin ?? "#C58C66",
    shirt = look.shirt ?? "#548E87",
    trousers = look.trousers ?? "#506572",
    hair = look.hair ?? "#43372F",
    build = clamp(look.build ?? 1, 0.8, 1.3),
    legRatio = look.legRatio ?? 1;
  const distance = (travel?.distance ?? 0) / scale,
    speed = (travel?.speed ?? 0) / scale,
    weight = action === "walk" || action === "carry" ? clamp(speed / 140) : 0;
  const gait = sampleGait({
    distance,
    stride,
    legRatio,
    settle: travel?.settle ?? 1,
    activity: weight,
  });
  const seated =
    action === "sit"
      ? clamp(progress)
      : action === "stand"
        ? 1 - clamp(progress)
        : 0;
  const idle = !travel;
  const hip = {
    x: action === "sit" || action === "stand" ? -24 * seated : gait.hip.x,
    y: mix(
      idle ? -(2 * gait.legLength + 9) : gait.hip.y,
      -104 * legRatio,
      seated,
    ),
  };
  const foot = (which: "front" | "back") => {
    const f = gait[which];
    if (action === "sit" || action === "stand")
      return {
        ...f,
        ankle: { x: which === "front" ? 52 : 29, y: -12 },
        angle: 0,
      };
    return idle
      ? { ...f, ankle: { x: which === "front" ? 13 : -14, y: -12 }, angle: 0 }
      : f;
  };
  const front = foot("front"),
    back = foot("back"),
    L = gait.legLength;
  // Prepared sit/stand foot placement also needs the same reach constraint as walking.
  for (const f of [front, back])
    hip.y = Math.max(
      hip.y,
      f.ankle.y -
        Math.sqrt(Math.max(1, (2 * L - 0.5) ** 2 - (f.ankle.x - hip.x) ** 2)),
    );
  const fk = solveLimb(hip, front.ankle, L, L),
    bk = solveLimb(hip, back.ankle, L, L);
  const breathe = Math.sin(time * 1.5) * 0.65 * (1 - weight),
    sy = hip.y - 118 - breathe;
  const shoulderNear = { x: hip.x + 9, y: sy + 5 },
    shoulderFar = { x: hip.x - 7, y: sy + 3 };
  const arm = (near: boolean) => {
    const shoulder = near ? shoulderNear : shoulderFar,
      p = gait.phase * Math.PI * 2,
      a = ((-Math.cos(p) * (near ? 1 : -1) * 25 * weight + 2) * Math.PI) / 180;
    const elbow = {
        x: shoulder.x + Math.sin(a) * 60,
        y: shoulder.y + Math.cos(a) * 60,
      },
      b = a + ((18 + 8 * Math.max(0, Math.sin(a))) * Math.PI) / 180;
    let error = 0;
    let hand = { x: elbow.x + Math.sin(b) * 56, y: elbow.y + Math.cos(b) * 56 },
      joint = elbow;
    let target: Point | null = null;
    if (action === "carry")
      target = { x: near ? 94 : 30, y: sy + (near ? 80 : 77) };
    if (near && action === "point") target = { x: hip.x + 124, y: sy - 16 };
    if (near && action === "reach") target = { x: hip.x + 108, y: sy + 43 };
    if (seated > 0)
      target = lerpPoint(
        hand,
        { x: hip.x + (near ? 55 : 34), y: hip.y - 12 },
        seated,
      );
    if (target) {
      hand = lerpPoint(
        hand,
        target,
        action === "sit" || action === "stand" ? 1 : clamp(progress),
      );
      const solution = solveLimb(shoulder, hand, 60, 60, near ? -1 : 1);
      joint = solution.joint;
      error = solution.targetError;
    }
    const skinSleeve = lerpPoint(joint, hand, look.coat ? 0.86 : 0.45);
    return (
      <g data-person-arm={near ? "near" : "far"} data-ik-error={error}>
        <PaperShape
          d={limbPath(shoulder, joint, 27 * build, 21 * build)}
          fill={shirt}
          rim={1.15}
        />
        <PaperShape
          d={limbPath(joint, hand, 17 * build, 13 * build)}
          fill={skin}
          rim={0.9}
        />
        <PaperShape
          d={limbPath(joint, skinSleeve, 21 * build, 18 * build)}
          fill={shirt}
          rim={1.1}
        />
        <PaperHand
          x={hand.x}
          y={hand.y}
          scale={0.61}
          fill={skin}
          pose={
            action === "carry"
              ? "grip"
              : near && action === "point"
                ? "point"
                : "relaxed"
          }
          angle={action === "carry" ? 0 : near && action === "point" ? 0 : -14}
        />
      </g>
    );
  };
  const leg = (near: boolean) => {
    const f = near ? front : back,
      k = near ? fk.joint : bk.joint;
    return (
      <g data-person-leg={near ? "near" : "far"}>
        <PaperShape
          d={limbPath(hip, k, (near ? 31 : 28) * build, 23 * build)}
          fill={trousers}
          rim={1.25}
        />
        <PaperShape
          d={limbPath(k, f.ankle, 24 * build, 17 * build)}
          fill={trousers}
          rim={1.15}
        />
        <g
          data-person-foot={near ? "near" : "far"}
          data-stance={f.stance}
          transform={`translate(${pt(f.ankle)}) rotate(${f.angle})`}
        >
          <PaperShape d={shoe} fill={look.shoes ?? "#343D43"} rim={1.1} />
          <path
            d="M-15 8Q5 11 28 7"
            stroke="#C8C5AD"
            strokeWidth="2"
            fill="none"
          />
        </g>
      </g>
    );
  };
  const headY = sy - 52,
    headX = hip.x + 6;
  return (
    <g
      data-paper-person
      data-ik-error={Math.max(fk.targetError, bk.targetError)}
      data-distance={travel?.distance ?? 0}
      data-action={action}
    >
      {shadow ? (
        <ContactShadow
          x={x + dir * (travel?.distance ?? 0)}
          y={y}
          width={118 * scale}
          depth={13 * scale}
        />
      ) : null}
      <g
        transform={`translate(${x + dir * (travel?.distance ?? 0)} ${y}) scale(${dir * scale} ${scale})`}
      >
        <g opacity="1">
          {arm(false)}
          {leg(false)}
        </g>
        {leg(true)}
        <PaperShape
          d={`M${hip.x - 25 * build} ${sy + 4}Q${hip.x - 15} ${sy - 10} ${hip.x + 16 * build} ${sy - 5}L${hip.x + 32 * build} ${sy + 12}L${hip.x + 27 * build} ${hip.y + (look.coat ? 23 : 3)}L${hip.x - 28 * build} ${hip.y + (look.coat ? 22 : 1)}Z`}
          fill={shirt}
          rim={1.7}
        />
        <path
          d={`M${hip.x + 8} ${sy + 17}L${hip.x + 11} ${hip.y - 6}`}
          stroke="#F7E8CB"
          opacity=".22"
          strokeWidth="2"
        />
        <PaperShape
          d={`M${headX - 10} ${sy - 30}L${headX + 10} ${sy - 28}L${headX + 8} ${sy + 1}L${headX - 12} ${sy - 2}Z`}
          fill={skin}
          rim={1.1}
        />
        <g transform={`translate(${headX} ${headY})`}>
          <PaperShape
            d="M-27-28Q-9-47 14-35L29-22L29-8L38 1L28 7L26 20L13 34L-7 32L-24 15L-30-3Z"
            fill={skin}
            rim={1.4}
          />
          <PaperShape
            d={
              look.hairStyle === "bob"
                ? "M-28-21Q-25-48 1-43Q31-42 31-20L21-4L9-25L-8-16L-11 23L-31 35L-38 16Z"
                : look.hairStyle === "curls"
                  ? "M-31-10Q-46-18-32-29Q-39-44-23-43Q-17-58-4-47Q10-58 17-43Q35-47 32-29Q43-17 28-13L13-28L-1-23L-17-10L-18 7L-30 5Z"
                  : "M-31-7Q-40-27-22-39L-10-46L14-39L31-26L30-15L14-26L-3-22L-20-7L-20 8L-29 4Z"
            }
            fill={hair}
            rim={1.1}
          />
          <PaperShape
            d="M-17-5Q-7-11-6 1Q-9 12-17 9Z"
            fill={skin}
            rim={0.7}
            shadow={false}
          />
          <path
            d="M19-8h2M22 16l5-1"
            stroke="#433B35"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </g>
        {action === "carry" ? (
          <g
            data-attachment="carried-item"
            transform={`translate(25 ${sy + 28})`}
          >
            {item}
          </g>
        ) : null}
        {arm(true)}
        {debug ? (
          <g fill="#D64B4B" stroke="#FBF2DC" strokeWidth="1">
            {[hip, fk.joint, bk.joint, front.ankle, back.ankle].map((p, i) => (
              <circle key={i} cx={p.x} cy={p.y} r="3" />
            ))}
          </g>
        ) : null}
      </g>
    </g>
  );
};
