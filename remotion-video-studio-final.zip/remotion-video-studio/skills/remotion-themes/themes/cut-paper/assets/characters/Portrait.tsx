import React from "react";
import {PaperShape,PaperDisc} from "../core/material";
import {clamp} from "../core/math";
export type PortraitProps={x?:number;y?:number;scale?:number;skin?:string;shirt?:string;hair?:string;emotion?:"neutral"|"happy"|"concerned"|"thinking";blink?:number;speaking?:number};
/** Bottom-centre bust anchor. Blink/mouth are authored state, never random browser animation. */
export const PaperPortrait:React.FC<PortraitProps>=({x=0,y=0,scale=1,skin="#B9805B",shirt="#578B86",hair="#40362F",emotion="neutral",blink=0,speaking=0})=>{
 const b=clamp(blink),talk=clamp(speaking);
 if(![x,y,scale,blink,speaking].every(Number.isFinite)||scale<=0)throw new Error("Portrait needs finite controls and positive scale.");
 return <g data-paper-portrait transform={`translate(${x} ${y}) scale(${scale})`}>
 <PaperShape d="M-108 0Q-103-89-38-97H40Q107-87 109 0Z" fill={shirt}/>
 <PaperShape d="M-22-143H22V-89Q0-69-22-90Z" fill={skin}/>
 <PaperDisc x={-58} y={-170} radius={16} fill={skin}/><PaperDisc x={58} y={-170} radius={16} fill={skin}/>
 <PaperShape d="M-55-225Q-1-271 54-224L58-162Q53-110 0-102Q-51-110-58-162Z" fill={skin}/>
 <PaperShape d="M-60-176Q-78-234-31-252Q27-280 62-228L61-190L42-218L15-231L-23-209L-46-201L-45-170Z" fill={hair}/>
 <g stroke="#423A34" strokeWidth={3} strokeLinecap="round" fill="none"><path d={emotion==="concerned"?"M-39-201l22-6M17-207l22 6":"M-39-207h22M17-207h22"}/><g transform={`translate(-26 -188) scale(1 ${Math.max(.06,1-b)})`}><ellipse rx={3.5} ry={5} fill="#423A34" stroke="none"/></g><g transform={`translate(26 -188) scale(1 ${Math.max(.06,1-b)})`}><ellipse rx={3.5} ry={5} fill="#423A34" stroke="none"/></g><path d="M0-184L-4-164L3-161" opacity={.5}/>
 {talk>0?<ellipse cx={0} cy={-142} rx={9} ry={3+talk*8} fill="#694738" stroke="none"/>:<path d={emotion==="happy"?"M-17-145Q0-128 17-145":emotion==="concerned"?"M-13-140Q0-151 13-140":emotion==="thinking"?"M-1-143h16":"M-13-142h26"}/>}</g></g>;
};
export const PaperHandshake:React.FC<{x?:number;y?:number;scale?:number;progress?:number;leftSkin?:string;rightSkin?:string;leftSleeve?:string;rightSleeve?:string}>=({x=0,y=0,scale=1,progress=1,leftSkin="#B9805B",rightSkin="#E0B28A",leftSleeve="#538F89",rightSleeve="#C79D60"})=>{
 if(![x,y,scale,progress].every(Number.isFinite)||scale<=0)throw new Error("Handshake needs finite controls and positive scale.");
 const q=clamp(progress),gap=(1-Math.min(1,q/.35))*65,shake=Math.sin(Math.PI*clamp((q-.35)/.65)*6)*Math.sin(Math.PI*clamp((q-.35)/.65))**2*8;
 return <g data-paper-handshake transform={`translate(${x} ${y+shake}) scale(${scale})`}>
 <g transform={`translate(${-gap} 0)`}><PaperShape d="M-205-17L-78-52L-57-5L-185 43Z" fill={leftSleeve}/><PaperShape d="M-85-48L-35-64L3-52L35-15L15 13L-33-3L-65 6Z" fill={leftSkin}/></g>
 <g transform={`translate(${gap} 0)`}><PaperShape d="M194-28L74-55L59-4L184 37Z" fill={rightSleeve}/><PaperShape d="M82-48L40-61L-5-38L-21-14L-2 9L27 15L61 1Z" fill={rightSkin}/><PaperShape d="M43-50L16-36L-3-10Q-13-6-17-14L-20-28L-4-51L18-64Z" fill={rightSkin} shadow={false}/></g>
 <path d="M-26-11L0 17M-14-19L12 12M0-25L24 3" stroke="#785342" opacity=".35" strokeWidth="2"/></g>;
};
