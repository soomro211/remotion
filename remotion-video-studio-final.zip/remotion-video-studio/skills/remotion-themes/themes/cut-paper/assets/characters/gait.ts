import {
  clamp,
  hermite,
  mix,
  rotate,
  smooth,
  solveLimb,
  type Point,
} from "../core/math";
export type Journey = {
  startSeconds: number;
  durationSeconds: number;
  distance: number;
  rampSeconds?: number;
  settleSeconds?: number;
};
export type Travel = { distance: number; speed: number; settle: number };
const integral = (u: number) => u ** 6 - 3 * u ** 5 + 2.5 * u ** 4;
// Distance and speed share one analytic clock. No accumulated frame state.
export const sampleJourney = (time: number, j: Journey): Travel => {
  if (
    !Number.isFinite(time) ||
    !Number.isFinite(j.distance) ||
    j.distance < 0 ||
    !(j.durationSeconds > 0) ||
    !Number.isFinite(j.durationSeconds) ||
    !Number.isFinite(j.startSeconds)
  )
    throw new Error(
      "Journey requires finite time, nonnegative distance and positive duration. Use facing for direction.",
    );
  const ramp = j.rampSeconds ?? Math.min(0.45, j.durationSeconds / 4),
    tail = j.settleSeconds ?? 0.28;
  if (!Number.isFinite(ramp) || !Number.isFinite(tail) || !(ramp > 0 && ramp <= j.durationSeconds / 2) || !(tail > 0))
    throw new Error(
      "Journey ramp must be positive and at most half its duration; settle must be positive.",
    );
  const t = clamp(time - j.startSeconds, 0, j.durationSeconds),
    v = j.distance / (j.durationSeconds - ramp);
  let distance: number, speed: number;
  if (t < ramp) {
    distance = v * ramp * integral(t / ramp);
    speed = v * smooth(t / ramp);
  } else if (t > j.durationSeconds - ramp) {
    const u = (j.durationSeconds - t) / ramp;
    distance = j.distance - v * ramp * integral(u);
    speed = v * smooth(u);
  } else {
    distance = v * (t - ramp / 2);
    speed = v;
  }
  const settle =
    time < j.startSeconds
      ? 1
      : time < j.startSeconds + Math.min(0.24, ramp)
        ? 1 - smooth((time - j.startSeconds) / Math.min(0.24, ramp))
        : smooth((time - j.startSeconds - j.durationSeconds) / tail);
  return { distance, speed, settle };
};
export type Foot = {
  ankle: Point;
  angle: number;
  lift: number;
  phase: number;
  stance: boolean;
  contact: Point;
  flatX: number;
};
export type GaitOptions = {
  distance: number;
  stride?: number;
  legRatio?: number;
  settle?: number;
  activity?: number;
};
export const heel = { x: -14, y: 12 },
  toe = { x: 29, y: 12 };
export const sampleFoot = (
  distance: number,
  stride: number,
  offset: number,
  settle = 0,
): Foot => {
  const p = (((distance / stride + offset) % 1) + 1) % 1,
    stance = p <= 0.62,
    half = (stride * 0.62) / 2;
  let flatX: number,
    angle: number,
    lift = 0;
  if (stance) {
    flatX = half - stride * p;
    angle =
      p < 0.13
        ? -10 * (1 - smooth(p / 0.13))
        : p > 0.46
          ? 18 * smooth((p - 0.46) / 0.16)
          : 0;
  } else {
    const q = (p - 0.62) / 0.38;
    flatX = hermite(-half, half, -stride * 0.38, -stride * 0.38, q);
    lift = 31 * Math.sin(Math.PI * q) ** 2;
    angle = mix(18, -10, smooth(q));
  }
  angle *= 1 - clamp(settle);
  lift *= 1 - clamp(settle);
  const pivot = angle < 0 ? heel : toe,
    r = rotate(pivot, angle),
    h = rotate(heel, angle),
    tip = rotate(toe, angle);
  const ankle = { x: flatX + pivot.x - r.x, y: -Math.max(h.y, tip.y) - lift };
  return {
    ankle,
    angle,
    lift,
    phase: p,
    stance,
    contact: { x: ankle.x + r.x, y: ankle.y + r.y },
    flatX,
  };
};
export const sampleGait = ({
  distance,
  stride = 240,
  legRatio = 1,
  settle = 0,
  activity = 1,
}: GaitOptions) => {
  if (
    !Number.isFinite(distance) ||
    distance < 0 ||
    !(stride >= 80 && stride <= 280) ||
    !(legRatio >= 0.85 && legRatio <= 1.15)
  )
    throw new Error(
      "Gait: nonnegative distance, stride 80..280 and legRatio .85..1.15 required.",
    );
  const phase = (distance / stride) % 1,
    L = 93 * legRatio;
  const hip = {
    x: 2.4 * activity,
    y: -(2 * L + 9) + 2 * Math.cos(phase * Math.PI * 4) * activity,
  };
  const front = sampleFoot(distance, stride, 0, settle),
    back = sampleFoot(distance, stride, 0.5, settle);
  for (const foot of [front, back])
    hip.y = Math.max(
      hip.y,
      foot.ankle.y -
        Math.sqrt(
          Math.max(1, (2 * L - 0.5) ** 2 - (foot.ankle.x - hip.x) ** 2),
        ),
    );
  const frontLeg = solveLimb(hip, front.ankle, L, L),
    backLeg = solveLimb(hip, back.ankle, L, L);
  return {
    phase,
    hip,
    front,
    back,
    frontKnee: frontLeg.joint,
    backKnee: backLeg.joint,
    legLength: L,
    targetError: Math.max(frontLeg.targetError, backLeg.targetError),
  };
};
