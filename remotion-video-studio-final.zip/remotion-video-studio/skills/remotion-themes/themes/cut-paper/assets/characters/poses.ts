import { clamp, mix, smooth } from "../core/math";

export type Gesture = "wave" | "think" | "offer";
export type GestureArm = {
  upperAngle: number;
  lowerAngle: number;
  wristAngle: number;
  handPose: "open" | "grip" | "relaxed";
  openness: number;
};

/** Angles are measured from downward, towards the front of the body. */
export const sampleGestureArm = (
  gesture: Gesture,
  phase: number,
  near = true,
): GestureArm | null => {
  if (!Number.isFinite(phase)) throw new Error("Gesture phase must be finite.");
  const p = clamp(phase);
  if (!near && gesture !== "offer") return null;
  const restUpper = 2,
    restLower = 20.3;
  if (gesture === "wave") {
    // Raise, hold a legible elbow-out silhouette, wave at the wrist, then lower.
    const raise = smooth(p / 0.24) * (1 - smooth((p - 0.76) / 0.24));
    const waving = smooth((p - 0.24) / 0.08) * (1 - smooth((p - 0.68) / 0.08));
    const oscillation = Math.sin(((p - 0.24) / 0.44) * Math.PI * 4) * waving;
    const upperAngle = mix(restUpper, 78, raise);
    const lowerAngle = mix(restLower, 148 + oscillation * 4, raise);
    return {
      upperAngle,
      lowerAngle,
      wristAngle: 180 - lowerAngle + oscillation * 10,
      handPose: "open",
      openness: smooth(p / 0.18) * (1 - smooth((p - 0.82) / 0.18)),
    };
  }
  if (gesture === "think") {
    const q = smooth(p);
    return {
      upperAngle: mix(restUpper, 55, q),
      lowerAngle: mix(restLower, 209, q),
      wristAngle: 0,
      handPose: "grip",
      openness: 0,
    };
  }
  const q = smooth(p),
    upperAngle = mix(restUpper, near ? 49 : 39, q),
    lowerAngle = mix(restLower, near ? 76 : 68, q);
  return {
    upperAngle,
    lowerAngle,
    wristAngle: mix(180 - restLower, 90, q),
    handPose: "open",
    openness: q,
  };
};

/** Same path topology at every phase, so fingers open without a hand-shape pop. */
export const openHandPath = (openness: number) => {
  const f = clamp(openness),
    s = 0.62 + 0.38 * f,
    x = (v: number) => (v - 3) * s + 3;
  const index = -25 - 17 * f,
    middle = -29 - 21 * f,
    ring = -25 - 19 * f,
    pinky = -21 - 12 * f;
  return `M-6 1L-8-9L${x(-17)} ${-14 - 4 * f}Q${x(-21)} ${-20 - 4 * f} ${x(-16)} ${-21 - 4 * f}Q${x(-13)} ${-22 - 4 * f} ${x(-7)} ${-15 - 4 * f}L${x(-8)} ${index + 5}Q${x(-8)} ${index} ${x(-5)} ${index}Q${x(-2)} ${index} ${x(-2)} ${index + 5}L${x(0)}-18L${x(0)} ${middle + 5}Q${x(0)} ${middle} ${x(3)} ${middle}Q${x(6)} ${middle} ${x(6)} ${middle + 5}L${x(6)}-18L${x(10)} ${ring + 3}Q${x(11)} ${ring - 1} ${x(14)} ${ring}Q${x(17)} ${ring + 1} ${x(16)} ${ring + 5}L${x(13)}-17L${x(19)} ${pinky + 2}Q${x(22)} ${pinky - 2} ${x(25)} ${pinky}Q${x(27)} ${pinky + 2} ${x(25)} ${pinky + 6}L${x(19)}-9Q${x(18)}-2 8 2Z`;
};

export const armPoints = (
  shoulder: { x: number; y: number },
  pose: GestureArm,
) => {
  const upper = (pose.upperAngle * Math.PI) / 180,
    lower = (pose.lowerAngle * Math.PI) / 180;
  const elbow = {
    x: shoulder.x + Math.sin(upper) * 60,
    y: shoulder.y + Math.cos(upper) * 60,
  };
  return {
    elbow,
    wrist: {
      x: elbow.x + Math.sin(lower) * 56,
      y: elbow.y + Math.cos(lower) * 56,
    },
  };
};
