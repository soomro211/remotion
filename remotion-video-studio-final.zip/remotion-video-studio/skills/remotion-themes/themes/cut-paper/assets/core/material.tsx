import React, { createContext, useContext, useId } from "react";
import { circlePath, rectanglePath } from "./math";
export const palette = {
  cream: "#F4EBD8",
  rim: "#FBF2DC",
  ink: "#1B2845",
  teal: "#388E97",
  green: "#71956D",
  yellow: "#F2BC55",
  coral: "#D9825B",
  wood: "#92724E",
  sky: "#B6D2C8",
  navy: "#273D50",
};
const MaterialContext = createContext<string | null>(null);
export const PaperStage: React.FC<{
  width: number;
  height: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
  label?: string;
}> = ({ width, height, children, style, label }) => {
  const id = "paper" + useId().replace(/[^a-zA-Z0-9]/g, "");
  return (
    <MaterialContext.Provider value={id}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        aria-label={label}
        style={{ display: "block", overflow: "visible", ...style }}
      >
        <defs>
          <filter
            id={`${id}-shadow`}
            x="-30%"
            y="-30%"
            width="160%"
            height="180%"
            colorInterpolationFilters="sRGB"
          >
            <feDropShadow
              dx=".7"
              dy="2"
              stdDeviation=".65"
              floodColor="#24322D"
              floodOpacity=".25"
            />
            <feDropShadow
              dx="1"
              dy="5"
              stdDeviation="3.2"
              floodColor="#26312B"
              floodOpacity=".13"
            />
          </filter>
          <filter id={`${id}-noise`} x="0" y="0" width="100%" height="100%">
            <feTurbulence
              type="fractalNoise"
              baseFrequency=".48 .65"
              numOctaves="2"
              seed="23"
            />
            <feColorMatrix type="saturate" values="0" />
          </filter>
          <pattern
            id={`${id}-fibres`}
            width="192"
            height="192"
            patternUnits="userSpaceOnUse"
          >
            <rect
              width="192"
              height="192"
              fill="#9D9685"
              filter={`url(#${id}-noise)`}
            />
            {Array.from({ length: 32 }, (_, i) => {
              const x = (i * 67) % 192,
                y = (i * 43) % 192;
              return (
                <path
                  key={i}
                  d={`M${x} ${y}l${1 + (i % 3)} ${2 + (i % 5)}`}
                  stroke={i % 2 ? "#5E5849" : "#FFF9E9"}
                  strokeWidth=".6"
                  opacity=".35"
                />
              );
            })}
          </pattern>
        </defs>
        {children}
      </svg>
    </MaterialContext.Provider>
  );
};
export type PaperShapeProps = {
  d: string;
  fill?: string;
  rim?: number;
  shadow?: boolean;
  texture?: number;
  opacity?: number;
  transform?: string;
  fillRule?: "nonzero" | "evenodd";
};
export const PaperShape: React.FC<PaperShapeProps> = ({
  d,
  fill = palette.cream,
  rim = 1.8,
  shadow = true,
  texture = 0.13,
  opacity = 1,
  transform,
  fillRule = "nonzero",
}) => {
  const id = useContext(MaterialContext);
  if (!id) throw new Error("Paper assets must be inside one PaperStage.");
  return (
    <g
      transform={transform}
      opacity={opacity}
      filter={shadow ? `url(#${id}-shadow)` : undefined}
    >
      <path
        d={d}
        fill={fill}
        fillRule={fillRule}
        stroke={palette.rim}
        strokeWidth={rim}
        strokeLinejoin="round"
        paintOrder="stroke"
      />
      {texture > 0 ? (
        <path
          d={d}
          fill={`url(#${id}-fibres)`}
          fillRule={fillRule}
          opacity={texture}
          style={{ mixBlendMode: "multiply" }}
        />
      ) : null}
    </g>
  );
};
export const PaperRect: React.FC<{
  x?: number;
  y?: number;
  width: number;
  height: number;
  fill?: string;
  rim?: number;
  shadow?: boolean;
}> = ({ x = 0, y = 0, width, height, ...rest }) => (
  <PaperShape d={rectanglePath(x, y, width, height)} {...rest} />
);
export const PaperDisc: React.FC<{
  x?: number;
  y?: number;
  radius: number;
  fill?: string;
  seed?: number;
  rim?: number;
  shadow?: boolean;
}> = ({ x = 0, y = 0, radius, seed = 1, ...rest }) => (
  <PaperShape d={circlePath(x, y, radius, seed)} {...rest} />
);
// Bottom-center anchor. Render in world coordinates, outside a mirrored actor.
export const ContactShadow: React.FC<{
  x?: number;
  y?: number;
  width?: number;
  depth?: number;
  opacity?: number;
}> = ({ x = 0, y = 0, width = 110, depth = 12, opacity = 0.18 }) => (
  <ellipse
    cx={x}
    cy={y + 2}
    rx={width / 2}
    ry={depth / 2}
    fill="#263B34"
    opacity={opacity}
  />
);
