export type Point = { x: number; y: number };
export const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const mix = (a: number, b: number, p: number) => a + (b - a) * p;
export const smooth = (v: number) => {
  const p = clamp(v);
  return clamp(p * p * p * (p * (p * 6 - 15) + 10));
};
export const lerpPoint = (a: Point, b: Point, p: number): Point => ({
  x: mix(a.x, b.x, p),
  y: mix(a.y, b.y, p),
});
export const length = (a: Point, b: Point) => Math.hypot(b.x - a.x, b.y - a.y);
export const rotate = (p: Point, degrees: number): Point => {
  const a = (degrees * Math.PI) / 180;
  return {
    x: p.x * Math.cos(a) - p.y * Math.sin(a),
    y: p.x * Math.sin(a) + p.y * Math.cos(a),
  };
};
export const fmt = (v: number) => Number(v.toFixed(3));
export const pt = (p: Point) => `${fmt(p.x)} ${fmt(p.y)}`;
export const hermite = (
  a: number,
  b: number,
  ta: number,
  tb: number,
  u: number,
) =>
  (2 * u ** 3 - 3 * u * u + 1) * a +
  (u ** 3 - 2 * u * u + u) * ta +
  (-2 * u ** 3 + 3 * u * u) * b +
  (u ** 3 - u * u) * tb;
export const circlePath = (x: number, y: number, r: number, seed = 1) =>
  "M" +
  Array.from({ length: 48 }, (_, i) => {
    const a = (i / 48) * Math.PI * 2,
      rr = r * (1 + 0.006 * Math.sin(a * 7 + seed) + 0.004 * Math.sin(a * 11));
    return `${fmt(x + rr * Math.cos(a))} ${fmt(y + rr * Math.sin(a))}`;
  }).join("L") +
  "Z";
export const rectanglePath = (x: number, y: number, w: number, h: number) =>
  `M${x + 1} ${y}L${x + w} ${y + 1.4}L${x + w - 0.8} ${y + h}L${x} ${y + h - 1}Z`;
export const limbPath = (a: Point, b: Point, wa: number, wb: number) => {
  const d = length(a, b) || 1,
    n = { x: -(b.y - a.y) / d, y: (b.x - a.x) / d };
  return `M${pt({ x: a.x + (n.x * wa) / 2, y: a.y + (n.y * wa) / 2 })}L${pt({ x: b.x + (n.x * wb) / 2, y: b.y + (n.y * wb) / 2 })}Q${pt({ x: b.x + ((b.x - a.x) / d) * wb * 0.32, y: b.y + ((b.y - a.y) / d) * wb * 0.32 })} ${pt({ x: b.x - (n.x * wb) / 2, y: b.y - (n.y * wb) / 2 })}L${pt({ x: a.x - (n.x * wa) / 2, y: a.y - (n.y * wa) / 2 })}Q${pt({ x: a.x - ((b.x - a.x) / d) * wa * 0.25, y: a.y - ((b.y - a.y) / d) * wa * 0.25 })} ${pt({ x: a.x + (n.x * wa) / 2, y: a.y + (n.y * wa) / 2 })}Z`;
};

// Analytic two-bone IK. targetError is evidence of an unreachable authored target.
export const solveLimb = (
  a: Point,
  b: Point,
  upper: number,
  lower: number,
  bend = -1,
) => {
  if (![a.x, a.y, b.x, b.y, upper, lower, bend].every(Number.isFinite) || upper <= 0 || lower <= 0)
    throw new Error("Limb coordinates must be finite and lengths positive.");
  const distance = length(a, b),
    minimum = Math.abs(upper - lower),
    epsilon = Math.min(1e-7,(upper+lower)*1e-6),
    d = clamp(distance, Math.max(epsilon, minimum), upper + lower),
    u = distance > Number.EPSILON ? { x: (b.x - a.x) / distance, y: (b.y - a.y) / distance } : {x: 1, y: 0};
  const along = (upper * upper - lower * lower + d * d) / (2 * d),
    h = Math.sqrt(Math.max(0, upper * upper - along * along));
  return {
    joint: {
      x: a.x + u.x * along - u.y * h * bend,
      y: a.y + u.y * along + u.x * h * bend,
    },
    targetError: Math.max(0, distance - (upper + lower), minimum - distance),
  };
};
