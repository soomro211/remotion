import React, { useId } from "react";
import { PaperShape } from "../core/material";
import { smooth, clamp } from "../core/math";
import { sampleEffect, type EffectKind, type EffectTiming } from "./particles";
import { samplePivot } from "../motion/interaction";
import type { Timed } from "../motion/choreography";
export type EffectProps = EffectTiming & {
  x?: number;
  y?: number;
  kind?: EffectKind;
  fill?: string;
};
export const PaperEffect: React.FC<EffectProps> = ({
  x = 0,
  y = 0,
  kind = "steam",
  fill,
  ...timing
}) => {
  const id = "effect" + useId().replace(/[^a-z0-9]/gi, ""),
    particles = sampleEffect(kind, timing),
    weather = kind === "rain" || kind === "snow",
    color =
      fill ??
      {
        steam: "#F1E9D4",
        smoke: "#70887E",
        dust: "#B49A73",
        rain: "#81B3AE",
        snow: "#F4F1DD",
        splash: "#7AB3AD",
      }[kind];
  return (
    <g data-paper-effect={kind} transform={`translate(${x} ${y})`}>
      <defs>
        <clipPath id={id}>
          <rect width={timing.width ?? 500} height={timing.height ?? 400} />
        </clipPath>
      </defs>
      <g clipPath={weather ? `url(#${id})` : undefined}>
        {particles.map((p) => (
          <g
            key={p.id}
            data-particle={p.id}
            opacity={p.opacity}
            transform={`translate(${p.x} ${p.y}) rotate(${p.rotation})`}
          >
            {kind === "steam" ? (
              <path
                d={`M0 8Q${-p.size} ${-p.size * 0.4} 0 ${-p.size}T0 ${-p.size * 2}`}
                stroke={color}
                strokeWidth={5 + p.u * 4}
                fill="none"
                strokeLinecap="round"
              />
            ) : kind === "rain" ? (
              <path
                d={`M0 0l${(timing.wind ?? 12) * 0.09} ${p.size}`}
                stroke={color}
                strokeWidth={2.5}
                strokeLinecap="round"
              />
            ) : kind === "smoke" ? (
              <PaperShape
                d={`M${-p.size} 0Q${-p.size * 1.4} ${-p.size} ${-p.size * 0.3} ${-p.size * 0.9}Q${p.size * 0.2} ${-p.size * 1.8} ${p.size * 0.7} ${-p.size * 0.7}Q${p.size * 1.6} ${-p.size * 0.6} ${p.size} ${p.size * 0.2}Z`}
                fill={color}
                shadow={false}
                rim={0}
              />
            ) : kind === "dust" ? (
              <ellipse rx={p.size} ry={p.size * 0.33} fill={color} />
            ) : (
              <circle r={p.size} fill={color} />
            )}
          </g>
        ))}
      </g>
    </g>
  );
};
export const Steam: React.FC<EffectProps> = (p) => (
  <PaperEffect {...p} kind="steam" />
);
export const Smoke: React.FC<EffectProps> = (p) => (
  <PaperEffect {...p} kind="smoke" />
);
export const Dust: React.FC<EffectProps> = (p) => (
  <PaperEffect {...p} kind="dust" />
);
export const Rain: React.FC<EffectProps> = (p) => (
  <PaperEffect {...p} kind="rain" />
);
export const Snow: React.FC<EffectProps> = (p) => (
  <PaperEffect {...p} kind="snow" />
);
export const Splash: React.FC<EffectProps> = (p) => (
  <PaperEffect {...p} kind="splash" />
);
/** World-layer reveal. Put the screen-space captions outside this component. */
export const PaperOcclusion: React.FC<{
  progress: number;
  width: number;
  height: number;
  from: React.ReactNode;
  to: React.ReactNode;
  edge?: string;
}> = ({ progress, width, height, from, to, edge = "#EADFC5" }) => {
  const id = "occlusion" + useId().replace(/[^a-z0-9]/gi, ""),
    q = smooth(clamp(progress)),
    x = -90 + (width + 180) * q,
    d = `M-120-60H${x}L${x + 12} ${height * 0.22}L${x - 7} ${height * 0.47}L${x + 7} ${height * 0.72}L${x} ${height + 60}H-120Z`;
  return (
    <g data-paper-occlusion>
      {from}
      <defs>
        <clipPath id={id}>
          <path d={d} />
        </clipPath>
      </defs>
      <g clipPath={`url(#${id})`}>{to}</g>
      {q > 0 && q < 1 ? (
        <path
          d={`M${x} -10L${x + 12} ${height * 0.22}L${x - 7} ${height * 0.47}L${x + 7} ${height * 0.72}L${x} ${height + 10}`}
          fill="none"
          stroke={edge}
          strokeWidth={9}
        />
      ) : null}
    </g>
  );
};
export const DepthMove: React.FC<{
  cameraX: number;
  cameraY?: number;
  depth: number;
  children: React.ReactNode;
}> = ({ cameraX, cameraY = 0, depth, children }) => {
  if (
    ![cameraX, cameraY, depth].every(Number.isFinite) ||
    depth < 0 ||
    depth > 1
  )
    throw new Error("Depth must be in [0,1].");
  return (
    <g
      data-depth={depth}
      transform={`translate(${-cameraX * depth} ${-cameraY * depth})`}
    >
      {children}
    </g>
  );
};
export const PivotTurn: React.FC<
  Timed & {
    time: number;
    pivot: { x: number; y: number };
    from?: number;
    to?: number;
    children: React.ReactNode;
  }
> = ({ time, pivot, from = 0, to = 90, children, ...timing }) => (
  <g
    transform={`translate(${pivot.x} ${pivot.y}) rotate(${samplePivot(time, timing, from, to)}) translate(${-pivot.x} ${-pivot.y})`}
  >
    {children}
  </g>
);
