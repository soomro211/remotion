import { clamp, smooth } from "../core/math";
export type EffectKind =
  | "steam"
  | "smoke"
  | "dust"
  | "rain"
  | "snow"
  | "splash";
export type EffectTiming = {
  time: number;
  startSeconds: number;
  durationSeconds: number;
  seed?: number;
  density?: number;
  wind?: number;
  width?: number;
  height?: number;
};
const hash = (n: number) => {
  const q = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return q - Math.floor(q);
};
export const sampleEffect = (
  kind: EffectKind,
  {
    time,
    startSeconds,
    durationSeconds,
    seed = 7,
    density = 1,
    wind = 12,
    width = 500,
    height = 400,
  }: EffectTiming,
) => {
  if (
    ![
      time,
      startSeconds,
      durationSeconds,
      seed,
      density,
      wind,
      width,
      height,
    ].every(Number.isFinite) ||
    durationSeconds <= 0 ||
    density <= 0 ||
    density > 3 ||
    width <= 0 ||
    height <= 0
  )
    throw new Error(
      "Effects require finite geometry, positive duration and density in (0,3].",
    );
  const life =
      kind === "rain"
        ? 0.75
        : kind === "snow"
          ? 3.2
          : kind === "splash"
            ? 0.7
            : 2.4,
    rate =
      (kind === "rain"
        ? 32
        : kind === "snow"
          ? 10
          : kind === "splash"
            ? 18
            : 7) * density;
  const t = time - startSeconds,
    first = Math.max(0, Math.ceil((t - life) * rate)),
    last = Math.min(
      Math.floor(t * rate),
      Math.ceil(durationSeconds * rate) - 1,
    ),
    particles = [];
  for (let i = first; i <= last; i++) {
    const age = t - i / rate,
      u = clamp(age / life),
      r = hash(i + seed * 13),
      s = hash(i * 3 + seed * 11),
      fade =
        (kind === "rain" ? 1 : smooth(u / 0.1)) *
        (1 - smooth((u - 0.55) / 0.45));
    let x = 0,
      y = 0;
    if (kind === "rain" || kind === "snow") {
      x =
        r * width +
        wind * age +
        (kind === "snow" ? Math.sin(age * 2 + i) * 9 : 0);
      y = -20 + (height + 40) * u;
    } else if (kind === "splash") {
      x = (r - 0.5) * 170 * u;
      y = -110 * (0.6 + s) * u + 180 * u * u;
    } else if (kind === "dust") {
      x = (r - 0.5) * 50 + wind * age + u * 80 * (r - 0.5);
      y = -u * 35 - 15 * Math.sin(u * Math.PI);
    } else {
      x = (r - 0.5) * 24 + wind * age + Math.sin(age * 1.8 + i) * 8;
      y = -u * height;
    }
    if (kind === "splash" && y > 0) continue;
    particles.push({
      id: i,
      x,
      y,
      u,
      opacity:
        fade *
        (kind === "steam"
          ? 0.28
          : kind === "smoke"
            ? 0.32
            : kind === "dust"
              ? 0.3
              : 0.72),
      size:
        kind === "snow"
          ? 2 + s * 3
          : kind === "rain"
            ? 12 + s * 15
            : kind === "splash"
              ? 2 + s * 2
              : 8 + u * (kind === "smoke" ? 42 : 15),
      rotation: kind === "rain" ? 0 : r * 40 - 20,
    });
  }
  return particles;
};
