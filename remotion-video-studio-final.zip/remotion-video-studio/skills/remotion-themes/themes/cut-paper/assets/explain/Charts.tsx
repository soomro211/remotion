import React from "react";
import {PaperShape,PaperDisc,PaperRect,palette} from "../core/material";
import {clamp} from "../core/math";
/** Caller supplies values and truthful labels; the asset invents no statistics. */
export const PaperBarChart:React.FC<{values:readonly number[];x?:number;y?:number;width?:number;height?:number;maximum?:number;progress?:number;fill?:string}>=({values,x=0,y=0,width=320,height=210,maximum=Math.max(1,...values),progress=1,fill=palette.teal})=>{
 if(!values.length||!values.every(v=>Number.isFinite(v)&&v>=0)||![x,y,width,height,maximum,progress].every(Number.isFinite)||Math.min(width,height,maximum)<=0||values.some(v=>v>maximum))throw new Error("Chart needs finite nonnegative values within a positive domain.");
 const unit=width/values.length,p=clamp(progress);
 return <g data-paper-chart transform={`translate(${x} ${y})`}><path d={`M0 ${-height}V0H${width}`} fill="none" stroke={palette.ink} strokeWidth={3}/>{values.map((v,i)=>v>0?<PaperRect key={i} x={i*unit+unit*.18} y={-height*v/maximum*p} width={unit*.64} height={height*v/maximum*p} fill={fill} shadow={false}/>:null)}</g>;
};
export type NetworkNode={id:string;x:number;y:number;radius?:number;fill?:string};
export const PaperNetwork:React.FC<{nodes:readonly NetworkNode[];edges:readonly (readonly [string,string])[];progress?:number;fill?:string}>=({nodes,edges,progress=1,fill=palette.teal})=>{
 const lookup=new Map(nodes.map(n=>[n.id,n]));
 if(lookup.size!==nodes.length||!Number.isFinite(progress)||nodes.some(n=>![n.x,n.y,n.radius??20].every(Number.isFinite)||(n.radius??20)<=0)||edges.some(e=>!lookup.has(e[0])||!lookup.has(e[1])))throw new Error("Network needs unique IDs, finite nodes and existing edge targets.");
 const p=clamp(progress);
 return <g data-paper-network>{edges.map(([from,to],i)=>{const a=lookup.get(from)!,b=lookup.get(to)!;return <path key={i} d={`M${a.x} ${a.y}L${b.x} ${b.y}`} fill="none" stroke="#94AE9E" strokeWidth={7} pathLength={1} strokeDasharray={1} strokeDashoffset={1-p} opacity={p>0?1:0}/>;})}{nodes.map(n=><g key={n.id}><PaperDisc x={n.x} y={n.y} radius={n.radius??20} fill={n.fill??fill}/><PaperShape d={`M${n.x-5} ${n.y-5}h10v10h-10Z`} fill="#F4EBD8" shadow={false} rim={0}/></g>)}</g>;
};
