import React, { useMemo } from "react";
import { PaperDisc, PaperShape, palette } from "../core/material";
import { circlePath, clamp } from "../core/math";
import {
  bezierPath,
  preparePath,
  samplePath,
  type Cubic,
  phaseAt,
} from "../motion/path";
export const PaperArrow: React.FC<{
  curve: Cubic;
  fill?: string;
  width?: number;
  progress?: number;
}> = ({ curve, fill = palette.coral, width = 8, progress = 1 }) => {
  const path = useMemo(() => preparePath(curve), [curve]),
    end = samplePath(path, clamp(progress)),
    a = (end.angle * Math.PI) / 180;
  const points = path.points.slice(
    0,
    Math.max(1, Math.floor(end.u * path.steps) + 1),
  );
  points.push(end);
  return (
    <g>
      <path
        d={"M" + points.map((p) => `${p.x} ${p.y}`).join("L")}
        stroke={palette.rim}
        strokeWidth={width + 2.5}
        fill="none"
        strokeLinecap="round"
      />
      <path
        d={"M" + points.map((p) => `${p.x} ${p.y}`).join("L")}
        stroke={fill}
        strokeWidth={width}
        fill="none"
        strokeLinecap="round"
      />
      {progress > 0.02 ? (
        <PaperShape
          d={`M${end.x + Math.cos(a) * 12} ${end.y + Math.sin(a) * 12}L${end.x - Math.cos(a) * 13 - Math.sin(a) * 12} ${end.y - Math.sin(a) * 13 + Math.cos(a) * 12}L${end.x - Math.cos(a) * 13 + Math.sin(a) * 12} ${end.y - Math.sin(a) * 13 - Math.cos(a) * 12}Z`}
          fill={fill}
          rim={1.4}
        />
      ) : null}
    </g>
  );
};
export const PaperFlow: React.FC<{
  curve: Cubic;
  time: number;
  period?: number;
  count?: number;
  fill?: string;
  radius?: number;
  track?: boolean;
}> = ({
  curve,
  time,
  period = 3,
  count = 7,
  fill = palette.yellow,
  radius = 7,
  track = true,
}) => {
  const path = useMemo(() => preparePath(curve), [curve]);
  return (
    <g>
      {track ? (
        <path
          d={bezierPath(curve)}
          fill="none"
          stroke="#8D9B8E"
          strokeWidth="2"
          opacity=".5"
        />
      ) : null}
      {Array.from({ length: Math.max(0, Math.floor(count)) }, (_, i) => {
        const p = samplePath(path, phaseAt(time, period, i / count));
        return (
          <PaperDisc
            key={i}
            x={p.x}
            y={p.y}
            radius={radius}
            fill={fill}
            shadow={false}
            rim={1}
          />
        );
      })}
    </g>
  );
};
export const PaperConnector: React.FC<{
  curve: Cubic;
  fill?: string;
  width?: number;
  dashed?: boolean;
}> = ({ curve, fill = "#7E9288", width = 5, dashed = false }) => (
  <path
    d={bezierPath(curve)}
    stroke={fill}
    strokeWidth={width}
    fill="none"
    strokeLinecap="round"
    strokeDasharray={dashed ? "10 12" : undefined}
  />
);
export const PaperWheel: React.FC<{
  x?: number;
  y?: number;
  radius?: number;
  angle?: number;
  fill?: string;
  spokes?: number;
}> = ({
  x = 0,
  y = 0,
  radius = 80,
  angle = 0,
  fill = palette.wood,
  spokes = 8,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${angle})`}>
    <circle
      r={radius * 0.91}
      fill="none"
      stroke={fill}
      strokeWidth={radius * 0.18}
    />
    <circle r={radius} fill="none" stroke={palette.rim} strokeWidth="2" />
    {Array.from({ length: Math.max(3, Math.floor(spokes)) }, (_, i) => (
      <PaperShape
        key={i}
        d={`M-6 0L-5 ${-radius * 0.86}L5 ${-radius * 0.86}L6 0Z`}
        transform={`rotate(${(i * 360) / spokes})`}
        fill={fill}
        rim={1.3}
      />
    ))}
    <PaperDisc radius={radius * 0.18} fill="#B6BEA2" />
    <PaperDisc radius={radius * 0.07} fill={palette.ink} />
  </g>
);
export const PaperGear: React.FC<{
  x?: number;
  y?: number;
  radius?: number;
  teeth?: number;
  angle?: number;
  fill?: string;
}> = ({
  x = 0,
  y = 0,
  radius = 70,
  teeth = 12,
  angle = 0,
  fill = "#81958B",
}) => {
  const n = Math.max(6, Math.floor(teeth)),
    points = Array.from({ length: n * 4 }, (_, i) => {
      const a = (i / (n * 4)) * Math.PI * 2,
        r = radius * (i % 4 === 0 || i % 4 === 3 ? 0.88 : 1.08);
      return `${Math.cos(a) * r} ${Math.sin(a) * r}`;
    });
  return (
    <g transform={`translate(${x} ${y}) rotate(${angle})`}>
      <PaperShape d={"M" + points.join("L") + "Z"} fill={fill} rim={1.8} />
      <PaperDisc radius={radius * 0.55} fill="#536D69" rim={1} />
      <PaperDisc radius={radius * 0.17} fill={palette.cream} />
    </g>
  );
};
export const PaperHighlight: React.FC<{
  x?: number;
  y?: number;
  radius?: number;
  fill?: string;
  progress?: number;
}> = ({ x = 0, y = 0, radius = 60, fill = palette.yellow, progress = 1 }) => (
  <path
    d={circlePath(x, y, radius, 4)}
    stroke={fill}
    strokeWidth="5"
    fill="none"
    pathLength="1"
    strokeDasharray="1"
    strokeDashoffset={1 - clamp(progress)}
    strokeLinecap="round"
  />
);
