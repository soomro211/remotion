<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](../../../../../video-director/references/current-workflow.md).

# Permanent Cut Paper story asset archive

This is part of the **main skill set**, not a video project cache. Save every ready original/adapted story asset here, including topic-specific illustrations. The archive travels with installed skills and the single ZIP. It complements the foundational component [catalog](../README.md).

Open [the saved-asset gallery](catalog.html) or search with `remotion-themes/scripts/asset_workflow.py search --query QUERY`. Read the complete [asset-first production workflow](../../../../../video-director/references/asset-first-workflow.md) for creation, review, archive, restore, versioning and Git-update commands.

Each `<id>/<version>/` contains editable source, previews, review evidence and a sealed `asset.json`. It has no dependency on the video that introduced it. IDs describe the object/process rather than a film date or scene number. `scope: topic` assets remain here too; universal scope is not a condition of preservation.

The `layered-river-valley` package is a small source/reference example: editable SVG depth planes, a composition recipe, anchors and reviewed previews. It illustrates package structure and material controls, not a mandatory background for future videos. Use the topic's art direction. It has no baked headings, subtitles, counters or progress graphics.

Use immutable versions. Sync additional installed packages into a checkout before updating skills or making a release. Preserve both archives' existing entries; conflicting versions require a reviewed new version. `index.json` and `catalog.html` are generated with `reindex` after validated changes. Metadata checks support review; each future adaptation still needs visual/motion inspection.
