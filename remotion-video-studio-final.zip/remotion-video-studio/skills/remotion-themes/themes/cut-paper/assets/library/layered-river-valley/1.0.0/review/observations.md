# Layered river valley — visual source review

Reviewed the actual 1440×1080 composite and four-plane contact sheet with the image viewer on 2026-10-23, against current street/process Cut Paper references. The initial water marks extended over land; they were corrected and clipped to the river silhouette, regenerated, and the final composite was opened again.

- Material: muted mint/teal/green sheets, cream cut edges, restrained tight/soft shadows and fine matte fibres match the shared material relationships.
- Silhouette/scale: the river bend reads across the frame; foreground plants/stones separate from the banks. Distinct back/mid/front planes remain legible at contact-sheet scale.
- Layers: sky, distant hills, river/floor and foreground banks have separate editable SVG sources on one 1440×1080 canvas. Transparent layers were inspected on cream. Recompose back to front as recorded in source/layers.json; composite.svg is a generated convenience proof, not a second source to edit independently.
- Coverage: this is a full-frame wide static source study. No portrait reframing, independent parallax range, zoom extremes or moving camera have been certified. Adapt coverage and inspect any new camera/aspect ratio before using it in a film.
- Motion: not applicable to this static source proof. No playback or animated mechanism review is claimed. Moving the river ripples or planes needs authored timing and fresh review.
- Text: no baked headings, subtitles, counters, progress bars or watermarks. The contact-sheet labels are review-only.
- Portability: geometry/material definitions are embedded; there are no images, fonts, absolute URLs, private narration or imports from a film project. The shared asset checker verifies sealed bytes and restore behavior separately.

Edit the four depth-plane SVG files; regenerate the composite/proofs together after changing geometry/material, then publish a reviewed new version. Controls are source geometry/fills/visibility. A React rig or interactive palette UI is not supplied.
