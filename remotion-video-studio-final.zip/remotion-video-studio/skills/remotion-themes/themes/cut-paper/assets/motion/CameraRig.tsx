// Install the canonical camera with remotion-themes/scripts/assets.py. World coordinates are composition pixels.
// Put captions outside this rig. Author overscan; the rig cannot invent artwork.
import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";

export type CameraPose = { centerX: number; centerY: number; zoom: number };

export const CameraRig: React.FC<{
  from: CameraPose;
  to: CameraPose;
  startSeconds: number;
  sourceSeconds?: number;
  durationSeconds: number;
  children: React.ReactNode;
}> = ({ from, to, startSeconds, durationSeconds, sourceSeconds, children }) => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  if (durationSeconds <= 0 || Math.min(from.zoom, to.zoom) <= 0) {
    throw new Error("CameraRig needs positive duration and zoom");
  }
  const p = Math.max(
    0,
    Math.min(
      1,
      ((sourceSeconds ?? frame / fps) - startSeconds) / durationSeconds,
    ),
  );
  // Quintic smoothstep: zero velocity and acceleration at each end.
  const u = p * p * p * (p * (p * 6 - 15) + 10);
  const mix = (a: number, b: number) => a + (b - a) * u;
  const zoom = mix(from.zoom, to.zoom);
  const x = mix(from.centerX, to.centerX);
  const y = mix(from.centerY, to.centerY);
  return (
    <AbsoluteFill
      data-camera-rig
      style={{
        transformOrigin: "0 0",
        translate: `${width / 2 - x * zoom}px ${height / 2 - y * zoom}px`,
        scale: zoom,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

// Pass the actual visual sequence start, including its transition overlap.
// Use this clock for recurring wheels, water, smoke and other continuous action.
export const useSourceSeconds = (sequenceStartSeconds: number) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return sequenceStartSeconds + frame / fps;
};
