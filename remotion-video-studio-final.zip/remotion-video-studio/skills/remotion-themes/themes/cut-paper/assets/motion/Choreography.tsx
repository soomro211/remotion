import React,{useId} from "react";
import {clamp} from "../core/math";
import {progressAt,sampleArc,sampleOrbit,samplePulse,sampleStagger,type Timed} from "./choreography";
import type {Point} from "../core/math";
type Children={children:React.ReactNode};
export const ArcTransfer:React.FC<Timed&Children&{time:number;from:Point;to:Point;clearance?:number}>=({time,from,to,clearance=80,children,...timing})=>{
  const p=sampleArc(time,timing,from,to,clearance);return <g transform={`translate(${p.x} ${p.y})`}>{children}</g>;
};
export const Hinge:React.FC<Children&{pivot:Point;progress:number;closedAngle?:number;openAngle?:number}>=({pivot,progress,closedAngle=0,openAngle=-90,children})=>{
  const angle=closedAngle+(openAngle-closedAngle)*clamp(progress);return <g transform={`translate(${pivot.x} ${pivot.y}) rotate(${angle}) translate(${-pivot.x} ${-pivot.y})`}>{children}</g>;
};
export const TracePath:React.FC<{d:string;progress:number;stroke?:string;width?:number;underlay?:string}>=({d,progress,stroke="#F2BC55",width=8,underlay})=><g>{underlay?<path d={d} fill="none" stroke={underlay} strokeWidth={width}/>:null}<path data-trace-path d={d} pathLength={1} fill="none" stroke={stroke} strokeWidth={width} strokeLinecap="round" strokeDasharray={1} strokeDashoffset={1-clamp(progress)} opacity={progress>0?1:0}/></g>;
export const Pulse:React.FC<Timed&Children&{time:number;pivot?:Point;cycles?:number;amplitude?:number}>=({time,pivot={x:0,y:0},cycles=2,amplitude=.08,children,...timing})=>{
  const s=samplePulse(time,timing,cycles,amplitude);return <g transform={`translate(${pivot.x} ${pivot.y}) scale(${s}) translate(${-pivot.x} ${-pivot.y})`}>{children}</g>;
};
export const Orbit:React.FC<Timed&Children&{time:number;center:Point;radius:number;turns?:number;orient?:boolean}>=({time,center,radius,turns=1,orient=false,children,...timing})=>{
  const p=sampleOrbit(time,timing,center,radius,turns);return <g transform={`translate(${p.x} ${p.y}) rotate(${orient?p.angle+90:0})`}>{children}</g>;
};
export const Stagger:React.FC<Timed&Children&{time:number;index:number;delaySeconds?:number;travel?:number}>=({time,index,delaySeconds=.12,travel=16,children,...timing})=>{
  const p=sampleStagger(time,timing,index,delaySeconds);return <g opacity={p} transform={`translate(0 ${(1-p)*travel})`}>{children}</g>;
};
export const LiquidStream:React.FC<{from:Point;to:Point;flow:number;width?:number;fill?:string}>=({from,to,flow,width=10,fill="#66AAA8"})=>{
  const id="liquid"+useId().replace(/[^a-z0-9]/gi,""),p=clamp(flow);
  return <g opacity={p}><defs><clipPath id={id}><rect x={Math.min(from.x,to.x)-width*3} y={Math.min(from.y,to.y)} width={Math.abs(to.x-from.x)+width*6} height={Math.abs(to.y-from.y)+width}/></clipPath></defs><path clipPath={`url(#${id})`} d={`M${from.x} ${from.y}Q${from.x} ${to.y} ${to.x} ${to.y}`} stroke={fill} strokeWidth={width*p} fill="none" strokeLinecap="round"/></g>;
};
export const ObjectSettle:React.FC<Timed&Children&{time:number;from?:Point;anticipation?:number}>=({time,from={x:0,y:50},anticipation=6,children,...timing})=>{
  const p=progressAt(time,timing),q=p*p*p*(p*(p*6-15)+10),settle=Math.sin(Math.PI*p)*Math.sin(Math.PI*p*2)*anticipation;
  return <g opacity={clamp(p*6)} transform={`translate(${from.x*(1-q)} ${from.y*(1-q)+settle})`}>{children}</g>;
};
