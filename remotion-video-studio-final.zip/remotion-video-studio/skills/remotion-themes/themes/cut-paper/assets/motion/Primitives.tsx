import React, { useId } from "react";
import { clamp } from "../core/math";
import { samplePath, type MotionPath } from "./path";
// Masks one object with authored bounds. It is not a default full-scene wipe.
export const ObjectReveal: React.FC<{
  x: number;
  y: number;
  width: number;
  height: number;
  progress: number;
  from?: "left" | "right" | "top" | "bottom";
  children: React.ReactNode;
}> = ({ x, y, width, height, progress, from = "left", children }) => {
  const id = "reveal" + useId().replace(/:/g, ""),
    p = clamp(progress),
    pad = p === 1 ? 18 : 0;
  if (!(width > 0 && height > 0))
    throw new Error("ObjectReveal needs positive bounds.");
  const horizontal = from === "left" || from === "right",
    w = horizontal ? width * p : width,
    h = horizontal ? height : height * p;
  const rx = x + (from === "right" ? width - w : 0),
    ry = y + (from === "bottom" ? height - h : 0);
  return (
    <g>
      <defs>
        <clipPath id={id}>
          <rect
            x={rx - pad}
            y={ry - pad}
            width={w + 2 * pad}
            height={h + 2 * pad}
          />
        </clipPath>
      </defs>
      <g clipPath={`url(#${id})`}>{children}</g>
    </g>
  );
};
export const PathFollower: React.FC<{
  path: MotionPath;
  progress: number;
  orient?: boolean;
  children: React.ReactNode;
}> = ({ path, progress, orient = false, children }) => {
  const p = samplePath(path, progress);
  return (
    <g
      transform={`translate(${p.x} ${p.y})${orient ? ` rotate(${p.angle})` : ""}`}
    >
      {children}
    </g>
  );
};
