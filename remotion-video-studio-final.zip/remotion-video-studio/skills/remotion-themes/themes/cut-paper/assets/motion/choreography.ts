import {clamp,lerpPoint,mix,smooth,type Point} from "../core/math";
import {mixAngle} from "./path";
export type Timed = {startSeconds:number;durationSeconds:number};
export const progressAt=(time:number,timing:Timed)=>{
  if (![time,timing.startSeconds,timing.durationSeconds].every(Number.isFinite)||timing.durationSeconds<=0) throw new Error("Finite seconds and positive duration required.");
  return clamp((time-timing.startSeconds)/timing.durationSeconds);
};
/** C2 arrival and departure, exact endpoints, no frame accumulation. */
export const sampleTween=(time:number,timing:Timed,from=0,to=1)=>mix(from,to,smooth(progressAt(time,timing)));
/** Pick/place or transfer arc. Height is a visual clearance, not a gravity simulation. */
export const sampleArc=(time:number,timing:Timed,from:Point,to:Point,height=80)=>{
  if(![from.x,from.y,to.x,to.y,height].every(Number.isFinite))throw new Error("Arc endpoints and clearance must be finite.");
  const p=smooth(progressAt(time,timing)),point=lerpPoint(from,to,p);
  return {...point,y:point.y-height*4*p*(1-p),progress:p};
};
export const sampleStagger=(time:number,timing:Timed,index:number,delaySeconds=.12)=>{
  if (!Number.isInteger(index)||index<0||!Number.isFinite(delaySeconds)||delaySeconds<0)throw new Error("Stagger requires nonnegative index and delay.");
  return smooth(progressAt(time,{...timing,startSeconds:timing.startSeconds+index*delaySeconds}));
};
/** Finite, gently enveloped oscillation which returns exactly to rest. */
export const samplePulse=(time:number,timing:Timed,cycles=2,amplitude=.08)=>{
  if(!Number.isFinite(cycles)||cycles<0||!Number.isFinite(amplitude)||amplitude<0||amplitude>=1)throw new Error("Pulse cycles must be nonnegative; amplitude must be in [0,1).");
  const p=progressAt(time,timing);
  return 1+Math.sin(p*Math.PI*2*cycles)*Math.sin(Math.PI*p)**2*amplitude;
};
export const sampleOrbit=(time:number,timing:Timed,center:Point,radius:number,turns=1,startAngle=-90)=>{
  if (![center.x,center.y,radius,turns,startAngle].every(Number.isFinite)||radius<0)throw new Error("Orbit requires finite controls and a nonnegative radius.");
  const p=smooth(progressAt(time,timing)),angle=startAngle+p*360*turns,a=angle*Math.PI/180;
  return {x:center.x+Math.cos(a)*radius,y:center.y+Math.sin(a)*radius,angle,progress:p};
};
/** One transfer clock drives the item and both hand targets. */
export const sampleHandoff=(time:number,timing:Timed,from:Point,to:Point,clearance=45)=>{
  const p=progressAt(time,timing),position=sampleArc(time,timing,from,to,clearance);
  return {...position,owner:p<.35?"giver" as const:p>.65?"receiver" as const:"shared" as const,giverGrip:1-smooth((p-.55)/.15),receiverGrip:smooth((p-.3)/.15)};
};
/** Tilt -> pour -> return. Volume removed exactly equals volume received. */
export const samplePour=(time:number,timing:Timed,initialVolume=1,amount=.7)=>{
  if (![initialVolume,amount].every(Number.isFinite)||initialVolume<0||amount<0||amount>initialVolume)throw new Error("Pour amount must fit available volume.");
  const p=progressAt(time,timing),flow=smooth((p-.25)/.5),tilt=p>=1?0:smooth(p/.2)*(1-smooth((p-.8)/.2));
  const streamPhase=clamp((p-.2)/.6);
  return {angle:tilt>0?-62*tilt:0,stream:streamPhase>0&&streamPhase<1?Math.sin(Math.PI*streamPhase)**2:0,sourceVolume:initialVolume-amount*flow,receivedVolume:amount*flow,progress:p};
};
export type CameraKey={seconds:number;centerX:number;centerY:number;zoom:number};
export const sampleCameraPath=(time:number,keys:readonly CameraKey[])=>{
  if (!Number.isFinite(time)||!keys.length||keys.some((k,i)=>![k.seconds,k.centerX,k.centerY,k.zoom].every(Number.isFinite)||k.zoom<=0||(i>0&&k.seconds<=keys[i-1].seconds)))throw new Error("Camera keys require increasing finite seconds and positive zoom.");
  if(time<=keys[0].seconds)return {...keys[0]};
  if(time>=keys[keys.length-1].seconds)return {...keys[keys.length-1]};
  const j=keys.findIndex(k=>k.seconds>=time),a=keys[j-1],b=keys[j],p=smooth((time-a.seconds)/(b.seconds-a.seconds));
  return {seconds:time,centerX:mix(a.centerX,b.centerX,p),centerY:mix(a.centerY,b.centerY,p),zoom:mix(a.zoom,b.zoom,p)};
};
export const sampleTurn=(time:number,timing:Timed,from:number,to:number)=>mixAngle(from,to,smooth(progressAt(time,timing)));
