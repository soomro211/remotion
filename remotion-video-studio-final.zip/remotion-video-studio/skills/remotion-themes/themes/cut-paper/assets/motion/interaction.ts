import { clamp, mix, smooth, lerpPoint } from "../core/math";
import { progressAt, type Timed } from "./choreography";
export const sampleLift = (
  time: number,
  timing: Timed,
  mode: "lift" | "place" = "lift",
) => {
  const p = progressAt(time, timing),
    u = mode === "place" ? 1 - p : p;
  const bend = smooth(u / 0.28) * (1 - smooth((u - 0.36) / 0.4)),
    raise = smooth((u - 0.32) / 0.42),
    grip = smooth((u - 0.12) / 0.16);
  const bottom = mix(0, -175, raise),
    lean = 28 * bend;
  const nearContact = { x: 65, y: bottom - 80 },
    farContact = { x: 80, y: bottom - 80 };
  // Both wrists are derived from the same item contacts. Approach is explicit before ownership.
  const restNear = { x: 35 + lean, y: -202 + 125 * bend },
    restFar = { x: 20 + lean, y: -206 + 125 * bend };
  return {
    phase: p,
    crouch: bend,
    lean,
    bottom,
    grip,
    near: lerpPoint(restNear, nearContact, grip),
    far: lerpPoint(restFar, farContact, grip),
    nearContact,
    farContact,
    attached: grip >= 1 - 1e-8,
  };
};
export const samplePivot = (time: number, timing: Timed, from = 0, to = 90) => {
  if (![from, to].every(Number.isFinite))
    throw new Error("Pivot angles must be finite.");
  return mix(from, to, smooth(clamp(progressAt(time, timing))));
};
