import { clamp, length, mix, type Point } from "../core/math";
export type Cubic = readonly [Point, Point, Point, Point];
export const bezier = (p: Cubic, u: number): Point => {
  const t = clamp(u),
    v = 1 - t;
  return {
    x:
      v ** 3 * p[0].x +
      3 * v * v * t * p[1].x +
      3 * v * t * t * p[2].x +
      t ** 3 * p[3].x,
    y:
      v ** 3 * p[0].y +
      3 * v * v * t * p[1].y +
      3 * v * t * t * p[2].y +
      t ** 3 * p[3].y,
  };
};
export const bezierPath = (p: Cubic) =>
  `M${p[0].x} ${p[0].y}C${p[1].x} ${p[1].y} ${p[2].x} ${p[2].y} ${p[3].x} ${p[3].y}`;
export const preparePath = (curve: Cubic, steps = 120) => {
  if (
    steps < 8 ||
    !Number.isInteger(steps) ||
    curve.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y))
  )
    throw new Error(
      "Finite control points and at least 8 integer path samples required.",
    );
  const points = Array.from({ length: steps + 1 }, (_, i) =>
      bezier(curve, i / steps),
    ),
    distances = [0];
  for (let i = 1; i <= steps; i++)
    distances.push(distances[i - 1] + length(points[i - 1], points[i]));
  const total = distances[steps];
  if (total < 0.0001) throw new Error("Motion path must have nonzero length.");
  return { curve, points, distances, total, steps };
};
export type MotionPath = ReturnType<typeof preparePath>;
export const samplePath = (path: MotionPath, progress: number) => {
  const distance = clamp(progress) * path.total,
    i = Math.min(
      path.steps - 1,
      Math.max(0, path.distances.findIndex((v) => v >= distance) - 1),
    ),
    span = path.distances[i + 1] - path.distances[i],
    q = span ? clamp((distance - path.distances[i]) / span) : 0;
  const u = (i + q) / path.steps,
    p = bezier(path.curve, u),
    a = bezier(path.curve, Math.max(0, u - 0.001)),
    b = bezier(path.curve, Math.min(1, u + 0.001));
  return {
    ...p,
    angle: (Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI,
    u,
    distance,
  };
};
export const wheelAngle = (distance: number, radius: number) => {
  if (!(radius > 0)) throw new Error("Wheel radius must be positive.");
  return ((distance / radius) * 180) / Math.PI;
};
export const gearAngle = (
  driverAngle: number,
  driverRadius: number,
  followerRadius: number,
) => {
  if (!(driverRadius > 0 && followerRadius > 0))
    throw new Error("Gear radii must be positive.");
  return (-driverAngle * driverRadius) / followerRadius;
};
export const timeProgress = (time: number, start: number, duration: number) => {
  if (!(duration > 0)) throw new Error("Animation duration must be positive.");
  return clamp((time - start) / duration);
};
export const phaseAt = (time: number, period: number, offset = 0) => {
  if (!(period > 0)) throw new Error("Loop period must be positive.");
  return (((time / period + offset) % 1) + 1) % 1;
};
export const mixAngle = (from: number, to: number, t: number) =>
  mix(from, from + ((to - from + 540) % 360) - 180, t);
