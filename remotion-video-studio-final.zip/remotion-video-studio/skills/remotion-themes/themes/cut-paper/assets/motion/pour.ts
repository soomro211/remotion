import { clamp, mix, rotate, smooth, type Point } from "../core/math";

export const pitcherOutline: readonly Point[] = [
  { x: 64, y: 54 },
  { x: 164, y: 54 },
  { x: 195, y: 32 },
  { x: 212, y: 38 },
  { x: 187, y: 71 },
  { x: 182, y: 91 },
  { x: 173, y: 225 },
  { x: 143, y: 237 },
  { x: 99, y: 234 },
  { x: 78, y: 228 },
  { x: 62, y: 90 },
];
export const pitcherPivot = { x: 44, y: 142 },
  pitcherLip = { x: 212, y: 38 };
export const polygonPath = (points: readonly Point[]) =>
  points.map((p, i) => (i ? "L" : "M") + p.x + " " + p.y).join("") + "Z";
export const polygonArea = (points: readonly Point[]) =>
  Math.abs(
    points.reduce((sum, a, i) => {
      const b = points[(i + 1) % points.length];
      return sum + a.x * b.y - b.x * a.y;
    }, 0),
  ) / 2;
export const belowSurface = (points: readonly Point[], surface: number) => {
  const result: Point[] = [];
  points.forEach((a, i) => {
    const b = points[(i + 1) % points.length],
      insideA = a.y >= surface,
      insideB = b.y >= surface;
    if (insideA) result.push(a);
    if (insideA !== insideB) {
      const q = (surface - a.y) / (b.y - a.y);
      result.push({ x: mix(a.x, b.x, q), y: surface });
    }
  });
  return result;
};
export const pitcherPoint = (point: Point, angle: number) => {
  const p = rotate(
    { x: point.x - pitcherPivot.x, y: point.y - pitcherPivot.y },
    angle,
  );
  return { x: p.x + pitcherPivot.x, y: p.y + pitcherPivot.y };
};
const area = polygonArea(pitcherOutline);
export const capacityAtAngle = (angle: number) => {
  const body = pitcherOutline.map((p) => pitcherPoint(p, angle)),
    lip = pitcherPoint(pitcherLip, angle);
  return clamp(polygonArea(belowSurface(body, lip.y)) / area);
};
export const angleForCapacity = (fraction: number) => {
  let lo = 0,
    hi = 85;
  for (let i = 0; i < 24; i++) {
    const middle = (lo + hi) / 2;
    if (capacityAtAngle(middle) > fraction) lo = middle;
    else hi = middle;
  }
  return (lo + hi) / 2;
};
export const horizontalSurface = (body: readonly Point[], fraction: number) => {
  const total = polygonArea(body),
    desired = total * clamp(fraction);
  let lo = Math.min(...body.map((p) => p.y)),
    hi = Math.max(...body.map((p) => p.y));
  if (fraction <= 0) return hi;
  if (fraction >= 1) return lo;
  for (let i = 0; i < 28; i++) {
    const middle = (lo + hi) / 2;
    if (polygonArea(belowSurface(body, middle)) > desired) lo = middle;
    else hi = middle;
  }
  return (lo + hi) / 2;
};

export type PourConfig = {
  startSeconds: number;
  durationSeconds: number;
  initialVolume?: number;
  amount?: number;
  source?: Point;
  scale?: number;
  mouth?: Point;
  receiverWidth?: number;
  receiverHeight?: number;
  flightSeconds?: number;
};
export const preparePour = (config: PourConfig) => {
  const c = {
    initialVolume: 0.8,
    amount: 0.45,
    source: { x: 100, y: 0 },
    scale: 1.6,
    mouth: { x: 590, y: 470 },
    receiverWidth: 180,
    receiverHeight: 240,
    flightSeconds: 0.38,
    ...config,
  };
  if (
    ![
      c.startSeconds,
      c.durationSeconds,
      c.initialVolume,
      c.amount,
      c.source.x,
      c.source.y,
      c.scale,
      c.mouth.x,
      c.mouth.y,
      c.receiverWidth,
      c.receiverHeight,
      c.flightSeconds,
    ].every(Number.isFinite) ||
    c.durationSeconds <= 0 ||
    c.scale <= 0 ||
    c.receiverWidth <= 0 ||
    c.receiverHeight <= 0 ||
    c.flightSeconds <= 0 ||
    c.initialVolume <= 0 ||
    c.initialVolume > 1 ||
    c.amount < 0 ||
    c.amount > c.initialVolume
  )
    throw new Error(
      "Pour requires finite geometry, positive timing/scale and available liquid.",
    );
  const startAngle = angleForCapacity(c.initialVolume),
    endAngle = angleForCapacity(c.initialVolume - c.amount);
  const receiverArea = c.receiverWidth * c.receiverHeight * 0.86;
  const receiverCapacity = receiverArea / (area * c.scale * c.scale);
  if (c.amount > receiverCapacity)
    throw new Error("Receiver is too small for the requested volume.");
  return { ...c, startAngle, endAngle, receiverCapacity };
};
export type PreparedPour = ReturnType<typeof preparePour>;

const emittedAt = (time: number, c: PreparedPour) => {
  const phase = clamp((time - c.startSeconds) / c.durationSeconds),
    u = clamp((phase - 0.28) / 0.42);
  return c.amount * smooth(u);
};
const poseAt = (time: number, c: PreparedPour) => {
  const phase = clamp((time - c.startSeconds) / c.durationSeconds),
    emitted = emittedAt(time, c),
    sourceVolume = c.initialVolume - emitted;
  let angle = 0;
  if (phase < 0.28) angle = c.startAngle * smooth(phase / 0.28);
  else if (phase <= 0.7) angle = angleForCapacity(sourceVolume);
  else angle = c.endAngle * (1 - smooth((phase - 0.7) / 0.28));
  const lipLocal = pitcherPoint(pitcherLip, angle);
  return {
    angle,
    sourceVolume,
    lip: {
      x: c.source.x + lipLocal.x * c.scale,
      y: c.source.y + lipLocal.y * c.scale,
    },
  };
};
export const samplePouring = (time: number, c: PreparedPour) => {
  if (!Number.isFinite(time))
    throw new Error("Pour source time must be finite.");
  const pose = poseAt(time, c),
    emitted = emittedAt(time, c),
    received = emittedAt(time - c.flightSeconds, c);
  const start = c.startSeconds + 0.28 * c.durationSeconds,
    end = c.startSeconds + 0.7 * c.durationSeconds;
  const first = clamp((time - end) / c.flightSeconds),
    last = clamp((time - start) / c.flightSeconds);
  const active = last > first && c.amount > 0;
  const stream: Point[] = [];
  if (active)
    for (let i = 0; i <= 24; i++) {
      const u = mix(first, last, i / 24),
        emissionTime = time - u * c.flightSeconds,
        origin = poseAt(emissionTime, c).lip;
      // A finite flight clock follows each emitted parcel from the moving lip to the mouth.
      stream.push({
        x: mix(origin.x, c.mouth.x, u),
        y: origin.y + (c.mouth.y - origin.y) * u * u,
      });
    }
  const body = pitcherOutline.map((p) => {
    const local = pitcherPoint(p, pose.angle);
    return {
      x: c.source.x + local.x * c.scale,
      y: c.source.y + local.y * c.scale,
    };
  });
  const fraction = clamp(received / c.receiverCapacity),
    surface =
      c.mouth.y + c.receiverHeight - 8 - (c.receiverHeight - 18) * fraction;
  const ratePhase = clamp(
    ((time - c.startSeconds) / c.durationSeconds - 0.28) / 0.42,
  );
  const rate =
    (c.amount *
      30 *
      ratePhase *
      ratePhase *
      (1 - ratePhase) *
      (1 - ratePhase)) /
    (0.42 * c.durationSeconds);
  const arrivalPhase = clamp(
    ((time - c.flightSeconds - c.startSeconds) / c.durationSeconds - 0.28) /
      0.42,
  );
  const arrivalRate =
    (30 *
      arrivalPhase *
      arrivalPhase *
      (1 - arrivalPhase) *
      (1 - arrivalPhase)) /
    1.875;
  return {
    ...pose,
    emitted,
    received,
    inFlight: emitted - received,
    body,
    sourceSurface: horizontalSurface(body, pose.sourceVolume),
    receiverSurface: surface,
    receiverFraction: fraction,
    stream,
    flowRate: rate,
    arrivalRate,
    active,
    phase: clamp((time - c.startSeconds) / c.durationSeconds),
  };
};
