import React from "react";
import {palette,PaperShape} from "../core/material";
import {circlePath} from "../core/math";
export type ObjectProps = {
  x?: number; y?: number; scale?: number;
  fill?: string; accent?: string; ink?: string;
  /** A bounded authored state, e.g. opening or growth; not an automatic timer. */
  progress?: number; level?: number; angle?: number;
};
export const ObjectFrame: React.FC<ObjectProps & {name:string; children:React.ReactNode}> = ({x=0,y=0,scale=1,angle=0,progress=1,level=.6,name,children}) => {
  if (![x,y,scale,angle,progress,level].every(Number.isFinite) || scale<=0)
    throw new Error("Object coordinates/state must be finite; scale must be positive.");
  return <g data-paper-object={name} transform={`translate(${x} ${y}) rotate(${angle}) scale(${scale}) translate(-120 -220)`}>{children}</g>;
};
export const Detail:React.FC<{d:string;fill?:string;width?:number;opacity?:number}> = ({d,fill=palette.ink,width=2.4,opacity=.6}) => <path d={d} fill="none" stroke={fill} strokeWidth={width} opacity={opacity} strokeLinecap="round" strokeLinejoin="round"/>;
export const Ring:React.FC<{x:number;y:number;radius:number;hole:number;fill:string}>=({x,y,radius,hole,fill})=><PaperShape d={circlePath(x,y,radius)+circlePath(x,y,hole)} fillRule="evenodd" fill={fill}/>;
