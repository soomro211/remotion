import React from "react";
import {
  PaperShape as P,
  PaperRect as R,
  PaperDisc as D,
  palette,
} from "../core/material";
import { clamp } from "../core/math";
import { ObjectFrame, Detail as L, type ObjectProps } from "./Base";
import { VehicleWheel } from "./Transport";
export type EquipmentProps = ObjectProps & { distance?: number };
export const PaperOven: React.FC<ObjectProps> = (p) => {
  const q = clamp(p.progress ?? 0);
  return (
    <ObjectFrame {...p} name="oven">
      <R x={34} y={45} width={173} height={166} fill={p.fill ?? "#7F9890"} />
      <P d="M34 45L54 26H217L207 45Z" fill="#B5BCAB" />
      {[76, 158].map((x) => (
        <g key={x}>
          <ellipse cx={x} cy={36} rx={26} ry={7} fill="#49676B" />
          <ellipse
            cx={x}
            cy={36}
            rx={16}
            ry={4}
            fill="none"
            stroke="#A7B2A4"
            strokeWidth={2}
          />
        </g>
      ))}
      <R x={45} y={57} width={151} height={26} fill="#D7D4BC" />
      {[61, 99, 139, 177].map((x) => (
        <D key={x} x={x} y={70} radius={6} fill={p.ink ?? palette.ink} />
      ))}
      <R x={48} y={96} width={146} height={100} fill="#3D595D" />
      <g
        transform={`translate(48 196) scale(1 ${1 - q * 0.9}) translate(-48 -196)`}
      >
        <R x={48} y={96} width={146} height={100} fill="#A9B5A4" />
        <R x={59} y={119} width={123} height={63} fill="#536C6B" />
        <R x={66} y={103} width={109} height={6} fill="#E1DDC5" />
      </g>
      <R x={43} y={210} width={16} height={10} fill="#405E61" />
      <R x={182} y={210} width={16} height={10} fill="#405E61" />
    </ObjectFrame>
  );
};
export const PaperConveyor: React.FC<EquipmentProps> = ({
  distance = 0,
  ...p
}) => (
  <ObjectFrame {...p} name="conveyor">
    <R x={21} y={121} width={198} height={51} fill="#6D8C84" />
    <R x={26} y={161} width={15} height={59} fill="#48676B" />
    <R x={199} y={161} width={15} height={59} fill="#48676B" />
    <R x={16} y={114} width={208} height={37} fill="#455F62" />
    {Array.from({ length: 9 }, (_, i) => (
      <D key={i} x={29 + i * 23} y={132} radius={11} fill="#A3B0A0" />
    ))}
    <path d="M28 115H210M28 149H210" stroke="#D7D7BF" strokeWidth={3} />
    {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
      <path
        key={i}
        d={`M${27 + ((i * 23 + (((distance % 23) + 23) % 23)) % 184)} 117v30`}
        stroke="#657D77"
        strokeWidth={2}
      />
    ))}
    <P d="M78 113V73L116 57L154 74V114Z" fill={p.fill ?? "#C4A16B"} />
    <P d="M78 73L116 89L154 74L116 57Z" fill="#DDC18A" />
    <L d="M116 89V113" fill="#8A7656" />
  </ObjectFrame>
);
export const PaperPallet: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="pallet">
    <P d="M22 154L165 127L224 166L80 196Z" fill="#8F7959" />
    {[0, 1, 2, 3].map((i) => (
      <P
        key={i}
        d={`M${22 + i * 15} ${145 + i * 9}l143-27 12 8-143 28Z`}
        fill={p.fill ?? "#C3A16F"}
      />
    ))}
    <P d="M22 157L80 193V218L22 181Z" fill="#B39160" />
    <P d="M80 193L224 165V190L80 218Z" fill="#9A815D" />
    <P
      d="M91 201L121 195V212L91 217ZM169 185L199 179V195L169 201Z"
      fill="#4F5C50"
    />
    <L d="M33 164L71 189M95 193L213 170" fill="#E1C38C" />
  </ObjectFrame>
);
export const PaperForklift: React.FC<EquipmentProps> = ({
  distance = 0,
  ...p
}) => {
  const lift = clamp(p.progress ?? 0) * 62;
  return (
    <ObjectFrame {...p} name="forklift">
      <P d="M28 145H137L156 176V203H28Z" fill={p.fill ?? "#C9AC6A"} />
      <R x={77} y={59} width={9} height={91} fill="#405F62" />
      <R x={139} y={59} width={9} height={112} fill="#405F62" />
      <R x={67} y={51} width={93} height={12} fill="#405F62" />
      <R x={167} y={53} width={10} height={156} fill="#4F6D6B" />
      <R x={184} y={53} width={8} height={156} fill="#829A8D" />
      <g transform={`translate(0 ${-lift})`}>
        <P d="M178 170H191V201H230V210H178Z" fill="#6D837B" />
      </g>
      <P d="M86 126H107V155H132V164H85Z" fill="#4D6768" />
      <L d="M127 132L133 111L144 107" fill="#496568" width={5} />
      <VehicleWheel x={54} y={199} radius={21} distance={distance} />
      <VehicleWheel x={143} y={203} radius={17} distance={distance} />
      <L d="M37 158H65" fill="#E3D3A7" width={4} />
    </ObjectFrame>
  );
};
export const PaperHandcart: React.FC<EquipmentProps> = ({
  distance = 0,
  ...p
}) => (
  <ObjectFrame {...p} name="handcart">
    <L
      d="M63 40H99L139 198H208V210H120L82 57H64"
      fill={p.ink ?? palette.ink}
      width={10}
      opacity={1}
    />
    <P d="M104 113L164 102L182 173L121 186Z" fill={p.fill ?? "#C1A075"} />
    <P d="M104 113L125 95L183 86L164 102Z" fill="#D8BC8A" />
    <P d="M164 102L183 86L200 155L182 173Z" fill="#A88B61" />
    <L d="M121 135L173 125" fill="#E2CAA1" width={12} />
    <VehicleWheel x={132} y={199} radius={21} distance={distance} />
  </ObjectFrame>
);
export const PaperCashRegister: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="cash-register">
    <P d="M36 153L193 152L214 206H25Z" fill={p.fill ?? "#6F958C"} />
    <R x={39} y={184} width={155} height={30} fill="#487478" />
    <L d="M99 194H140" fill="#E1D7BB" width={4} />
    <P d="M73 94H178L188 153H59Z" fill="#A4B5A5" />
    <R x={90} y={36} width={90} height={54} fill="#3F6269" />
    <R x={99} y={45} width={72} height={33} fill="#B8C7A5" />
    <R x={120} y={89} width={17} height={19} fill="#3F6269" />
    {[0, 1, 2].map((j) =>
      [0, 1, 2, 3].map((i) => (
        <R
          key={i + "-" + j}
          x={77 + i * 24}
          y={111 + j * 11}
          width={16}
          height={7}
          fill={i === 3 ? "#CEB171" : "#E9DFC3"}
        />
      )),
    )}
    <P d="M40 152V94H66V151Z" fill="#F1E8D0" />
    <L d="M45 110H59M45 119H59" fill="#96A18A" width={2} />
  </ObjectFrame>
);
export const PaperMedicalBed: React.FC<EquipmentProps> = ({
  distance = 0,
  ...p
}) => (
  <ObjectFrame {...p} name="medical-bed">
    <R x={31} y={160} width={11} height={47} fill="#668B87" />
    <R x={196} y={164} width={11} height={43} fill="#668B87" />
    <P d="M30 125L193 139L210 168L31 159Z" fill={p.fill ?? "#7CA39A"} />
    <P d="M37 112L191 126L211 145L33 135Z" fill="#E7E8D4" />
    <P d="M96 117L191 126L209 146L92 137Z" fill="#A1C0B2" />
    <P d="M43 107L83 110L90 127L41 124Z" fill="#F7EFDA" />
    <L
      d="M24 150V103H52M214 171V127H190M72 147L167 155"
      fill="#73988F"
      width={6}
    />
    <VehicleWheel x={37} y={211} radius={9} distance={distance} />
    <VehicleWheel x={201} y={211} radius={9} distance={distance} />
    <R x={51} y={174} width={135} height={7} fill="#7F9C92" />
  </ObjectFrame>
);
export const PaperMedicalCart: React.FC<EquipmentProps> = ({
  distance = 0,
  ...p
}) => (
  <ObjectFrame {...p} name="medical-cart">
    <R x={57} y={84} width={127} height={114} fill={p.fill ?? "#A8BBA9"} />
    <R x={48} y={73} width={145} height={15} fill="#75968B" />
    {[0, 1, 2].map((i) => (
      <g key={i}>
        <R x={64} y={94 + i * 31} width={112} height={26} fill="#D8DECA" />
        <L d={`M105 ${106 + i * 31}h31`} fill="#668A80" width={4} />
      </g>
    ))}
    <L d="M51 96H31V140H51" fill="#6E9088" width={7} />
    <VehicleWheel x={70} y={211} radius={9} distance={distance} />
    <VehicleWheel x={172} y={211} radius={9} distance={distance} />
    <R x={80} y={37} width={31} height={35} fill="#EBE7D1" />
    <P d="M91 43H100V51H107V60H100V67H91V60H83V51H91Z" fill="#BB7F67" />
    <R x={130} y={46} width={28} height={26} fill="#8EA99B" />
    <R x={134} y={38} width={20} height={10} fill="#5D817A" />
  </ObjectFrame>
);
export const PaperStreetlamp: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="streetlamp">
    <R x={113} y={51} width={12} height={164} fill={p.fill ?? "#4E7371"} />
    <P d="M89 214H149L159 222H79Z" fill="#405E60" />
    <P d="M93 54L81 17H157L145 54Z" fill="#D8C796" />
    <P d="M77 17L119 1L162 17Z" fill="#45686A" />
    <R x={88} y={53} width={63} height={8} fill="#45686A" />
    <L d="M99 20L105 51M139 20L134 51" fill="#738B7A" width={4} />
    <D x={120} y={36} radius={9} fill="#E9D7A4" />
  </ObjectFrame>
);
export const PaperMailbox: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="mailbox">
    <R x={111} y={147} width={17} height={73} fill="#6D8172" />
    <P
      d="M53 149V77Q55 29 111 29H163Q194 29 194 78V151Z"
      fill={p.fill ?? "#71998B"}
    />
    <P d="M53 149V78Q55 34 90 34Q124 34 126 78V149Z" fill="#56807C" />
    <R x={63} y={82} width={52} height={11} fill="#334F54" />
    <P d="M140 81V39H170V58H150V81Z" fill={p.accent ?? "#C18A68"} />
    <L d="M72 131H105" fill="#E2D9B8" width={4} />
  </ObjectFrame>
);
export const PaperBusStop: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="bus-stop">
    <R x={30} y={61} width={10} height={157} fill="#547675" />
    <R x={194} y={61} width={10} height={157} fill="#547675" />
    <R x={41} y={73} width={152} height={114} fill="#A6BCAD" />
    <L d="M90 74V184M146 74V184" fill="#E7DFC6" width={3} />
    <P d="M16 61L37 38H207L225 61Z" fill={p.fill ?? "#6C9284"} />
    <R x={51} y={170} width={132} height={13} fill="#B99C71" />
    <L d="M64 182V218M171 182V218" fill="#4C6D6D" width={7} />
    <R x={56} y={88} width={25} height={46} fill="#F1E6C9" />
    <L d="M61 97H75M61 107H75M61 117H75" fill="#809A8A" width={2} />
    <R x={161} y={8} width={33} height={28} fill="#CDB374" />
    <P d="M168 15H187V28H168Z" fill="#4A6F70" />
  </ObjectFrame>
);
export const PaperTrashBin: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="trash-bin">
    <P d="M67 73H178L168 212H78Z" fill={p.fill ?? "#789184"} />
    <R x={59} y={60} width={125} height={19} fill="#4E746E" />
    <P d="M77 59L87 43H157L168 59Z" fill="#8DA18D" />
    <L
      d="M93 94L99 191M122 92V195M152 94L146 191"
      fill="#C8D0B5"
      width={5}
      opacity={0.35}
    />
    <P d="M111 121L123 103L138 126H126L120 117L114 128Z" fill="#E4DDC1" />
    <D x={86} y={212} radius={8} fill="#3D5A5B" />
    <D x={159} y={212} radius={8} fill="#3D5A5B" />
  </ObjectFrame>
);
export const PaperBench: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="bench">
    <L
      d="M50 134L40 217M187 135L198 217M38 160H205"
      fill="#4C6D68"
      width={10}
      opacity={1}
    />
    {[0, 1, 2].map((i) => (
      <R
        key={i}
        x={28}
        y={73 + i * 22}
        width={187}
        height={17}
        fill={p.fill ?? "#B39469"}
      />
    ))}
    <P d="M27 136H215L225 156H17Z" fill={p.fill ?? "#B39469"} />
    <L d="M35 143H207M50 86H196" fill="#E2C396" width={2} />
    <L d="M30 137V119H47M211 137V119H194" fill="#4C6D68" width={5} />
  </ObjectFrame>
);
export const PaperBooks: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="books">
    {[0, 1, 2].map((i) => (
      <g key={i} transform={`translate(${(i % 2) * 11} ${-i * 24})`}>
        <P
          d="M34 177L180 165L211 178L63 194Z"
          fill={["#B98066", "#6E958A", "#D2B176"][i]}
        />
        <P d="M63 194L211 178V202L63 218Z" fill="#E6DFC5" />
        <P
          d="M34 177L63 194V218L34 203Z"
          fill={["#9C6D58", "#537B72", "#AF915E"][i]}
        />
        <L d="M73 202L200 188M73 209L200 195" fill="#A8AD99" width={1.4} />
      </g>
    ))}
  </ObjectFrame>
);
export const PaperWrench: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="wrench">
    <P
      d="M65 196L133 105Q102 62 145 34L143 67L167 78L193 60Q208 104 163 117L99 207Q76 229 61 211Z"
      fill={p.fill ?? "#9BAFA1"}
    />
    <P d="M73 195L145 109L153 115L85 206Z" fill="#C9D2BC" shadow={false} />
    <D x={79} y={205} radius={8} fill="#667C74" />
  </ObjectFrame>
);
export const PaperBucket: React.FC<ObjectProps> = (p) => (
  <ObjectFrame {...p} name="bucket">
    <path
      d="M59 112Q46 30 121 30T184 112"
      stroke="#527673"
      strokeWidth={8}
      fill="none"
    />
    <P d="M55 105H188L171 209Q121 226 72 208Z" fill={p.fill ?? "#8CA596"} />
    <ellipse cx={121} cy={105} rx={66} ry={13} fill="#CCD2B8" />
    <ellipse cx={121} cy={106} rx={56} ry={8} fill="#4E716A" />
    <ellipse
      cx={121}
      cy={106}
      rx={52}
      ry={6}
      fill="#78ADA8"
      opacity={clamp(((p.level ?? 0.5) - 0.6) * 3)}
    />
    <L d="M73 124L83 193" fill="#E8E1C1" width={4} opacity={0.4} />
    <D x={59} y={112} radius={5} fill="#557975" />
    <D x={184} y={112} radius={5} fill="#557975" />
  </ObjectFrame>
);
