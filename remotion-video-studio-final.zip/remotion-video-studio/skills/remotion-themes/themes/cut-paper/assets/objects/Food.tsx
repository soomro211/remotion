import React from "react";
import {PaperShape as P,PaperDisc as D,palette} from "../core/material";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperApple:React.FC<ObjectProps>=(p)=>{
 const {fill="#C88367",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="apple"><L d="M119 69Q111 40 134 25" fill={ink} width={9}/><P d="M125 57Q142 20 177 39Q164 67 125 57Z" fill="#7E9A74"/><P d="M121 80Q57 52 36 108Q21 162 69 206Q97 223 120 208Q151 224 180 200Q222 154 202 107Q181 59 121 80Z" fill={fill}/><L d="M60 114Q49 138 62 164" fill="#F4EBD8" width={6} opacity={.3}/><L d="M105 84Q121 92 139 83" fill={ink} width={2} opacity={.3}/></ObjectFrame>;
};

export const PaperBread:React.FC<ObjectProps>=(p)=>{
 const {fill="#BD965F"}=p;
 return <ObjectFrame {...p} name="bread"><P d="M32 116Q35 57 120 52Q204 55 210 116L208 184Q178 215 52 204L31 183Z" fill={fill}/><P d="M44 127Q42 78 120 70Q194 71 197 124L196 178Q140 203 46 184Z" fill="#E8C68D" shadow={false}/><L d="M71 94L58 121M116 84L104 114M159 91L147 120" fill="#A17748" width={8}/><L d="M61 166H76M104 146H117M152 170H162" fill="#B28F5C" width={3} opacity={.5}/></ObjectFrame>;
};

export const PaperBowl:React.FC<ObjectProps>=(p)=>{
 const {fill="#C9945D",accent="#F2BC55"}=p;
 return <ObjectFrame {...p} name="bowl"><P d="M24 101Q121 65 218 101Q197 198 147 210H91Q40 192 24 101Z" fill={fill}/><P d="M26 101Q121 70 216 101Q122 135 26 101Z" fill="#F4EBD8"/><P d="M41 101Q121 81 203 101Q121 122 41 101Z" fill={accent}/><L d="M49 134Q58 170 79 184" fill="#F4EBD8" width={5} opacity={.35}/><P d="M91 204L147 204L152 217H87Z" fill={fill}/></ObjectFrame>;
};

export const PaperPlate:React.FC<ObjectProps>=(p)=>{
 const {fill="#A4B5A7"}=p;
 return <ObjectFrame {...p} name="plate"><P d="M20 124C15 57 228 53 221 125C227 198 15 198 20 124Z" fill={fill}/><P d="M42 125C41 78 204 78 201 125C204 171 41 172 42 125Z" fill="#F4EBD8" shadow={false}/><P d="M59 125C58 92 186 93 184 125C187 157 59 158 59 125Z" fill="#E1DAC6" shadow={false}/><L d="M44 97Q89 70 150 82" fill="#F4EBD8" width={4} opacity={.5}/></ObjectFrame>;
};

export const PaperCarrot:React.FC<ObjectProps>=(p)=>{
 const {fill="#D79C60"}=p;
 return <ObjectFrame {...p} name="carrot"><P d="M102 75Q76 34 94 18Q118 31 119 68Q134 23 154 29Q161 54 130 82Z" fill="#6D936A"/><P d="M80 78Q116 57 154 82Q145 135 107 215Q79 184 75 139Z" fill={fill}/><L d="M91 103L122 110M103 135L136 143M90 161L115 168" fill="#8F6341" width={3} opacity={.5}/><L d="M87 91L88 134" fill="#F4EBD8" width={3} opacity={.3}/></ObjectFrame>;
};

export const PaperCheese:React.FC<ObjectProps>=(p)=>{
 const {fill="#E0BE69",accent="#F2BC55"}=p;
 return <ObjectFrame {...p} name="cheese"><P d="M31 127L149 55L213 128L208 209L30 208Z" fill={fill}/><P d="M31 127L149 55L213 128Z" fill={accent}/><D x={89} y={157} radius={17} fill="#BC964C" shadow={false}/><D x={163} y={179} radius={12} fill="#BC964C" shadow={false}/><D x={141} y={103} radius={12} fill="#D3AA55" shadow={false}/><D x={63} y={190} radius={6} fill="#BC964C" shadow={false}/><L d="M42 139V188" fill="#F4EBD8" opacity={.35}/></ObjectFrame>;
};
