import React from "react";
import {PaperShape as P,PaperRect as R,PaperDisc as D,palette} from "../core/material";
import {clamp} from "../core/math";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperMug:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B"}=p;
 return <ObjectFrame {...p} name="mug"><P d="M174 107Q224 101 219 144Q216 175 179 175L179 157Q201 156 201 136Q202 121 177 126Z" fill={fill}/><P d="M45 86L178 88L174 191Q162 214 112 215Q61 212 50 192Z" fill={fill}/><P d="M46 87Q110 69 178 88Q111 106 46 87Z" fill="#F4EBD8"/><P d={`M59 89Q111 77 163 90Q112 100 59 89Z`} fill="#655346" shadow={false}/><L d="M63 113L66 179" fill="#F4EBD8" width={4} opacity={.35}/></ObjectFrame>;
};

export const PaperTeapot:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55"}=p;
 return <ObjectFrame {...p} name="teapot"><P d="M169 111Q214 80 211 108L201 157L166 178Z" fill={fill}/><path d="M65 116C5 65 11 175 64 168" fill="none" stroke={fill} strokeWidth={18}/><P d="M60 106Q116 75 172 108L185 181Q164 216 113 216Q67 212 50 180Z" fill={fill}/><P d="M58 105Q114 73 174 106L177 113H57Z" fill={accent}/><D x={117} y={86} radius={10} fill={accent}/><L d="M72 126Q66 157 74 176" fill="#F4EBD8" width={4} opacity={.3}/></ObjectFrame>;
};

export const PaperLamp:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="lamp"><P d="M80 114L34 209L207 210L163 114Z" fill="#F2D087" opacity={q*.18} shadow={false} rim={0}/><R x={113} y={86} width={14} height={115} fill={ink}/><P d="M79 32L161 34L193 118L46 116Z" fill={fill}/><P d="M46 116Q120 134 193 118L184 130H54Z" fill={accent}/><P d="M73 199Q122 184 170 200L177 214H66Z" fill={ink}/><L d="M171 127V158" fill={ink} width={2}/><D x={171} y={161} radius={4} fill={accent}/></ObjectFrame>;
};

export const PaperSofa:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="sofa"><R x={39} y={185} width={16} height={35} fill={ink}/><R x={183} y={185} width={16} height={35} fill={ink}/><P d="M31 80Q119 62 210 82L204 183H34Z" fill={fill}/><R x={36} y={133} width={173} height={63} fill={fill}/><P d="M35 139L119 137L118 179L34 178Z" fill={accent}/><P d="M122 137L205 140L205 178L122 180Z" fill={accent}/><R x={18} y={113} width={29} height={86} fill={fill}/><R x={194} y={113} width={29} height={86} fill={fill}/><L d="M70 93V126M161 93V127" fill="#F4EBD8" opacity={.22}/></ObjectFrame>;
};

export const PaperBed:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="bed"><P d="M25 95Q59 76 96 88L97 180L25 188Z" fill={fill}/><P d="M27 103Q61 88 88 98V132L27 141Z" fill={accent}/><R x={27} y={173} width={12} height={47} fill={ink}/><R x={197} y={184} width={12} height={36} fill={ink}/><P d="M31 139L178 120L215 158L204 197L32 186Z" fill={fill}/><P d="M33 129L176 111L216 148L199 177L34 165Z" fill="#F4EBD8"/><P d="M91 124L177 115L213 149L199 181L89 165Z" fill={accent}/><P d="M42 127L78 121Q89 121 94 131L90 148L43 151Z" fill="#E6DCC3"/><L d="M103 137L181 132L201 151M105 150L184 145" fill="#F4EBD8" opacity={.4}/><P d="M194 171L219 166V209L194 216Z" fill={fill}/><L d="M39 180L189 193" fill={ink} width={4} opacity={.25}/></ObjectFrame>;
};

export const PaperPlant:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="plant"><g transform={`translate(120 155) scale(${.25+.75*q}) translate(-120 -155)`}><L d="M120 164Q116 114 126 42" fill="#55715B" width={9}/><P d="M119 116Q61 121 48 77Q95 67 119 116Z" fill={fill}/><P d="M123 91Q135 36 181 43Q175 86 123 91Z" fill={fill}/><P d="M120 144Q155 96 197 122Q171 157 120 144Z" fill={fill}/><L d="M61 85L111 111M136 80L171 51" fill="#F4EBD8" opacity={.25}/></g><P d="M71 158L169 160L153 213L88 214Z" fill={accent}/><R x={66} y={153} width={109} height={16} fill={accent}/><L d="M84 177L92 202" fill="#F4EBD8" opacity={.3}/></ObjectFrame>;
};

export const PaperClock:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="clock"><D x={120} y={119} radius={94} fill={fill}/><D x={120} y={119} radius={82} fill="#F4EBD8"/>{Array.from({length:12},(_,i)=><L key={i} d="M120 45V54" fill={ink} width={3} opacity={.7}/>).map((node,i)=><g key={i} transform={`rotate(${i*30} 120 119)`}>{node}</g>)}<g transform={`rotate(${q*360} 120 119)`}><P d="M116 123L118 64L123 63L125 123Z" fill={ink} shadow={false}/></g><g transform={`rotate(${q*30+58} 120 119)`}><P d="M116 124L117 82L124 82L125 123Z" fill={ink} shadow={false}/></g><D x={120} y={119} radius={7} fill={accent}/></ObjectFrame>;
};

export const PaperDoor:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="door"><R x={48} y={23} width={146} height={197} fill={ink}/><R x={58} y={33} width={125} height={187} fill="#334849"/><g transform={`translate(58 33) scale(${1-q*.85} 1)`}><R width={125} height={185} fill={fill}/><P d="M15 16L109 18L109 83L15 81Z" fill={accent}/><P d="M15 103L110 104L108 167L16 165Z" fill={accent}/><D x={108} y={96} radius={5} fill="#F2BC55"/></g><R x={44} y={21} width={13} height={199} fill={accent}/><R x={184} y={21} width={13} height={199} fill={accent}/><R x={44} y={19} width={153} height={13} fill={accent}/></ObjectFrame>;
};

export const PaperWindow:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55"}=p;
 return <ObjectFrame {...p} name="window"><R x={35} y={30} width={171} height={176} fill={fill}/><R x={47} y={42} width={147} height={150} fill="#86B1AE"/><P d="M50 150L97 109L132 142L165 101L193 129V192H49Z" fill="#98AF8D"/><R x={114} y={39} width={10} height={158} fill="#F4EBD8"/><R x={44} y={111} width={153} height={10} fill="#F4EBD8"/><R x={25} y={201} width={192} height={15} fill={accent}/><L d="M60 55L91 86M151 54L176 78" fill="#F4EBD8" width={4} opacity={.25}/></ObjectFrame>;
};

export const PaperUmbrella:React.FC<ObjectProps>=(p)=>{
 const {fill="#71978B",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="umbrella"><L d="M120 82V191Q120 221 144 210Q151 204 147 193" fill={ink} width={9}/><g transform={`translate(120 99) scale(${.12+.88*q} 1) translate(-120 -99)`}><P d="M18 106Q120-29 222 106Q192 89 171 109Q144 89 121 111Q94 89 69 109Q43 89 18 106Z" fill={fill}/><L d="M120 35Q84 59 69 107M120 35Q120 71 121 109M120 35Q157 57 171 106" fill="#F4EBD8" width={2} opacity={.55}/></g><D x={120} y={34} radius={5} fill={accent}/></ObjectFrame>;
};

export type {ObjectProps} from "./Base";
