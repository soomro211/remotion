import React from "react";
import {PaperShape as P,PaperRect as R,PaperDisc as D,palette} from "../core/material";
import {clamp} from "../core/math";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperThermometer:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",ink=palette.ink,level=.6}=p;
 const v=clamp(level);
 return <ObjectFrame {...p} name="thermometer"><P d="M100 151V43Q99 16 120 15Q143 18 142 43V151Q170 177 151 202Q121 230 92 203Q72 179 100 151Z" fill="#E7E4D1"/><D x={121} y={183} radius={24} fill={fill}/><R x={114} y={153-v*113} width={14} height={38+v*113} fill={fill} shadow={false}/><L d="M149 52H169M149 76H161M149 100H169M149 124H161M149 148H169" fill={ink} width={3}/></ObjectFrame>;
};

export const PaperBalance:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="balance"><P d="M112 92H129L140 211H100Z" fill={ink}/><P d="M69 207H171L185 220H55Z" fill={ink}/><g transform={`rotate(${-20+q*40} 120 88)`}><L d="M34 88H207" fill={fill} width={12}/><L d="M45 88L18 154M45 88L75 154M195 88L165 154M195 88L224 154" fill={ink} width={2}/><P d="M17 154H77Q65 187 45 185Q25 186 17 154Z" fill={accent}/><P d="M163 154H226Q215 187 194 186Q174 186 163 154Z" fill={accent}/></g><D x={120} y={88} radius={13} fill={fill}/></ObjectFrame>;
};

export const PaperGauge:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="gauge"><D x={120} y={122} radius={90} fill={ink}/><D x={120} y={122} radius={78} fill="#F4EBD8"/>{Array.from({length:9},(_,i)=><g key={i} transform={`rotate(${-120+i*30} 120 122)`}><L d="M120 55V64" fill={ink} width={3}/></g>)}<g transform={`rotate(${-120+q*240} 120 122)`}><P d="M115 127L119 56L124 127Z" fill={fill}/></g><D x={120} y={122} radius={11} fill={accent}/><R x={89} y={162} width={61} height={20} fill="#D3D4BB"/></ObjectFrame>;
};
