import React from "react";
import {PaperShape as P,PaperDisc as D,palette} from "../core/material";
import {clamp} from "../core/math";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperFlower:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="flower"><L d="M120 123V218" fill={ink} width={8}/><P d="M118 182Q74 180 72 149Q109 146 118 182Z" fill={fill}/><P d="M123 164Q146 130 174 145Q161 174 123 164Z" fill={fill}/>{Array.from({length:7},(_,i)=><g key={i} transform={`rotate(${i*360/7} 120 92)`}><P d="M110 83Q81 36 111 23Q143 22 132 78Z" fill={accent}/></g>)}<D x={120} y={92} radius={29} fill="#D5AA5A"/><D x={120} y={92} radius={17} fill="#94764D"/></ObjectFrame>;
};

export const PaperSprout:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="sprout"><P d="M47 213Q119 191 195 215L209 222H31Z" fill="#8B7356"/><g transform={`translate(120 214) scale(${.25+.75*q}) translate(-120 -214)`}><L d="M120 214Q109 163 125 113" fill={ink} width={8}/><P d="M118 164Q54 156 50 99Q103 91 118 164Z" fill={fill}/><P d="M121 145Q130 76 194 82Q188 136 121 145Z" fill={fill}/><L d="M65 112L109 153M133 133L180 94" fill="#F4EBD8" opacity={.3}/></g></ObjectFrame>;
};

export const PaperLeaf:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C"}=p;
 return <ObjectFrame {...p} name="leaf"><P d="M44 190Q23 79 179 32Q224 160 74 194Z" fill={fill}/><L d="M36 216Q86 159 177 44M79 164L64 111M105 136L151 143M125 112L111 76M147 86L175 96" fill="#E3E1BB" width={3} opacity={.6}/></ObjectFrame>;
};

export const PaperRock:React.FC<ObjectProps>=(p)=>{
 const {fill="#9DA58F"}=p;
 return <ObjectFrame {...p} name="rock"><P d="M21 165L43 100L99 60L171 71L217 131L211 206L133 219L49 211Z" fill={fill}/><P d="M43 101L100 61L110 148L22 164Z" fill="#ABB09A" shadow={false}/><P d="M111 147L171 72L216 133L211 204L132 217Z" fill="#7B8978" shadow={false}/><L d="M48 115L88 86M153 170L187 144" fill="#F4EBD8" opacity={.23}/></ObjectFrame>;
};

export const PaperMountain:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C"}=p;
 return <ObjectFrame {...p} name="mountain"><P d="M13 218L105 33L141 79L171 57L232 218Z" fill={fill}/><P d="M106 34L146 218H15Z" fill="#9EAD91" shadow={false}/><P d="M105 33L78 89L101 77L116 96L126 69Z" fill="#F4EBD8"/><P d="M171 57L151 97L171 86L188 105Z" fill="#E0DEC7"/><L d="M104 117L76 183M172 122L195 187" fill="#F4EBD8" opacity={.18}/></ObjectFrame>;
};

export const PaperMoon:React.FC<ObjectProps>=(p)=>{
 const {fill="#D9D2B7"}=p;
 return <ObjectFrame {...p} name="moon"><P d="M152 29C66 16 20 108 67 176C96 219 163 224 201 174C114 202 69 107 152 29Z" fill={fill}/><D x={87} y={114} radius={14} fill="#B8B69E" shadow={false}/><D x={112} y={176} radius={10} fill="#C7C3AA" shadow={false}/><D x={71} y={150} radius={6} fill="#C7C3AA" shadow={false}/><L d="M65 90Q75 58 102 47" fill="#F4EBD8" width={4} opacity={.35}/></ObjectFrame>;
};

export const PaperFish:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="fish"><g transform={`rotate(${-20+q*40} 173 122)`}><P d="M169 121L223 81L215 165Z" fill={accent}/></g><P d="M70 113L93 69L136 94Z" fill={accent}/><P d="M77 136L107 179L147 146Z" fill={accent}/><P d="M26 120Q86 53 170 104L190 121L169 142Q86 189 26 120Z" fill={fill}/><D x={63} y={112} radius={7} fill={ink}/><D x={61} y={110} radius={2} fill="#F4EBD8"/><L d="M83 96Q99 121 83 143M108 106L126 121L109 138" fill="#F4EBD8" opacity={.35}/></ObjectFrame>;
};

export const PaperBird:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="bird"><P d="M61 128L19 102L32 145L72 153Z" fill={ink}/><P d="M54 134Q93 94 139 114Q171 86 194 105Q211 126 191 149Q164 179 97 174Z" fill={fill}/><P d="M194 118L223 131L194 138Z" fill={accent}/><g transform={`rotate(${-30+q*70} 115 133)`}><P d="M115 133Q92 50 38 43Q47 117 115 144Z" fill={accent}/></g><D x={180} y={121} radius={5} fill={ink}/><L d="M121 170L111 193M144 169L138 195" fill={ink} width={3}/></ObjectFrame>;
};

export const PaperWateringCan:React.FC<ObjectProps>=(p)=>{
 const {fill="#78966C",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="watering-can"><path d="M72 108Q36 42 95 35Q145 30 162 92" fill="none" stroke={ink} strokeWidth={12}/><P d="M153 128L203 91L214 106L171 174Z" fill={fill}/><P d="M195 78L226 89L225 114L195 110Z" fill={accent}/><P d="M57 101Q113 88 165 104L177 195Q118 221 49 194Z" fill={fill}/><P d="M56 102Q111 87 165 104Q117 120 56 102Z" fill={accent}/><L d="M72 128L68 179" fill="#F4EBD8" width={4} opacity={.3}/></ObjectFrame>;
};
