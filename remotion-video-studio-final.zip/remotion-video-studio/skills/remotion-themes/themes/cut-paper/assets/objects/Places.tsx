import React from "react";
import {PaperShape as P,PaperRect as R,PaperDisc as D,palette} from "../core/material";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperShop:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="shop"><R x={32} y={73} width={180} height={146} fill={fill}/><R x={52} y={129} width={73} height={70} fill="#83AAA7"/><R x={144} y={130} width={43} height={89} fill={ink}/><R x={150} y={137} width={30} height={44} fill="#83AAA7"/><D x={177} y={190} radius={3} fill={accent}/><P d="M25 73H217L227 111H16Z" fill={accent}/>{[0,1,2,3,4].map(i=><P key={i} d={`M${22+i*41} 75H${43+i*41}L${46+i*41} 109H${20+i*41}Z`} fill="#F4EBD8" shadow={false}/>)}<R x={51} y={38} width={141} height={30} fill={ink}/><L d="M69 53H173" fill="#E8D8B4" width={4}/></ObjectFrame>;
};

export const PaperSchool:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="school"><R x={26} y={102} width={190} height={117} fill={fill}/><P d="M19 102L120 49L225 102Z" fill={ink}/><R x={101} y={152} width={39} height={68} fill={ink}/>{[0,1].map(i=><g key={i}><R x={44+i*112} y={120} width={35} height={44} fill="#B4C3AD"/><L d={`M${61+i*112} 121V163M${45+i*112} 140H${78+i*112}`} fill="#F4EBD8" width={3}/></g>)}<D x={120} y={110} radius={19} fill="#F4EBD8"/><L d="M120 98V112L130 117" fill={ink} width={2}/><L d="M120 49V21" fill={ink} width={4}/><P d="M121 21L160 28L122 39Z" fill={accent}/></ObjectFrame>;
};

export const PaperHospital:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="hospital"><R x={26} y={90} width={190} height={129} fill={fill}/><R x={86} y={39} width={72} height={180} fill="#E4DFC9"/><R x={109} y={52} width={26} height={45} fill={accent}/><R x={99} y={62} width={46} height={25} fill={accent}/><R x={101} y={163} width={41} height={57} fill={ink}/>{[0,1].map(i=><g key={i}><R x={40+i*128} y={109} width={32} height={30} fill="#8EB0AB"/><R x={40+i*128} y={154} width={32} height={30} fill="#8EB0AB"/></g>)}<L d="M121 167V219" fill="#F4EBD8" width={2}/></ObjectFrame>;
};

export const PaperBridge:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="bridge"><P d="M14 150H227V219H183Q180 166 120 166Q62 166 58 219H14Z" fill={fill}/><P d="M14 134H227V155H14Z" fill={accent}/><L d="M21 128V94M57 129V95M92 129V95M128 129V95M164 129V95M202 129V95M17 95H224" fill={ink} width={5}/><L d="M27 173H44M191 173H212M29 195H42M196 195H212" fill="#F4EBD8" width={2} opacity={.4}/></ObjectFrame>;
};

export const PaperStairs:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="stairs"><P d="M22 217V185H62V151H102V117H142V83H182V49H221V217Z" fill={fill}/><L d="M23 186H62V152H102V118H142V84H182V50H221" fill="#F4EBD8" width={4} opacity={.65}/><L d="M36 174V149L202 12M77 141V115M122 103V77M167 65V39" fill={ink} width={5}/><L d="M47 203H190" fill={ink} opacity={.2}/></ObjectFrame>;
};

export const PaperFence:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="fence"><R x={18} y={117} width={207} height={15} fill={ink}/><R x={18} y={172} width={207} height={15} fill={ink}/>{[0,1,2,3,4].map(i=><P key={i} d={`M${23+i*41} 218V91L${35+i*41} 73L${48+i*41} 91V218Z`} fill={fill}/>)}<L d="M32 104V199M114 104V199M197 104V199" fill="#F4EBD8" opacity={.25}/></ObjectFrame>;
};
