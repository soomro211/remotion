import React from "react";
import {PaperShopBuilding,PaperSchoolBuilding,PaperHospitalBuilding} from "../scenery/Architecture";
import {PaperShape as P,PaperRect as R,palette} from "../core/material";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperShop:React.FC<ObjectProps>=({x=0,y=0,scale=1,angle=0,progress=0,fill,accent,ink})=><g data-paper-object="shop" transform={`translate(${x} ${y}) rotate(${angle})`}><PaperShopBuilding scale={scale*.4} fill={fill} accent={accent} ink={ink} open={progress}/></g>;

export const PaperSchool:React.FC<ObjectProps>=({x=0,y=0,scale=1,angle=0,progress=0,fill,accent,ink})=><g data-paper-object="school" transform={`translate(${x} ${y}) rotate(${angle})`}><PaperSchoolBuilding scale={scale*.4} fill={fill} accent={accent} ink={ink} open={progress}/></g>;

export const PaperHospital:React.FC<ObjectProps>=({x=0,y=0,scale=1,angle=0,progress=0,fill,accent,ink})=><g data-paper-object="hospital" transform={`translate(${x} ${y}) rotate(${angle})`}><PaperHospitalBuilding scale={scale*.4} fill={fill} accent={accent} ink={ink} open={progress}/></g>;

export const PaperBridge:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="bridge"><P d="M14 150H227V219H183Q180 166 120 166Q62 166 58 219H14Z" fill={fill}/><P d="M14 134H227V155H14Z" fill={accent}/><L d="M21 128V94M57 129V95M92 129V95M128 129V95M164 129V95M202 129V95M17 95H224" fill={ink} width={5}/><L d="M27 173H44M191 173H212M29 195H42M196 195H212" fill="#F4EBD8" width={2} opacity={.4}/></ObjectFrame>;
};

export const PaperStairs:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="stairs"><P d="M22 217V185H62V151H102V117H142V83H182V49H221V217Z" fill={fill}/><L d="M23 186H62V152H102V118H142V84H182V50H221" fill="#F4EBD8" width={4} opacity={.65}/><L d="M36 174V149L202 12M77 141V115M122 103V77M167 65V39" fill={ink} width={5}/><L d="M47 203H190" fill={ink} opacity={.2}/></ObjectFrame>;
};

export const PaperFence:React.FC<ObjectProps>=(p)=>{
 const {fill="#BBA47B",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="fence"><R x={18} y={117} width={207} height={15} fill={ink}/><R x={18} y={172} width={207} height={15} fill={ink}/>{[0,1,2,3,4].map(i=><P key={i} d={`M${23+i*41} 218V91L${35+i*41} 73L${48+i*41} 91V218Z`} fill={fill}/>)}<L d="M32 104V199M114 104V199M197 104V199" fill="#F4EBD8" opacity={.25}/></ObjectFrame>;
};

export {PaperShopBuilding,PaperSchoolBuilding,PaperHospitalBuilding} from "../scenery/Architecture";
