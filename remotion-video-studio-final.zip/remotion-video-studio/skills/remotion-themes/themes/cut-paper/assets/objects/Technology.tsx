import React,{useId} from "react";
import {PaperShape as P,PaperRect as R,PaperDisc as D,palette} from "../core/material";
import {clamp} from "../core/math";
import {ObjectFrame,Detail as L,type ObjectProps} from "./Base";

export const PaperBulb:React.FC<ObjectProps>=(p)=>{
 const {fill="#E7C97E",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="bulb"><P d="M84 143C39 110 61 29 119 28C183 27 202 108 157 145L149 172H92Z" fill={fill}/><P d="M94 155L145 156L143 194L133 212H106L95 196Z" fill={ink}/><L d="M96 174L144 168M98 187L143 181M103 199L138 194" fill="#F4EBD8" width={3}/><L d="M108 153V115L90 96M130 153V115L149 96M90 96L108 106L130 94L149 96" fill={accent} width={4} opacity={.5+.5*q}/><L d="M76 80Q79 53 102 49" fill="#F4EBD8" width={5} opacity={.35}/></ObjectFrame>;
};

export const PaperBattery:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",ink=palette.ink,level=.6}=p;
 const v=clamp(level);
 const id="battery"+useId().replace(/[^a-z0-9]/gi,"");
 return <ObjectFrame {...p} name="battery"><R x={100} y={24} width={40} height={18} fill={ink}/><P d="M77 40L165 41L169 215L73 214Z" fill={ink}/><P d="M86 53H155V200H85Z" fill="#D5D7BE"/><defs><clipPath id={id}><path d="M88 57H152V198H88Z"/></clipPath></defs><g clipPath={`url(#${id})`}><R x={86} y={198-v*144} width={68} height={144*v} fill={fill} shadow={false}/></g><L d="M111 80H131M121 70V90M112 175H132" fill={ink} width={4} opacity={.8}/></ObjectFrame>;
};

export const PaperPlug:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="plug"><L d="M119 159V181Q118 210 154 212H212" fill={ink} width={14}/><R x={81} y={35} width={15} height={57} fill="#ACBAB2"/><R x={143} y={35} width={15} height={57} fill="#ACBAB2"/><P d="M56 83H183L174 142L146 164H97L65 140Z" fill={fill}/><P d="M101 156H142V179H102Z" fill={ink}/><L d="M74 101H163M78 117H159" fill="#F4EBD8" opacity={.3}/></ObjectFrame>;
};

export const PaperSolarPanel:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="solar-panel"><P d="M71 141L83 219H99L90 143Z" fill={ink}/><P d="M165 142L150 219H169L181 138Z" fill={ink}/><P d="M36 57L202 39L221 152L52 170Z" fill={ink}/><P d="M46 64L195 48L211 145L60 160Z" fill={fill}/>{[0,1,2,3].map(i=><L key={i} d={`M${56+i*35} ${63-i*3.6}L${69+i*35} ${157-i*3.6}`} fill="#B6D2C8" width={2} opacity={.7}/>)}<L d="M52 94L201 78M56 126L206 110" fill="#B6D2C8" width={2} opacity={.7}/><L d="M69 68L92 87M112 63L136 82" fill="#F4EBD8" opacity={.35}/></ObjectFrame>;
};

export const PaperWindTurbine:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="wind-turbine"><P d="M114 82H127L138 219H102Z" fill="#D9DBCB"/><g transform={`rotate(${q*360} 120 77)`}><P d="M117 75L106 26L117 13L127 68Z" fill={fill}/><P d="M123 75L173 77L184 91L129 88Z" fill={fill}/><P d="M120 82L92 123L74 126L109 81Z" fill={fill}/></g><D x={120} y={77} radius={13} fill={accent}/><P d="M96 213H143L154 221H87Z" fill={ink}/></ObjectFrame>;
};

export const PaperMicrophone:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="microphone"><path d="M73 103V122Q75 166 121 166Q166 166 169 123V103" fill="none" stroke={ink} strokeWidth={12}/><P d="M91 45Q120 22 151 46L150 116Q148 146 120 147Q92 146 91 117Z" fill={fill}/><L d="M103 58H139M102 71H140M101 84H140M102 97H140" fill={ink} width={3} opacity={.5}/><R x={115} y={166} width={12} height={39} fill={ink}/><P d="M83 207Q122 192 161 208L165 219H77Z" fill={accent}/><D x={121} y={123} radius={5} fill={accent}/></ObjectFrame>;
};

export const PaperSpeaker:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="speaker"><P d="M59 33L187 34L193 217L53 215Z" fill={fill}/><D x={122} y={85} radius={27} fill={ink}/><D x={122} y={85} radius={17} fill="#8CA9A2"/><D x={122} y={159} radius={44} fill={ink}/><D x={122} y={159} radius={31+q*3} fill="#668B8E"/><D x={122} y={159} radius={14} fill={ink}/><D x={70} y={48} radius={3} fill={accent}/><D x={175} y={203} radius={3} fill={accent}/></ObjectFrame>;
};

export const PaperServer:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="server"><P d="M60 28L178 29L190 212L51 212Z" fill={ink}/>{[0,1,2,3].map(i=><g key={i}><R x={65} y={43+i*40} width={109} height={31} fill={fill}/><L d={`M77 ${53+i*40}H128M77 ${63+i*40}H128`} fill="#B6D2C8" width={2}/><D x={157} y={58+i*40} radius={4} fill={i===0?accent:'#8FA98B'}/></g>)}<R x={69} y={209} width={17} height={12} fill={ink}/><R x={155} y={209} width={17} height={12} fill={ink}/></ObjectFrame>;
};

export const PaperHeadphones:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="headphones"><path d="M53 143V107Q53 34 120 33Q189 34 189 108V143" fill="none" stroke={ink} strokeWidth={24}/><path d="M54 100Q54 43 119 43Q182 43 188 100" fill="none" stroke={fill} strokeWidth={12}/><P d="M33 123L65 120L72 195L40 201Z" fill={fill}/><P d="M174 120L207 124L200 201L168 196Z" fill={fill}/><R x={58} y={132} width={21} height={60} fill={accent}/><R x={161} y={132} width={21} height={60} fill={accent}/></ObjectFrame>;
};

export const PaperRobot:React.FC<ObjectProps>=(p)=>{
 const {fill="#4C7F89",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="robot"><R x={105} y={181} width={16} height={38} fill={ink}/><R x={143} y={181} width={16} height={38} fill={ink}/><R x={96} y={209} width={29} height={12} fill={ink}/><R x={140} y={209} width={29} height={12} fill={ink}/><P d="M79 104L175 106L181 182L74 181Z" fill={fill}/><g transform={`rotate(${-q*55} 79 116)`}><P d="M78 105L62 110L48 160L63 169L90 126Z" fill={accent}/><D x={54} y={168} radius={12} fill={ink}/></g><g transform={`rotate(${q*45} 177 116)`}><P d="M173 106L189 111L207 160L192 171L165 127Z" fill={accent}/><D x={201} y={169} radius={12} fill={ink}/></g><R x={78} y={43} width={98} height={66} fill={accent}/><R x={91} y={57} width={72} height={35} fill={ink}/><D x={108} y={74} radius={6} fill="#B6D2C8"/><D x={145} y={74} radius={6} fill="#B6D2C8"/><L d="M127 42V26" fill={ink} width={5}/><D x={127} y={22} radius={7} fill={fill}/><R x={102} y={127} width={50} height={30} fill={ink}/><D x={127} y={142} radius={8} fill="#B6D2C8"/></ObjectFrame>;
};
