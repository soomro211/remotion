import React from "react";
import {PaperShape as P,PaperRect as R,PaperDisc as D,palette} from "../core/material";
import {clamp} from "../core/math";
import {ObjectFrame,Ring,Detail as L,type ObjectProps} from "./Base";

export const PaperPencil:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="pencil"><g transform="rotate(27 120 120)"><P d="M102 41L136 42L135 176L118 213L102 175Z" fill={fill}/><P d="M102 176L135 176L118 213Z" fill="#E6C49A"/><P d="M111 198L124 198L118 213Z" fill={ink}/><R x={101} y={35} width={36} height={23} fill="#C98B87"/><R x={100} y={54} width={37} height={15} fill="#A8B4AA"/><L d="M111 75L111 168M127 75L127 169" fill="#F4EBD8" width={2}/></g></ObjectFrame>;
};

export const PaperScissors:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="scissors"><g transform={`rotate(${-q*22} 120 120)`}><P d="M115 121L110 30Q123 42 129 116L163 182Q187 223 214 187Q226 154 192 153Q176 155 173 176L129 113Z M188 166Q215 165 202 187Q184 207 178 186Q173 172 188 166Z" fillRule="evenodd" fill="#A4B6B0"/></g><g transform={`rotate(${q*22} 120 120)`}><P d="M126 122L130 30Q116 42 113 116L75 182Q52 222 25 186Q12 152 48 153Q65 155 67 175L112 111Z M50 166Q23 165 36 187Q53 206 61 186Q65 172 50 166Z" fillRule="evenodd" fill={fill}/></g><D x={120} y={120} radius={9} fill={ink}/><L d="M116 120H124" fill="#F4EBD8"/></ObjectFrame>;
};

export const PaperRuler:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="ruler"><g transform="rotate(-23 120 120)"><P d="M21 84L220 84L218 152L21 151Z" fill={fill}/>{Array.from({length:19},(_,i)=><L key={i} d={`M${29+i*10} 88V${i%5===0?116:104}`} fill={ink} width={1.6} opacity={.7}/>)}<D x={36} y={134} radius={6} fill="#F4EBD8"/><L d="M57 137H201" fill="#F4EBD8" width={2} opacity={.3}/></g></ObjectFrame>;
};

export const PaperBackpack:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="backpack"><path d="M74 78Q38 99 52 190M169 78Q207 98 190 191" fill="none" stroke={ink} strokeWidth={13}/><path d="M98 53V36Q120 17 143 36V53" fill="none" stroke={ink} strokeWidth={11}/><P d="M60 75Q121 43 180 75L190 195Q175 219 119 219Q64 217 51 195Z" fill={fill}/><P d="M76 145Q120 132 168 146L168 200L76 199Z" fill={accent}/><L d="M70 96Q119 79 174 97M84 155H157" fill={ink} width={3}/><R x={137} y={96} width={7} height={13} fill="#F4EBD8"/></ObjectFrame>;
};

export const PaperBriefcase:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="briefcase"><path d="M90 80V57Q120 43 151 57V80" fill="none" stroke={ink} strokeWidth={13}/><R x={28} y={80} width={184} height={131} fill={fill}/><P d="M29 80L213 82L209 136Q117 157 30 135Z" fill={accent}/><R x={66} y={129} width={15} height={24} fill={ink}/><R x={158} y={129} width={15} height={24} fill={ink}/><L d="M43 94H196M43 195H196" fill="#F4EBD8" opacity={.25}/></ObjectFrame>;
};

export const PaperClipboard:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="clipboard"><R x={49} y={36} width={146} height={183} fill={fill}/><R x={60} y={51} width={124} height={154} fill="#F4EBD8"/><P d="M92 36V25Q121 10 149 26V37L158 42V62H83V42Z" fill={ink}/><R x={99} y={29} width={44} height={13} fill="#9CAFAB"/><L d="M76 89H163M76 112H164M76 135H151M76 158H162M76 181H136" fill={ink} opacity={.45}/></ObjectFrame>;
};

export const PaperFolder:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",accent="#F2BC55",progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="folder"><P d="M29 68H99L113 85H210V210H29Z" fill={accent}/><g transform={`translate(30 118) skewX(${-q*13}) translate(-30 -118)`}><P d="M29 99L211 100L207 212L30 210Z" fill={fill}/><L d="M48 119H112" fill="#F4EBD8" width={5} opacity={.35}/></g></ObjectFrame>;
};

export const PaperEnvelope:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",accent="#F2BC55",progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="envelope"><R x={25} y={78} width={191} height={126} fill={fill}/><P d="M26 203L119 130L215 204Z" fill={accent}/><g transform={`translate(120 78) scale(1 ${1-q*1.9}) translate(-120 -78)`}><P d="M25 78L120 151L217 78Z" fill="#E8D7B3"/></g><L d="M28 82L92 138M212 82L148 138" fill="#F4EBD8" opacity={.35}/></ObjectFrame>;
};

export const PaperKey:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364"}=p;
 return <ObjectFrame {...p} name="key"><g transform="rotate(-30 120 120)"><Ring x={121} y={74} radius={42} hole={20} fill={fill}/><P d="M109 109H131L132 187H156V203H132V217H109Z" fill={fill}/><L d="M119 122V184" fill="#F4EBD8" width={3} opacity={.35}/></g></ObjectFrame>;
};

export const PaperLock:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="lock"><g transform={`translate(${q*17} ${-q*35}) rotate(${q*15} 159 106)`}><path d="M77 114V76Q77 30 121 30Q166 30 166 76V117" fill="none" stroke={ink} strokeWidth={18}/></g><R x={50} y={106} width={142} height={108} fill={fill}/><D x={122} y={151} radius={14} fill={ink}/><P d="M116 157L109 182H135L128 157Z" fill={ink} shadow={false}/><L d="M66 124V191" fill="#F4EBD8" width={4} opacity={.3}/></ObjectFrame>;
};

export const PaperMagnifier:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",accent="#F2BC55",ink=palette.ink}=p;
 return <ObjectFrame {...p} name="magnifier"><g transform="rotate(-36 120 120)"><P d="M105 142H137L140 216H103Z" fill={fill}/><D x={121} y={91} radius={66} fill={ink}/><D x={121} y={91} radius={52} fill="#A1C4BE"/><L d="M84 75Q94 48 120 50" fill="#F4EBD8" width={7} opacity={.5}/><R x={103} y={146} width={36} height={18} fill={accent}/></g></ObjectFrame>;
};

export const PaperCamera:React.FC<ObjectProps>=(p)=>{
 const {fill="#C69364",accent="#F2BC55",ink=palette.ink,progress=1}=p;
 const q=clamp(progress);
 return <ObjectFrame {...p} name="camera-prop"><P d="M32 86H65L81 62H151L168 86H214V205H28Z" fill={fill}/><R x={35} y={111} width={174} height={72} fill={ink}/><D x={121} y={147} radius={51} fill={ink}/><D x={121} y={147} radius={40} fill="#679A9D"/><D x={121} y={147} radius={27-q*14} fill="#263E4D"/><D x={111} y={135} radius={9} fill="#B7CDC5"/><R x={174} y={92} width={23} height={13} fill="#E9D7AF"/><R x={44} y={76} width={23} height={10} fill={accent}/></ObjectFrame>;
};
