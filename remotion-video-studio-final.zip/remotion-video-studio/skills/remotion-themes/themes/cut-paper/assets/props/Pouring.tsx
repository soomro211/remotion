import React, { useId } from "react";
import { PaperShape, ContactShadow, palette } from "../core/material";
import {
  preparePour,
  samplePouring,
  polygonPath,
  pitcherOutline,
  pitcherPivot,
  type PourConfig,
} from "../motion/pour";

export type PouringProps = PourConfig & {
  time: number;
  x?: number;
  y?: number;
  visualScale?: number;
  liquid?: string;
  glass?: string;
  handle?: string;
};

/** A complete paper pouring interaction. Source units occupy about 800×740. */
export const PaperPouring: React.FC<PouringProps> = ({
  time,
  x = 0,
  y = 0,
  visualScale = 1,
  liquid = "#70ADB3",
  glass = "#DCE4D5",
  handle = "#7D9D96",
  ...config
}) => {
  const id = "pour" + useId().replace(/[^a-z0-9]/gi, "");
  const prepared = preparePour(config);
  const state = samplePouring(time, prepared),
    c = prepared;
  const left = c.mouth.x - c.receiverWidth / 2,
    right = c.mouth.x + c.receiverWidth / 2,
    bottom = c.mouth.y + c.receiverHeight;
  const receiver = `M${left} ${c.mouth.y}L${right} ${c.mouth.y}L${right - c.receiverWidth * 0.12} ${bottom}Q${c.mouth.x} ${bottom + 8} ${left + c.receiverWidth * 0.12} ${bottom}Z`;
  const native = polygonPath(pitcherOutline),
    world = polygonPath(state.body);
  const pitcherTransform = `translate(${c.source.x} ${c.source.y}) scale(${c.scale}) rotate(${state.angle} ${pitcherPivot.x} ${pitcherPivot.y})`;
  const minX = Math.min(...state.body.map((p) => p.x)) - 4,
    maxX = Math.max(...state.body.map((p) => p.x)) + 4,
    maxY = Math.max(...state.body.map((p) => p.y)) + 4;
  const streamPath = state.stream
    .map((p, i) => (i ? "L" : "M") + p.x + " " + p.y)
    .join("");
  return (
    <g
      data-paper-pouring
      data-source-volume={state.sourceVolume}
      data-received-volume={state.received}
      data-flight-volume={state.inFlight}
      transform={`translate(${x} ${y}) scale(${visualScale})`}
    >
      <defs>
        <clipPath id={id + "-source"}>
          <path d={world} />
        </clipPath>
        <clipPath id={id + "-receiver"}>
          <path d={receiver} />
        </clipPath>
      </defs>
      <ContactShadow
        x={c.mouth.x}
        y={bottom + 5}
        width={c.receiverWidth * 0.94}
        depth={18}
      />
      <g transform={pitcherTransform}>
        <PaperShape
          d="M64 83C7 62 10 187 73 173L72 151C39 167 30 106 66 108Z"
          fill={handle}
        />
        <PaperShape d={native} fill={glass} />
        <path
          d="M65 54Q111 42 165 54L194 34L211 38"
          fill="none"
          stroke="#70908B"
          strokeWidth={5}
        />
      </g>
      <g clipPath={`url(#${id}-source)`}>
        <path
          data-horizontal-liquid-surface
          d={`M${minX} ${state.sourceSurface}H${maxX}V${maxY}H${minX}Z`}
          fill={liquid}
        />
        <path
          d={`M${minX} ${state.sourceSurface}H${maxX}`}
          stroke="#BBD8D4"
          strokeWidth={2}
        />
      </g>
      <g transform={pitcherTransform}>
        <path
          d={native}
          fill="none"
          stroke={palette.rim}
          strokeWidth={1.6}
          strokeLinejoin="round"
        />
        <path
          d="M79 99L89 202M154 96L152 119"
          stroke="#F7F4DC"
          strokeWidth={4}
          strokeLinecap="round"
          opacity={0.35}
        />
        <path
          d="M181 92L172 220L149 232"
          stroke="#74958E"
          strokeWidth={3}
          fill="none"
          opacity={0.3}
        />
      </g>
      <PaperShape d={receiver} fill={glass} />
      <ellipse
        cx={c.mouth.x}
        cy={c.mouth.y}
        rx={c.receiverWidth / 2}
        ry={12}
        fill="#C9D8CC"
        stroke={palette.rim}
        strokeWidth={2}
      />
      <g clipPath={`url(#${id}-receiver)`}>
        {state.received > 0 ? (
          <path
            d={`M${left} ${state.receiverSurface}H${right}V${bottom + 8}H${left}Z`}
            fill={liquid}
          />
        ) : null}
        {state.arrivalRate > 0 ? (
          <path
            d={`M${c.mouth.x} ${c.mouth.y}V${state.receiverSurface}`}
            stroke={liquid}
            strokeWidth={4 * state.arrivalRate}
            opacity={0.75}
          />
        ) : null}
        {state.arrivalRate > 0 ? (
          <ellipse
            cx={c.mouth.x}
            cy={state.receiverSurface}
            rx={12 + state.arrivalRate * 9}
            ry={3.5}
            fill="none"
            stroke="#D0E5DC"
            strokeWidth={1.5}
            opacity={state.arrivalRate * 0.7}
          />
        ) : null}
      </g>
      {state.active ? (
        <g data-flow-lip-x={state.lip.x} data-flow-lip-y={state.lip.y}>
          <path
            data-pour-stream
            d={streamPath}
            fill="none"
            stroke={liquid}
            strokeWidth={Math.max(
              2.8,
              Math.min(7.5, Math.sqrt(state.flowRate) * 12 + 2.4),
            )}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={streamPath}
            fill="none"
            stroke="#C8E4DF"
            strokeWidth={1.1}
            strokeLinecap="round"
            opacity={0.55}
          />
          {state.stream.length > 0 ? (
            <circle
              cx={state.stream[state.stream.length - 1].x}
              cy={state.stream[state.stream.length - 1].y}
              r={2.8}
              fill={liquid}
            />
          ) : null}
        </g>
      ) : null}
      <g clipPath={`url(#${id}-receiver)`}>
        <path d={receiver} fill="#F4EBD8" opacity={0.12} />
        <path
          d={`M${left + c.receiverWidth * 0.16} ${c.mouth.y + 36}L${left + c.receiverWidth * 0.22} ${bottom - 30}`}
          stroke="#F5F4E1"
          strokeWidth={4}
          opacity={0.45}
        />
      </g>
      <path d={receiver} fill="none" stroke={palette.rim} strokeWidth={2} />
      <path
        d={`M${left} ${c.mouth.y}Q${c.mouth.x} ${c.mouth.y + 25} ${right} ${c.mouth.y}`}
        fill="none"
        stroke={palette.rim}
        strokeWidth={3}
      />
    </g>
  );
};
