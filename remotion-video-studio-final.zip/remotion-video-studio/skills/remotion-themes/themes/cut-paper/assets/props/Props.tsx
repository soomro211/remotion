import React from "react";
import { PaperDisc, PaperRect, PaperShape, palette } from "../core/material";
import { clamp, mix } from "../core/math";
export const PaperBox: React.FC<{
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  fill?: string;
  open?: number;
}> = ({
  x = 0,
  y = 0,
  width = 120,
  height = 100,
  fill = "#BB9A65",
  open = 0,
}) => (
  <g transform={`translate(${x} ${y})`}>
    <PaperShape d={`M0 0L${width} 2L${width} ${height}H0Z`} fill={fill} />
    <PaperShape
      d={`M${width * 0.68} 1L${width} 2V${height}H${width * 0.68}Z`}
      fill="#947649"
      rim={0.9}
    />
    <PaperShape
      d={`M0 0L${width * 0.21} -14L${width * 1.06} -10L${width} 2Z`}
      fill="#D3B47D"
    />
    <PaperRect
      x={width * 0.42}
      y={0}
      width={width * 0.13}
      height={height}
      fill="#DDCA9C"
      shadow={false}
      rim={0.7}
    />
    <g transform={`rotate(${-clamp(open) * 65} 0 0)`}>
      <PaperShape
        d={`M0 0L${width * 0.65} 0L${width * 0.78} -15L${width * 0.16} -15Z`}
        fill="#D3B47D"
        rim={1.1}
      />
    </g>
  </g>
);
export const PaperContainer: React.FC<{
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  kind?: "jar" | "bucket" | "bottle";
  fill?: string;
  level?: number;
  contents?: string;
}> = ({
  x = 0,
  y = 0,
  width = 90,
  height = 130,
  kind = "jar",
  fill = "#9BAE9C",
  level = 0,
  contents = "#DFC06A",
}) => {
  const neck = kind === "bottle" ? 0.3 : kind === "bucket" ? 1 : 0.8,
    w = width,
    h = height;
  return (
    <g transform={`translate(${x} ${y})`}>
      <PaperShape
        d={
          kind === "bucket"
            ? `M0 0H${w}L${w * 0.84} ${h}H${w * 0.16}Z`
            : `M${(w * (1 - neck)) / 2} 0H${(w * (1 + neck)) / 2}V${h * 0.16}L${w * 0.95} ${h * 0.3}L${w * 0.89} ${h}H${w * 0.09}L0 ${h * 0.3}L${(w * (1 - neck)) / 2} ${h * 0.16}Z`
        }
        fill={fill}
      />
      {level > 0 ? (
        <PaperShape
          d={`M${w * 0.1} ${mix(h * 0.92, h * 0.36, clamp(level))}H${w * 0.86}V${h * 0.93}H${w * 0.12}Z`}
          fill={contents}
          rim={0}
          shadow={false}
        />
      ) : null}
      <PaperRect
        x={(w * (1 - neck)) / 2 - 3}
        y={-7}
        width={w * neck + 6}
        height={14}
        fill="#647C74"
      />
      {kind === "bucket" ? (
        <path
          d={`M${w * 0.06} ${h * 0.15}Q${w * 0.5} ${-h * 0.72} ${w * 0.94} ${h * 0.15}`}
          fill="none"
          stroke="#62776D"
          strokeWidth="4"
        />
      ) : null}
      <path
        d={`M${w * 0.2} ${h * 0.3}V${h * 0.79}`}
        stroke={palette.rim}
        strokeWidth="3"
        opacity=".5"
      />
    </g>
  );
};
export const PaperDocument: React.FC<{
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  kind?: "sheet" | "book";
  fill?: string;
}> = ({
  x = 0,
  y = 0,
  width = 120,
  height = 154,
  kind = "sheet",
  fill = palette.cream,
}) => (
  <g transform={`translate(${x} ${y})`}>
    {kind === "book" ? (
      <PaperRect
        x={-6}
        y={-5}
        width={width + 13}
        height={height + 12}
        fill="#5C8280"
      />
    ) : null}
    <PaperShape d={`M0 0H${width - 23}L${width} 25V${height}H0Z`} fill={fill} />
    <PaperShape d={`M${width - 23} 0V25H${width}Z`} fill="#D8CFB3" rim={0.8} />
    {[0.28, 0.39, 0.5, 0.61, 0.72].map((p, i) => (
      <path
        key={p}
        d={`M${width * 0.17} ${height * p}H${width * (i === 4 ? 0.55 : 0.8)}`}
        stroke="#748277"
        strokeWidth={i === 0 ? 5 : 2.3}
        opacity={i === 0 ? 0.8 : 0.5}
      />
    ))}
  </g>
);
export const PaperTokens: React.FC<{
  x?: number;
  y?: number;
  count?: number;
  radius?: number;
  fill?: string;
}> = ({ x = 0, y = 0, count = 4, radius = 26, fill = palette.yellow }) => (
  <g transform={`translate(${x} ${y})`}>
    {Array.from(
      { length: Math.max(0, Math.min(20, Math.floor(count))) },
      (_, i) => (
        <g key={i} transform={`translate(${(i % 2) * 3} ${-i * 10})`}>
          <PaperShape
            d={`M${-radius} 0V9Q0 24 ${radius} 9V0Z`}
            fill="#B18A4D"
            rim={1}
          />
          <ellipse
            rx={radius}
            ry={radius * 0.36}
            fill={fill}
            stroke={palette.rim}
            strokeWidth="1.4"
          />
        </g>
      ),
    )}
  </g>
);
export const PaperFurniture: React.FC<{
  x?: number;
  y?: number;
  kind?: "chair" | "bench" | "table";
  scale?: number;
  fill?: string;
}> = ({ x = 0, y = 0, kind = "chair", scale = 1, fill = "#AA875C" }) => {
  const w = kind === "bench" ? 240 : kind === "table" ? 280 : 110,
    seat = kind === "table" ? -180 : -104;
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      {kind !== "table" ? (
        <>
          <PaperRect
            x={-w / 2}
            y={seat - 103}
            width={w}
            height={31}
            fill={fill}
          />
          <PaperRect
            x={-w / 2}
            y={seat - 56}
            width={w}
            height={25}
            fill={fill}
          />
          <path
            d={`M${-w * 0.39} ${seat - 110}V${seat + 3}M${w * 0.39} ${seat - 110}V${seat + 3}`}
            stroke="#455B59"
            strokeWidth="9"
          />
        </>
      ) : null}
      <PaperRect
        x={-w / 2 - 8}
        y={seat}
        width={w + 16}
        height={15}
        fill={fill}
      />
      <path
        d={`M${-w * 0.37} ${seat + 10}L${-w * 0.43} 0M${w * 0.37} ${seat + 10}L${w * 0.43} 0`}
        stroke="#405653"
        strokeWidth="11"
      />
    </g>
  );
};
export const PaperDevice: React.FC<{
  x?: number;
  y?: number;
  width?: number;
  kind?: "phone" | "laptop" | "monitor";
  screen?: string;
}> = ({ x = 0, y = 0, width = 160, kind = "monitor", screen = "#8CADA7" }) => {
  const h = kind === "phone" ? width * 1.75 : width * 0.65;
  return (
    <g transform={`translate(${x} ${y})`}>
      <PaperRect width={width} height={h} fill="#3C535D" />
      <PaperRect
        x={8}
        y={8}
        width={width - 16}
        height={h - 19}
        fill={screen}
        rim={0.8}
      />
      <path
        d={`M${width * 0.22} ${h * 0.3}H${width * 0.7}M${width * 0.22} ${h * 0.44}H${width * 0.58}`}
        stroke={palette.cream}
        strokeWidth="3"
        opacity=".5"
      />
      {kind === "phone" ? (
        <PaperDisc x={width / 2} y={h - 7} radius={2} fill={palette.cream} />
      ) : kind === "laptop" ? (
        <PaperShape
          d={`M0 ${h}L${-width * 0.1} ${h + 17}H${width * 1.1}L${width} ${h}Z`}
          fill="#748782"
        />
      ) : (
        <>
          <PaperRect
            x={width * 0.45}
            y={h}
            width={width * 0.1}
            height={30}
            fill="#667E78"
          />
          <PaperRect
            x={width * 0.25}
            y={h + 27}
            width={width * 0.5}
            height={8}
            fill="#667E78"
          />
        </>
      )}
    </g>
  );
};
