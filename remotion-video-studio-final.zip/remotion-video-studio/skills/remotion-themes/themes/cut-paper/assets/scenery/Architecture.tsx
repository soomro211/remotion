import React from "react";
import {
  PaperShape as P,
  PaperRect as R,
  PaperDisc as D,
  ContactShadow,
} from "../core/material";
import { clamp } from "../core/math";
export type BuildingProps = {
  x?: number;
  y?: number;
  scale?: number;
  fill?: string;
  accent?: string;
  ink?: string;
  open?: number;
  light?: number;
  label?: string;
};
const cream = "#F4EBD8",
  glass = "#85AAA7",
  dark = "#3C5960";
const Line: React.FC<{
  d: string;
  color?: string;
  width?: number;
  opacity?: number;
}> = ({ d, color = cream, width = 3, opacity = 0.65 }) => (
  <path
    d={d}
    fill="none"
    stroke={color}
    strokeWidth={width}
    opacity={opacity}
  />
);
const Frame: React.FC<
  BuildingProps & { name: string; children: React.ReactNode }
> = ({ x = 0, y = 0, scale = 1, name, children, open = 0, light = 0 }) => {
  if (![x, y, scale, open, light].every(Number.isFinite) || scale <= 0)
    throw new Error("Building needs finite controls and positive scale.");
  return (
    <g
      data-paper-building={name}
      transform={`translate(${x} ${y}) scale(${scale}) translate(-300 -460)`}
    >
      <ContactShadow x={300} y={463} width={525} depth={24} />
      {children}
    </g>
  );
};
const Win: React.FC<{
  x: number;
  y: number;
  w?: number;
  h?: number;
  light?: number;
  arched?: boolean;
}> = ({ x, y, w = 55, h = 65, light = 0, arched = false }) => (
  <g>
    <R x={x - 5} y={y - 5} width={w + 10} height={h + 10} fill={cream} />
    {arched ? (
      <P
        d={`M${x} ${y + h}V${y + 20}Q${x + w / 2} ${y - 17} ${x + w} ${y + 20}V${y + h}Z`}
        fill={light > 0.5 ? "#E6C579" : glass}
      />
    ) : (
      <R
        x={x}
        y={y}
        width={w}
        height={h}
        fill={light > 0.5 ? "#E6C579" : glass}
      />
    )}
    <Line
      d={`M${x + w / 2} ${y}V${y + h}M${x} ${y + h * 0.5}H${x + w}`}
      width={3}
    />
    <Line d={`M${x + 6} ${y + 10}l${w * 0.28} ${h * 0.22}`} opacity={0.3} />
    <R x={x - 9} y={y + h} width={w + 18} height={7} fill="#B69D79" />
  </g>
);
const Door: React.FC<{
  x: number;
  y: number;
  w?: number;
  h?: number;
  open?: number;
}> = ({ x, y, w = 68, h = 112, open = 0 }) => (
  <g>
    <R x={x - 6} y={y - 6} width={w + 12} height={h + 6} fill={cream} />
    <R x={x} y={y} width={w} height={h} fill={dark} />
    <g transform={`translate(${x} ${y}) scale(${1 - clamp(open) * 0.86} 1)`}>
      <R width={w} height={h} fill="#668D87" />
      <R x={7} y={8} width={w - 14} height={h * 0.6} fill="#A9C1B4" />
      <D x={w - 10} y={h * 0.76} radius={3} fill="#E4C176" />
    </g>
    <R x={x - 12} y={y + h} width={w + 24} height={9} fill="#B9AA8F" />
  </g>
);
const Sign: React.FC<{
  x: number;
  y: number;
  w: number;
  text: string;
  fill?: string;
}> = ({ x, y, w, text, fill = dark }) => (
  <g>
    <R x={x} y={y} width={w} height={42} fill={fill} />
    <text
      x={x + w / 2}
      y={y + 28}
      textAnchor="middle"
      fill={cream}
      fontFamily="DM Sans, sans-serif"
      fontWeight={700}
      fontSize={20}
      letterSpacing={2}
    >
      {text}
    </text>
  </g>
);
const Brick: React.FC<{
  x: number;
  y: number;
  columns: number;
  rows: number;
}> = ({ x, y, columns, rows }) => (
  <g opacity={0.24}>
    {Array.from({ length: rows }, (_, j) =>
      Array.from({ length: columns }, (_, i) => (
        <Line
          key={j + "-" + i}
          d={`M${x + i * 45 + (j % 2) * 20} ${y + j * 25}h28`}
          width={2}
          opacity={1}
        />
      )),
    )}
  </g>
);
const Awning: React.FC<{ x: number; y: number; w: number; fill: string }> = ({
  x,
  y,
  w,
  fill,
}) => (
  <g>
    <P
      d={`M${x + 8} ${y}H${x + w - 8}L${x + w + 10} ${y + 45}H${x - 10}Z`}
      fill={fill}
    />
    {Array.from({ length: 7 }, (_, i) => (
      <P
        key={i}
        d={`M${x + 8 + (i * (w - 16)) / 7} ${y + 1}h${(w - 16) / 14}l${4 + i * 1.2} 43h${-(w + 20) / 14}Z`}
        fill={cream}
        shadow={false}
      />
    ))}
    <R x={x - 10} y={y + 44} width={w + 20} height={13} fill={fill} />
  </g>
);
const Side: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  fill?: string;
}> = ({ x, y, w, h, fill = "#9C967F" }) => (
  <P d={`M${x} ${y}l${w} -24v${h}l${-w} 24Z`} fill={fill} />
);

export const PaperFactory: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="factory">
    <R x={91} y={76} width={46} height={293} fill="#A9765C" />
    <R x={84} y={63} width={60} height={20} fill="#70594B" />
    <Brick x={98} y={105} columns={1} rows={8} />
    <Side x={522} y={219} w={35} h={239} />
    <P
      d="M48 257L168 194V257L289 194V257L410 194V257L522 219V457H48Z"
      fill={p.fill ?? "#B69B75"}
    />
    <P
      d="M48 257L167 198V220L87 263ZM170 257L289 198V220L209 263ZM292 257L410 198V220L331 263Z"
      fill={glass}
    />
    <Line d="M47 268H522" color={dark} width={10} />
    <Brick x={65} y={292} columns={10} rows={6} />
    {[80, 179, 278].map((x) => (
      <Win key={x} x={x} y={293} w={68} h={72} light={p.light} />
    ))}
    <R x={390} y={325} width={94} height={130} fill={dark} />
    <g
      transform={`translate(390 325) scale(1 ${1 - clamp(p.open ?? 0) * 0.9})`}
    >
      <R width={94} height={130} fill="#78918A" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <Line key={i} d={`M3 ${13 + i * 20}h88`} opacity={0.4} />
      ))}
    </g>
    <P d="M377 452H503L517 463H366Z" fill="#A4A38F" />
  </Frame>
);
export const PaperBakery: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="bakery">
    <Side x={500} y={161} w={36} h={296} fill="#A27C61" />
    <R x={80} y={153} width={420} height={304} fill={p.fill ?? "#CDAB83"} />
    <P d="M62 158L288 53L518 158Z" fill="#A26F56" />
    <P d="M91 146L288 65L488 147Z" fill="#BA8461" shadow={false} />
    <Win x={260} y={102} w={55} h={49} arched />
    <Sign
      x={166}
      y={198}
      w={230}
      text={p.label ?? "BAKERY"}
      fill={p.accent ?? "#568783"}
    />
    <R x={109} y={290} width={219} height={133} fill={dark} />
    <R x={117} y={296} width={203} height={120} fill="#91ACA2" />
    {[0, 1, 2].map((i) => (
      <g key={i}>
        <P d={`M${136 + i * 61} 377q0-36 24-36t24 36Z`} fill="#DBB474" />
        <Line
          d={`M${146 + i * 61} 351l-3 15m12-18l-3 16`}
          color={cream}
          width={3}
        />
      </g>
    ))}
    <Line d="M119 393H319M220 297V416" />
    <Door x={365} y={308} w={78} h={143} open={p.open} />
    <Awning x={99} y={250} w={352} fill={p.accent ?? "#B76E55"} />
    <R x={98} y={424} width={233} height={14} fill="#B98C63" />
  </Frame>
);
export const PaperBank: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="bank">
    <Side x={507} y={197} w={35} h={260} />
    <R x={79} y={193} width={428} height={256} fill={p.fill ?? "#C8C4AB"} />
    <P d="M55 193L291 63L531 193Z" fill={p.accent ?? "#6B8884"} />
    <P d="M108 177L291 83L477 177Z" fill="#B7B7A1" />
    <D x={291} y={140} radius={28} fill="#E3C17B" />
    <Line d="M291 120V159M281 127h20m-20 23h20" color={dark} width={4} />
    <R x={57} y={197} width={472} height={24} fill={cream} />
    {[107, 190, 363, 446].map((x) => (
      <g key={x}>
        <R x={x - 7} y={235} width={47} height={15} fill={cream} />
        <R x={x} y={249} width={33} height={164} fill="#DDD8C0" />
        <Line
          d={`M${x + 8} 259V406M${x + 24} 259V406`}
          color="#A5AA99"
          width={3}
        />
        <R x={x - 8} y={412} width={49} height={17} fill={cream} />
      </g>
    ))}
    <Door x={263} y={307} w={72} h={124} open={p.open} />
    <Sign x={224} y={236} w={146} text={p.label ?? "BANK"} />
    {[0, 1, 2].map((i) => (
      <R
        key={i}
        x={72 - i * 13}
        y={429 + i * 10}
        width={441 + i * 26}
        height={10}
        fill={i % 2 ? "#AAA88F" : "#D8D1B7"}
      />
    ))}
  </Frame>
);
export const PaperWarehouse: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="warehouse">
    <Side x={515} y={197} w={38} h={260} />
    <R x={65} y={197} width={450} height={260} fill={p.fill ?? "#A3AAA0"} />
    <P d="M44 198L292 79L537 198Z" fill={p.accent ?? "#53777C"} />
    <Win x={249} y={126} w={81} h={38} />
    {[0, 1].map((i) => (
      <g key={i}>
        <R x={95 + i * 214} y={268} width={177} height={176} fill={dark} />
        <g
          transform={`translate(${99 + i * 214} 272) scale(1 ${1 - clamp(p.open ?? 0) * 0.86})`}
        >
          <R width={169} height={170} fill="#788F88" />
          {[0, 1, 2, 3, 4, 5, 6].map((j) => (
            <Line key={j} d={`M2 ${12 + j * 24}h165`} opacity={0.45} />
          ))}
        </g>
        <R x={85 + i * 214} y={442} width={197} height={16} fill="#726D5F" />
      </g>
    ))}
    <R x={71} y={222} width={438} height={16} fill="#C4BCA5" />
  </Frame>
);
export const PaperHospitalBuilding: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="hospital">
    <R x={58} y={204} width={484} height={252} fill={p.fill ?? "#CACDBB"} />
    <Side x={542} y={204} w={23} h={252} />
    <R x={221} y={92} width={158} height={364} fill="#E6E2CB" />
    <R x={209} y={77} width={182} height={25} fill="#728F88" />
    <P
      d="M283 118H315V144H342V176H315V203H283V176H256V144H283Z"
      fill={p.accent ?? "#B87763"}
    />
    {[88, 420].map((x) =>
      [240, 326].map((y) => (
        <Win key={x + "-" + y} x={x} y={y} w={82} h={58} light={p.light} />
      )),
    )}
    <R x={240} y={332} width={119} height={124} fill={dark} />
    <R x={248} y={340} width={46} height={116} fill={glass} />
    <R x={303} y={340} width={48} height={116} fill={glass} />
    <Line d="M299 337V454" />
    <P d="M208 311L379 311L396 336H192Z" fill="#71948D" />
    <Line d="M211 335V455M379 335V455" color={cream} width={7} />
    <R x={234} y={259} width={130} height={29} fill="#839F96" />
    <text
      x={299}
      y={280}
      fontFamily="DM Sans"
      fontSize={16}
      textAnchor="middle"
      fill={cream}
    >
      CARE
    </text>
  </Frame>
);
export const PaperPharmacy: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="pharmacy">
    <R x={91} y={170} width={418} height={285} fill={p.fill ?? "#D4CFB3"} />
    <Side x={509} y={170} w={32} h={285} />
    <R x={76} y={155} width={449} height={26} fill="#6C9084" />
    <Sign
      x={122}
      y={206}
      w={355}
      text={p.label ?? "PHARMACY"}
      fill={p.accent ?? "#668B80"}
    />
    <Win x={124} y={283} w={172} h={130} />
    <Door x={350} y={294} w={99} h={155} open={p.open} />
    <P
      d="M182 310H213V332H236V361H213V385H182V361H159V332H182Z"
      fill="#D5E0C6"
    />
    <R x={479} y={209} width={58} height={58} fill="#648D7C" />
    <Line d="M508 220V256M490 238H526" width={10} />
  </Frame>
);
export const PaperCafe: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="cafe">
    <R x={94} y={128} width={410} height={327} fill={p.fill ?? "#BDB194"} />
    <Side x={504} y={128} w={31} h={327} />
    <R x={76} y={114} width={445} height={23} fill="#6E837C" />
    <Win x={137} y={161} w={94} h={70} />
    <Win x={363} y={161} w={94} h={70} />
    <Sign x={224} y={250} w={151} text={p.label ?? "CAFÉ"} />
    <Win x={127} y={319} w={172} h={99} />
    <Door x={358} y={327} h={121} w={86} open={p.open} />
    <Awning x={107} y={286} w={382} fill={p.accent ?? "#658E83"} />
    <R x={116} y={431} width={193} height={11} fill="#9E7D5D" />
    <Line d="M143 441V461M283 441V461" color={dark} width={8} />
  </Frame>
);
export const PaperGrocery: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="grocery">
    <R x={75} y={178} width={449} height={275} fill={p.fill ?? "#CEB18B"} />
    <Side x={524} y={178} w={28} h={275} />
    <R x={61} y={161} width={477} height={26} fill="#6E8F7B" />
    <Sign
      x={106}
      y={204}
      w={386}
      text={p.label ?? "GROCER"}
      fill={p.accent ?? "#778F64"}
    />
    <Win x={110} y={296} w={212} h={110} />
    <Door x={379} y={299} w={95} h={151} open={p.open} />
    <Awning x={87} y={259} w={430} fill={p.accent ?? "#8C9D67"} />
    {[0, 1, 2].map((i) => (
      <g key={i}>
        <P d={`M${94 + i * 83} 419h76l-5 35h-65Z`} fill="#A3845C" />
        {[0, 1, 2, 3].map((j) => (
          <D
            key={j}
            x={110 + i * 83 + j * 14}
            y={416 - (j % 2) * 7}
            radius={10}
            fill={i === 1 ? "#D5AE62" : i === 2 ? "#94A675" : "#BF8061"}
          />
        ))}
        <Line d={`M${100 + i * 83} 434h64`} width={2} />
      </g>
    ))}
  </Frame>
);
export const PaperWorkshop: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="workshop">
    <R x={74} y={194} width={451} height={263} fill={p.fill ?? "#B89C7B"} />
    <Side x={525} y={194} w={31} h={263} />
    <P d="M51 198L293 92L549 198Z" fill={p.accent ?? "#667D78"} />
    <Brick x={90} y={225} columns={9} rows={9} />
    <R x={107} y={278} width={198} height={178} fill={dark} />
    <g
      transform={`translate(111 281) scale(1 ${1 - clamp(p.open ?? 0) * 0.9})`}
    >
      <R width={190} height={174} fill="#81948A" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <Line key={i} d={`M2 ${16 + i * 28}h186`} opacity={0.4} />
      ))}
    </g>
    <Win x={352} y={274} w={106} h={91} />
    <Door x={385} y={382} w={58} h={69} open={p.open} />
    <Sign x={189} y={212} w={223} text={p.label ?? "WORKSHOP"} />
  </Frame>
);
export const PaperApartments: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="apartments">
    <Side x={480} y={90} w={42} h={367} fill="#A58B73" />
    <R x={119} y={90} width={361} height={367} fill={p.fill ?? "#C6A383"} />
    <R x={105} y={74} width={389} height={25} fill={p.accent ?? "#6E8E82"} />
    {[0, 1, 2].map((row) =>
      [0, 1, 2].map((col) => (
        <g key={row + "-" + col}>
          <Win
            x={151 + col * 114}
            y={121 + row * 103}
            w={65}
            h={58}
            light={p.light}
          />
          {col !== 1 ? (
            <>
              <R
                x={140 + col * 114}
                y={182 + row * 103}
                width={88}
                height={7}
                fill={dark}
              />
              <Line
                d={`M${146 + col * 114} ${171 + row * 103}v15m16-15v15m16-15v15m16-15v15m16-15v15`}
                color={dark}
                width={3}
              />
            </>
          ) : null}
        </g>
      )),
    )}
    <Door x={268} y={362} w={68} h={88} open={p.open} />
  </Frame>
);
export const PaperOffice: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="office">
    <Side x={477} y={75} w={48} h={382} fill="#78958E" />
    <R x={117} y={75} width={360} height={382} fill={p.fill ?? "#9AADA1"} />
    <R x={103} y={62} width={387} height={23} fill={dark} />
    {Array.from({ length: 4 }, (_, j) =>
      Array.from({ length: 4 }, (_, i) => (
        <Win
          key={j + "-" + i}
          x={142 + i * 82}
          y={104 + j * 70}
          w={55}
          h={45}
          light={p.light}
        />
      )),
    )}
    <R x={247} y={385} width={102} height={71} fill={dark} />
    <Line d="M298 390V453M254 391H343" />
    <P d="M223 374H374L393 390H205Z" fill={p.accent ?? "#678981"} />
  </Frame>
);
export const PaperStation: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="station">
    <R x={49} y={267} width={502} height={188} fill={p.fill ?? "#C5B18B"} />
    <R x={230} y={150} width={141} height={305} fill="#D6C8A7" />
    <P d="M212 153L300 72L389 153Z" fill={p.accent ?? "#5F7C79"} />
    <D x={301} y={202} radius={39} fill={cream} />
    <D x={301} y={202} radius={32} fill="#DAD2B7" />
    <Line d="M301 180V204L320 216" color={dark} width={4} />
    <Sign x={231} y={261} w={140} text={p.label ?? "STATION"} />
    {[86, 164, 401, 479].map((x) => (
      <Win key={x} x={x} y={312} w={43} h={78} arched />
    ))}
    <Door x={266} y={332} w={70} h={119} open={p.open} />
    <P d="M24 402H575L557 421H44Z" fill="#6E8D81" />
    <Line
      d="M66 419V457M203 419V457M397 419V457M534 419V457"
      color={dark}
      width={5}
    />
  </Frame>
);
export const PaperFireStation: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="fire-station">
    <R x={62} y={187} width={473} height={270} fill={p.fill ?? "#B58167"} />
    <Brick x={82} y={215} columns={10} rows={9} />
    <R x={50} y={173} width={497} height={24} fill={dark} />
    <Sign x={151} y={212} w={300} text={p.label ?? "FIRE STATION"} />
    {[0, 1, 2].map((i) => (
      <g key={i}>
        <P d={`M${91 + i * 147} 454V330q0-30 55-30t55 30v124Z`} fill={cream} />
        <R x={98 + i * 147} y={331} width={96} height={123} fill={dark} />
        <g
          transform={`translate(${101 + i * 147} 334) scale(1 ${1 - clamp(p.open ?? 0) * 0.9})`}
        >
          <R width={90} height={120} fill={p.accent ?? "#A56350"} />
          {[0, 1, 2, 3].map((j) => (
            <Line key={j} d={`M3 ${19 + j * 28}h84`} opacity={0.4} />
          ))}
        </g>
      </g>
    ))}
  </Frame>
);
export const PaperLibrary: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="library">
    <R x={79} y={178} width={441} height={276} fill={p.fill ?? "#C3B08E"} />
    <P d="M59 179L300 60L540 179Z" fill={p.accent ?? "#6F8782"} />
    <P d="M260 132L298 143L338 132V166L299 178L260 166Z" fill={cream} />
    <Line d="M299 145V173" color={dark} width={2} />
    <Sign x={177} y={203} w={244} text={p.label ?? "LIBRARY"} />
    {[115, 389].map((x) => (
      <Win key={x} x={x} y={276} w={93} h={127} arched light={p.light} />
    ))}
    <Door x={267} y={311} w={68} h={140} open={p.open} />
    <R x={65} y={442} width={469} height={16} fill="#9B997F" />
  </Frame>
);
export const PaperShopBuilding: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="shop">
    <Side x={497} y={117} w={37} h={340} />
    <R x={92} y={117} width={405} height={340} fill={p.fill ?? "#C5A482"} />
    <R x={76} y={101} width={437} height={25} fill="#798B7D" />
    {[143, 346].map((x) => (
      <Win key={x} x={x} y={157} w={96} h={79} arched light={p.light} />
    ))}
    <Sign
      x={132}
      y={264}
      w={323}
      text={p.label ?? "GENERAL STORE"}
      fill={p.accent ?? "#547E7B"}
    />
    <R x={120} y={332} width={195} height={102} fill={dark} />
    <R x={128} y={340} width={179} height={86} fill={glass} />
    <Line d="M185 342V426M249 342V426" />
    <R x={142} y={395} width={42} height={30} fill="#CCB174" />
    <R x={206} y={384} width={33} height={42} fill="#C28F73" />
    <Door x={367} y={335} w={83} h={114} open={p.open} />
    <Awning x={105} y={304} w={377} fill={p.accent ?? "#BD805D"} />
  </Frame>
);
export const PaperSchoolBuilding: React.FC<BuildingProps> = (p) => (
  <Frame {...p} name="school">
    <R x={69} y={227} width={463} height={227} fill={p.fill ?? "#C6B08A"} />
    <R x={229} y={171} width={143} height={283} fill="#D9C5A0" />
    <P d="M48 228L299 107L553 228Z" fill={p.accent ?? "#5D7C7B"} />
    <D x={301} y={233} radius={31} fill={cream} />
    <Line d="M301 215V235L315 246" color={dark} width={3} />
    {[102, 172, 396, 466].map((x) => (
      <Win key={x} x={x} y={286} w={39} h={82} light={p.light} />
    ))}
    <Door x={265} y={337} w={73} h={112} open={p.open} />
    <R x={215} y={443} width={172} height={16} fill="#A79D83" />
    <Line d="M299 109V49" color={dark} width={5} />
    <P d="M302 49L370 61L302 82Z" fill="#D3AD66" />
  </Frame>
);
