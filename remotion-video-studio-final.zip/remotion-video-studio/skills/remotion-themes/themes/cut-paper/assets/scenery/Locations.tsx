import React from "react";
import {
  PaperShape as P,
  PaperRect as R,
  PaperDisc as D,
} from "../core/material";
import * as B from "./Architecture";
import { PaperSurface } from "./Surfaces";
export type LocationKind =
  | "city"
  | "old-town"
  | "industrial"
  | "bakery-interior"
  | "shop-interior"
  | "hospital-corridor"
  | "station-platform"
  | "harbor"
  | "rocky-coast"
  | "desert"
  | "dry-canyon"
  | "winter";
export type LocationProps = {
  x?: number;
  y?: number;
  scale?: number;
  kind?: LocationKind;
  sky?: string;
};
const cream = "#F2E8D1",
  teal = "#6E9792";
const Pane: React.FC<{ x: number; y: number; w?: number; h?: number }> = ({
  x,
  y,
  w = 250,
  h = 310,
}) => (
  <g>
    <R x={x - 12} y={y - 12} width={w + 24} height={h + 24} fill={cream} />
    <R x={x} y={y} width={w} height={h} fill="#9EB9AE" />
    <path
      d={`M${x + w / 2} ${y}V${y + h}M${x} ${y + h * 0.5}H${x + w}`}
      stroke={cream}
      strokeWidth={10}
    />
    <path
      d={`M${x + 20} ${y + 30}l${w * 0.33} ${h * 0.26}`}
      stroke={cream}
      strokeWidth={9}
      opacity={0.28}
    />
  </g>
);
const Shelf: React.FC<{ x: number; y: number; bakery?: boolean }> = ({
  x,
  y,
  bakery = false,
}) => (
  <g>
    <R x={x} y={y} width={370} height={320} fill="#A58B66" />
    {[0, 1, 2].map((row) => (
      <g key={row}>
        {[0, 1, 2, 3, 4].map((i) =>
          bakery ? (
            <P
              key={i}
              d={`M${x + 19 + i * 68} ${y + 84 + row * 101}q-4-55 26-55t26 55Z`}
              fill="#DDB97A"
            />
          ) : (
            <g key={i}>
              <R
                x={x + 21 + i * 67}
                y={y + 25 + row * 101}
                width={44}
                height={62}
                fill={["#73978B", "#C48D6D", "#D1B171"][i % 3]}
              />
              <R
                x={x + 26 + i * 67}
                y={y + 39 + row * 101}
                width={34}
                height={22}
                fill={cream}
              />
            </g>
          ),
        )}
        <R
          x={x + 4}
          y={y + 88 + row * 101}
          width={362}
          height={13}
          fill="#D0B18A"
        />
      </g>
    ))}
  </g>
);
/** Authored location, 1600×1000 native. Layers remain editable SVG, no forced garden backdrop. */
export const PaperLocation: React.FC<LocationProps> = ({
  x = 0,
  y = 0,
  scale = 1,
  kind = "city",
  sky,
}) => {
  if (![x, y, scale].every(Number.isFinite) || scale <= 0)
    throw new Error("Location needs finite placement and positive scale.");
  const indoors = kind.endsWith("interior") || kind === "hospital-corridor";
  return (
    <g
      data-paper-location={kind}
      transform={`translate(${x} ${y}) scale(${scale})`}
    >
      <R
        width={1600}
        height={1000}
        fill={
          sky ??
          (kind === "winter"
            ? "#BCD0CA"
            : kind === "desert"
              ? "#E9C99B"
              : kind === "dry-canyon"
                ? "#DDC3A0"
                : indoors
                  ? "#D8D1BA"
                  : "#D5DED0")
        }
        shadow={false}
        rim={0}
      />
      {kind === "city" ? (
        <>
          <g opacity={0.35}>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <R
                key={i}
                x={i * 290 - 50}
                y={250 + (i % 3) * 67}
                width={240}
                height={440}
                fill={i % 2 ? "#8AA197" : "#A4AD9A"}
                shadow={false}
              />
            ))}
          </g>
          <B.PaperApartments x={220} y={765} scale={1.23} />
          <B.PaperOffice x={750} y={765} scale={1.5} />
          <B.PaperShopBuilding x={1330} y={765} scale={1.08} />
          <PaperSurface y={765} width={1600} height={84} kind="sidewalk" />
          <PaperSurface y={849} width={1600} height={151} kind="asphalt" />
        </>
      ) : null}
      {kind === "old-town" ? (
        <>
          <B.PaperBakery x={225} y={770} scale={1.16} />
          <B.PaperCafe x={790} y={770} scale={1.1} />
          <B.PaperLibrary x={1367} y={770} scale={1.1} />
          <PaperSurface y={770} width={1600} height={230} kind="cobbles" />
        </>
      ) : null}
      {kind === "industrial" ? (
        <>
          <P
            d="M0 520L290 441L470 521L730 404L1010 518L1260 439L1600 533V800H0Z"
            fill="#B3B8A3"
            shadow={false}
          />
          <B.PaperFactory x={460} y={785} scale={1.7} />
          <B.PaperWarehouse x={1290} y={785} scale={1.05} />
          <PaperSurface
            y={785}
            width={1600}
            height={215}
            kind="asphalt"
            markings={false}
          />
          <path
            d="M0 927H1600"
            stroke="#CBBF8D"
            strokeWidth={7}
            strokeDasharray="34 26"
          />
        </>
      ) : null}
      {indoors ? (
        <>
          <R y={690} width={1600} height={25} fill="#8B9E8B" />
          <PaperSurface
            y={715}
            width={1600}
            height={285}
            kind={kind === "bakery-interior" ? "wood" : "tile"}
          />
          <R x={0} y={0} width={1600} height={30} fill="#7A9689" />
        </>
      ) : null}
      {kind === "bakery-interior" ? (
        <>
          <Pane x={70} y={190} w={340} h={340} />
          <Shelf x={505} y={225} bakery />
          <P d="M1015 709V328Q1015 143 1248 143T1480 328V709Z" fill="#A37B5D" />
          <P d="M1060 606V340Q1060 205 1248 205T1435 340V606Z" fill="#554E42" />
          <R x={1065} y={579} width={365} height={22} fill="#C7A878" />
          <R x={430} y={651} width={500} height={183} fill="#B8966C" />
          <R x={409} y={627} width={542} height={30} fill={cream} />
          {[0, 1, 2].map((i) => (
            <P
              key={i}
              d={`M${475 + i * 130} 626q-3-57 49-57t49 57Z`}
              fill="#D9AF6A"
            />
          ))}
        </>
      ) : null}
      {kind === "shop-interior" ? (
        <>
          <Shelf x={65} y={227} />
          <Shelf x={580} y={227} />
          <Pane x={1110} y={162} w={356} h={397} />
          <R x={984} y={651} width={500} height={190} fill="#829B8B" />
          <R x={960} y={624} width={545} height={31} fill={cream} />
          <P d="M1210 620V549H1360V620Z" fill="#3E5F64" />
          <R x={1223} y={560} width={122} height={44} fill="#AFBFA3" />
        </>
      ) : null}
      {kind === "hospital-corridor" ? (
        <>
          <Pane x={40} y={152} w={355} h={350} />
          {[549, 1080].map((i) => (
            <g key={i}>
              <R x={i} y={173} width={310} height={538} fill="#9AB1A4" />
              <R x={i + 18} y={190} width={274} height={521} fill="#658B85" />
              <R x={i + 56} y={230} width={196} height={140} fill="#B6C8B8" />
              <D x={i + 251} y={471} radius={9} fill={cream} />
            </g>
          ))}
          <R x={12} y={552} width={480} height={22} fill="#7D9686" />
          <P
            d="M196 374H257V416H299V477H257V519H196V477H154V416H196Z"
            fill="#B87C67"
          />
        </>
      ) : null}
      {kind === "station-platform" ? (
        <>
          <R y={478} width={1600} height={235} fill="#B8B8A0" />
          {[150, 535, 920, 1305].map((i) => (
            <Pane key={i} x={i} y={255} w={220} h={225} />
          ))}
          <P d="M0 85H1600L1510 215H70Z" fill="#68877E" />
          {[85, 790, 1510].map((i) => (
            <R key={i} x={i} y={198} width={31} height={577} fill="#466C6A" />
          ))}
          <D x={800} y={308} radius={70} fill={cream} />
          <path
            d="M800 258V310L838 339"
            fill="none"
            stroke="#486A6B"
            strokeWidth={8}
          />
          <PaperSurface y={713} width={1600} height={135} kind="sidewalk" />
          <R y={817} width={1600} height={20} fill="#D1B15D" />
          <PaperSurface y={848} width={1600} height={152} kind="rail" />
        </>
      ) : null}
      {kind === "harbor" ? (
        <>
          <P
            d="M0 498L261 432L550 498L854 412L1188 492L1600 423V623H0Z"
            fill="#A3B6A7"
            shadow={false}
          />
          <R y={577} width={1600} height={423} fill={teal} shadow={false} />
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <path
              key={i}
              d={`M${i * 271 - 60} ${690 + (i % 2) * 82}h170m25 17h90`}
              stroke="#B5D0BD"
              opacity={0.6}
              strokeWidth={5}
            />
          ))}
          <P d="M0 625H734L830 785H0Z" fill="#B4AD91" />
          <P d="M965 600H1530L1600 785H965Z" fill="#ACA88E" />
          <B.PaperWarehouse x={317} y={667} scale={1.02} />
          <P d="M1010 632V225H1470V246H1031V632Z" fill="#B39F70" />
          <path
            d="M1028 251L1175 631M1430 246V496"
            stroke="#5A7773"
            strokeWidth={7}
          />
          <P
            d="M1417 494q-18 44 13 44t13-44"
            fill="none"
            rim={0}
            shadow={false}
          />
          <PaperSurface y={785} width={1600} height={215} kind="wood" />
          <R y={782} width={1600} height={25} fill="#8A785D" />
        </>
      ) : null}
      {kind === "rocky-coast" ? (
        <>
          <R y={420} width={1600} height={580} fill={teal} shadow={false} />
          <P
            d="M0 420L310 375L485 423L642 566L879 657L1066 757L1049 1000H0Z"
            fill="#8E9A89"
          />
          <P
            d="M0 538L325 456L458 529L622 713L858 779L1000 1000H0Z"
            fill="#B2B39B"
          />
          <P
            d="M0 413L300 355L486 409L646 559L548 574L401 474L262 439L0 490Z"
            fill="#D0C9AC"
          />
          <path
            d="M735 689q135 7 249 103m109-216h292m-263 100h179"
            stroke="#C7DDC8"
            strokeWidth={7}
            fill="none"
            opacity={0.8}
          />
          <P d="M1074 991L1160 870L1287 916L1346 1000Z" fill="#7F958A" />
        </>
      ) : null}
      {kind === "desert" ? (
        <>
          <D x={1260} y={216} radius={89} fill="#DFB666" />
          <P
            d="M0 561Q294 333 703 575T1600 486V1000H0Z"
            fill="#D6B07A"
            shadow={false}
          />
          <P d="M0 701Q453 447 916 701T1600 620V1000H0Z" fill="#C99767" />
          <P d="M0 896Q490 624 1021 848T1600 775V1000H0Z" fill="#E0BF86" />
          <path
            d="M82 876Q490 666 983 844M1007 636Q1313 572 1529 644"
            stroke="#EDD39C"
            strokeWidth={6}
            fill="none"
            opacity={0.5}
          />
        </>
      ) : null}
      {kind === "dry-canyon" ? (
        <>
          <P
            d="M0 170H314L373 304H491L539 607L761 778L698 1000H0Z"
            fill="#BA8865"
          />
          <P
            d="M1600 112H1345L1282 258H1177L1085 563L914 765L1035 1000H1600Z"
            fill="#A97C60"
          />
          <P d="M0 499L431 485L500 618L664 813L616 1000H0Z" fill="#D1A17A" />
          <P
            d="M1600 472L1148 483L1086 624L962 819L1064 1000H1600Z"
            fill="#C89570"
          />
          <P d="M680 1000L747 749L835 588L901 749L1009 1000Z" fill="#DABB8C" />
          <path
            d="M20 341H375M40 432H415M1280 347H1587M1151 571H1600"
            stroke="#E1BE96"
            strokeWidth={8}
            opacity={0.5}
          />
        </>
      ) : null}
      {kind === "winter" ? (
        <>
          <P
            d="M0 642L230 268L472 622L790 232L1113 637L1378 324L1600 660V1000H0Z"
            fill="#87A79E"
          />
          <P
            d="M230 269L138 416L229 389L305 429ZM790 233L661 402L781 361L883 403ZM1378 325L1297 434L1381 413L1454 455Z"
            fill="#E8EEE0"
          />
          <P d="M0 755Q401 585 816 764T1600 678V1000H0Z" fill="#D9E4D7" />
          <P d="M0 893Q429 734 949 881T1600 822V1000H0Z" fill="#EDF0DF" />
          {[135, 1255, 1437].map((i, j) => (
            <g key={i}>
              <path
                d={`M${i} ${840 + (j % 2) * 70}V${510 + (j % 2) * 70}m0 160l-66-70m66 24l62-76m-62 24l-38-52`}
                stroke="#647E76"
                strokeWidth={13}
                fill="none"
                strokeLinecap="round"
              />
              <path
                d={`M${i - 69} ${596 + (j % 2) * 70}l63 70m8-48l53-65`}
                stroke="#E7ECDE"
                strokeWidth={7}
                fill="none"
              />
            </g>
          ))}
        </>
      ) : null}
    </g>
  );
};
export const CityStreet: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="city" />
);
export const OldTown: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="old-town" />
);
export const IndustrialYard: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="industrial" />
);
export const BakeryInterior: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="bakery-interior" />
);
export const ShopInterior: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="shop-interior" />
);
export const HospitalCorridor: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="hospital-corridor" />
);
export const StationPlatform: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="station-platform" />
);
export const Harbor: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="harbor" />
);
export const RockyCoast: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="rocky-coast" />
);
export const Desert: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="desert" />
);
export const DryCanyon: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="dry-canyon" />
);
export const WinterValley: React.FC<LocationProps> = (p) => (
  <PaperLocation {...p} kind="winter" />
);
