import React, { useId } from "react";
import { PaperDisc, PaperRect, PaperShape, palette } from "../core/material";
import { circlePath, mix } from "../core/math";
export const PaperGround: React.FC<{
  x?: number;
  y?: number;
  width: number;
  height: number;
  fill?: string;
  rise?: number;
  seed?: number;
}> = ({
  x = 0,
  y = 0,
  width,
  height,
  fill = palette.green,
  rise = 50,
  seed = 1,
}) => (
  <g transform={`translate(${x} ${y})`}>
    <PaperShape
      d={`M0 0C${width * 0.17} ${-rise} ${width * 0.3} ${rise * 0.5} ${width * 0.5} ${-rise * 0.1}S${width * 0.84} ${-rise * (0.5 + 0.1 * seed)} ${width} 0V${height}H0Z`}
      fill={fill}
      rim={2.2}
      shadow={false}
    />
  </g>
);
export const PaperPath: React.FC<{
  x?: number;
  y?: number;
  width: number;
  height: number;
  fill?: string;
}> = ({ x = 0, y = 0, width, height, fill = "#D7C19B" }) => (
  <g transform={`translate(${x} ${y})`}>
    <PaperShape
      d={`M0 ${height * 0.38}Q${width * 0.3} ${-height * 0.15} ${width * 0.58} ${height * 0.18}T${width} ${height * 0.04}V${height * 0.67}Q${width * 0.76} ${height * 1.15} ${width * 0.5} ${height * 0.75}T0 ${height}Z`}
      fill={fill}
      rim={2}
      shadow={false}
    />
  </g>
);
export const PaperCloud: React.FC<{
  x?: number;
  y?: number;
  scale?: number;
  time?: number;
  fill?: string;
}> = ({ x = 0, y = 0, scale = 1, time = 0, fill = "#F1E8D3" }) => (
  <g
    transform={`translate(${x} ${y + Math.sin(time * 0.3) * 2}) scale(${scale})`}
  >
    <PaperShape
      d="M-96 27Q-126 21-110-8Q-98-27-76-21Q-69-68-27-58Q-5-103 34-68Q66-71 78-36Q124-37 128 4Q128 33 93 33Z"
      fill={fill}
      rim={2}
    />
  </g>
);
export const PaperTree: React.FC<{
  x?: number;
  y?: number;
  height?: number;
  kind?: "leafy" | "bare" | "pine";
  time?: number;
  leaf?: string;
  trunk?: string;
}> = ({
  x = 0,
  y = 0,
  height = 380,
  kind = "leafy",
  time = 0,
  leaf = "#71956D",
  trunk = "#8F6D4D",
}) => (
  <g transform={`translate(${x} ${y}) scale(${height / 380})`}>
    <PaperShape
      d="M-14 0L-10-172L-62-239L-52-251L-5-203L4-314L18-309L15-199L70-260L81-248L20-173L18 0Z"
      fill={trunk}
      rim={2}
    />
    {kind === "bare" ? (
      <path
        d="M0-53V-174L-44-232M9-176L62-241M9-212L13-292"
        fill="none"
        stroke="#D2B58C"
        strokeWidth="2"
      />
    ) : (
      <g transform={`rotate(${Math.sin(time * 0.65) * 0.85} 0 -180)`}>
        {kind === "pine" ? (
          <PaperShape
            d="M0-380L-52-273L-29-276L-85-175L-47-184L-111-78L109-82L48-181L83-176L32-274L55-272Z"
            fill={leaf}
            rim={2}
          />
        ) : (
          (
            [
              [-64, -257, 77],
              [-1, -318, 88],
              [71, -264, 85],
              [3, -225, 84],
            ] as const
          ).map(([cx, cy, r], i) => (
            <g key={i}>
              <PaperDisc x={cx} y={cy} radius={r} fill={leaf} seed={i + 2} />
              <path
                d={`M${cx - 20} ${cy + 31}q20-36 48-52`}
                stroke="#E7DDB4"
                strokeWidth="1.7"
                opacity=".3"
                fill="none"
              />
            </g>
          ))
        )}
      </g>
    )}
  </g>
);
export const PaperWater: React.FC<{
  x?: number;
  y?: number;
  width: number;
  height: number;
  time?: number;
  fill?: string;
}> = ({ x = 0, y = 0, width, height, time = 0, fill = "#6A9D9C" }) => {
  const id = "water" + useId().replace(/:/g, "");
  return (
    <g transform={`translate(${x} ${y})`}>
      <defs>
        <clipPath id={id}>
          <rect width={width} height={height} />
        </clipPath>
      </defs>
      <PaperRect width={width} height={height} fill={fill} shadow={false} />
      <g clipPath={`url(#${id})`}>
        {Array.from({ length: 7 }, (_, i) => (
          <path
            key={i}
            d={`M-50 ${25 + (i * height) / 7}Q${width * 0.2} ${10 + (i * height) / 7} ${width * 0.5} ${25 + (i * height) / 7}T${width + 70} ${25 + (i * height) / 7}`}
            stroke="#D7E2CD"
            strokeWidth="2.5"
            strokeDasharray="62 130 22 110"
            strokeDashoffset={-time * 18 - i * 47}
            fill="none"
            opacity=".6"
          />
        ))}
      </g>
    </g>
  );
};
export const PaperBuilding: React.FC<{
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  fill?: string;
  roof?: "flat" | "pitched";
  columns?: number;
  rows?: number;
  window?: string;
}> = ({
  x = 0,
  y = 0,
  width = 240,
  height = 390,
  fill = "#829085",
  roof = "flat",
  columns = 3,
  rows = 4,
  window = "#E6D9AC",
}) => {
  const left = -width / 2;
  return (
    <g transform={`translate(${x} ${y})`}>
      <PaperRect
        x={left}
        y={-height}
        width={width}
        height={height}
        fill={fill}
      />
      {roof === "pitched" ? (
        <PaperShape
          d={`M${left - 12} ${-height}L-8 ${-height - 76}L${width / 2 + 12} ${-height}Z`}
          fill="#3F5260"
          rim={2}
        />
      ) : (
        <PaperRect
          x={left - 8}
          y={-height - 12}
          width={width + 16}
          height={18}
          fill="#667D76"
        />
      )}
      {Array.from({ length: rows }, (_, row) =>
        Array.from({ length: columns }, (_, col) => (
          <g key={`${row}-${col}`}>
            <PaperRect
              x={
                left +
                (width * (col + 1)) / (columns + 1) -
                (width / (columns + 1)) * 0.23
              }
              y={-height + 34 + (row * (height - 105)) / rows}
              width={(width / (columns + 1)) * 0.46}
              height={Math.min(54, ((height - 100) / rows) * 0.62)}
              fill={window}
              rim={0.7}
              shadow={false}
            />
          </g>
        )),
      )}
      <PaperRect
        x={-width * 0.075}
        y={-62}
        width={width * 0.15}
        height={62}
        fill="#3B5558"
        rim={1}
      />
    </g>
  );
};
export const PaperRoom: React.FC<{
  width: number;
  height: number;
  floorY: number;
  wall?: string;
  floor?: string;
  window?: boolean | { x: number; y: number; width: number; height: number };
}> = ({
  width,
  height,
  floorY,
  wall = "#E4D7BA",
  floor = "#A38E70",
  window = true,
}) => {
  const pane =
    typeof window === "object"
      ? window
      : {
          x: width * 0.67,
          y: floorY * 0.24,
          width: width * 0.2,
          height: floorY * 0.47,
        };
  return (
    <g>
      <PaperRect width={width} height={height} fill={wall} shadow={false} />
      {window ? (
        <g transform={`translate(${pane.x} ${pane.y})`}>
          <PaperRect width={pane.width} height={pane.height} fill="#98B6B5" />
          <path
            d={`M${pane.width / 2} 0V${pane.height}M0 ${pane.height / 2}H${pane.width}`}
            stroke={palette.cream}
            strokeWidth="7"
          />
        </g>
      ) : null}
      <PaperRect
        y={floorY}
        width={width}
        height={height - floorY}
        fill={floor}
        shadow={false}
      />
      <path d={`M0 ${floorY}H${width}`} stroke={palette.rim} strokeWidth="4" />
      {[0.15, 0.43, 0.71].map((p) => (
        <path
          key={p}
          d={`M0 ${mix(floorY, height, p)}H${width}`}
          stroke="#786B56"
          strokeWidth="2"
          opacity=".28"
        />
      ))}
    </g>
  );
};
export const PaperSun: React.FC<{
  x?: number;
  y?: number;
  radius?: number;
  fill?: string;
}> = ({ x = 0, y = 0, radius = 100, fill = palette.yellow }) => (
  <g>
    <PaperDisc x={x} y={y} radius={radius * 1.05} fill="#CE994C" />
    <PaperDisc x={x} y={y} radius={radius} fill={fill} />
    <PaperShape
      d={circlePath(x - radius * 0.13, y - radius * 0.1, radius * 0.76)}
      fill="#F9D88F"
      rim={0}
      shadow={false}
      opacity={0.3}
    />
  </g>
);
