import React, { useId } from "react";
import { PaperRect as R } from "../core/material";
export type SurfaceKind =
  | "asphalt"
  | "cobbles"
  | "dirt"
  | "gravel"
  | "rail"
  | "sidewalk"
  | "tile"
  | "wood"
  | "sand"
  | "snow";
export type SurfaceProps = {
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  kind?: SurfaceKind;
  markings?: boolean;
  fill?: string;
};
const colors: Record<SurfaceKind, string> = {
  asphalt: "#626D6B",
  cobbles: "#9E9D8A",
  dirt: "#B48C63",
  gravel: "#A8A99A",
  rail: "#8C8C78",
  sidewalk: "#C5C0A8",
  tile: "#D0CBB8",
  wood: "#B08E67",
  sand: "#D2B47C",
  snow: "#DEE6DA",
};
/** Top-left surface patch. Extend beyond the camera crop; share the same floor y with actors. */
export const PaperSurface: React.FC<SurfaceProps> = ({
  x = 0,
  y = 0,
  width = 1200,
  height = 250,
  kind = "asphalt",
  markings = true,
  fill,
}) => {
  const id = "surface" + useId().replace(/[^a-z0-9]/gi, "");
  if (
    ![x, y, width, height].every(Number.isFinite) ||
    width <= 0 ||
    height <= 0
  )
    throw new Error("Surface geometry must be finite and positive.");
  return (
    <g data-paper-surface={kind} transform={`translate(${x} ${y})`}>
      <defs>
        <pattern
          id={id}
          width={kind === "wood" ? 160 : 80}
          height={kind === "wood" ? 45 : 60}
          patternUnits="userSpaceOnUse"
        >
          {kind === "cobbles" ? (
            <>
              {[0, 1].map((row) =>
                [0, 1].map((col) => (
                  <path
                    key={row + "-" + col}
                    d={`M${col * 40 + (row % 2) * 15} ${row * 30 + 2}h35l2 23h-36Z`}
                    fill={row === col ? "#B4B09B" : "#949987"}
                    stroke="#D1CBB2"
                    strokeWidth={2}
                  />
                )),
              )}
            </>
          ) : kind === "tile" || kind === "sidewalk" ? (
            <path
              d="M0 0H80V60H0ZM40 0V60"
              fill="none"
              stroke="#999F8F"
              strokeWidth={2}
            />
          ) : kind === "wood" ? (
            <>
              <path
                d="M0 1H160M0 44H160M80 0V45"
                stroke="#7E7862"
                strokeWidth={2}
              />
              <path
                d="M9 15q22-5 53 0m35 13q29-6 57 0"
                fill="none"
                stroke="#D3B48A"
                strokeWidth={2}
              />
            </>
          ) : kind === "gravel" ? (
            <>
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <path
                  key={i}
                  d={`M${(i * 29) % 77} ${(i * 17) % 53}l8-3 7 5-5 6-9-2Z`}
                  fill={i % 2 ? "#838E80" : "#C3C3AB"}
                />
              ))}
            </>
          ) : kind === "sand" || kind === "dirt" || kind === "snow" ? (
            <path
              d="M8 19q16-5 32 0m7 25q13-4 27 0"
              fill="none"
              stroke={kind === "snow" ? "#B9CEC7" : "#A98D62"}
              opacity={0.35}
              strokeWidth={2}
            />
          ) : (
            <>
              {[0, 1, 2, 3, 4].map((i) => (
                <circle
                  key={i}
                  cx={(i * 23) % 80}
                  cy={(i * 19) % 60}
                  r={1.5}
                  fill="#D1CDB4"
                  opacity={0.2}
                />
              ))}
            </>
          )}
        </pattern>
      </defs>
      <R
        width={width}
        height={height}
        fill={fill ?? colors[kind]}
        shadow={false}
        rim={0}
      />
      <rect width={width} height={height} fill={`url(#${id})`} />
      {kind === "rail" ? (
        <>
          {Array.from({ length: Math.ceil(width / 65) }, (_, i) => (
            <R
              key={i}
              x={i * 65}
              y={height * 0.2}
              width={20}
              height={height * 0.64}
              fill="#736D58"
              shadow={false}
            />
          ))}
          {[0.32, 0.71].map((q) => (
            <g key={q}>
              <R
                y={height * q}
                width={width}
                height={11}
                fill="#455F61"
                shadow={false}
              />
              <path
                d={`M0 ${height * q}H${width}`}
                stroke="#C9CEC0"
                strokeWidth={3}
              />
            </g>
          ))}
        </>
      ) : kind === "asphalt" && markings ? (
        <>
          <path
            d={`M0 ${height * 0.12}H${width}M0 ${height * 0.88}H${width}`}
            stroke="#D8D1AD"
            strokeWidth={3}
          />
          <path
            d={`M0 ${height * 0.5}H${width}`}
            stroke="#E2D5A5"
            strokeWidth={5}
            strokeDasharray="54 40"
          />
        </>
      ) : null}
    </g>
  );
};
export const AsphaltRoad: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="asphalt" />
);
export const CobbleStreet: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="cobbles" />
);
export const DirtTrack: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="dirt" />
);
export const GravelGround: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="gravel" />
);
export const RailwayTrack: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="rail" />
);
export const Sidewalk: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="sidewalk" />
);
export const TileFloor: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="tile" />
);
export const WoodFloor: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="wood" />
);
export const SandGround: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="sand" />
);
export const SnowGround: React.FC<SurfaceProps> = (p) => (
  <PaperSurface {...p} kind="snow" />
);
