import React from "react";
import {Composition} from "remotion";
import {PaperVideo, Plan} from "./theme";
import plan from "../video/plan.json";

// Duration, size and fps come from video/plan.json (timing is written by after_vo.py).
const p = plan as unknown as Plan;
export const StudioRoot: React.FC = () => (
  <Composition id="Main" component={PaperVideo} durationInFrames={Math.max(30, p.total_frames || 30)} fps={p.fps || 30} width={p.width || 1080} height={p.height || 1920} defaultProps={{plan: p}} />
);
