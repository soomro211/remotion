import os, math, random
from playwright.sync_api import sync_playwright
HERE = os.path.dirname(os.path.abspath(__file__))
def _fontdir():
    p = HERE
    for _ in range(6):
        c = os.path.join(p, '_shared', 'fonts')
        if os.path.isdir(c): return c
        p = os.path.dirname(p)
    return os.path.join(HERE, 'fonts')
FONTDIR = _fontdir()
OUT = os.environ.get('OUT_DIR') or os.path.join(HERE, 'out')
FONTS = """
@font-face{font-family:'Bricolage';src:url('fonts/Bricolage.ttf');font-weight:200 800}
@font-face{font-family:'Caveat';src:url('fonts/Caveat.ttf');font-weight:400 700}
@font-face{font-family:'DM Sans';src:url('fonts/DMSans.ttf');font-weight:100 1000}
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1080px;height:1920px;overflow:hidden}
.f{position:relative;width:1080px;height:1920px;overflow:hidden}
.abs{position:absolute}
"""
FONTS = FONTS.replace("url('fonts/", "url('file://" + FONTDIR + "/")
GRAIN = """<svg class='abs' style='inset:0;width:100%;height:100%;pointer-events:none;mix-blend-mode:@B;opacity:@O' width='1080' height='1920'><filter id='gn'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0'/></filter><rect width='1080' height='1920' filter='url(#gn)'/></svg>"""
def grain(blend='multiply', op=.18): return GRAIN.replace('@B',blend).replace('@O',str(op))
def page(css, body):
    return f"<!doctype html><html><head><meta charset='utf-8'><style>{FONTS}{css}</style></head><body><div class='f'>{body}</div></body></html>"
def render_all(themes, only=None):
    os.makedirs(OUT, exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width':1080,'height':1920})
        for tid, (name, frames) in themes.items():
            if only and tid not in only: continue
            for i, html in enumerate(frames, 1):
                path = os.path.join(HERE, f'_{tid}_{i}.html')
                open(path,'w').write(html)
                pg.goto('file://'+path); pg.wait_for_timeout(400)
                pg.evaluate('document.fonts.ready')
                pg.screenshot(path=os.path.join(OUT, f'{name}-{i}.png'))
                os.remove(path)
        b.close()
