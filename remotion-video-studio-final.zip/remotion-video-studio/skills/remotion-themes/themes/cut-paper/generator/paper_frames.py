#!/usr/bin/env python3
"""CUT PAPER theme: full-bleed layered paper-diorama style frames (1080x1920).
Renders 4 frames with Chromium (playwright). Edit the TEXT dict to change copy.  python3 paper_frames.py"""
import math, random
from common import *

# ---------- palette tokens ----------
P = dict(cream='#F6EBD0', rim='#FBF3DE', ink='#1E2A44', coral='#FF6B4A', sun='#F4B03E', sun2='#FFD15C', sky='#6DB8E3', sky2='#8FCDEE', sky3='#B4E0F5',
         green1='#8DB9A0', green2='#5E9B62', green3='#3C7A55', green4='#2A5D48', green5='#1D4636', navy='#1E2A44', navy2='#2B3A5E',
         mauve='#5B3B7A', plum='#3A2455', pink='#E8647A', orange='#F28C4A', teal='#2F8F9D', white='#FFF8E8')
TEXT = dict(
  f1=['Why is', 'the sky', 'blue?'], f1_tag='A 30-second answer',
  f2_title=['Sunlight looks white.', "It isn't."], f2_blue='Short waves bounce everywhere.', f2_orange='Long waves sail straight through.',
  f3_title='Three things to know', f3=[('1', 'Blue light scatters the most.'), ('2', 'Red light scatters the least.'), ('3', 'At sunset the light travels farther. Red wins.')],
  f4=['Same trick.', 'Red sunsets.'], f4_tag='Follow for one answer a day.')

# ---------- geometry ----------
def smooth(pts, closed=False):
    n = len(pts); d = f"M{pts[0][0]:.1f},{pts[0][1]:.1f}"
    for i in range(n if closed else n - 1):
        p0 = pts[(i - 1) % n] if (closed or i > 0) else pts[0]; p1 = pts[i]; p2 = pts[(i + 1) % n]
        p3 = pts[(i + 2) % n] if (closed or i + 2 < n) else pts[-1]
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6); c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d += f"C{c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f}"
    return d + ('Z' if closed else '')
def hill(base, amp, seed, bottom=1960, step=110, ph=0.0):
    r = random.Random(seed); pts = []
    for x in range(-150, 1250, step):
        y = base + amp * (math.sin(x / 260 + ph + seed) * .6 + math.sin(x / 110 + seed * 2) * .25) + r.uniform(-amp * .12, amp * .12); pts.append((x, y))
    return smooth(pts) + f"L1250,{bottom}L-150,{bottom}Z"
def band(y0, amp, seed, bottom=1960, torn=False):
    """Top edge: scissor-cut (smooth wobble) or torn (jagged)."""
    r = random.Random(seed); pts = []
    if torn:
        x = -20
        while x < 1100: pts.append((x, y0 + r.uniform(-amp, amp))); x += r.uniform(10, 26)
        return 'M' + 'L'.join(f'{a:.0f},{b:.0f}' for a, b in pts) + f"L1100,{bottom}L-20,{bottom}Z"
    for x in range(-100, 1200, 140): pts.append((x, y0 + r.uniform(-amp, amp)))
    return smooth(pts) + f"L1200,{bottom}L-100,{bottom}Z"
def circle_path(cx, cy, r): return f"M{cx-r},{cy}a{r},{r} 0 1,0 {2*r},0a{r},{r} 0 1,0 {-2*r},0Z"
def sun_petals(cx, cy, r1, r2, n=18, rot=0):
    pts = []
    for i in range(n * 2):
        a = math.pi * i / n + rot; rr = r2 if i % 2 == 0 else r1; pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return 'M' + 'L'.join(f'{a:.1f},{b:.1f}' for a, b in pts) + 'Z'

DEFS = f"""<defs>
<filter id='b14' x='-20%' y='-20%' width='140%' height='140%'><feGaussianBlur stdDeviation='14'/></filter>
<filter id='b3' x='-5%' y='-5%' width='110%' height='110%'><feGaussianBlur stdDeviation='3'/></filter>
<filter id='fiber' x='0' y='0' width='100%' height='100%'>
 <feTurbulence type='fractalNoise' baseFrequency='.8 .5' numOctaves='3' seed='7' result='n'/>
 <feDiffuseLighting in='n' lighting-color='#ffffff' surfaceScale='1.6'><feDistantLight azimuth='235' elevation='62'/></feDiffuseLighting>
</filter>
<filter id='fiber2' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='.012 .02' numOctaves='2' seed='3'/><feColorMatrix values='0 0 0 0 .2  0 0 0 0 .1  0 0 0 0 0  0 0 0 .55 0'/></filter>
</defs>"""
def piece(d, fill, rim=5, rimcol=None, shadow=.34, off=10, extra=''):
    rimcol = rimcol or P['rim']
    return (f"<g><path d='{d}' fill='#1a0f05' opacity='{shadow}' transform='translate(0,{off+6})' filter='url(#b14)'/>"
            f"<path d='{d}' fill='#1a0f05' opacity='{shadow*.9:.2f}' transform='translate(0,{off/3:.0f})' filter='url(#b3)'/>"
            f"<path d='{d}' fill='none' stroke='{rimcol}' stroke-width='{rim*2}' stroke-linejoin='round'/><path d='{d}' fill='{fill}' {extra}/></g>")
def cloud(x, y, s=1, col=None):
    col = col or P['white']; cs = [(0, 0, 46), (52, -22, 60), (116, -4, 50), (170, 8, 40), (60, 16, 52), (118, 18, 44)]
    d = ''.join(circle_path(x + dx * s, y + dy * s, r * s) for dx, dy, r in cs)
    return piece(d, col, 4, off=8, extra="fill-rule='nonzero'")
def tree(x, y, h, c1, c2):
    w = h * .42; d = ''
    for i, k in enumerate((1, .78, .56)):
        yy = y - h * (.28 + i * .24); d += f"M{x-w*k/2:.0f},{yy+h*.3:.0f}L{x:.0f},{yy-h*.12:.0f}L{x+w*k/2:.0f},{yy+h*.3:.0f}Z"
    trunk = f"M{x-h*.04:.0f},{y}h{h*.08:.0f}v{-h*.2:.0f}h{-h*.08:.0f}Z"
    return piece(trunk, '#6B4A32', 2, off=4, shadow=.2) + piece(d, c1, 3, off=6, shadow=.25)
def bird(x, y, s=1, col=None):
    col = col or P['ink']; d = f"M{x},{y}Q{x+22*s},{y-26*s} {x+46*s},{y-4*s}Q{x+70*s},{y-30*s} {x+96*s},{y}Q{x+70*s},{y-14*s} {x+48*s},{y+10*s}Q{x+26*s},{y-14*s} {x},{y}Z"
    return piece(d, col, 2, off=4, shadow=.2)
def star(x, y, r, col):
    return piece(sun_petals(x, y, r * .42, r, 5, -math.pi / 2), col, 2, off=3, shadow=.2)
def tape(x, y, w, h, rot, col='#F4B03E'):
    return (f"<div style='position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;transform:rotate({rot}deg);background:repeating-linear-gradient(45deg,{col} 0 14px,rgba(255,255,255,.55) 14px 22px);opacity:.88;"
            f"clip-path:polygon(0 0,4% 12%,0 25%,4% 38%,0 50%,4% 62%,0 75%,4% 88%,0 100%,100% 100%,96% 88%,100% 75%,96% 62%,100% 50%,96% 38%,100% 25%,96% 12%,100% 0);filter:drop-shadow(0 2px 2px rgba(0,0,0,.25))'></div>")
def slip(txt, x, y, fs, bg, fg, rot, pad='16px 36px 22px', extra=''):
    return (f"<div style='position:absolute;left:{x}px;top:{y}px;transform:rotate({rot}deg);filter:drop-shadow(0 5px 0 rgba(30,15,5,.35)) drop-shadow(0 16px 14px rgba(30,15,5,.3))'>"
            f"<div style='font-family:Bricolage;font-weight:800;font-size:{fs}px;line-height:1;letter-spacing:-2px;text-transform:uppercase;padding:{pad};background:{bg};color:{fg};border:6px solid {P['rim']};white-space:nowrap;"
            f"clip-path:polygon(0 4%,2% 0,38% 2%,100% 0,98% 50%,100% 100%,60% 97%,0 100%,2% 50%);{extra}'>{txt}</div></div>")
def tag(txt, x, y, w, rot=0, fs=40, col=None, sub=None):
    col = col or P['ink']
    return (f"<div style='position:absolute;left:{x}px;top:{y}px;width:{w}px;transform:rotate({rot}deg);filter:drop-shadow(0 5px 0 rgba(30,15,5,.3)) drop-shadow(0 14px 12px rgba(30,15,5,.28))'>"
            f"<div style='background:{P['white']};border:6px solid {P['rim']};padding:26px 30px 26px 54px;font-family:Bricolage;font-weight:700;font-size:{fs}px;line-height:1.12;color:{col};"
            f"clip-path:polygon(0 0,100% 0,100% 100%,0 100%,32px 50%)'>{txt}</div></div>")

CSS = f"""
.f{{background:{P['sky']};font-family:'Bricolage'}}
.over{{position:absolute;inset:0;pointer-events:none}}
"""
def wrap(svg_inner, html=''):
    s = f"<svg class='abs' style='left:0;top:0' width='1080' height='1920' viewBox='0 0 1080 1920'>{DEFS}{svg_inner}</svg>"
    tex = ("<svg class='over' width='1080' height='1920' style='mix-blend-mode:multiply;opacity:.55'><rect width='1080' height='1920' filter='url(#fiber)'/></svg>"
           "<svg class='over' width='1080' height='1920' style='mix-blend-mode:multiply;opacity:.35'><rect width='1080' height='1920' filter='url(#fiber2)'/></svg>"
           "<div class='over' style='background:radial-gradient(ellipse at 50% 40%,transparent 55%,rgba(40,20,5,.28) 100%)'></div>")
    # defs are needed by the texture svgs too
    defs_only = f"<svg width='0' height='0' style='position:absolute'>{DEFS}</svg>"
    return defs_only + s + html + tex

def frame1():
    s = f"<rect width='1080' height='1920' fill='{P['sky']}'/>"
    for r, c in ((640, P['sky2']), (500, P['sky3']), (360, '#D3EEFA')): s += piece(circle_path(800, 880, r), c, 4, off=6, shadow=.18)
    s += piece(sun_petals(800, 880, 200, 262, 20, .1), P['sun'], 4) + piece(circle_path(800, 880, 190), P['sun2'], 3, off=4) + piece(circle_path(800, 880, 128), '#FFE79A', 3, off=3, shadow=.15)
    s += cloud(120, 1010, 1.15) + cloud(640, 560, .85) + cloud(430, 1180, .7, '#FFFFFF')
    s += piece(hill(1180, 70, 1), P['green1']) + piece(hill(1290, 90, 2, ph=1), P['green2'])
    for x, h in ((150, 150), (260, 210), (880, 190), (980, 140)): s += tree(x, 1360, h, P['green3'], P['green4'])
    s += piece(hill(1410, 80, 3, ph=2), P['green3'])
    for x, h in ((70, 260), (190, 190), (930, 280), (1030, 200)): s += tree(x, 1540, h, P['green4'], P['green5'])
    s += piece(hill(1560, 70, 4, ph=3), P['green4']) + piece(hill(1700, 60, 5, ph=4), P['green5'])
    s += bird(760, 380, 1.1) + bird(870, 330, .8) + bird(690, 300, .7)
    t = TEXT['f1']
    h = slip(t[0], 90, 340, 150, P['white'], P['ink'], -2.5) + slip(t[1], 130, 530, 150, P['coral'], P['white'], 1.8) + slip(t[2], 100, 720, 190, P['ink'], '#FFD86B', -1.2)
    h += tape(80, 330, 120, 40, -35) + tape(560, 515, 120, 40, 28, '#E8647A') + tape(60, 722, 120, 40, 30, '#35C4A8')
    h += tag(TEXT['f1_tag'], 120, 1090, 560, -2)
    return page(CSS, wrap(s, h))

def frame2():
    sx, sy, ex, ey, gx, gy = 220, 470, 470, 800, 800, 1290
    ang = math.degrees(math.atan2(gy - sy, gx - sx)); L = math.hypot(gx - sx, gy - sy); L1 = math.hypot(ex - sx, ey - sy)
    s = f"<rect width='1080' height='1920' fill='{P['navy']}'/>"
    r = random.Random(4)
    for _ in range(26): s += star(r.uniform(60, 1020), r.uniform(280, 640), r.uniform(10, 22), P['sun2'] if r.random() > .4 else P['white'])
    s += piece(band(700, 26, 11), P['sky2'], 5) + piece(band(840, 20, 12), P['sky'], 5)
    s += piece(sun_petals(sx, sy, 92, 128, 16, .2), P['sun'], 4) + piece(circle_path(sx, sy, 90), P['sun2'], 3, off=4)
    # rays
    s += f"<rect x='{sx}' y='{sy-20}' width='{L1}' height='40' rx='20' fill='{P['white']}' transform='rotate({ang:.1f} {sx} {sy})'/>"
    rr = random.Random(9)
    for _ in range(80):
        th = rr.uniform(0, 360); rad = rr.uniform(70, 470); x = ex + rad * math.cos(math.radians(th)); y = ey + rad * math.sin(math.radians(th)) * .8
        if 730 < y < 1230 and -20 < x < 1100: s += f"<rect x='{x:.0f}' y='{y:.0f}' width='{rr.choice((54,66,42))}' height='15' rx='7.5' fill='{rr.choice(('#2F6FE0','#1C4FB8','#4F8DF0'))}' transform='rotate({th:.0f} {x:.0f} {y:.0f})'/>"
    s += piece(hill(1180, 60, 21), P['green2']) + piece(hill(1330, 70, 22, ph=1), P['green3']) + piece(hill(1480, 60, 23, ph=2), P['green4']) + piece(hill(1640, 50, 24, ph=3), P['green5'])
    s += f"<rect x='{ex}' y='{ey-20}' width='{L-L1}' height='40' rx='20' fill='{P['orange']}' transform='rotate({ang:.1f} {sx} {sy}) translate({L1-0},{0}) translate(0,0)' opacity='0'/>"
    s += f"<g transform='rotate({ang:.1f} {sx} {sy})'><rect x='{L1-6}' y='{sy-20}' width='{L-L1+6}' height='40' rx='20' fill='{P['orange']}'/></g>"
    for x, h in ((90, 190), (200, 140), (940, 220), (1030, 150)): s += tree(x, 1330, h, P['green3'], P['green4'])
    s += tree(gx + 40, 1320, 210, P['green4'], P['green5'])
    t = TEXT['f2_title']
    h = slip(t[0], 345, 340, 56, P['white'], P['ink'], 1.5, '12px 24px 16px') + slip(t[1], 400, 430, 96, P['coral'], P['white'], -1.5, '12px 30px 16px')
    h += tape(335, 335, 90, 32, -30) + tag(f"<span style='color:#1C4FB8;font-weight:800'>BLUE</span><br>{TEXT['f2_blue']}", 70, 1210, 470, -2, 38) + tag(f"<span style='color:#E5622A;font-weight:800'>ORANGE</span><br>{TEXT['f2_orange']}", 560, 1270, 450, 2, 38)
    return page(CSS, wrap(s, h))

def frame3():
    s = f"<rect width='1080' height='1920' fill='{P['cream']}'/>"
    s += piece(band(300, 22, 31, torn=True, bottom=1960), P['coral'], 7) + piece(band(520, 16, 32), P['cream'], 5)
    s += piece(circle_path(930, 260, 250), P['sun'], 5) + piece(circle_path(930, 260, 170), P['sun2'], 4, off=5)
    s += piece(band(1250, 18, 33, torn=True), P['teal'], 8) + piece(band(1530, 20, 34), P['navy'], 5)
    r = random.Random(5)
    for _ in range(34):
        x, y, rr = r.uniform(20, 1060), r.uniform(540, 1240), r.uniform(8, 20); s += piece(circle_path(x, y, rr), r.choice((P['coral'], P['teal'], P['sun'], P['pink'], P['navy'])), 2, off=3, shadow=.22)
    s += star(110, 1640, 30, P['sun2']) + star(960, 1600, 24, P['coral'])
    h = slip(TEXT['f3_title'], 70, 330, 78, P['ink'], '#FFD86B', -1.5, '12px 30px 16px')
    cols = (P['white'], P['sky3'], P['white'])
    for i, (n, txt) in enumerate(TEXT['f3']):
        y = 500 + i * 300; rot = (-2.2, 1.6, -1.2)[i]
        h += (f"<div style='position:absolute;left:70px;top:{y}px;width:880px;transform:rotate({rot}deg);filter:drop-shadow(0 5px 0 rgba(30,15,5,.3)) drop-shadow(0 16px 14px rgba(30,15,5,.28))'>"
              f"<div style='display:flex;align-items:center;gap:26px;background:{cols[i]};border:6px solid {P['rim']};padding:24px 34px;font-family:Bricolage;font-weight:700;font-size:46px;line-height:1.1;color:{P['ink']};clip-path:polygon(0 3%,3% 0,100% 1%,99% 52%,100% 100%,2% 98%,0 50%)'>"
              f"<div style='flex:none;width:96px;height:96px;border-radius:50%;background:{(P['coral'],P['teal'],P['sun'])[i]};color:{P['white']};font-weight:800;font-size:64px;display:flex;align-items:center;justify-content:center'>{n}</div><div>{txt}</div></div></div>")
        h += tape(120 + i * 60, y - 18, 110, 36, (-8, 6, -4)[i], (P['sun'], P['pink'], '#35C4A8')[i])
    return page(CSS, wrap(s, h))

def frame4():
    s = f"<rect width='1080' height='1920' fill='{P['plum']}'/>"
    s += piece(band(420, 20, 41), P['mauve'], 5) + piece(band(700, 22, 42), P['pink'], 5) + piece(band(960, 22, 43), P['orange'], 5)
    s += piece(sun_petals(540, 1240, 250, 320, 22, .05), P['sun'], 5) + piece(circle_path(540, 1240, 240), P['sun2'], 4, off=6) + piece(circle_path(540, 1240, 160), '#FFE79A', 3, off=4, shadow=.15)
    s += cloud(80, 800, .9, '#F8C6C0') + cloud(700, 640, 1.0, '#F8C6C0')
    s += piece(hill(1330, 60, 51), P['mauve']) + piece(hill(1450, 70, 52, ph=1), P['plum']) + piece(hill(1600, 60, 53, ph=2), '#2A1840') + piece(hill(1750, 50, 54, ph=3), '#1B0F2C')
    for x, h in ((100, 230), (220, 170), (900, 260), (1010, 190)): s += tree(x, 1520, h, '#2A1840', '#1B0F2C')
    s += bird(120, 560, 1) + bird(250, 500, .7) + bird(880, 470, .9)
    t = TEXT['f4']
    h = slip(t[0], 100, 340, 138, P['white'], P['ink'], -2) + slip(t[1], 70, 520, 138, P['coral'], P['white'], 1.6) + tape(90, 335, 110, 36, -34) + tape(520, 505, 110, 36, 28, '#35C4A8')
    h += tag(TEXT['f4_tag'], 120, 780, 760, -1.5, 42)
    return page(CSS, wrap(s, h))

if __name__ == '__main__':
    render_all({'cut-paper': ('frame', [frame1(), frame2(), frame3(), frame4()])})
    print('done')
