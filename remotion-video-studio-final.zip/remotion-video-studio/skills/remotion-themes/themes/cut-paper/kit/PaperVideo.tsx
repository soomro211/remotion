// Timing/font scaffold, not a finished explainer. Author topic-specific scenes and smooth captions.
// Internal scene names never render as headings. Optional display copy has a finite time window.
import React from "react";
import {AbsoluteFill, Easing, Sequence, useCurrentFrame, useVideoConfig} from "remotion";
import {Audio} from "@remotion/media";
import {staticFile} from "remotion";
import {Card, PaperBackground, Slip, Variant, paper, slipHeight, useThemeFonts, Entrance} from "./paper";
import {SfxTrack} from "../SfxTrack";

export type PlanScene = {id: string; name?: string; type: string; narration?: string; onscreen: string[]; text_role?: string; text_window?: {start_s: number; end_s: number}; entrance?: Entrance | string; start_frame: number; duration_frames: number; paper?: {variant?: Variant}};
export type Plan = {fps: number; width: number; height: number; total_frames: number; cta?: string; vo?: {file?: string}; scenes: PlanScene[]; music?: {file?: string; volume?: number} | null};

const SLIP_COLORS = [[paper.cream, paper.ink], [paper.orange, paper.cream], [paper.ink, paper.yellow], [paper.teal, paper.ink], [paper.pink, paper.cream]] as const;
const TAPES = [paper.yellow, paper.pink, paper.teal];
const variantFor = (s: PlanScene, i: number): Variant => s.paper?.variant ?? (s.type === "cta" || s.type === "payoff" ? "sunset" : i === 0 ? "day" : i % 3 === 1 ? "dusk" : i % 3 === 2 ? "mint" : "day");
const ent = (s: PlanScene): Entrance => (["slide", "pop", "stamp", "drop", "none"].includes(String(s.entrance)) ? (s.entrance as Entrance) : "slide");

// A finite display-copy window. Use explicit longer windows only for useful labels/data.
// Object-relative labels should be authored in custom scenes rather than as oversized title slips.
const TextWindow: React.FC<{s: PlanScene; children: React.ReactNode}> = ({s, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const start = Math.max(0, Math.round((s.text_window?.start_s ?? 0) * fps));
  const end = Math.min(s.duration_frames, Math.round((s.text_window?.end_s ?? 2.5) * fps));
  if (end <= start || frame < start || frame >= end) return null;
  const fadeFrames = Math.max(1, Math.min(Math.round(0.18 * fps), Math.floor((end - start) / 3)));
  const opacity = Easing.inOut(Easing.cubic)(Math.min(1, (end - frame) / fadeFrames));
  return <Sequence from={start} durationInFrames={end - start}><AbsoluteFill data-display-copy style={{opacity}}>{children}</AbsoluteFill></Sequence>;
};

const Lines: React.FC<{s: PlanScene; top: number; bottom: number}> = ({s, top, bottom}) => {
  const lines = s.onscreen;
  if (!lines.length) return null;
  const gap = 34; const hs = lines.map((l) => slipHeight(l)); const total = hs.reduce((a, b) => a + b, 0) + gap * (lines.length - 1);
  const start = top + Math.max(0, (bottom - top - total) / 2); let y = start;
  return <>{lines.map((l, i) => { const [c, ink] = SLIP_COLORS[(i + (s.type === "cta" ? 1 : 0)) % SLIP_COLORS.length]; const el = <Slip key={i} text={l} y={y} color={c} ink={ink} delay={4 + i * 7} kind={ent(s)} rotate={(i % 2 ? 1 : -1) * 1.5} seed={i + 2} tape={i === 0 ? TAPES[0] : i === 2 ? TAPES[1] : undefined} />; y += hs[i] + gap; return el; })}</>;
};

const SceneView: React.FC<{s: PlanScene; i: number; cta?: string}> = ({s, i, cta}) => {
  const v = variantFor(s, i); const {top, bottom} = paper.safe; const H = 1920;
  if (s.type === "list") {
    return (
      <AbsoluteFill><PaperBackground variant={v} sun={false} birds={false} trees={false} hillsFrom={1500} />
        {s.onscreen.length ? <TextWindow s={s}>{s.onscreen.slice(0, 4).map((t, k) => <Card key={k} n={k + 1} text={t} y={top + 70 + k * 290} delay={6 + k * 12} color={k % 2 ? "#FBF4E4" : paper.cream} />)}</TextWindow> : null}</AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill>
      <PaperBackground variant={v} sun={s.type !== "list"} birds={i % 2 === 0} hillsFrom={s.type === "cta" ? 1250 : 1180} seed={7 + i * 3} />
      {s.onscreen.length || (s.type === "cta" && cta) ? <TextWindow s={s}>
        <Lines s={s} top={top + 30} bottom={H - bottom - (s.type === "cta" ? 160 : 0)} />
        {s.type === "cta" && cta ? <Slip text={cta} y={H - bottom - 120} color={paper.yellow} ink={paper.ink} delay={8} kind="slide" rotate={-2} max={76} seed={5} tape={paper.pink} /> : null}
      </TextWindow> : null}
    </AbsoluteFill>
  );
};

export const PaperVideo: React.FC<{plan: Plan}> = ({plan}) => {
  useThemeFonts();
  return (
    <AbsoluteFill style={{background: paper.ink}}>
      {plan.scenes.map((s, i) => (
        <Sequence key={s.id} from={s.start_frame} durationInFrames={s.duration_frames} name={s.name ?? s.id}>
          <SceneView s={s} i={i} cta={plan.cta} />
        </Sequence>
      ))}
      {plan.vo?.file ? <Audio src={staticFile(String(plan.vo.file).replace(/^public\//, ""))} /> : null}
      {plan.music?.file ? <Audio src={staticFile(String(plan.music.file).replace(/^public\//, ""))} volume={plan.music.volume ?? 0.08} loop /> : null}
      <SfxTrack />
    </AbsoluteFill>
  );
};
