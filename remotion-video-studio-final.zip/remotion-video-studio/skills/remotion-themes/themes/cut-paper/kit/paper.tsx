// CUT PAPER theme kit: full-bleed layered-paper scenes for Remotion. No dependencies beyond react + remotion.
import React, {useEffect, useState} from "react";
import {AbsoluteFill, cancelRender, continueRender, delayRender, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";

export const paper = {
  cream: "#F4EBD8", ink: "#1B2845", orange: "#F26A41", yellow: "#F2B83B", teal: "#2FB5A0", pink: "#E8658A", blue: "#3E8EC9",
  skies: {day: ["#4FA8DC", "#A9D8EE"], sunset: ["#3B3A7A", "#F28A5B"], dusk: ["#1B2A55", "#4F6FB5"], mint: ["#2FA58F", "#BDE8D6"]},
  hills: {day: ["#7FB085", "#5D9A63", "#3E7C52", "#245A3B"], sunset: ["#7A4E8C", "#5B3A7A", "#3F2A66", "#2A1E4F"], dusk: ["#2A4A7A", "#223C68", "#1A2F55", "#12233F"], mint: ["#4FB08F", "#3C9A7C", "#2C7F66", "#1F6552"]},
  // Conservative title/label margins. Captions use their separate lower plate
  // (x=80, y=1500, w=890, h=148 at 1080x1920); check actual destination controls.
  safe: {top: 270, bottom: 420, left: 60, right: 110},
};
export type Variant = keyof typeof paper.skies;

export const FONT_FILES = [
  {family: "Bricolage", file: "fonts/Bricolage.ttf", weight: "200 800"},
  {family: "Caveat", file: "fonts/Caveat.ttf", weight: "400 700"},
  {family: "DM Sans", file: "fonts/DMSans.ttf", weight: "100 1000"},
];
// Call once at the top of a composition: blocks rendering until the fonts are ready.
export const useThemeFonts = () => {
  const [handle] = useState(() => delayRender("theme fonts"));
  useEffect(() => {
    Promise.all(FONT_FILES.map((f) => new FontFace(f.family, `url(${staticFile(f.file)})`, {weight: f.weight}).load().then((ff) => document.fonts.add(ff))))
      .then(() => continueRender(handle)).catch((error: unknown) => cancelRender(error instanceof Error ? error : new Error(String(error))));
  }, [handle]);
};

const rnd = (seed: number) => { let s = seed * 9301 + 49297; return () => ((s = (s * 9301 + 49297) % 233280) / 233280); };

// Smooth by default. Pass step=3 only for an explicitly chosen stop-motion treatment.
// Keep this name for compatibility with existing scenes; no-argument callers now update every frame.
export const useStepFrame = (step = 1) => {
  const frame = useCurrentFrame();
  const interval = Math.max(1, Math.round(step));
  return Math.floor(frame / interval) * interval;
};

export type Entrance = "slide" | "pop" | "stamp" | "drop" | "none";
export const useEntrance = (delay: number, kind: Entrance = "slide") => {
  const frame = useCurrentFrame(); const {fps} = useVideoConfig(); const f = Math.max(0, frame - delay);
  const cfg = kind === "pop" ? {damping: 9, stiffness: 160, mass: 0.7} : kind === "stamp" ? {damping: 12, stiffness: 240, mass: 0.6} : {damping: 200, stiffness: 120, mass: 0.9};
  const p = kind === "none" ? 1 : spring({frame: f, fps, config: cfg});
  const opacity = kind === "none" ? 1 : interpolate(f, [0, 4], [0, 1], {extrapolateRight: "clamp"});
  const tf = kind === "slide" ? `translateX(${(1 - p) * -900}px) rotate(${(1 - p) * -6}deg)`
    : kind === "drop" ? `translateY(${(1 - p) * -700}px) rotate(${(1 - p) * 4}deg)`
    : kind === "stamp" ? `scale(${1 + (1 - p) * 0.55}) rotate(${(1 - p) * 5}deg)`
    : kind === "pop" ? `scale(${0.4 + 0.6 * p})` : "none";
  return {opacity, transform: tf, p};
};

// Slightly irregular hand-cut outline (clip-path polygon).
export const cutPath = (w: number, h: number, seed: number, jitter = 3) => {
  const r = rnd(seed), pts: string[] = [], nx = Math.max(2, Math.round(w / 140)), ny = Math.max(2, Math.round(h / 140));
  const j = () => (r() - 0.5) * 2 * jitter;
  for (let i = 0; i <= nx; i++) pts.push(`${(i / nx) * w + (i && i < nx ? j() : 0)}px ${j() + 1}px`);
  for (let i = 1; i <= ny; i++) pts.push(`${w - 1 + j()}px ${(i / ny) * h + (i < ny ? j() : 0)}px`);
  for (let i = nx - 1; i >= 0; i--) pts.push(`${(i / nx) * w + (i ? j() : 0)}px ${h - 1 + j()}px`);
  for (let i = ny - 1; i > 0; i--) pts.push(`${1 + j()}px ${(i / ny) * h + j()}px`);
  return `polygon(${pts.join(",")})`;
};

// One sheet of paper: soft double shadow, lighter rim, fibre texture. Children go inside.
export const Piece: React.FC<{x: number; y: number; w: number; h: number; color?: string; rotate?: number; delay?: number; kind?: Entrance; seed?: number; radius?: number; children?: React.ReactNode; style?: React.CSSProperties}> =
  ({x, y, w, h, color = paper.cream, rotate = 0, delay = 0, kind = "slide", seed = 1, radius = 0, children, style}) => {
    const e = useEntrance(delay, kind);
    return (
      <div style={{position: "absolute", left: x, top: y, width: w, height: h, opacity: e.opacity, transform: `${e.transform} rotate(${rotate}deg)`, filter: "drop-shadow(0 2px 1.5px rgba(10,20,40,.35)) drop-shadow(0 14px 14px rgba(10,20,40,.28))", ...style}}>
        <div style={{position: "absolute", inset: 0, background: color, clipPath: radius ? undefined : cutPath(w, h, seed), borderRadius: radius || undefined, boxShadow: "inset 0 0 0 2px rgba(255,255,255,.28), inset 0 -3px 6px rgba(0,0,0,.10)"}}>
          <Fibres />
          <div style={{position: "relative", width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", padding: "0 36px"}}>{children}</div>
        </div>
      </div>
    );
  };

const Fibres: React.FC = () => (
  <svg width="100%" height="100%" style={{position: "absolute", inset: 0, mixBlendMode: "multiply", opacity: 0.22}}>
    <filter id="fib"><feTurbulence type="fractalNoise" baseFrequency="0.04 0.9" numOctaves="3" seed="4" /><feColorMatrix values="0 0 0 0 0.3  0 0 0 0 0.25  0 0 0 0 0.2  0 0 0 1.2 -0.25" /></filter>
    <rect width="100%" height="100%" filter="url(#fib)" />
  </svg>
);

// A line of big title text on a coloured paper slip, sized to fit.
export const Slip: React.FC<{text: string; y: number; color?: string; ink?: string; delay?: number; kind?: Entrance; rotate?: number; maxW?: number; max?: number; seed?: number; tape?: string}> =
  ({text, y, color = paper.cream, ink = paper.ink, delay = 0, kind = "slide", rotate = 0, maxW = 940, max = 150, seed = 3, tape}) => {
    const size = Math.min(max, Math.floor((maxW - 80) / (Math.max(4, text.length) * 0.56))); const w = Math.min(maxW, Math.round(text.length * size * 0.58 + 90)); const h = Math.round(size * 1.28);
    const left = (1080 - w) / 2 + ((seed % 3) - 1) * 18;
    return (
      <>
        <Piece x={left} y={y} w={w} h={h} color={color} rotate={rotate} delay={delay} kind={kind} seed={seed}>
          <span style={{fontFamily: "Bricolage, Inter, sans-serif", fontWeight: 800, fontSize: size, lineHeight: 1, color: ink, letterSpacing: -2, whiteSpace: "nowrap", textTransform: "uppercase"}}>{text}</span>
        </Piece>
        {tape ? <Tape x={left + 20} y={y - 22} color={tape} delay={delay + 6} rotate={-28} /> : null}
      </>
    );
  };
export const slipHeight = (text: string, maxW = 940, max = 150) => Math.round(Math.min(max, Math.floor((maxW - 80) / (Math.max(4, text.length) * 0.56))) * 1.28);

export const Tape: React.FC<{x: number; y: number; color?: string; rotate?: number; delay?: number}> = ({x, y, color = paper.yellow, rotate = -20, delay = 0}) => {
  const e = useEntrance(delay, "stamp");
  return <div style={{position: "absolute", left: x, top: y, width: 150, height: 46, background: `repeating-linear-gradient(45deg, ${color} 0 12px, rgba(255,255,255,.55) 12px 22px)`, opacity: e.opacity * 0.92, transform: `${e.transform} rotate(${rotate}deg)`, boxShadow: "0 3px 6px rgba(0,0,0,.25)"}} />;
};

// ---- Scenery ----
const hillPath = (w: number, y0: number, amp: number, seed: number, h: number) => {
  const r = rnd(seed), n = 7, pts = Array.from({length: n + 1}, (_, i) => [(i / n) * (w + 400) - 200, y0 + (r() - 0.5) * amp] as const);
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < n; i++) { const [x1, y1] = pts[i], [x2, y2] = pts[i + 1], mx = (x1 + x2) / 2; d += ` C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`; }
  return `${d} L ${w + 200} ${h + 200} L -200 ${h + 200} Z`;
};
export const Sun: React.FC<{x: number; y: number; r?: number; color?: string}> = ({x, y, r = 190, color = paper.yellow}) => {
  const f = useStepFrame(); const rays = 24; const rot = f * 0.25;
  return (
    <svg style={{position: "absolute", left: x - r * 1.5, top: y - r * 1.5, filter: "drop-shadow(0 8px 10px rgba(0,0,0,.3))"}} width={r * 3} height={r * 3} viewBox={`${-r * 1.5} ${-r * 1.5} ${r * 3} ${r * 3}`}>
      <g transform={`rotate(${rot})`}>{Array.from({length: rays}, (_, i) => { const a = (i / rays) * Math.PI * 2, b = ((i + 0.5) / rays) * Math.PI * 2, c = ((i + 1) / rays) * Math.PI * 2; const R1 = r * 1.12, R2 = r * 1.4;
        return <polygon key={i} points={`${Math.cos(a) * R1},${Math.sin(a) * R1} ${Math.cos(b) * R2},${Math.sin(b) * R2} ${Math.cos(c) * R1},${Math.sin(c) * R1}`} fill="#E9A32F" />; })}</g>
      <circle r={r * 1.1} fill="#E9A32F" /><circle r={r} fill={color} /><circle r={r * 0.72} fill="#F7D774" /><circle r={r} fill="none" stroke="rgba(255,255,255,.35)" strokeWidth={3} />
    </svg>
  );
};
export const Cloud: React.FC<{x: number; y: number; s?: number; speed?: number}> = ({x, y, s = 1, speed = 0.15}) => {
  const f = useStepFrame();
  return (
    <svg style={{position: "absolute", left: x + f * speed, top: y, filter: "drop-shadow(0 8px 8px rgba(0,0,0,.22))"}} width={300 * s} height={140 * s} viewBox="0 0 300 140">
      <path d="M40 120 C0 120 0 70 40 68 C42 30 90 20 110 50 C130 10 200 14 205 55 C250 45 285 85 255 120 Z" fill={paper.cream} /><path d="M40 120 C0 120 0 70 40 68 C42 30 90 20 110 50 C130 10 200 14 205 55 C250 45 285 85 255 120 Z" fill="none" stroke="rgba(255,255,255,.7)" strokeWidth={3} />
    </svg>
  );
};
export const Tree: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = "#2C6040"}) => (
  <svg style={{position: "absolute", left: x, top: y, filter: "drop-shadow(0 6px 6px rgba(0,0,0,.3))"}} width={120 * s} height={260 * s} viewBox="0 0 120 260">
    {[0, 1, 2].map((i) => <polygon key={i} points={`60,${10 + i * 62} ${110 - i * 6},${100 + i * 62} ${10 + i * 6},${100 + i * 62}`} fill={color} stroke="rgba(244,235,216,.7)" strokeWidth={2.5} />)}
  </svg>
);
export const Bird: React.FC<{x: number; y: number; s?: number; speed?: number}> = ({x, y, s = 1, speed = 0.4}) => {
  const f = useStepFrame(); const flap = Math.sin(f * 0.5) * 6;
  return <svg style={{position: "absolute", left: x + f * speed, top: y + Math.sin(f * 0.05) * 6}} width={90 * s} height={40 * s} viewBox="0 0 90 40"><path d={`M2 ${20 + flap} Q22 ${-4 - flap} 45 18 Q68 ${-4 - flap} 88 ${20 + flap} Q66 8 45 26 Q24 8 2 ${20 + flap} Z`} fill={paper.ink} /></svg>;
};

// Full-bleed layered scenery. `variant` sets the palette, `drift` slowly pans the layers (parallax).
export const PaperBackground: React.FC<{variant?: Variant; sun?: boolean; birds?: boolean; clouds?: boolean; hillsFrom?: number; trees?: boolean; seed?: number}> =
  ({variant = "day", sun = true, birds = true, clouds = true, hillsFrom = 1180, trees = true, seed = 7}) => {
    const f = useStepFrame(); const [a, b] = paper.skies[variant]; const hs = paper.hills[variant];
    return (
      <AbsoluteFill style={{background: `linear-gradient(${a}, ${b})`}}>
        <svg style={{position: "absolute", inset: 0, mixBlendMode: "soft-light", opacity: 0.5}} width="100%" height="100%"><filter id="sky"><feTurbulence type="fractalNoise" baseFrequency="0.006 0.012" numOctaves="3" seed={seed} /></filter><rect width="100%" height="100%" filter="url(#sky)" /></svg>
        {sun ? <div style={{transform: `translateY(${Math.sin(f * 0.03) * 6}px)`}}><Sun x={760} y={hillsFrom - 340} r={170} color={variant === "sunset" ? "#F7B267" : paper.yellow} /></div> : null}
        {clouds ? <><Cloud x={-120} y={hillsFrom - 700} s={1.1} /><Cloud x={620} y={hillsFrom - 560} s={0.8} speed={0.1} /></> : null}
        {birds ? <><Bird x={150} y={400} /><Bird x={260} y={460} s={0.7} speed={0.3} /></> : null}
        <svg style={{position: "absolute", inset: 0, filter: "drop-shadow(0 -6px 8px rgba(0,0,0,.25))"}} width="1080" height="1920" viewBox="0 0 1080 1920">
          {hs.map((c, i) => <g key={i} transform={`translate(${Math.sin(f * 0.012 + i) * (3 + i * 3)} 0)`}><path d={hillPath(1080, hillsFrom + i * 190, 90, seed + i * 5, 1920)} fill={c} stroke="rgba(244,235,216,.75)" strokeWidth={3} /></g>)}
        </svg>
        {trees ? <><Tree x={40} y={hillsFrom + 60} s={1.1} color={hs[2]} /><Tree x={150} y={hillsFrom + 120} s={0.8} color={hs[3]} /><Tree x={880} y={hillsFrom + 90} s={1} color={hs[2]} /></> : null}
        <Texture />
      </AbsoluteFill>
    );
  };

// Paper grain + soft vignette over the whole frame (keeps everything feeling like one physical stack).
export const Texture: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <svg width="100%" height="100%" style={{position: "absolute", inset: 0, mixBlendMode: "multiply", opacity: 0.2}}><filter id="gr"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" /><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" /></filter><rect width="100%" height="100%" filter="url(#gr)" /></svg>
    <div style={{position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(10,20,40,.35) 100%)"}} />
  </AbsoluteFill>
);

// Full-screen cream sheet that sweeps away at the start of a scene (use at scene boundaries).
export const PaperWipe: React.FC<{frames?: number}> = ({frames = 12}) => {
  const f = useCurrentFrame(); if (f >= frames) return null;
  const p = interpolate(f, [0, frames], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: (t) => t * t * (3 - 2 * t)});
  return <div style={{position: "absolute", left: 0, top: 0, width: 1080, height: 1920, background: paper.cream, transform: `translateX(${p * 1180}px) skewX(-6deg)`, boxShadow: "-30px 0 40px rgba(0,0,0,.35)"}} />;
};

export const Card: React.FC<{n: number; text: string; y: number; delay: number; color?: string}> = ({n, text, y, delay, color = paper.cream}) => (
  <Piece x={90} y={y} w={900} h={230} color={color} delay={delay} kind="slide" rotate={n % 2 ? -1.2 : 1.2} seed={n + 3}>
    <div style={{display: "flex", alignItems: "center", gap: 36, width: "100%"}}>
      <div style={{width: 120, height: 120, borderRadius: 60, background: paper.orange, color: paper.cream, fontFamily: "Bricolage", fontWeight: 800, fontSize: 78, display: "flex", alignItems: "center", justifyContent: "center", flex: "none", boxShadow: "inset 0 -5px 0 rgba(0,0,0,.18)"}}>{n}</div>
      <div style={{fontFamily: "Bricolage", fontWeight: 700, fontSize: text.length > 26 ? 56 : 68, lineHeight: 1.05, color: paper.ink}}>{text}</div>
    </div>
  </Piece>
);
