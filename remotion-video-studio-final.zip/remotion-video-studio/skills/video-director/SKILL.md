---
name: video-director
description: "Produce finished Cut Paper explainers: research, one script/storyboard approval, reviewed assets archived in the main skill set, original supplied voice, actual-audio timing, smooth motion/captions, render and final QA. Existing authorization carries forward."
version: 1.5.0
---

# Video Director

Read [current production defaults](references/current-workflow.md) first. Resolve this skill's
`scripts/` directory as `DIRECTOR_SCRIPTS`; run helpers from the video project, not the skill folder.
Keep all 16 sibling skills together. Open the actual theme images and asset previews.

## 1. Plan and obtain the existing single approval

Use `remotion-preproduction` and `video-scriptwriting`. Research facts; write natural narration and
concrete visual actions, motion, camera handoffs and an asset brief. Most explanation scenes have
`onscreen: []`; internal names are never automatic headings. Use [the plan schema](references/plan-schema.md).

```bash
python3 "$DIRECTOR_SCRIPTS/init_video.py" . --theme cut-paper --title "..."
python3 "$DIRECTOR_SCRIPTS/doctor.py" --project .
python3 "$DIRECTOR_SCRIPTS/plan_docs.py" video/plan.json
```

Initialization preserves existing work and supplies a scaffold, local fonts and sound library.
Fix plan diagnostics. Present the actual `PLAN.md` contents: storyboard, narration, TTS style and
paste-ready transcript. Request approval and the user's voice take only when authorization is
missing. Approved work or an instruction to proceed needs no renewed gate. Do not assemble film
scenes before approval. Standalone asset work follows its authorized scope and needs no voice.

## 2. Create, review and archive artwork before assembly

Follow [asset-first production](references/asset-first-workflow.md). Search both catalogs; select
useful foundations and design distinctive subject art. Fill `assets/brief.json`. Author layered,
editable sources, inspect real proofs and isolated motion, then archive ready new/adapted packages
in the **main skill set's** `remotion-themes/themes/cut-paper/assets/library/`, including topic-specific
art. Keep versioned project snapshots and honest review evidence. Project-only files are insufficient.

```bash
python3 "$DIRECTOR_SCRIPTS/check_assets.py" --project .
```

Pass readiness before scene assembly. Asset self-review adds no user gate. It can run while the
user prepares audio; audio analysis can proceed independently. Consult [asset recipes](../remotion-themes/themes/cut-paper/assets/README.md)
and [universal object/motion recipes](../remotion-themes/themes/cut-paper/assets/UNIVERSAL.md) as needed.

## 3. Preserve and align supplied speech

Save the take unchanged under `public/`; compare its words with the approved script and record its
hash. Then run `after_vo.py --project . --vo public/vo.wav` (optional `--music`). Pause estimates are
starting points. Align against actual speech, correct scene boundaries and caption words, record
the method, set `vo.timing_verified`, update consumed timing data and rerun `auto_sfx.py` for cues.
Never rerun estimation over a verified timeline or alter speech start/speed/content to fit a guess.
See [audio and delivery](references/delivery-workflow.md) and `remotion-captions`.

## 4. Assemble and animate from ready sources

Use `remotion-create`, `remotion-markup`, `remotion-captions` and the relevant API references on demand.
Keep Studio open. Build topic-specific cause/process/result scenes; the stock kit is scaffolding.
Derive source seconds from the real timeline. Use grounded characters, distance-linked wheels,
attached props, meaningful camera travel and a small transition vocabulary. Keep captions outside
the world camera on the continuous voice clock. Avoid persistent headings and decorative UI.

Review shot beginnings, settled poses, action/exit, every transition and camera extremes. Inspect
loaded-font glyph bounds, subtitle changes, contacts and native-speed movement. Use
[visual QA](references/production-quality.md) and [the report template](assets/qa-report.template.md).

## 5. Render, audit, preserve improvements and deliver

```bash
python3 "$DIRECTOR_SCRIPTS/finalize.py" --project . --comp Main --audio-master video/preview-mix.wav --out out/final.mp4
```

Supply `--audio-master` only for a current verified timeline-aligned uncompressed mix; it replaces
render audio once. Otherwise omit it. Finalization repeats asset readiness, renders/masters and
checks the encoded export. Fix failures; inspect the actual MP4 and complete QA. Archive revised
art as reviewed new versions with refreshed previews. Merge installed library additions before
skill/Git/ZIP updates; keep earlier versions and customized files.

Deliver a clickable MP4 and useful SRT. Report actual checks and material limits: distinguish still
inspection, motion playback, transcription, audio measurements and listening. Do not claim quality
from a clean script exit alone. Continue authorized production through delivery.
