---
name: video-director
description: End-to-end Remotion video production with ONE approval gate. Use whenever the user asks for a video, reel, short, explainer or map video. Plans the video, shows the plan with a TTS style prompt and narration prompt for approval, creates and reviews distinctive layered assets, saves them in the main skill-set library, then aligns supplied audio, assembles Cut Paper scenes, builds sound, renders and audits the final MP4.
version: 1.4.0
---

<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Video Director

You carry the whole pipeline through to delivery. The user approves the plan and supplies the
voice; you author and review everything else without making them request each production step.
Resolve this skill's installed location from the `SKILL.md` you opened. Set
`DIRECTOR_SCRIPTS` to its absolute `scripts/` directory. Run the commands below
from the video project root; these scripts are not copied into the project's `scripts/`.
Install the whole folder together: scripts reference the sibling skills `remotion-themes` and `remotion-sound-design`.

**Read [production quality defaults](references/production-quality.md) before planning or building.**
Smooth animation, purposeful transitions, topic-specific backgrounds/illustrations and smooth,
theme-matched subtitles are defaults for narrated explainers. Inspect the theme images.
Do not pin main headings over explanations: scene names are internal, most `onscreen` arrays
are empty, and an optional opening title leaves after a short readable introduction.
The user should not have to request these improvements again. Explicit user preferences override defaults.
Read [asset-first production and permanent storage](references/asset-first-workflow.md), [current workflow and references](references/current-workflow.md), the
[asset catalog](../remotion-themes/themes/cut-paper/assets/README.md), [camera and continuity](references/camera-and-continuity.md), the
[Industrial Revolution reference](references/industrial-revolution-example.md), and
[delivery workflow](references/delivery-workflow.md). Use the QA template in `assets/`.
Instructions support quality; authored visual decisions and actual render review are still required.

## Pipeline

```
 1 intake -> 2 plan -> 3 APPROVAL GATE (PLAN.md + style prompt + narration)
 -> 4 create/review/archive assets in the main skill set -> 5 supplied audio -> 6 timing/sound
 -> 7 assemble/animate -> 8 render/audit -> 9 preserve asset improvements -> 10 deliver
```

### 1. Intake (silent, one message at most)
Use `/remotion-preproduction` and `/video-scriptwriting` rules. Ask only what is missing (max 4 questions, each
with a default). The included theme is `cut-paper`: tactile paper scenes for explainers, stories,
facts, education and topic-specific diagrams. Never ask about style frames or look verification:
inspect the included references and adapt the scenery within the paper material system.

### 2. Plan
```
python3 "$DIRECTOR_SCRIPTS/init_video.py" . --theme cut-paper --title "..."
python3 "$DIRECTOR_SCRIPTS/doctor.py" --project .                                    # environment check, once
```
`init_video.py` creates `video/plan.json` from the template, copies the theme kit to `src/theme`, fonts to `public/fonts`,
synthesizes the SFX library to `public/sfx`, and supplies `src/StudioRoot.tsx`. Existing entries are
preserved: register StudioRoot or your final composition in the existing root manually, keeping
other compositions intact. The final composition should be `Main` unless you pass another id. Fill `video/plan.json` (schema:
`references/plan-schema.md`). Fill `production`, including `camera_plan`, and each scene's `motion`, `transition` and text purpose/window;
the template's sample topic and stock kit are scaffolds, not finished content. Then:
```
python3 "$DIRECTOR_SCRIPTS/plan_docs.py" video/plan.json
```
It validates (length vs word count, banned phrases, unsourced numbers) and writes `PLAN.md`, `narration.txt`, `tts-prompt.txt`.
Fix every error it prints and re-run.
Resolve quality warnings or record a concrete user/brief override; do not treat a clean script exit
as proof of visual quality, factual accuracy or theme-image inspection.

### 3. The approval gate (the only one, when not already satisfied)
Existing authorization carries forward. If this plan is already approved, or the user explicitly asks
to skip approval, record that and continue. Do not re-request approval for the same work. Otherwise,
show the user the **contents of PLAN.md**: summary, storyboard table, the narration script, the **TTS style prompt**, and the
**paste-ready TTS prompt** (style + exact transcript). End with: "Reply **approve** (or tell me what to change). Then generate the
voice with your TTS and send me the audio file." Do not write any scene code before approval. On changes: edit plan.json, re-run
`plan_docs.py`, show it again.

### 4. Create, review and preserve the artwork first
Read [the asset-first workflow](references/asset-first-workflow.md). Fill the initialized
`assets/brief.json` with per-scene requirements. Search both the foundational component catalog
and saved story packages; open their actual previews. Create distinctive subject art as editable,
layered packages in `assets/packages/`, then inspect contact sheets and isolated motion proofs.
Save every ready new/adapted package, including topic-specific art, in
`remotion-themes/themes/cut-paper/assets/library/` using `asset_workflow.py archive`.
That shared archive is part of the main skill set and must work without this video project.
Reuse brings an immutable snapshot back into the next project's `assets/`.
Run `python3 "$DIRECTOR_SCRIPTS/check_assets.py" --project .` before scene assembly.
The check writes `video/asset-check.json`; fix missing sources, review evidence, dependencies,
requirements or shared copies first. Asset review is agent self-QA, not another user gate.
Asset work can proceed after approval while the user generates audio; timing analysis may run
independently. Project scaffolds and isolated asset tests are allowed, film assembly waits.

### 5. The user sends the audio (wav/mp3/m4a)
Save the original into the project (e.g. `public/vo.wav`) without changing its bytes, content or speed.
Verify its words against the approved script. A genuinely wrong or unusable take may require a new take;
update the style prompt or `voice.pronunciations` when appropriate. Do not claim to have listened if you
could only inspect transcription and measurements.

### 6. One command: timing + sound
```
python3 "$DIRECTOR_SCRIPTS/after_vo.py" --project . --vo public/vo.mp3 [--music public/music.mp3]
```
Detects the pauses between scenes in the voice, writes `start_frame` / `duration_frames` / `total_frames` into plan.json and
`src/data/timing.json`, places every sound cue on its exact frame (`src/sfxCues.ts`), writes `video/cue-sheet.md` and
`video/preview-mix.wav`. Check the printed scene boundaries: if the count of pauses did not match the scene count it falls back to
word counts and says so. Treat this as an alignment problem first: align the approved transcript to the
actual speech, inspect sentence pauses/waveforms and correct the boundaries, recording the method.
Set `vo.timing_verified` after checking; regenerate sound cues with `auto_sfx.py` after corrections.
Do not rerun the estimator over a verified timeline. `vo.file` is relative to `public/`.
Do not request another take solely because pause detection failed. Rough word-count timing is insufficient
for final scene/caption sync. Use `/remotion-captions` for actual-audio caption timing.

### 7. Build from ready assets
If TypeScript complains about importing `plan.json`, add `"resolveJsonModule": true` to tsconfig. Run once per project: `npx remotion add @remotion/media @remotion/transitions` (project from `/remotion-create`; init works on top of it).
The theme kit (`PaperVideo`) is a timing/font scaffold. Build topic-specific visual scenes;
stock scenery plus a persistent heading on each scene is not a finished video. Read `/remotion-themes`,
`/remotion-best-practices`, `/remotion-markup` and `/remotion-captions`; consult `/remotion-docs` for APIs.
Keep Studio open while working. Preserve shared objects/camera continuity, use smooth eased motion,
and integrate theme-matched subtitles by default for narrated explainers. Search/install suitable reusable assets before rebuilding common geometry. Record library version, selected IDs and adaptations; use the jointed person/journey for walking, one canonical camera and the canonical smooth caption renderer. The kit does not automatically transcribe or stage the finished explanation: implement and verify those steps.

Inspect stills at opening, settled, mid-action and exit frames of every shot, several frames inside each
transition, and extreme camera positions. Scrub/play motion and subtitle changes; check loaded glyph
bounds and line count. At 1080x1920 use top 270 / bottom 420 / right 110 px margins for titles and
labels. Subtitles have their own lower lane: x=80, y=1500, w=890, h=148, leaving 272px below the
backing. Do not move captions upward to satisfy the title margin. Check actual controls and
re-layout other formats. Follow `remotion-preproduction/references/qa.md` and record evidence in `video/qa-report.md`.
The opening title must leave; explanation scenes must not auto-render internal names or chapter slogans.

### 8. Render, loudness, audit
```
python3 "$DIRECTOR_SCRIPTS/finalize.py" --project . --comp Main --audio-master video/preview-mix.wav --out out/final.mp4
```
Use `--audio-master` only for a verified, current, timeline-aligned uncompressed mix. It replaces
the render audio. Omit it to master the rendered audio instead. Never stack both copies.
Renders, normalizes to about -14 LUFS / -1.5 dBTP with the video stream copied, and audits. Fix any FAIL (see
`remotion-sound-design/references/mixing-and-loudness.md`), re-run. Inspect and probe the actual final MP4
for duration, frame count, resolution, fps, complete ending, assets, subtitle motion and audio levels.
`verify_export.py` writes technical checks; it cannot judge artistic quality, transcript accuracy or feel.

### 9. Preserve improvements
If film review changed any artwork/rig, save a reviewed new version with refreshed previews and
rebind the affected requirement, then rerun asset readiness and inspect affected shots. Preserve
earlier versions. Sync the growing installed `assets/library/` into the main skill-set checkout
before updating Git or the ZIP; never leave the newest assets only in a film folder. See the
[storage/update commands](references/asset-first-workflow.md).

### 10. Deliver
Deliver the finished MP4 using the client's file-delivery tool when available, or a clickable artifact/file
link. Say briefly what you verified and any material limitation. Distinguish frames viewed, motion played
and audio measured/listened to; never claim checks you did not perform.

## Rules
- One approval gate. No questions after it unless something blocks.
- Do not fabricate facts, numbers, real logos or claimed supplied/licensed assets. Author original topic-specific artwork; record provenance and reuse rights. Unresolved factual/source items go in `open_questions` with a default.
- Derive scene boundaries from `timing.json` / plan.json; derive authored motion offsets from seconds and fps.
- No frame counters, scene numbers, progress bars or filler. Titles and labels need a purpose and exit.
- Preserve completed work. `init_video.py` keeps existing authored files by default; `auto_sfx.py`
  regenerates derived cue/mix files. Review manual cue edits before regenerating them, and never
  rerun the timing estimator over a verified timeline.
- If a step fails, read the message, fix the cause, re-run that one script.
