---
name: video-director
description: "Direct a film from the current brief: establish scope and audience, write speech and shots independently, develop contextual art direction, prepare project artwork, assemble, review creativity and engineering separately, and deliver."
version: 3.1.0
---

# Video Director

Start with [the decision architecture](references/current-workflow.md). The current user request and confirmed requirements define this production. Creative choices are recorded in the project.

## Understand and plan
Establish the specific question/purpose, audience and prior knowledge, evidence, scope and delivery constraints. Record user requirements with their source; label assumptions.

Write speech for that audience: concrete, speakable language, unfamiliar terms explained, causal steps complete, claims verified and illustrative examples marked as such. Choose the explanatory sequence from what must be understood first; the opening should give this viewer an immediate reason to watch and must be delivered by the film. Rehearse at the intended pace. Test the opening as a moving sequence, not a sentence.

Develop the treatment and opening appropriate to this explanation. Write `narration` and `shots` independently using [schema 3](references/plan-schema.md). Assign each selected reference its intended role. Art direction comes from setting, materials, lighting, historical/scientific context, tone and readability. Compare options when that resolves a real uncertainty; the project decides how many are useful.

```bash
python3 /absolute/path/to/video-director/scripts/init_video.py /path/to/project
python3 /absolute/path/to/video-director/scripts/plan_docs.py video/plan.json
```

Initialization writes empty project records. Configure dimensions/fps from the brief; choose fonts and production techniques after the visual treatment. The channel profile is available when its user preferences apply; selecting it is explicit. Resolve this skill's scripts path and run helpers from the project.

Present the concrete treatment, script, shots and voice prompt for the established script/storyboard approval when missing. Existing authorization carries forward. Audio handoff and internal review add no extra permission gates.

## Prepare artwork, then assemble
Follow [project asset preparation](references/asset-first-workflow.md). Create style-frame tests and needed project artwork/poses/rigs before final assembly. Choose illustration, generated layers, vector geometry, supplied material or another technique according to the intended result and actual rights. Save sources and truthful provenance in the project.

Inspect contextual stills and necessary motion ranges, then record project integrity with `check_assets.py --project . --seal`. Missing artwork returns to preparation. The scene timeline imports prepared artwork and controls its action, composition, camera and sound.

Keep the supplied voice intact. `after_vo.py` records the take; schema 3 does not derive shot cuts from speech pauses. Align actual words, choose shot cues, then author verified frame timing. `auto_sfx.py` emits only explicitly authored events. See [delivery](references/delivery-workflow.md).

## Review and deliver
Keep Studio open during composition work. Use [camera/continuity](references/camera-and-continuity.md) where needed. Perform [creative review](references/production-quality.md) on actual pictures and normal-speed moving sequences; complete engineering checks separately. Record evidence and unavailable review in the [QA record](assets/qa-report.template.md).

`finalize.py --project . --comp Main --audio-master video/preview-mix.wav --out out/final.mp4` uses a current verified mix in place of rendered audio once. Omit `--audio-master` when it is not appropriate. Inspect the encoded deliverable, finish both review records and deliver the MP4 and useful SRT. Publish or push only within the user's authorization.
