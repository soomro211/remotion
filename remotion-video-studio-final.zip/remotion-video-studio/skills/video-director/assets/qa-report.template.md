# Production QA — PROJECT TITLE

Status: NOT REVIEWED. Replace pending entries with actual files, frame/time samples, methods and limits.

## Story and sources
- Factual sources, natural script, concrete cause/process/result: PENDING.
- Actual theme/selected asset images opened; preserved material/type/palette: PENDING.
- Opening title clears; purposeful labels; no persistent headings or template debris: PENDING.

## Asset readiness before assembly
- Brief requirements, new/adapt/reuse decisions and source versions: PENDING.
- Editable layers, controls, dependencies and source/scale/contact proofs reviewed: PENDING.
- Ready new/adapted art saved in main skill-set `assets/library/`, including topic art: PENDING.
- `video/asset-check.json` passed before scene assembly; project/runtime mappings recorded: PENDING.
- Later changes archived as reviewed new versions; installed additions synced before updates: PENDING.

## Picture and movement
- Opening/settled/action/exit, every transition and extreme camera pose inspected: PENDING.
- Feet/floor, seats/supports, hands/items, hinges and distance/rotation contact: PENDING.
- Overscan, clipping, IDs, repeated-object phase and continuous source clock: PENDING.
- Native-speed playback/scrub scope and remaining visual limits: PENDING.

## Voice and subtitles
- Original voice file/hash, actual transcript comparison and timing/alignment method: PENDING.
- Start/middle/end words and scenes aligned; supplied start/speed/content preserved: PENDING.
- Loaded-font line/glyph bounds, longest phrase, exact words and caption transitions: PENDING.
- Stable backing/clock, ≤2 lines, lower lane x80/y1500/w890/h148 at 1080×1920; actual controls checked: PENDING.

## Encoded delivery and limits
- Actual MP4 dimensions/fps/frames/duration, full ending/decode and encoded-picture review: PENDING.
- Final LUFS/true peak/clipping, mix sync and `video/export-check.json`: PENDING.
- Listening scope (or measurements/transcription only): PENDING.
- Explicit overrides, observed limitations and follow-up work: PENDING.

Follow [current defaults](../references/current-workflow.md). A passing script is not artistic or factual certification.
