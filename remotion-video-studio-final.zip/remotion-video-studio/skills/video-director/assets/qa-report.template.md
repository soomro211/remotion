# Review — PROJECT

Process: [decision architecture](../references/current-workflow.md).
Creative status: NOT REVIEWED
Engineering status: NOT CHECKED

## Creative evidence
- Brief/scope/audience and source requirements actually used: PENDING.
- Script comprehension and opening intent: PENDING.
- Art-direction reasons and reference roles; actual frames opened; observations/revisions: PENDING.
- Moving-sequence review with timecodes: attention, explanatory action, pacing, connections and ending: PENDING.
- Full-cut playback and listening scope; unresolved creative assessment: PENDING.

## Engineering evidence
- Prepared project source/proofs, dependencies/copies and integrity report: PENDING.
- Geometry/contact/camera coverage and loaded-font caption bounds: PENDING.
- Original speech/hash, transcript/actual timing and beginning/middle/end sync: PENDING.
- Final encoded dimensions/fps/frames/duration, full decode/ending, sound levels/true peak: PENDING.
- Failures, fixes and remaining technical limits: PENDING.

## Feedback record
Observation → proposed cause → project correction → evidence after correction → scope of any proposed shared change.

Use actual files, observations and methods. Measurements, transcription, still review, playback and listening are distinct. Metadata cannot establish artistic quality or chronology.
