# Production QA — PROJECT TITLE

Status: NOT REVIEWED. Replace each pending entry with evidence or a limitation.
Do not turn this template into a blanket PASS.

## Art direction and explanation
- Theme images opened: PENDING (paths and preserved material/type/palette).
- Topic-specific cause/process/result shown: PENDING (shot/action examples).
- Sources and asset credits: PENDING (project file links).
- Opening title exit, object labels, no persistent headings or template debris: PENDING.

## Camera and motion
- Shot start/settle/action/exit and extreme travel samples: PENDING (frame/time list).
- Every transition sampled: PENDING (frames, geometry, direction and continuity).
- Overscan, path joins, repeated object phase and camera velocity: PENDING.
- Native-speed motion playback or scrubbing: PENDING (method; distinguish still review).

## Voice and subtitles
- Original narration file and SHA-256: PENDING.
- Transcript comparison and alignment method/confidence: PENDING.
- Beginning/middle/end word and scene sync: PENDING.
- Loaded-font glyph/line checks, longest page and phone-scale review: PENDING.
- Every phrase change checked for plate continuity, ghosting, clipping and baseline shifts: PENDING.
- Lower subtitle lane (1080x1920: x=80, y=1500, w=890, h=148; 272px below backing),
  checked against actual controls independently of title margins: PENDING.

## Encoded delivery
- Final file, dimensions/fps/frames/duration, complete ending and decode: PENDING.
- Final audio LUFS / true peak / clipping: PENDING.
- Original voice timing and speed preserved: PENDING (hash alone does not prove the final mix).
- Listening: PENDING (devices/method, or measurements only).
- Encoded-file frame/motion review: PENDING (evidence, not only Studio screenshots).
- Technical export-check.json: PENDING.

## Remaining limits and overrides
- PENDING. Record observed limits, user-requested exceptions and follow-up work honestly.

## Reused assets and current references

- Current production images/catalog actually viewed: PENDING.
- Library version, asset IDs and adaptations: PENDING.
- Feet/floor, hands/items, sitting/support and other contact checks: PENDING.
- Source time, path speed, wheel distance/rotation and mirrored action: PENDING.
- Camera extreme bounds and actual loaded-font lower subtitle placement: PENDING.
- Native-speed execution, visually inspected poses/encoded frames, and listening scope: PENDING (separate these claims).

Follow [current workflow](../references/current-workflow.md) and [asset recipes](../../remotion-themes/themes/cut-paper/assets/README.md); source/code changes require reference and validation updates before a release.
