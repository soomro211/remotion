<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](current-workflow.md).

# Asset-first production and the permanent skill library

Create the artwork the story needs, review it, and save it in the **main skill-set assets directory before assembling the video**. Each film should improve the library. Keeping artwork only in a video project, `public/`, a temporary render folder or a conversation attachment does not complete this stage.

## Sequence and approval

Research → inspect current theme images and both asset catalogs → plan/script/storyboard approval → asset brief → create/adapt artwork → isolated visual/motion review → archive in the shared skill library → asset readiness check → scene assembly, camera, captions and sound → film QA/export → archive any revised assets.

The existing plan/script approval is the only routine user gate. Asset review is the agent's responsibility. Once the plan is approved, asset work can proceed while the user prepares narration. Preserve supplied speech; actual-audio alignment may run independently. Scene timing and final animation use that alignment. Standalone asset work does not require a voice take. Project scaffolding, transcription, asset proofs and isolated motion tests are permitted before scene assembly; they are not a substitute for finished-film review.

## One permanent home, portable project snapshots

Resolve `ASSET_WORKFLOW` to the absolute `remotion-themes/scripts/asset_workflow.py` beside the installed skills. Its default shared archive is:

```
skills/remotion-themes/themes/cut-paper/assets/
  catalog.json                    # foundational React components and motion tools
  library/
    index.json                    # saved story packages, generated from their manifests
    catalog.html                  # searchable local visual reference
    <descriptive-asset-id>/
      <x.y.z>/
        asset.json
        source/                   # editable geometry, layers, textures, rig source
        previews/                 # inspected renders; motion proof when applicable
        review/                   # contact sheet / pose tests / written observations
```

Each video's `assets/brief.json` records requirements; `assets/manifest.json` binds them to versions. Its `assets/packages/<id>/<version>/` snapshots contain the same source and metadata as the shared archive. The shared copy is mandatory for **topic-specific as well as universal artwork**. A useful historical machine, scientific diagram or character must remain discoverable without its original film. Promote mature, broadly useful functionality into the foundational component catalog when appropriate; ordinary topic packages do not need to become generic components.

Sources live in the package. Import TS/SVG/PNG source by relative path when supported. If a loader needs files under `public/assets/` or `src/assets/`, generate working copies from the package, record the mapping/hashes in production notes, and regenerate them after a revision. Update the canonical source first. The helper validates the package and archive; inspect any loader-specific runtime copies separately. Never introduce two independently edited sources.

## 1. Brief and search

`init_video.py` creates the asset brief and manifest without replacing existing files. They can also be initialized separately:

```bash
python3 "$ASSET_WORKFLOW" init /path/to/video
python3 "$ASSET_WORKFLOW" search --query "river terrain"
python3 /path/to/skills/remotion-themes/scripts/assets.py list --search walking
```

Open the actual reference pictures and relevant saved previews. Fill `reference_review`, `visual_direction` and `requirements` in `assets/brief.json`. Every requirement has a unique `key`, concrete `purpose`, `scene_ids`, and `kind`: `new`, `adapt`, `reuse` or `core`. Core requirements also declare `asset_ids` installed by `assets.py`.

Specify the distinctive hero asset/process, background depth planes, props, poses, viewing angles, contact anchors, palette/material, camera coverage and moving parts. Connect each requirement to an explanatory action. Do not count decorative objects as progress. Default to bespoke artwork for what makes this topic distinctive; reuse materials, typography and proven rigs. If existing artwork fully serves the story, record the concrete reason in `reuse_only_reason` rather than manufacture unnecessary variants.

## 2. Create layered, editable assets

```bash
python3 "$ASSET_WORKFLOW" new /path/to/video --id river-cross-section --version 1.0.0 --scope topic
```

Author inside the generated package. Fill `asset.json`; its initial `draft`/`pending` values intentionally fail readiness. Supply editable sources, previews and review evidence. Keep the subject separate from background/captions. Separate parts that need independent depth or movement. Make overscan sufficient for the planned camera; draw hidden/contact geometry where needed. Use clear silhouettes and deliberate shape detail, consistent paper edges, matte fibre, cream rims and restrained tight/soft shadows. Avoid low-detail placeholder icons, a single flattened poster for an animated explanation, or a generic collection of stock scenery.

Use SVG/React for geometry, articulated rigs, diagrams and controllable mechanisms. Generate or illustrate raster art when it improves the scene; save its editable layers where available, prompts/settings and original provenance. A prompt alone is not an asset. Do not pass a flattened image off as layered source. Name actual controls and limitations honestly. Preserve existing walking/contact, camera and smooth lower-caption tools unless the brief requires a tested improvement.

Packages must be self-contained: bundle local imports, textures and dependency geometry. Declare npm dependencies in `dependencies.packages`; use relative imports for local files. A package must not import the original film, depend on its `staticFile()` folder, load temporary absolute paths or need a running server. Record canvas, anchor, controls, tags, sources, creator and reuse rights. Packaged documentation should refer to portable paths, not local machine directories.

## 3. Review before marking ready

Render a contact sheet/in-context proof at the intended scale. Open it and inspect silhouette, colour separation, cut edges, shadows, layering and enough camera coverage. Test articulated/moving assets through their actual range: starts/stops, mirrored action, joints, feet/floor, hands/items, occlusion and loops. A static background may mark motion not applicable with a specific explanation. For full-frame art, verify space for the lower subtitle plate at x80/y1500/w890/h148 in a native 1080×1920 composition; captions are not baked into the asset.

Correct visible problems, rerender and record what was actually viewed/tested in `review/`. Complete the six checks in `asset.json`: `theme_fit`, `silhouette`, `scale`, `layers`, `edges_shadows`, `motion`. Set the package `status` to `ready` and review status to `passed` only after that work. Scripts validate evidence records and files, not artistic judgment; do not fill checks from code inspection alone or claim playback from stills.

## 4. Archive before assembling scenes

```bash
python3 "$ASSET_WORKFLOW" archive /path/to/video --package assets/packages/river-cross-section/1.0.0 --requirement hero
python3 "$ASSET_WORKFLOW" check /path/to/video --report video/asset-check.json
```

`archive` verifies metadata, review records, relative imports and file contents; seals source hashes; saves the complete package in the **installed skill's** `assets/library/`; binds the requirement; and rebuilds its searchable index/gallery. A successful project-only copy is insufficient. Run `check` before authoring the film's scenes. It requires every brief requirement to resolve, ready reviewed source, intact project/shared copies and installed core selections. `finalize.py` repeats this check for new productions before rendering/mastering. This technical gate cannot prove that an agent followed the order or that the art looks good; the QA record must contain real evidence.

To reuse a package in another project, without its original video:

```bash
python3 "$ASSET_WORKFLOW" reuse /path/to/new-video --id river-cross-section --version 1.0.0 --requirement hero
```

For adaptations, copy the source into a new version or a descriptive new asset ID, remove the old sealed `files` record, update metadata/provenance, review, then archive. Versions are immutable: archive, restore and sync refuse conflicting contents. They do not silently overwrite user edits. Reuse multiple requirements through separate explicit bindings when necessary.

## 5. Preserve improvements and update the Git skill set

After film review, archive a new reviewed version for any artwork/rig that changed. Rebind the affected project requirement deliberately, rerun readiness and inspect affected scene/camera/caption interactions. Retain earlier versions so finished films remain reproducible. Update previews, recipes and usage limits with the source.

When installed skills and a Git checkout are different folders, merge the saved packages **before replacing installed skills or building an update**:

```bash
python3 "$ASSET_WORKFLOW" sync --to-library /path/to/checkout/remotion-video-studio/skills/remotion-themes/themes/cut-paper/assets/library
```

`sync` validates both archives, preflights all collisions, merges versioned packages and rebuilds the destination index. It preserves existing packages. Repeat in the other direction to transfer a checkout's new assets into installed skills. Do not delete a growing installed library during a skill upgrade. For a read-only installation, work from a writable copy of the complete skill set and use its sibling helpers. Global `--library` supports explicit archive migration/checks; finalization uses the active sibling skill’s archive, so sync additions there before finishing. Do not fall back silently to a project-only directory.

The single release ZIP includes the complete shared library, editable files, previews, review evidence and index through the normal bundle manifest. Packaging verifies package contents/indexes and can merge a known installed library with `--merge-library`. A fresh agent needs only that updated skill set. No video source folder, voice take or previous conversation is required.

See the [portable source example](../../remotion-themes/themes/cut-paper/assets/library/README.md), [asset recipes](../../remotion-themes/themes/cut-paper/assets/README.md), and [QA template](../assets/qa-report.template.md).
