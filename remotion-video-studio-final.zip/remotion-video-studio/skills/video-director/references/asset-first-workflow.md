# Project-specific artwork before final assembly

Process: [decision architecture](current-workflow.md).

## Order and scope
Plan/script/storyboard → existing approval → create all needed project artwork → inspect in-context proofs and motion → seal project manifest → assemble final film. Asset self-review adds no user gate. Audio analysis is independent.

No shared visual library, catalog search, stock rigs or archive/sync step. Each project owns its art. Fonts, caption rendering and API/timing helpers are technical tools. Reference images establish art direction; they are not ready-made scenery to extract.

## Plan the asset brief
`init_video.py` creates `assets/brief.json` and `assets/manifest.json` without overwriting existing files. Fill `reference_review`, `visual_direction` and requirements `{key, purpose, shot_ids, moving}` from the chosen storyboard. Record required parts/poses, palette, anchors, views and camera coverage as useful extra fields. Reference records identify their roles and limits. Asset origins can be created-for-project, user-supplied or licensed-for-project; record actual provenance/rights. Do this before drawing; a missing object is not a reason to distort the explanation.

## Produce and inspect
Create layered editable sources under `assets/source/`. Prepare required poses/rigs and movement ranges here. Keep text/captions separate. Extend backgrounds for the entire camera view; test support/hand contacts and silhouette at intended scale. Use SVG/React or layered illustration as appropriate. For generated/supplied art record provenance and actual editability; a prompt is not a finished asset and a flattened image is not layered source.

Inspect compositions for the intended contextual color/material/light relationships, focal hierarchy and readability at destination size. Inspect moving assets through preparation, action, contact, return, start/stop and mirrored views where needed. Capture proofs in `assets/review/` and write specific observations/corrections. Motion proofs can be short MP4/WebM; record whether native playback or only frame inspection was possible.

## Manifest and runtime copies
Schema 2 manifest: `stage: "prepared-before-assembly"`, `assets: [...]`. Each entry binds one brief `key` and contains:

```json
{
  "key": "hero", "status": "ready", "origin": "created-for-project",
  "source_files": ["assets/source/hero.svg"],
  "preview_files": ["assets/review/hero-context.png"],
  "motion_files": [],
  "review_notes": "assets/review/hero.md",
  "runtime_copies": [],
  "files": {}
}
```

For `moving: true`, include an actual motion proof in `motion_files`. Review notes describe what was viewed, color/shape/scale/layers/coverage and any motion/contact checks or limits. Source dependencies belong in the project and must be listed/hashes recorded. Technical font/API helpers can be imported normally; do not reference installed visual packs, another film or temporary absolute files.

Use sources directly where the bundler supports them. If the loader needs a copy, record `runtime_copies: [{"source":"assets/source/hero.svg","target":"public/assets/hero.svg"}]`. Targets must be inside `public/assets/` or `src/assets/`; copy from the canonical source and keep bytes identical. Do not independently edit runtime copies.

After actual review:
```bash
python3 "$DIRECTOR_SCRIPTS/check_assets.py" --project . --seal
python3 "$DIRECTOR_SCRIPTS/check_assets.py" --project .
```

`--seal` records source/proof/note/copy hashes after validating readiness. Schema-3 sealing also records the reviewed art-direction context. Subsequent checks reject missing/changed files, changed art direction, incomplete requirements, escaping paths and mismatched copies; finalization repeats them. The checker cannot prove originality, visual quality or the order in which work happened. Do not describe it as creative approval.

## During film review
Assembly controls timing, composition, action and transitions using prepared art. If a new asset or material art correction is needed, return to this stage, update source/copies, inspect affected poses/compositions, then reseal deliberately. Keep all source/proofs with this project. Do not add its artwork to the skill bundle.

## Older projects
Finished projects retain their snapshots. Old schema-1 shared-library records are not silently accepted as the new contract. To revise an older film with current helpers, explicitly inventory its local sources/proofs in schema 2 and review them for that film; never delete its files to make migration pass.
