# Shot connection and motion

Process: [decision architecture](current-workflow.md).

For a shot, identify what the viewer notices and what changes. Choose framing, subject action and camera behavior to communicate it. A held camera, movement or change in shot size follows that purpose.

For adjacent shots, identify outgoing focus and incoming focus. Their relationship determines whether a direct cut, continuation, matched action/composition, occlusion or dissolve fits. Author timing, overlap and settling from the actual action. Review the join at normal speed; several stills cannot establish perceived smoothness.

## Technical implementation
Keep recurring motion on a coherent source clock. Match position/velocity/action phase where continuity is intended. A continuous camera path needs continuous derivatives; independently easing each segment can introduce stops.

`TransitionSeries` total duration equals summed sequence durations minus overlaps. Keep a continuous voice/caption track independent of illustration overlaps. For an incoming spoken cue at frame A and overlap O, a visual can start at A−O with duration extended by O; verify cumulative starts and total frames. See [transition API](../../remotion-markup/transitions.md).

For a camera centered at `(cx,cy)` with scale z, visible bounds are `cx ± width/(2z)` and `cy ± height/(2z)`. Union bounds along its path and extend artwork/shadows; inverse-transform viewport corners for rotation.

Where relevant, prepare project rigs with explicit contacts, reachable hands, hinge pivots and distance-linked wheel/foot phase. Keep held objects attached to shared anchors. Review starts/stops, pose extremes and actual support surfaces. Select physical detail appropriate to the visual model; measurements and perceived movement are separate evidence.
