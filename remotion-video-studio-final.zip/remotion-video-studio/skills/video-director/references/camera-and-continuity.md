<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](current-workflow.md). Apply the task-specific guidance below within those defaults.

# Camera movement and visual continuity

Read before storyboarding and before implementing a moving shot. The current asset-generated production images are the primary reference. The Industrial
Revolution film remains a historical camera study. Improve its choices for the next
subject; do not recycle its factory scenery, exact shot count or camera path.

## Direct the shot

For each shot, write the subject action, the reason for the camera move, its
starting and ending focus, approximate scale/travel, readable hold, and what
continues into the next shot. Use `production.camera_plan` for the overall approach
and `scenes[].motion` / `transition` for individual decisions. These fields guide
authored code; they do not animate anything automatically.

- A push reveals a detail; a pullback connects it to a larger system. A lateral
  move follows material, people or geography. Hold when movement adds nothing.
- Choose a dominant move per beat. Do not combine unrelated pan, zoom, rotation
  and bounce. A camera move alone cannot explain a mechanism.
- Start with restrained travel: roughly 4–10% change in scale over a held shot,
  or a larger deliberate reveal when the information requires it. These are
  starting points, not mandatory motion on every shot.
- Arrange foreground, subject and background with a consistent light direction.
  Use two or three useful depth planes. Reserve strong foreground travel for a
  motivated reveal, such as passing a wall into a factory.
- Link speed and motion to the subject. A wheel should turn as the mechanism
  operates; a train's wheel rotation should follow its distance along the track.
  Avoid detached objects sliding over a static scene without contact or cause.

## Maintain continuity across cuts

- Match the important object's screen position, apparent size and action phase.
  A waterwheel becoming a steam flywheel works because the hub and turning motion
  remain recognizable while the source of power changes.
- Maintain screen direction and camera height unless a motivated reframing
  explains the change. Avoid resetting the horizon or camera scale at a cut.
- Recurring actions need a shared time source. Derive global/source seconds from
  the sequence's actual timeline start plus local `frame / fps`. Do not restart
  rotation, flowing water or smoke at frame zero in every scene.
- For continuous camera travel, evaluate the same path from that shared clock.
  Do not apply a separate ease-in-out to each piece of one uninterrupted move:
  it makes the camera stop at every boundary. Use one path or match velocity.
- Use an occluding object from the world to hide a setting change where useful.
  An architectural pass should feel like crossing a wall, not a decorative wipe.
  Choose a small vocabulary; a clean match cut is often sufficient.

## Overlap without losing narration sync

Keep the voice and subtitles in one shared timing group for a continuous take.
The illustration `TransitionSeries` may overlap independently. Record the
visual start and the spoken cue for each shot.

If a shot's narration starts at frame `A` and its incoming illustration overlap
is `O`, its visual sequence starts at `A - O`; add `O` to that sequence's duration
so all starts after subtracting overlaps still match the approved timeline.
Local spoken time is `localFrame / fps - O / fps`. Global source time is
`(A - O + localFrame) / fps`. Verify the cumulative result, including any outgoing
overlap. Do not subtract transitions from a duration already measured from the
voice without compensating: that silently shortens the film.

Use actual word timings for important reveals. A cue tied to “steam” should
happen as the recording says it, not at an arbitrary fraction of a shot.

## Cover the camera's whole view

For a centered 2D camera at world point `(cx, cy)` and scale `z`, the visible world
is `cx ± width / (2*z)` by `cy ± height / (2*z)`. Union those bounds across the
whole move, including intermediate positions, then add room for shadows and
moving subjects. Pulling from 1.16 to 0.94 exposes more than the original frame.
For rotated cameras, inverse-transform all viewport corners and include them.

Extend the illustrated sky, floor, river, shadows and paths into that area.
Scaling down a full-frame PNG exposes a rectangle; a solid background color does
not repair a severed riverbank or floor. Check SVG viewBoxes and clipping masks.

[`CameraRig.tsx`](../../remotion-themes/themes/cut-paper/assets/motion/CameraRig.tsx) supplies a deterministic 2D move and
source-clock helper. Install `camera` through the selective asset helper. Pass `sourceSeconds` when continuing a world camera across independently timed scene groups. Its coordinate system
uses composition pixels and a world center. It provides no art, parallax or
automatic continuity. Keep captions outside its transformed subtree. Prefer
inline editable Remotion keyframes for simple shots; a reusable rig is useful
when coordinating the world requires it.

## Check the motion

Inspect the start, landing, mid-action, exit and largest camera travel of each
shot, plus several frames throughout each transition. Scrub or play at native
speed when possible. Check for edge exposure, velocity jumps, doubles, geometry
breaks, captions moving with the camera and mechanisms resetting. Several stills
can reveal geometry faults but cannot prove perceived smoothness. Record what
was viewed or played in the QA report and fix the observed failures.

## People, contact and paths

Install the canonical person and journey assets before rebuilding a walker. Keep ground baselines explicit; cumulative distance determines foot phase. Do not independently slide a character over the floor while cycling timer-driven feet. Keep height/stride/facing stable within a stride; change shot scale with the camera. Review heel contact, toe-off, passing, starts/stops, held props and mirrored travel. A source-time loop does not prove physical contact; inspect the actual shot. Use arc-length motion for constant-speed path following and link wheel rotation to travelled distance.

## Current asset-first order

Read [asset-first production](asset-first-workflow.md). Create and inspect layered subject art, save ready
versions in the main skill-set `assets/library/`, then assemble film scenes. Asset proofs and
project scaffolds can run earlier. Design coverage and anchors for the actual camera/motion.
A project-only copy does not preserve artwork for future agents; archive revisions and refresh
their previews before updating the skill set.
