# Current studio defaults — 1.4.0

This is the current production reference for the complete installed skill set. Explicit user instructions take priority. Technical/API references remain useful for their stated task; their generic typography, example titles, TTS providers, transitions or clip layouts do not override the finished-film rules here.

## Start from the current visual references

Open Cut Paper [overview](../../remotion-themes/themes/cut-paper/images/overview.png), [street](../../remotion-themes/themes/cut-paper/images/production-street.png), [interior](../../remotion-themes/themes/cut-paper/images/production-interior.png), [process](../../remotion-themes/themes/cut-paper/images/production-process.png) and [character](../../remotion-themes/themes/cut-paper/images/production-character.png). They are generated with the reusable asset source and current lower captions. Preserve fibres, cream cut edges, tight/soft shadows, matte warm/teal/navy relationships and ink DM Sans. Adapt scenery and composition to the subject. Reference assets are not compulsory props in every shot.

Inspect the [asset catalog](../../remotion-themes/themes/cut-paper/assets/README.md) before rebuilding common elements. Search, select and install the dependency closure. Author the subject-specific explanation around suitable assets. Use the jointed `PaperPerson`/distance-based journey for people, then inspect its actual motion in context. Keep library version and asset IDs/adaptations in production notes.

## Asset-first production is required

After the existing plan approval, create/review the art before film scene assembly. Read the
[complete asset-first workflow](asset-first-workflow.md). Make an asset brief, search the core
catalog and saved story archive, create distinctive layered/editable subject art, review real
previews and isolated motion tests, then archive the ready packages in the **main skill set's**
`remotion-themes/themes/cut-paper/assets/library/`. Keep topic-specific packages there too.
Project-only files do not complete preservation. The shared source, previews, review records,
metadata and dependencies must work without the original video. Each project uses a versioned
snapshot under `assets/`. Run the asset readiness check before assembling scenes; finalization
checks again. The agent reviews assets without adding a user approval gate. Audio alignment can
run independently; assemble on the approved take's verified timeline.

Search/reuse saves effort, while each story still needs appropriate distinctive visuals.
Do not flatten an animated explanation into a poster or require arbitrary new asset counts.
Record a concrete reuse-only reason when existing artwork fully serves the brief. Save later
improvements as reviewed new versions, refresh their references, and merge the installed archive
into the checkout before replacing skills or packaging. The ZIP includes that complete archive.

## Finished explainer defaults

- Topic-specific cause/process/result animation and a coherent world fill the frame. Camera travel serves the explanation; the camera does not replace the action.
- Smooth frame-driven motion, a shared source clock, physical contact and continuity. Wheels follow distance; stance feet plant; paths have enough coverage; follow-through does not become permanent drifting.
- Use a small purposeful transition vocabulary. A clean cut is valid. Preserve recurring objects, direction and phase; do not add a stock wipe at every boundary or double-expose silhouettes in fades.
- No persistent chapter headings. Scene names are internal. Optional opening titles leave after their readable introduction; contextual labels identify an object/event and clear when done. No counters, progress bars, watermarks, generic outro or unrequested CTA.
- Default subtitles: actual spoken words, semantic phrases, at most two measured lines, stable cream backing and soft 160ms/120ms text changes with at most 6px travel. At 1080×1920 the plate is x80/y1500/w890/h148 with 272px below it. Titles/labels separately use top270/bottom420/right110 margins. Re-layout other aspect ratios; verify actual platform controls.
- Keep supplied voice bytes, content, start and speed. Use actual-audio alignment rather than duration divided by word count. One continuous voice source has one continuous caption clock even while illustrations cut.
- Restrained effects; music is optional. A verified float mix replaces render audio once. Master around -14 LUFS and true peak ≤-1 dBTP, then measure the actual AAC deliverable.

## Authorization and delivery

Video Director uses one script/storyboard approval and the user's voice take. Existing approval carries forward. Do not ask again for routine scenery, reusable assets, motion, captions or the authorized export. Standalone asset work follows the user's approved asset scope; it does not need narration or a new TTS gate. Do not request a provider/key or regenerate supplied speech because an optional API guide contains a TTS example.

Keep Studio open; inspect current theme images and rendered stills, scrub transitions and caption changes, and run normal-speed playback when available. Check loaded-font glyph bounds and physical contact. Probe/full-decode the final MP4; inspect its encoded frames and audio levels. Report evidence separately from subjective listening/playback. Install instructions cannot guarantee future visual quality: every film needs its own factual and visual review.

Historical studies, including [Industrial Revolution](industrial-revolution-example.md), explain useful camera relationships. Their old character drawings, higher captions and introductory layout are not current defaults. Cut Paper remains the sole theme; general map API references do not add a second visual theme.
