# Decision architecture — 3.1.0

This document defines process and authority. Project files define the film's creative treatment. Explicit user instructions take priority.

## Authority and context
Distinguish three kinds of information:
- **User requirements:** format, duration, medium, audience, references and preferences actually requested. Record a source and scope. Existing authorization persists.
- **Technical requirements:** accurate source timing, valid files, reproducible rendering, readable measured text, audio integrity and honest review evidence.
- **Project decisions:** script structure, palette, type, settings, characters, illustration method, shot design, transitions and sound treatment. Record the reason in this project.

An agent's earlier aesthetic choice does not become a user preference. Carry user requirements forward with their source; project decisions expire with their project. The optional [channel profile](../profiles/channel.json) records specific preferences from this user and is selected only when applicable. Other briefs can establish different requirements.

At startup, use the current brief, confirmed requirements and relevant evidence. Previous films and reference material enter as deliberately selected inputs with stated purposes. Load specialist/API knowledge when needed. The sixteen supplied skills are independent resources, not a mandatory reading sequence.

## Flow and outputs
1. **Understand:** establish purpose, audience knowledge, factual scope, constraints and unresolved assumptions. Research relevant mechanisms and claim limits.
2. **Treat:** develop a coherent explanation and visual approach. Write speech and shots as independent structures. Plan what the opening makes the viewer notice or understand; the opening form follows the subject.
3. **Direct the look:** choose setting/material/light/tone and readable visual hierarchy. Derive palette/type/production method from these decisions. Assign references explicit roles. Evaluate actual style frames before committing to full art.
4. **Prepare:** create required project artwork, layers, poses, rig controls and camera coverage; inspect in-context proofs and necessary motion tests. Keep sources/provenance in the project. Complete this before final assembly; corrections return here.
5. **Assemble:** align actual speech, author shot timing, subject action, camera, connections, captions and sound from prepared assets. A sentence may span shots and a shot may span sentences.
6. **Review:** assess actual creative results and technical operation independently. Fix observed faults and revisit affected stages.
7. **Deliver:** check the encoded file, report actual scope and hand over authorized artifacts.

The established script/storyboard approval applies when missing; existing authorization avoids renewed gates. Asset/style/motion reviews are the agent's responsibility. Voice analysis can proceed independently of artwork.

## Art direction and references
Colors are chosen through the actual setting, objects/materials, lighting, period/context, editorial tone, focal hierarchy and legibility. Topic labels do not prescribe hues. The project can use strong or restrained saturation when the treatment supports it.

References have roles such as material, depth, lighting, composition, type, motion or palette. A role limits what is being adopted. A material/depth example does not implicitly supply the palette. A named medium describes construction possibilities; it does not determine the cast, environment, narrator or sequence.

The shared package contains methods, optional font resources and technical tools. Original production artwork belongs to its project. Style-frame examples used for release evaluation are evidence, not startup templates.

## Motion, text and sound
For each adjacent shot, decide what the viewer should follow from outgoing to incoming focus. That relationship determines the camera/transition and its timing. A direct cut, hold or continuous move can be appropriate; actual playback judges the result. See [camera/continuity](camera-and-continuity.md).

Captions reproduce actual speech. Their type, colors, surface, layout and motion come from project decisions and applicable user requirements. Measure loaded glyphs and destination UI. Keep their source clock coherent with speech. Sound events correspond to authored actions or editorial intent; music and silence are considered in context.

## Review and learning
Creative review records observations about comprehension, opening, color/composition, action, pace and perceived joins. Engineering checks cover files, timings, bounds, contacts, decoding and audio. A technical result does not establish a creative result.

Keep source speech unchanged unless the user authorizes an edit; record its hash and verified alignment. Distinguish still inspection, playback, transcription, measurements and listening.

Feedback first updates the affected project. A broader workflow change needs evidence that it is useful across briefs and preserves intentional choices. Promote general technical fixes separately from contextual artistic choices. See [review and feedback](production-quality.md).
