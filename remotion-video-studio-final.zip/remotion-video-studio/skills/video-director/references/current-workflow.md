# Current production defaults — 1.6.0

This is the shared authority for all 16 installed skills. Explicit user instructions take priority.
Read relevant API references on demand; their generic fonts, TTS examples or layouts do not override
these production defaults. Cut Paper is the sole visual theme; map APIs remain optional implementation knowledge.

## Production order

Research and visual/script plan → one existing script/storyboard approval → create/review/archive
assets → actual-audio timing → assemble/animate/caption → inspect and render → preserve improvements → deliver.
Asset work may proceed after approval while narration is prepared; audio analysis is independent.
Scaffolds and isolated asset proofs are allowed earlier. Existing authorization carries forward.
Standalone assets require no voice take or new approval. Continue authorized film work through export.

## Assets and references

Open the real [theme overview](../../remotion-themes/themes/cut-paper/images/overview.png), native
[interior](../../remotion-themes/themes/cut-paper/images/production-interior.png),
[street](../../remotion-themes/themes/cut-paper/images/production-street.png),
[process](../../remotion-themes/themes/cut-paper/images/production-process.png) and
[character](../../remotion-themes/themes/cut-paper/images/production-character.png) pictures.
Inspect the [catalog](../../remotion-themes/themes/cut-paper/images/assets/catalog.html), search the
foundations and saved story archive, then design the subject's distinctive art. Preserve material,
palette and typography; adapt environments and composition. No stock setting is compulsory. Choose terrain, road/floor material and architecture from the actual story location; a green park is only one option.

Follow [asset-first production](asset-first-workflow.md). Save editable source, dependencies, previews,
metadata and genuine review evidence in the main skill set's `remotion-themes/themes/cut-paper/assets/library/`
**before scene assembly**, including topic-specific assets. Project snapshots are versioned copies.
Pass asset readiness; finalization checks again. Record a concrete reuse-only reason when existing art
fully serves the brief. Archive improvements as reviewed new versions and merge installed additions
before replacing skills or packaging. A future agent must not need the original video.

## Visual and motion defaults

- Explain cause/process/result through subject action. Use smooth frame-driven animation, purposeful
  camera scale/depth/travel, enough overscan and a small transition vocabulary. Clean cuts are valid.
- Preserve recurring objects, direction, physical contact and source time. Feet plant; wheels follow
  distance; hands/props share anchors. Camera movement supports the action. Bounded actions settle.
- Inspect human poses enlarged before using them: authored preparation/action/return, stable elbows,
  aligned wrists, readable fingers, planted feet and reachable contacts. A hand and its object share
  a transform/clock; an isolated object arc is not a pickup. Pouring follows the actual moving lip,
  keeps a horizontal free surface, enters the receiver mouth and respects its front rim.
- No persistent chapter headings, scene counters, progress UI, watermark, filler or forced CTA.
  Internal scene names stay hidden. Optional opening titles leave; useful labels attach to their objects.
- Captions follow actual spoken words in semantic phrases: at most two measured lines, DM Sans,
  stable cream backing, ~160ms in/120ms out and ≤6px travel. At 1080×1920 use x80/y1500/w890/h148
  (272px below backing). Titles/labels separately use top270/bottom420/right110 margins. Re-layout
  other formats and check actual controls. Captions stay outside the world camera and do not reset at cuts.
- Keep supplied voice bytes, words, start and speed. Align to actual speech; word-count estimates are
  insufficient. Use the supplied take directly; optional TTS/API guides do not require provider keys or replacement speech. Effects are restrained; music is optional. Master around -14 LUFS, true peak ≤-1 dBTP,
  then measure the encoded deliverable. A verified mix replaces render audio once.

## Evidence

Keep Studio open. Inspect stills, contacts, state/camera extremes, transitions, loaded text and subtitle
changes; review motion at normal speed when available. Check the actual encoded file and audio levels.
Record [QA](../assets/qa-report.template.md) honestly: files/metadata/tests support review, not artistic
judgment. Distinguish measurements, transcription, still review, playback and listening. No skill set
can certify the quality or factual accuracy of an unreviewed future film.
