# Source timing and delivery

Process: [decision architecture](current-workflow.md).

1. Prepare/review project artwork before final assembly using [asset preparation](asset-first-workflow.md). Audio analysis may proceed independently.
2. Copy supplied speech unchanged into `public/` and record SHA-256. `after_vo.py --project . --vo public/vo.wav` registers schema-3 speech without choosing shot boundaries or effects. Older scene plans use a clearly identified legacy estimator; their estimates remain unverified.
3. Compare actual spoken words with the approved script, resolve recognition errors with available evidence, and save source-relative word/phrase timestamps. Record the alignment method and set `vo.timing_verified` after review. Author shot frames/cues independently and keep consumed timing data synchronized. Original bytes, start and speed remain intact unless an edit is authorized.
4. Group captions according to speech/grammar and measured project layout. Supply explicit project style to the technical renderer or implement the chosen treatment. Review actual page changes and beginning/middle/end sync.
5. Author sound events with chosen files, levels and times. `auto_sfx.py` emits only these events; missing events mean no effects. Create/import project sound files first. Music selection/level is explicit. Review the mix; measurements and listening are different evidence.
6. Render with the chosen format. For standard H.264 upload delivery, explicitly request yuv420p/BT.709 and inspect actual metadata. Preserve mastered audio and timing through any required conversion.
7. `finalize.py --project . --comp Main --audio-master video/preview-mix.wav --out out/final.mp4` uses a current verified mix to replace render audio once. Omit the audio-master argument when inappropriate. The helper checks project readiness, masters sound to supplied target settings and verifies the encoded file. An intentionally non-narrated source with no audio can use explicit `--silent`; it preserves the picture without inventing audio and rejects existing narration/sound.
8. Inspect the actual encoded picture/movement and complete [creative and engineering QA](../assets/qa-report.template.md) independently. Verify full decode, ending, dimensions/fps/frames, original-source integrity and audio levels. State what was actually viewed/played/heard.
9. Keep artwork, speech, sources, decisions and evidence with the project. Asset corrections return to preparation and deliberate resealing. Deliver a clickable MP4 and useful SRT. Publish/push only with authorization.

Take duration and explicit tolerances from the current brief. If intact prerecorded speech creates a real conflict, resolve it with the user rather than silently cutting or changing speed. A creative intention and a clean command exit are different kinds of evidence.
