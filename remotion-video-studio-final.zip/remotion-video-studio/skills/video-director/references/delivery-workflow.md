<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](current-workflow.md).

# Reliable audio, timing and delivery

Resolve the installed `video-director/scripts` path from its `SKILL.md`. Commands
in that skill use `DIRECTOR_SCRIPTS` for this absolute path and run from the
project root. Do not assume these scripts exist in the new project's `scripts/`.

0. Complete [asset-first production](asset-first-workflow.md): create/review sources, save them in the main skill-set assets archive, and pass `check_assets.py` before scene assembly. Audio analysis may proceed independently.
1. Copy the supplied take unchanged into `public/` and record its SHA-256.
   `after_vo.py` accepts WAV/MP3/M4A/OGG directly and stores a portable public-relative
   path. Any decoded analysis copies belong in `video/`, never over the original.
2. Compare the actual words with the approved script. Use available transcription
   or alignment tools; local Whisper/faster-whisper or a documented transcription
   service are options, not bundled requirements. No ASR model is included here.
   If only transcription and waveform measurements are available, state that.
3. Treat `after_vo.py` boundaries as estimates even if its pause count matches.
   Align the transcript to actual speech; check sentence starts, breaths and the
   first/middle/last words. Save word/phrase timestamps and the alignment method.
   Fix scene boundaries in `video/plan.json`, set `vo.timing_verified` only after
   reviewing them, update any consumed `src/data/timing.json`, then run
   `auto_sfx.py` on the corrected plan. Do not rerun the pause estimator over a
   verified timeline. Silent inserted scenes and lead-ins need an authored
   shared source timeline; the estimator rejects them rather than shifting voice.
4. Group exact words into readable semantic caption pages. Check and correct
   recognition errors against the recording, without concealing a different take.
   Implement the renderer; the theme kit does not transcribe or create captions.
   An optional starting renderer is in
   [SmoothPaperCaptions.tsx](../../remotion-captions/assets/SmoothPaperCaptions.tsx).
   It requires pre-grouped, sorted, positive-duration, non-overlapping `Caption`
   pages, loaded fonts, measured line breaks and a continuous shared clock.
5. Author scene events on real visual actions. An explicit `events: []` means no
   effects. Regenerate cues after changing visual timing. Preview the complete
   mix; music is optional, and the voice must remain clear. Float WAV previews
   preserve headroom; a clipping mix must be fixed before mastering.
6. Render the picture. Prefer a verified uncompressed mix for final mastering:
   `finalize.py --project . --comp Main --audio-master video/preview-mix.wav
   --out out/final.mp4`. The master replaces the render's audio; it is not added
   to it. Confirm identical start, duration, levels and events first: duration
   equality alone cannot prove sync. Never auto-pick a possibly stale preview.
   Without `--audio-master`, the script masters the render's own audio.
7. `finalize.py` copies the video stream, writes fast-start MP4 with 48kHz AAC,
   audits loudness/true peak, and runs `verify_export.py` for metadata, frame
   count, full media decode and original-source integrity when recorded. Review
   all warnings. Inspect frames from the actual encoded file as well as Studio.
8. Complete [the QA report template](../assets/qa-report.template.md). Technical
   PASS does not prove camera feel, factual accuracy, subtitle legibility or
   audio intelligibility. Record separate evidence and limitations.
9. Save film-review asset changes as reviewed new versions with current previews; rerun asset readiness. Merge installed-library additions into the checkout before a skill/Git/ZIP update. Keep topic-specific assets in the main skill set as well as the project.
10. Deliver a clickable MP4 and, when useful, SRT. Keep source project, original
   voice, sources, credits and QA evidence locally. Publish or push artifacts
   only when the user's instruction authorizes it.

Keep the requested duration and its explicit tolerance in the plan. Do not infer
that a tolerance from a different video applies again. Preserve the complete
take and its speed; if the approved narration cannot fit, resolve that actual
conflict rather than silently truncating or retiming it. A brief calm visual tail
may complete the thought without becoming filler.
