# Reference: Industrial Revolution explainer

This 55-second, 1080×1920, 30fps film established the current local baseline:
[finished video](https://github.com/soomro211/remotion/blob/main/videos/industrial-revolution.mp4).
The link is an optional reference; the bundle's instructions and theme images
remain usable without repository access.

The useful patterns were:

1. Begin with an active spinning wheel. Show the title briefly, then let it leave.
2. Pull back from one machine toward many spindles as production scales up.
   Preserve a recognizable wheel, thread and person across the visual handoff.
3. Follow the power source from water into a steam-engine cutaway. Keep the wheel
   hub and turning phase coherent while the surroundings change.
4. Expand into railway and harbor scenery. A flywheel leads into a train wheel;
   wheels and transport continue moving through the transition.
5. Move through the town into a working interior using architecture as a reveal.
   The scene demonstrates migration and factory work instead of displaying a slogan.
6. Show the human costs with specific imagery. Return to the connected industrial
   world for a resolved ending, rather than inserting a generic follow card.

Subtitles used short phrases, a fixed paper backing above bottom controls and
gentle text fades. The continuous narration and captions shared one timing group;
art transitions did not restart the caption clock. The final mix used the
unchanged source voice and restrained effects, followed by encoded-file checks.

Reuse these relationships, not this exact sequence. A new subject needs its own
visual explanation, framing, movement, sources and pacing. This reference is not
proof that a new render passes QA. Future improvements should refine camera
velocity, depth, physical action and composition where they help understanding.
