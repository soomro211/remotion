<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](current-workflow.md). Apply the task-specific guidance below within those defaults.

# Reference: Industrial Revolution explainer

This historical 55-second, 1080×1920, 30fps film established useful camera relationships. Current people, material components and subtitle placement are demonstrated in the newer [production references](current-workflow.md).
Its reference stills are included in the skill bundle:
[factory](../../remotion-themes/themes/cut-paper/images/history/industrial-factory.png),
[steam](../../remotion-themes/themes/cut-paper/images/history/industrial-steam.png),
[harbor](../../remotion-themes/themes/cut-paper/images/history/industrial-harbor.png) and
[cotton field](../../remotion-themes/themes/cut-paper/images/history/industrial-cotton.png).
Use these local images; access to the original video repository is not required.

The useful patterns were:

1. Begin with an active spinning wheel. Show the title briefly, then let it leave.
2. Pull back from one machine toward many spindles as production scales up.
   Preserve a recognizable wheel, thread and person across the visual handoff.
3. Follow the power source from water into a steam-engine cutaway. Keep the wheel
   hub and turning phase coherent while the surroundings change.
4. Expand into railway and harbor scenery. A flywheel leads into a train wheel;
   wheels and transport continue moving through the transition.
5. Move through the town into a working interior using architecture as a reveal.
   The scene demonstrates migration and factory work instead of displaying a slogan.
6. Show the human costs with specific imagery. Return to the connected industrial
   world for a resolved ending, rather than inserting a generic follow card.

Subtitles used short phrases, a fixed paper backing above bottom controls and
gentle text fades. The current skill revision lowers the default plate to y=1500
at 1080×1920 (272px below its 148px height); use that updated specification for
new videos rather than copying this film's older caption height. The continuous narration and captions shared one timing group;
art transitions did not restart the caption clock. The final mix used the
unchanged source voice and restrained effects, followed by encoded-file checks.

Reuse these relationships, not this exact sequence. A new subject needs its own
visual explanation, framing, movement, sources and pacing. This reference is not
proof that a new render passes QA. Future improvements should refine camera
velocity, depth, physical action and composition where they help understanding.

Use the newer jointed walking rig for people. This historical film’s timer-driven limbs are retained as the explicit “before” in the walking comparison, not as a reusable animation source.
