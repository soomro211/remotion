# Project plan — schema 3

Process: [decision architecture](current-workflow.md). Starter: `assets/plan.template.json`.

## Authority records
`requirements`: `{key,value,source,scope}`. `source: {kind:"user",reference:"request/quote/location"}` identifies an actual instruction. Use `kind:"assumption"` for inferred choices; `scope` is `project` or `session`. `assumptions` records unresolved interpretations. CLI configuration is recorded as an assumption until supported by a user instruction. Optional profiles add traceable user preferences when explicitly selected.

`title`, `theme`, `width`, `height`, `fps`, `target_seconds` are unset at initialization except a user-supplied CLI value. Fill from the brief/treatment. `brief` records purpose, audience, prior knowledge, scope, takeaway and evidence links.

## Speech and shots are independent
`narration: [{id,text,proof:[]}]` contains exact spoken paragraphs. `shots: [{id,purpose,visual,action,framing,camera,connection_to_next,spoken_cues:[],events:[]}]` contains illustrated shots. `spoken_cues` references narration IDs and optional actual words. Any many-to-many relation is valid. Shot timing is authored after speech alignment; paragraph count/pauses do not determine cuts.

`voice`: project-specific persona, tone, pace, accent, energy, `wpm`, `pause_ms`, pronunciations. Numeric estimates support planning, not final alignment. Narration can be absent for a deliberately non-narrated film.

## Art and sound decisions
`treatment`: chosen approach/reason, opening/ending intent, considered options if useful, and `art_direction`:
- `setting`, `materials`, `lighting`, `context`, `tone`, `production_method`: `{value,reason}`.
- `palette: {roles:{role:color},reason,evidence:[]}`: project colors and contextual reasoning.
- `typography: {roles:{role:font},reason}`: fonts selected for this project and their licence.
- `references: [{uri,roles:[],adopt,limits}]`: each reference's purpose and the bounds of influence.

`production.captions` records enabled status and explicit project renderer style/layout. A style can be adapted by format; the technical helper requires style values instead of supplying a universal visual treatment. `sound` records treatment/reason and explicit events; `music` is absent or a chosen public-relative track with level.

`production.asset_workflow` keeps the project-local source/proof readiness contract. Asset brief requirements use `shot_ids` (legacy `scene_ids` is supported). Every project decision stays in this project.

## Actual timing and handoff
After alignment, each shot receives `start_frame` and `duration_frames`; optional local events use `{t,file,volume,note}`. `total_frames` specifies delivery length. `vo` records public-relative `file`, duration, original hash, alignment method and `timing_verified`. Captions remain a separate exact source-relative JSON track.

`plan_docs.py` validates schema 3 and writes a reviewable plan, narration and voice prompt. It checks structure/traceability and reports unresolved choices; it cannot judge creative quality. Older scene-based projects are recognized as legacy records. Their existing sources/exports remain intact; current production uses schema 3.
