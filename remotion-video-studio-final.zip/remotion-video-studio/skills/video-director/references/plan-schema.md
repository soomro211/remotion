<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](current-workflow.md).

# video/plan.json

Template: `assets/plan.template.json` (a complete 4-scene example). Fields:

| Field | Meaning |
|---|---|
| title, theme (`cut-paper`), fps, width, height | composition basics (1080x1920 at 30 fps default) |
| target_seconds, platform, audience | length and where it plays |
| creative_promise, the_one_thing | one sentence each (see remotion-preproduction) |
| voice | persona, tone, pace, wpm, accent, energy, pause_ms, pronunciations{word: how to say} -> these become the TTS style prompt |
| production | quality defaults and concrete art/motion/caption direction; see below |
| scenes[] | id, internal name, type, narration, onscreen[], visual, motion, transition, entrance, events[], proof? |
| scenes[].name | internal Studio/timeline name; never automatically rendered on screen |
| scenes[].type | `hook` `explain` `list` `payoff` `cta` |
| scenes[].onscreen | optional display copy, normally `[]` in explanatory scenes; not the subtitle transcript. Needed text: roughly 2-5 words per line, up to 3 lines. `list`: explicit useful data, up to 4 lines |
| scenes[].text_role | `opening-title`, `label`, `data`, `chapter`, or `cta`; required for nonempty onscreen. This records purpose, not an automatic layout |
| scenes[].text_window | `{start_s, end_s}` relative to scene start, with `0 <= start_s < end_s`; required for display copy. Scaffold defaults to at most the first 2.5 seconds when absent. Adjust to actual reading time after the voice arrives |
| scenes[].text_purpose | explain why a label/chapter/data display is useful, especially when it remains throughout a shot |
| scenes[].motion, scenes[].transition | concrete subject/camera action and continuity/reason for the transition; author these in scene code |
| scenes[].entrance | `slide` `pop` `stamp` `drop` `none` |
| scenes[].events | `{t: seconds from scene start, kind, gain_db?}`; kinds: transition whoosh land pop reveal tick cta riser type ping pin route zoom error |
| scenes[].proof | source for any number or claim in the scene (required when digits appear) |
| scenes[].paper.variant | cut-paper only: `day` `sunset` `dusk` `mint` |
| cta | optional final call to action text; empty string is normal for an educational payoff |
| music | `null` or `{file, volume}` |
| open_questions | `{q, default}` |

Initially written by timing scripts, then corrected after actual-audio alignment: scenes[].start_frame,
duration_frames, vo_start_s, vo_end_s; total_frames; vo{file,duration_s,timing_method,timing_verified,original_sha256}.
`vo.file` is relative to `public/`, with no machine-specific absolute path. `timing_verified` starts false.
Keep any consumed `src/data/timing.json` in sync with the corrected plan. The original hash verifies
source bytes, not the final mix alignment. Do not rerun estimated timing over a verified timeline.

## Production settings

The template includes `production.quality_version`, `theme_reference_review`, `visual_direction`,
`motion`, `camera_plan`, `transitions`, `headings`, `captions`, `ending` and `overrides`.

- `theme_reference_review`: fill after opening the actual reference images. Record what material,
  palette and typography are preserved and what scenery is adapted for this topic. Do not claim
  the review from reading filenames alone. The template leaves this empty intentionally.
- `camera_plan`: explain focus, scale, travel, depth and continuity across the whole film. Each
  scene still needs its own concrete move/hold and handoff in `motion` / `transition`.
  See [camera and continuity](camera-and-continuity.md).
- `headings`: defaults to `{persistent: false, scene_names_visible: false, opening_title: "optional; brief and timed to leave"}`.
- `captions`: defaults to enabled, `style: "theme-matched"`, `placement: "lower-safe"`, `max_lines: 2`,
  semantic phrases around `phrase_words: [4, 7]`, soft text changes and `persistent_backing: true`.
  `plate_1080x1920` defaults to `{x:80, y:1500, width:890, height:148}`: 272px below the
  backing. This lower subtitle lane is independent of conservative title/label margins.
  It records layout direction; custom renderers must honor it and adapt other formats.
- `overrides`: a list of explicit user requests or brief-specific reasons that override a default,
  for example `"User requests no subtitles"`. Do not silently change the user's format.

These are planning/QA settings. The scaffold does not automatically create bespoke scenery,
transcribe audio or implement subtitles; the agent must author and verify those steps. It does
honor display-text windows, hides empty onscreen arrays without falling back to scene names,
and uses smooth ambient motion by default. Essential diagram labels/data may remain when needed;
author their object-relative placement rather than rendering them as giant title slips.

Rules of thumb: 4-7 shots for 20-35 s, varied by story; narration of one shot = 1-2 short sentences.
The ending resolves the explanation visually; a CTA is optional. Most explanatory shots have no
main heading. An optional opening title normally leaves after about 1-2.5 seconds, adjusted for
readability. Captions follow the actual voice recording separately from these display-text windows.
Read [production quality defaults](production-quality.md).

## Asset-first production records

`production.asset_workflow` defaults to `{required: true, brief: "assets/brief.json", manifest:
"assets/manifest.json", readiness_report: "video/asset-check.json", shared_archive:
"remotion-themes/themes/cut-paper/assets/library"}`. These are portable paths relative to the
project or installed skill, never an absolute machine location. The planner records asset needs;
readiness is completed after approval by creating, reviewing and archiving actual art.
`init_video.py` creates an intentionally incomplete asset brief without overwriting existing work.
The brief lists unique requirement keys, purpose, scene IDs and kind (`new`, `adapt`, `reuse`,
`core`); core selections list `asset_ids`. The archive helper writes the project's version bindings.
See [the asset-first workflow](asset-first-workflow.md) for the exact commands and package fields.
Run readiness before scene assembly; `finalize.py` repeats it for this production contract.
Legacy plans without an asset-first block remain technically supported and print a notice;
new films must use the current template rather than remove the block to skip preservation.

## Foundational asset records

`production.asset_library` records `{version, selected: [], adaptations: []}`. Select after inspecting the catalog; keep an empty selection when the scene needs entirely bespoke assets. `scenes[].asset_ids` can identify the components used in that shot. Record deliberate changes to anatomy, contact, coordinate anchors or material; recheck the resulting motion. These fields document choices and do not automatically place or animate assets.
