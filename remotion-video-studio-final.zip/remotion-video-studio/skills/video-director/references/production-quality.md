Production defaults: [current workflow](current-workflow.md).

# Visual direction and review

Make the explanation specific enough that swapping the topic would break the visuals. Choose a
hero/process, a clear cause/result and one memorable visual turn. A collection of props or animated
headlines is not an explanation. Research factual mechanisms before drawing them.

## Before assembly

Write the asset brief around planned actions and camera coverage. Search both catalogs, inspect real
references, create/adapt distinctive editable art and archive reviewed versions in the main skill
set. Follow [asset-first production](asset-first-workflow.md). Do not turn the catalog into a repeated
park/room template. Universal assets save geometry work; staging and explanatory action remain authored.

For each shot, decide its focal object, scale, depth planes, action, hold, camera move and handoff.
Keep the frame composed without reserving a permanent title area. Plan caption space separately.
Use [camera and continuity](camera-and-continuity.md) and the [universal recipes](../../remotion-themes/themes/cut-paper/assets/UNIVERSAL.md)
for anchors, pivots, distance-linked travel and bounded motion. Keep illustrative models/data honest.

## Review the actual picture

Inspect opening, settled, mid-action and exit stills; sample each transition and extreme camera pose.
Then scrub/play at normal speed when available. Check:

- Silhouette and contrast at phone size; matte texture, cut edges, consistent scale and restrained shadows.
- Source-time continuity, path joins, frame-rate independence, believable speed and clean starts/stops.
- Feet/floor, hands/items, seats/supports, hinge pivots and distance/rotation relationships.
- Overscan and occlusion: no exposed canvas, floating pieces, bad clipping, duplicate SVG IDs or ghosted fades.
- Opening-title exit; purposeful object labels; no persistent headings or template debris.
- Captions: loaded DM Sans, exact words/timing, stable backing, ≤2 measured lines, lower lane and smooth changes.

Inspect hands, faces and liquids at close range, then their actual transition poses. Reject elbow flips,
floating loads, sideways hose-like pouring, slippery feet and effects that continue after their source stops.
Check a quiet scene as carefully as a busy scene; do not use an effect to hide a contact error.

Correct visible faults before adding decorative motion. If only stills or measurements were available,
state that scope. Technical PASS does not establish that the motion feels right.

## Encoded delivery

Preserve source speech, use its verified timeline and inspect the final MP4 for full ending, timing,
missing assets, frames/dimensions/fps, complete decode and measured audio. Review encoded stills and
movement as well as Studio. Finish the [QA report](../assets/qa-report.template.md), archive revised
assets with current proofs, and deliver the authorized artifact. Record concrete limitations instead
of blanket assurances. Keep detailed audio procedures in [delivery workflow](delivery-workflow.md).
