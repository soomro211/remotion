# Production defaults for finished videos

Read this before planning and again before export. These defaults apply to this
studio's videos unless the user asks for something else. They record the lessons
from the rainbow, communism, capitalism, rivers and Industrial Revolution explainers. Preserve each
improvement in the next project; do not wait for the user to request it again.
Existing videos are references, not templates to copy unchanged. Read
[camera and continuity](camera-and-continuity.md) and the
[Industrial Revolution example](industrial-revolution-example.md) for concrete shot patterns.
Quality comes from executing and reviewing these choices; installing a skill alone cannot guarantee it.

## Visual storytelling and theme fidelity

- Open the selected theme's actual overview and representative images with an
  image viewer, and read its `THEME.md`. Reading filenames or palette tokens is
  insufficient. Describe the material, edges, shadows, typography and color roles
  you will preserve in the production brief.
- Treat the theme as an art direction system. Build scenery, objects, diagrams and
  backgrounds for the topic: a watershed for rivers, a marketplace for economics,
  a droplet for optics. The sample sun, hills, sky and title cards are examples,
  not mandatory scenery. New illustrations within that material system do not
  require switching to a custom theme or asking for another approval.
- Fill the frame with a coherent world. Plan a visual action for each narration
  beat that demonstrates its cause, process or result. Moving a camera over a
  static poster alone is not a sufficient explanation.
- Vary shot scale, composition, foreground and background as the story requires.
  Keep recurring objects recognizable across shots. Use a clear focal point and
  leave room for captions. Avoid unrelated decorative icons and stock layouts.
- The supplied `PaperVideo` components are scaffolds for checking
  timing, fonts and assets. Author the topic-specific scenes before calling the
  result finished. Do not ship the stock background with a different heading
  on every scene.

## Titles, labels and subtitles have different jobs

**Default: no persistent main headings.** Scene names are internal editing
metadata and must never become visible automatically. For most explanatory
scenes, set `onscreen: []`; the illustrations and narration carry the explanation,
and subtitles provide the spoken words.

- An opening title is optional. When useful, introduce it briefly over an already
  active visual, normally about 1–2.5 seconds for a short title. Give it enough
  reading time, then remove it and use that space for the scene. Do not reserve
  an empty header area after it leaves.
- Do not pin chapter slogans such as “WATER FINDS A WAY DOWNHILL” or “SMALL
  STREAMS JOIN, A RIVER GROWS” over an entire explanation. Do not replace them
  with a new large billboard at every cut.
- A short label, arrow, unit, formula, place name or comparison may appear when it
  helps the viewer identify something. Attach it to the relevant object or event,
  give it an explicit appearance and removal cue, and clear it once its job ends.
  Essential diagram labels or data may remain while the viewer needs them.
- A genuine chapter break, requested tutorial step, brand/legal text or text-led
  format may need longer text. State its purpose; this is not a blanket ban on
  useful typography. Do not invent a heading just to fill a template.
- End an explainer on the visual payoff or resolved process. A promotional CTA,
  follow prompt, logo card or outro slogan is optional and must serve the brief.
- Never add frame counters, scene numbers, progress bars, decorative timestamps,
  debug labels, watermarks or generic filler unless explicitly requested.

## Motion and transitions

- Smooth, continuous motion at the composition frame rate is the default,
  including for cut paper. Texture comes from the material, not compulsory
  frame stepping. Use stop motion only when requested or clearly chosen for the
  brief; do not confuse a paper style with choppy animation.
- Choreograph action, settle and readable holds. Use eased camera moves,
  restrained parallax and purposeful secondary motion. Avoid bouncing every
  object or making everything drift indefinitely.
- Prefer shared-object continuity, match cuts, camera travel and motivated
  reveals. Choose a small transition vocabulary, usually at most two types;
  transitions should explain a relationship or mark a change. A clean cut is
  valid. Do not put the same full-screen paper wipe at every boundary by default.
- Coordinate outgoing and incoming motion. Avoid blank flashes, resets,
  doubled objects, severed paths and abrupt changes in direction or velocity.
  Subtract transition overlap when calculating the final duration.
- Build art with enough overscan for the most extreme camera position. Inspect
  pullbacks and intermediate frames for exposed rectangular image boundaries,
  clipped SVG paths, flat path caps and broken joins. For connected curves,
  preserve tangent continuity when the intended shape should be smooth.
- Keep subtitles in screen space, outside the camera transform. Match recurring object position,
  scale and action phase across handoffs; use source/global time for continuous mechanisms.
- Preserve physical and causal sense: water flows downhill, particles follow the
  explanation, and an object does not jump to a new position without a reason.
- Drive motion deterministically from Remotion frames and configuration. Derive
  scene timing from the actual voice recording; use seconds/fps for authored
  offsets rather than scattering absolute frame constants.

## Subtitles by default

For narrated explainers, include accurate, theme-matched subtitles unless the
user opts out. Read [smooth subtitle defaults](../../remotion-captions/references/smooth-subtitles.md).

- Use short semantic phrases, usually 4–7 words and at most two balanced lines.
  Follow the actual recording. Do not substitute a paraphrase or a scene heading
  for the spoken transcript.
- Place them in a stable lower caption lane above platform controls, not at the
  bottom edge. At 1080×1920, a useful starting plate is x=80, y=1346, w=890,
  h=148 with roughly 52px DM Sans. Measure actual loaded glyphs and adapt to the
  phrase, composition and destination; these coordinates are not universal.
- Keep the backing and decoration mounted through phrase changes and short
  pauses. Animate the text gently, with about 120–180ms fades and optionally a
  movement of at most 6px. Do not pop a new paper card or tape onto every phrase.
- Caption timing belongs to its voice source, independently of illustration
  cuts. A single continuous voiceover may have one continuous caption overlay
  inside the same source group; independently edited clips need their own groups.

## Audio and timing

- Preserve the supplied narration file unchanged. Verify the transcript against
  it; do not cut content, alter delivery speed or regenerate the voice silently.
- Pause detection is an initial estimate. If it selects breaths instead of scene
  boundaries, align the approved transcript to the actual speech and inspect
  sentence pauses/waveforms. Record the method and confidence. Word-count timing
  is only a rough fallback and is not sufficient for final subtitle sync.
- A technical alignment failure alone is not a reason to demand another take.
  Ask only if the recording itself is unusable or the intended words cannot be
  established. Resolve analysis/decoder issues locally while keeping the original.
- Fit the requested duration and any explicitly allowed tolerance. Use a calm
  tail if needed, without slowing or truncating narration or adding filler.
- Use restrained, purposeful sound effects; do not put a hit on every subtitle.
  Normalize the final mix around -14 LUFS with a true-peak ceiling at or below
  -1 dBTP (normally target -1.5 dBTP). Verify the actual encoded deliverable.

## Required production review

Record concrete results in `video/qa-report.md`. A plan setting is an intention,
not proof that the rendered video passes.

1. Inspect opening, settled, mid-action and exit frames of every shot; inspect
   several frames inside every transition and at maximum camera travel.
2. Scrub or play transitions and caption changes at full speed. Check that
   opening titles leave, no scene names become billboards, and there are no
   counters, progress bars, unnecessary labels or frozen poster sequences.
3. Load the actual fonts before measuring. Check glyph bounds, line count,
   contrast and safe margins at phone size, including the longest subtitle.
   Count rendered lines instead of inferring line count from box height alone.
4. Check every caption change for flashes, missing backing, clipping, drifting
   plate size and overlapping ghost text. Prefer fixed geometry to phrase-sized
   backing. Check both phrase boundaries and the middle of longer holds.
5. Check narration alignment, intelligibility when listening is available,
   levels and clipping. State plainly if only measurements were possible;
   never claim listening or full-speed playback that was not performed.
6. Check the final MP4 itself: duration/frame count, complete ending, resolution,
   fps, playable video/audio, missing assets, audio loudness and true peak. An
   intermediate render or Studio screenshot is not the final encoded file.

Use [build QA](../../remotion-preproduction/references/qa.md) for the full checklist.
Fix failures before delivery. Preserve the single approved-plan/user-voiceover
workflow; these quality defaults introduce no additional approval gate.
