# Creative review, engineering review and feedback

Process: [decision architecture](current-workflow.md).

## Creative review
At treatment review, assess scope, evidence and whether an unfamiliar viewer can follow the explanation. Consider the opening's purpose and the chosen visual approach in relation to the brief.

During asset preparation, open actual style frames and contextual proofs at intended viewing size. Judge palette/material/light relationships, composition, silhouette, atmosphere and whether the chosen production method achieves the intended look. An unresolved visual problem returns to art production.

During assembly, view moving sequences at normal speed, including the opening, joins and ending. Assess what attention follows, whether actions explain anything, whether pacing fits the subject, and whether words/pictures support understanding. Inspect the complete cut in its intended sound context when available.

Record timecodes, observations, revisions and remaining uncertainties. Recheck affected sequences. Playback/listening unavailable means those assessments remain incomplete; stills and file tests establish different facts. Use [the QA record](../assets/qa-report.template.md).

## Engineering review
Check source/proof integrity, dependencies and runtime copies; frame-driven determinism; actual font/glyph bounds; image/camera coverage; source clocks and physical contacts where applicable. Inspect pose/contact extremes and transitions. Exclude hidden premounted elements from visible bounds checks.

Preserve supplied speech; compare the transcript, align actual words and check beginning/middle/end synchronization. Inspect the encoded metadata, complete decode, ending, readable captions, audio levels and true peak. Technical checks report only what they measured.

## Learning from feedback
Record the specific failure, its likely cause, the project revision and what evidence supports improvement. Visual choices remain contextual. A general technical correction can enter shared tooling; a proposed broader creative principle needs evaluation across briefs and room for intentional exceptions. User standing preferences retain their source and scope.

Release evaluation uses actual outputs and controlled changes to briefs: the same subject under different setting/tone and different subjects in the same medium. Judge appropriate response to those inputs. Similarity alone is not a failure; cosmetic difference alone is not a success. Keep evaluation examples outside startup creative inputs.
