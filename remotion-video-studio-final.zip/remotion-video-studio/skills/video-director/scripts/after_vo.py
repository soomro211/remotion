#!/usr/bin/env python3
"""Register an intact supplied take; schema 3 keeps shot timing independently authored."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--project',default='.');ap.add_argument('--vo',required=True);ap.add_argument('--plan',default='video/plan.json');a=ap.parse_args()
 root=Path(a.project).resolve();vo=Path(a.vo);vo=vo if vo.is_absolute()else root/vo;path=root/a.plan
 if not vo.is_file():sys.exit('voice file not found')
 try:relative=vo.resolve().relative_to((root/'public').resolve())
 except ValueError:sys.exit('Copy the original take unchanged under public/ first.')
 before=hashlib.sha256(vo.read_bytes()).hexdigest();p=json.loads(path.read_text())
 if p.get('schema_version')!=3:sys.exit('schema 3 required; older scene-based plans keep their existing exports')
 decoded=subprocess.run(['ffmpeg','-v','error','-i',str(vo),'-vn','-ac','1','-ar','48000','-f','s16le','-'],capture_output=True,check=True)
 duration=len(decoded.stdout)/96000
 if duration<=0:sys.exit('voice could not be decoded')
 old=p.get('vo',{});same=old.get('original_sha256')==before
 p['vo']={**(old if same else {}),'file':relative.as_posix(),'duration_s':duration,'original_sha256':before,'timing_verified':old.get('timing_verified',False) if same else False}
 path.write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
 print('Original take registered. Align actual words and author shot cues independently; no shot boundaries, effects or visual tail were inferred.')
 (root/'src/data').mkdir(parents=True,exist_ok=True);(root/'src/data/timing.json').write_text(json.dumps(p,indent=2)+'\n')
 if hashlib.sha256(vo.read_bytes()).hexdigest()!=before:sys.exit('FAIL original voice changed')
if __name__=='__main__':main()
