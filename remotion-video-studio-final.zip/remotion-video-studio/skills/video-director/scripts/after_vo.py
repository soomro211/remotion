#!/usr/bin/env python3
"""After the user sends the TTS audio: ONE command does timing + sound design.

  python3 after_vo.py --project . --vo public/vo.wav [--plan video/plan.json] [--music public/music.mp3]

= vo_to_timing.py (scene boundaries from the voice pauses, writes plan + src/data/timing.json)
+ auto_sfx.py     (cues on exact frames, src/sfxCues.ts, cue-sheet.md, preview-mix.wav).
Accepts mp3/m4a/ogg/wav directly; supplied audio is never overwritten.
This estimates boundaries; transcript and caption alignment still need review."""
import argparse, hashlib, json, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--project', default='.'); ap.add_argument('--vo', required=True); ap.add_argument('--plan', default='video/plan.json'); ap.add_argument('--music'); ap.add_argument('--tail', default='1.2'); a = ap.parse_args()
    proj = Path(a.project).resolve(); vo = Path(a.vo); vo = vo if vo.is_absolute() else proj / vo; plan = proj / a.plan
    if not vo.exists(): sys.exit(f'voice file not found: {vo}')
    try: public_path = vo.resolve().relative_to((proj / 'public').resolve())
    except ValueError: sys.exit('Copy the original voice file unchanged under public/ first, then pass that path.')
    before = hashlib.sha256(vo.read_bytes()).hexdigest()
    r = subprocess.run([sys.executable, str(HERE / 'vo_to_timing.py'), str(plan), str(vo), '--tail', a.tail]); 
    if r.returncode: sys.exit(r.returncode)
    p = json.load(open(plan)); p['vo'].update(file=public_path.as_posix(), original_sha256=before)
    json.dump(p, open(plan, 'w'), indent=2, ensure_ascii=False)
    (proj / 'src' / 'data').mkdir(parents=True, exist_ok=True); json.dump(p, open(proj / 'src' / 'data' / 'timing.json', 'w'), indent=1, ensure_ascii=False)
    cmd = [sys.executable, str(HERE / 'auto_sfx.py'), str(plan), '--project', str(proj), '--vo', str(vo)] + (['--music', a.music] if a.music else [])
    r = subprocess.run(cmd)
    if hashlib.sha256(vo.read_bytes()).hexdigest() != before: sys.exit('FAIL: supplied voice file changed')
    if r.returncode: sys.exit(r.returncode)
    print('Original audio preserved. Verify the transcript, align captions and review estimated scene boundaries before building.')
if __name__ == '__main__': main()
