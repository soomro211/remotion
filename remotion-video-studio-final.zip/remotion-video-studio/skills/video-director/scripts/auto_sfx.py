#!/usr/bin/env python3
"""Emit explicitly authored project sound events; no theme/scene-based sound selection."""
import argparse,json,math,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;SOUND=HERE.parents[1]/'remotion-sound-design/scripts'
def number(x):return isinstance(x,(int,float))and not isinstance(x,bool)and math.isfinite(x)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('plan');ap.add_argument('--project',default='.');ap.add_argument('--vo');ap.add_argument('--music');ap.add_argument('--no-preview',action='store_true');a=ap.parse_args()
 root=Path(a.project).resolve();p=json.loads(Path(a.plan).read_text());fps=p.get('fps');shots=p.get('shots',p.get('scenes',[]));cues=[]
 if not number(fps)or fps<=0:sys.exit('choose a valid fps before emitting sound')
 for shot in shots:
  events=shot.get('events',[])
  if not isinstance(events,list):sys.exit('events must be an array')
  for ev in events:
   if not isinstance(ev,dict)or not number(ev.get('t'))or ev['t']<0 or not number(ev.get('volume'))or ev['volume']<0:sys.exit('sound events need explicit finite t and volume')
   if not isinstance(shot.get('start_frame'),int)or not isinstance(shot.get('duration_frames'),int):sys.exit('author actual shot timing before placing sound')
   rel=ev.get('file');relpath=Path(rel)if isinstance(rel,str)else Path('/')
   if relpath.is_absolute()or '..'in relpath.parts:sys.exit('event file must be relative to public/sfx')
   sound=(root/'public/sfx'/relpath).resolve()
   if not sound.is_relative_to((root/'public/sfx').resolve())or not sound.is_file():sys.exit('missing project sound: '+str(rel))
   frame=shot['start_frame']+round(ev['t']*fps)
   if frame>=shot['start_frame']+shot['duration_frames']:sys.exit('sound event lies outside its shot')
   cues.append({'file':relpath.as_posix(),'frame':frame,'volume':ev['volume'],'note':ev.get('note',shot['id'])})
 total=p.get('total_frames')
 if not isinstance(total,int)or isinstance(total,bool)or total<=0:sys.exit('author total_frames before emitting a mix')
 cues.sort(key=lambda x:x['frame']);cj={'fps':fps,'duration_frames':total,'sfx_dir':str(root/'public/sfx'),'cues':cues}
 def public_file(value):
  q=Path(value);q=q if q.is_absolute()else root/'public'/str(value).removeprefix('public/')
  if not q.is_file():sys.exit('missing project audio: '+str(q))
  return q
 if not a.no_preview:
  vo=a.vo or (p.get('vo')or{}).get('playback_file')or(p.get('vo')or{}).get('file')
  if vo:cj['vo']={'file':str(public_file(vo))}
  music=a.music or(p.get('music')or{}).get('file')
  if music:
   settings=p.get('music')or{}
   if not number(settings.get('volume')):sys.exit('selected music needs an explicit project volume')
   cj['music']={'file':str(public_file(music)),'volume':settings['volume'],'duck_db':settings.get('duck_db',0)}
 (root/'video').mkdir(exist_ok=True);cp=root/'video/cues.json';cp.write_text(json.dumps(cj,indent=2)+'\n');(root/'src').mkdir(exist_ok=True)
 cmd=[sys.executable,str(SOUND/'mix_preview.py'),str(cp),'--out',str(root/'video/preview-mix.wav'),'--emit',str(root/'src/sfxCues.ts')]
 if a.no_preview:cmd.append('--emit-only')
 subprocess.run(cmd,check=True)
 rows='\n'.join(f"| {c['frame']/fps:.3f} | {c['file']} | {c['volume']} | {c['note']} |"for c in cues)
 (root/'video/cue-sheet.md').write_text('# Authored cue sheet\n\n| Seconds | File | Level | Reason |\n|---|---|---|---|\n'+rows+'\n')
 print(str(len(cues))+' explicit cues emitted; no sound choices inferred.')
if __name__=='__main__':main()
