#!/usr/bin/env python3
"""Check that reviewed visual sources are preserved in the permanent skill library."""
import argparse
import importlib.util
import sys
from pathlib import Path


def check_project(project, library=None):
    source = Path(__file__).resolve().parents[2] / 'remotion-themes/scripts/asset_workflow.py'
    spec = importlib.util.spec_from_file_location('studio_asset_workflow', source)
    workflow = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(workflow)
    result = workflow.check(project, library or workflow.LIBRARY)
    workflow.write_json(project / 'video/asset-check.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path('.'))
    parser.add_argument('--library', type=Path, help='explicit permanent shared archive override')
    args = parser.parse_args()
    result = check_project(args.project.resolve(), args.library.resolve() if args.library else None)
    print(result['status'] + ': reviewed sources preserved in the main skill-set assets library.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError) as exc:
        sys.exit('Asset readiness failed: ' + str(exc))
