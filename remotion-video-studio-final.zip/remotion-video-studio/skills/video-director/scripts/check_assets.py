#!/usr/bin/env python3
"""Validate prepared project-local artwork. --seal records reviewed file hashes.
This checks evidence/integrity, never artistic quality, originality or chronology.
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def initialize(project):
    defaults = {
        'brief.json': {'schema_version': 2, 'reference_review': '', 'visual_direction': '', 'requirements': []},
        'manifest.json': {'schema_version': 2, 'stage': 'draft', 'assets': []},
    }
    for name, data in defaults.items():
        path = project / 'assets' / name
        if not path.exists(): write_json(path, data)
    for name in ('source', 'review'):
        (project / 'assets' / name).mkdir(parents=True, exist_ok=True)


def check_project(project, seal=False):
    project = Path(project).resolve()
    report = project / 'video/asset-check.json'
    # Invalidate an earlier PASS before any validation can fail.
    write_json(report, {'status': 'NOT_CHECKED', 'scope': 'Project-local asset evidence/integrity only.'})
    brief = json.loads((project / 'assets/brief.json').read_text())
    manifest_path = project / 'assets/manifest.json'
    manifest = json.loads(manifest_path.read_text())
    if not isinstance(brief, dict) or not isinstance(manifest, dict): raise ValueError('asset records must be JSON objects')
    if brief.get('schema_version') != 2 or manifest.get('schema_version') != 2:
        raise ValueError('schema 2 project-local asset records required; explicitly migrate older snapshots, do not delete them')
    for key in ('reference_review', 'visual_direction'):
        if not isinstance(brief.get(key), str) or len(brief[key].strip()) < 20:
            raise ValueError('complete the asset brief: ' + key)
    if manifest.get('stage') != 'prepared-before-assembly':
        raise ValueError('asset preparation/review is incomplete')
    requirements = brief.get('requirements')
    assets = manifest.get('assets')
    if not isinstance(requirements, list) or not requirements or not isinstance(assets, list):
        raise ValueError('nonempty requirements and asset list required')
    reqs = {}
    plan_path = project / 'video/plan.json'
    plan = json.loads(plan_path.read_text()) if plan_path.exists() else {}
    if plan.get('schema_version') == 3:
        context = plan.get('treatment', {}).get('art_direction', {})
        context_hash = hashlib.sha256(json.dumps(context, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        if not seal and manifest.get('review_context_sha256') != context_hash:
            raise ValueError('art-direction context changed/unsealed; inspect affected artwork, then deliberately run --seal')
        manifest['review_context_sha256'] = context_hash
    scene_ids = {s['id'] for s in plan.get('shots', plan.get('scenes', []))}
    for req in requirements:
        if not isinstance(req, dict): raise ValueError('requirements must be objects')
        key = req.get('key')
        if not isinstance(key, str) or not re.fullmatch(r'[a-z0-9][a-z0-9-]*', key) or key in reqs:
            raise ValueError('requirements need unique descriptive keys')
        if not req.get('purpose') or not isinstance(req.get('moving'), bool):
            raise ValueError(key + ': purpose and explicit moving boolean required')
        scenes = req.get('shot_ids', req.get('scene_ids'))
        if not isinstance(scenes, list) or not scenes or any(not isinstance(s, str) for s in scenes):
            raise ValueError(key + ': shot_ids required')
        if scene_ids and not set(scenes) <= scene_ids:
            raise ValueError(key + ': unknown shot_ids')
        reqs[key] = req

    def local(relative, prefixes):
        if not isinstance(relative, str) or '\\' in relative:
            raise ValueError('use project-relative POSIX file paths')
        p = Path(relative)
        if p.is_absolute() or '..' in p.parts or not any(relative.startswith(x + '/') for x in prefixes):
            raise ValueError('asset path outside allowed project directory: ' + relative)
        target = project / p
        if not target.resolve().is_relative_to(project) or any(part.is_symlink() for part in [target, *target.parents] if part != project and part.is_relative_to(project)):
            raise ValueError('asset symlinks/escaping paths are not portable: ' + relative)
        if not target.is_file() or target.stat().st_size == 0:
            raise ValueError('missing/empty asset file: ' + relative)
        return target

    keys = set()
    prepared = []
    for asset in assets:
        if not isinstance(asset, dict): raise ValueError('manifest assets must be objects')
        key = asset.get('key')
        if key not in reqs or key in keys:
            raise ValueError('unknown/duplicate manifest key: ' + str(key))
        keys.add(key)
        if asset.get('status') != 'ready' or asset.get('origin') not in ['project-specific','created-for-project','user-supplied','licensed-for-project']:
            raise ValueError(key + ': review and project-specific origin required')
        source = asset.get('source_files')
        previews = asset.get('preview_files')
        motion = asset.get('motion_files', [])
        if not isinstance(source, list) or not source or not isinstance(previews, list) or not previews or not isinstance(motion, list):
            raise ValueError(key + ': source, preview and motion file lists required')
        files = {}
        def add(relative, prefixes):
            p = local(relative, prefixes)
            files[relative] = hashlib.sha256(p.read_bytes()).hexdigest()
            return p
        for rel in source:
            p = add(rel, ['assets/source'])
            if p.suffix.lower() not in {'.svg', '.tsx', '.ts', '.png', '.jpg', '.jpeg', '.webp', '.psd', '.ora', '.blend', '.json', '.css'}:
                raise ValueError(key + ': unsupported source type: ' + rel)
            if p.suffix in {'.ts', '.tsx', '.css', '.svg'}:
                text = p.read_text()
                if re.search(r'(?:[\'\"])/(?:workspace|tmp|home)/', text):
                    raise ValueError(key + ': source contains an external machine path; preserve it inside the project')
                if p.suffix in {'.ts', '.tsx'}:
                    for imported in re.findall(r'(?:from\s*|import\s*)[\'\"](\.[^\'\"]+)[\'\"]', text):
                        base = p.parent / imported
                        candidates = [base, *[Path(str(base) + x) for x in ('.ts', '.tsx', '.json', '.svg')], base / 'index.ts', base / 'index.tsx']
                        resolved = next((x for x in candidates if x.is_file()), None)
                        if resolved is None or not resolved.resolve().is_relative_to(project):
                            raise ValueError(key + ': missing/escaping relative source import: ' + imported)
        for rel in previews:
            p = add(rel, ['assets/review'])
            if p.suffix.lower() not in {'.png', '.jpg', '.jpeg', '.webp'}:
                raise ValueError(key + ': an actual picture proof is required')
        if reqs[key]['moving'] and not motion:
            raise ValueError(key + ': moving artwork needs a motion proof')
        for rel in motion:
            p = add(rel, ['assets/review'])
            if p.suffix.lower() not in {'.mp4', '.webm', '.gif'}:
                raise ValueError(key + ': motion proof must be a viewable clip')
        notes = add(asset.get('review_notes'), ['assets/review'])
        if len(notes.read_text().strip()) < 40:
            raise ValueError(key + ': write specific review observations and limitations')
        copies = asset.get('runtime_copies', [])
        if not isinstance(copies, list): raise ValueError(key + ': runtime_copies must be a list')
        for copy in copies:
            if not isinstance(copy, dict) or not isinstance(copy.get('source'), str) or not isinstance(copy.get('target'), str): raise ValueError(key + ': runtime copies need source/target paths')
            if copy['source'] not in source:
                raise ValueError(key + ': runtime copy source is not canonical')
            add(copy['target'], ['public/assets', 'src/assets'])
            if files[copy['source']] != files[copy['target']]:
                raise ValueError(key + ': runtime copy differs from source')
        if not seal and asset.get('files') != files:
            raise ValueError(key + ': changed/unsealed files; review changes, then deliberately run --seal')
        asset['files'] = files
        prepared.append({'key': key, 'source_files': source, 'review_notes': asset['review_notes']})
    if keys != set(reqs): raise ValueError('unprepared requirements: ' + ', '.join(sorted(set(reqs) - keys)))
    # Relative source dependencies must be inventoried so later edits invalidate readiness.
    inventoried = {name for asset in assets for name in asset['files']}
    for relative in sorted(inventoried):
        if relative.startswith('assets/source/') and Path(relative).suffix in {'.ts', '.tsx'}:
            p = project / relative
            for imported in re.findall(r'(?:from\s*|import\s*)[\'\"](\.[^\'\"]+)[\'\"]', p.read_text()):
                base = p.parent / imported
                candidates = [base, *[Path(str(base) + x) for x in ('.ts', '.tsx', '.json', '.svg')], base / 'index.ts', base / 'index.tsx']
                dep = next(x for x in candidates if x.is_file()).resolve()
                if dep.is_relative_to(project / 'assets/source') and dep.relative_to(project).as_posix() not in inventoried:
                    raise ValueError('unrecorded source dependency: ' + dep.relative_to(project).as_posix())
    if seal: write_json(manifest_path, manifest)
    result = {'schema_version': 2, 'status': 'PASS', 'stage': manifest['stage'], 'assets': prepared,
              'scope': 'Project-local files, evidence records, source dependencies, runtime copies and hashes. Does not certify visual quality, originality, playback or production order.'}
    write_json(report, result)
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', type=Path, default=Path('.'))
    ap.add_argument('--seal', action='store_true')
    args = ap.parse_args()
    result = check_project(args.project, args.seal)
    print(result['status'] + ': prepared project-local artwork/evidence integrity checked; creative review is separate.')


if __name__ == '__main__':
    try: main()
    except (ValueError, OSError, KeyError, TypeError, SyntaxError) as exc: sys.exit('Asset readiness failed: ' + str(exc))
