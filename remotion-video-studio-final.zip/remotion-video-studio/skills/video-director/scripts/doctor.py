#!/usr/bin/env python3
"""Check the environment once, print exactly what is missing and how to fix it.  python3 doctor.py [--project .]"""
import argparse, json, re, shutil, subprocess, sys
from pathlib import Path
def ver(cmd):
    try: return subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout.strip().splitlines()[0]
    except Exception: return None
def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--project', default='.'); a = ap.parse_args(); bad = 0
    def row(ok, name, info, fix=''):
        nonlocal bad; bad += (not ok); print(f"[{'OK' if ok else 'MISSING'}] {name}: {info}" + (f"   -> {fix}" if not ok and fix else ''))
    row(sys.version_info >= (3, 9), 'python', sys.version.split()[0], 'install Python 3.9+')
    for m in ('numpy', 'scipy'):
        try: __import__(m); row(True, m, 'importable')
        except Exception: row(False, m, 'not installed', f'pip install {m}')
    for t in ('ffmpeg', 'ffprobe'): row(bool(shutil.which(t)), t, ver([t, '-version']) or 'not found', 'install ffmpeg')
    n = ver(['node', '-v']); nv = tuple(int(x) for x in re.findall(r'\d+', n or '')[:3])
    node_ok = len(nv) == 3 and ((nv[0] == 20 and nv >= (20, 19, 0)) or (nv[0] == 22 and nv >= (22, 13, 0)) or nv[0] >= 24)
    row(node_ok, 'node', n or 'not found', 'use Node 20.19+, 22.13+ or 24+; also respect the project engines')
    row(bool(shutil.which('npx')), 'npx', ver(['npx', '-v']) or 'not found', 'comes with Node.js')
    try: __import__('playwright'); row(True, 'playwright (optional, for browser review)', 'importable')
    except Exception: print('[info] playwright not installed (optional browser-based layout/playback review)')
    p = Path(a.project) / 'package.json'
    if p.exists():
        d = json.load(open(p)); deps = {**d.get('dependencies', {}), **d.get('devDependencies', {})}
        row('remotion' in deps, 'remotion project', f"remotion {deps.get('remotion','-')}", 'run /remotion-create')
        row('@remotion/media' in deps, '@remotion/media', deps.get('@remotion/media', '-'), 'npx remotion add @remotion/media')
        remotion_versions = {k: v for k, v in deps.items() if k == 'remotion' or k.startswith('@remotion/')}
        row(len(set(remotion_versions.values())) <= 1, 'Remotion package versions', str(remotion_versions), 'pin remotion and @remotion/* to the same exact version')
        print('[info] optional: ' + ', '.join(f"{k} {'yes' if k in deps else 'no'}" for k in ('@remotion/transitions', '@remotion/google-fonts', '@remotion/captions')))
    else: print(f'[info] no package.json in {a.project}: create the Remotion project first (/remotion-create)')
    sys.exit(1 if bad else 0)
if __name__ == '__main__': main()
