#!/usr/bin/env python3
"""Render, loudness-normalize and audit the final video in one command.

  python3 finalize.py --project . --comp Main [--entry src/index.ts] [--out out/final.mp4] [--target -14]
  python3 finalize.py --project . --input out/raw.mp4 --audio-master video/preview-mix.wav --out out/final.mp4

Steps: npx remotion render -> ffmpeg two-pass loudnorm (video stream copied, AAC 256k) -> audit_audio.py --mix.
Exit code 1 if the audit has a FAIL."""
import argparse, json, re, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent; AUDIT = HERE / 'audit_audio.py'

def run(cmd, **k): return subprocess.run(cmd, text=True, capture_output=True, **k)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--project', default='.'); ap.add_argument('--comp', default='Main'); ap.add_argument('--entry'); ap.add_argument('--input')
    ap.add_argument('--out', default='out/final.mp4'); ap.add_argument('--target', type=float, default=-14.0); ap.add_argument('--tp', type=float, default=-1.5)
    ap.add_argument('--silent', action='store_true', help='explicitly deliver a source with no audio; incompatible with narration/audio-master')
    ap.add_argument('--audio-master', help='verified, timeline-aligned uncompressed mix; replaces rendered audio, never added to it')
    a = ap.parse_args()
    proj = Path(a.project).resolve()
    plan_path = proj / 'video' / 'plan.json'
    plan = json.loads(plan_path.read_text()) if plan_path.exists() else {}
    if plan.get('schema_version') == 3:
        from plan_docs import validate_plan
        errors = validate_plan(plan, render=True)
        if errors: sys.exit('Plan delivery contract failed: ' + '; '.join(errors))
    asset_rule = plan.get('production', {}).get('asset_workflow', {})
    if asset_rule.get('required') or (proj / 'assets' / 'brief.json').exists():
        from check_assets import check_project
        try:
            check_project(proj)
        except (ValueError, OSError, KeyError, TypeError, SyntaxError) as exc:
            sys.exit('Asset readiness failed before render/master: ' + str(exc))
    else:
        print('Legacy project: no asset-first record. Current production requires project-local artwork preparation and separate creative review.', flush=True)
    out = proj / a.out; out.parent.mkdir(parents=True, exist_ok=True)
    if a.input: raw = (proj / a.input).resolve()
    else:
        entry = a.entry or next((str(p.relative_to(proj)) for p in (proj / 'src' / 'index.ts', proj / 'src' / 'index.tsx', proj / 'src' / 'index.js') if p.exists()), None)
        if not entry: sys.exit('no Remotion entry found (src/index.ts); pass --entry')
        raw = proj / 'out' / 'raw.mp4'; print('rendering...', flush=True)
        r = subprocess.run(['npx', 'remotion', 'render', entry, a.comp, str(raw)], cwd=proj)
        if r.returncode: sys.exit('render failed (see output above)')
    if raw.resolve() == out.resolve(): sys.exit('input and output must be different files')
    audio = (proj / a.audio_master).resolve() if a.audio_master else raw
    if not raw.is_file() or not audio.is_file(): sys.exit('rendered video or audio master is missing')
    def duration(path):
        r = run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(path)])
        return float(r.stdout.strip())
    video_duration = duration(raw)
    if a.audio_master and abs(duration(audio) - video_duration) > .06:
        sys.exit('audio master duration differs from picture by over 60ms; fix the timeline before mastering')
    if a.silent:
        probe = run(['ffprobe', '-v', 'error', '-select_streams', 'a', '-show_entries', 'stream=index', '-of', 'csv=p=0', str(raw)])
        if a.audio_master or plan.get('narration') or plan.get('vo') or probe.stdout.strip():
            sys.exit('--silent requires a deliberate non-narrated source with no audio; no supplied sound is removed')
        copied = run(['ffmpeg', '-y', '-v', 'error', '-i', str(raw), '-map', '0:v:0', '-c:v', 'copy', '-an', '-movflags', '+faststart', str(out)])
        if copied.returncode: sys.exit(copied.stderr)
        sys.exit(subprocess.run([sys.executable, str(HERE / 'verify_export.py'), '--project', str(proj), '--input', str(out)]).returncode)
    p1 = run(['ffmpeg', '-nostats', '-i', str(audio), '-vn', '-af', f'loudnorm=I={a.target}:TP={a.tp}:LRA=11:print_format=json', '-f', 'null', '-'])
    m = re.search(r'\{[^{}]*"input_i"[^{}]*\}', p1.stderr, re.S)
    if not m: sys.exit('could not measure loudness (does the video have an audio track?)\n' + p1.stderr[-600:])
    j = json.loads(m.group(0)); print(f"measured: {j['input_i']} LUFS, true peak {j['input_tp']} dBTP")
    af = (f"loudnorm=I={a.target}:TP={a.tp}:LRA=11:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true,aresample=48000")
    inputs = ['-i', str(raw)] + (['-i', str(audio)] if a.audio_master else [])
    mapping = ['-map', '0:v:0', '-map', '1:a:0' if a.audio_master else '0:a:0']
    p2 = run(['ffmpeg', '-y', '-v', 'error', *inputs, *mapping, '-c:v', 'copy', '-af', af, '-c:a', 'aac', '-b:a', '256k', '-t', str(video_duration), '-movflags', '+faststart', str(out)])
    if p2.returncode: sys.exit('normalize failed:\n' + p2.stderr[-800:])
    print('wrote', out)
    r = subprocess.run([sys.executable, str(AUDIT), str(out), '--mix'])
    if r.returncode: sys.exit(r.returncode)
    r = subprocess.run([sys.executable, str(HERE / 'verify_export.py'), '--project', str(proj), '--input', str(out)])
    sys.exit(r.returncode)

if __name__ == '__main__': main()
