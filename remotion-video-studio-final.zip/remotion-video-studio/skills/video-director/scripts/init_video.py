#!/usr/bin/env python3
"""Set up a video project in one command (idempotent: safe to re-run, never overwrites without --force).

  python3 init_video.py <project_dir> --theme cut-paper [--title "..."] [--fps 30] [--size 1080x1920] [--no-sfx] [--force]

Creates: video/plan.json, public/fonts, public/sfx (synthesized), src/theme/ (theme kit), src/SfxTrack.tsx, src/sfxCues.ts, src/data/timing.json.
The Remotion project itself comes from /remotion-create (or `npx create-video@latest`); run this inside or on top of it."""
import argparse, json, shutil, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent; SK = HERE.parents[1]
THEMES = SK / 'remotion-themes' / 'themes'; SND = SK / 'remotion-sound-design'

def put(src, dst, force):
    if dst.exists() and not force: print(f'  keep   {dst.name} (exists)'); return
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir(): shutil.copytree(src, dst, dirs_exist_ok=True)
    else: shutil.copy2(src, dst)
    print(f'  wrote  {dst}')

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('--theme', default='cut-paper', choices=['cut-paper']); ap.add_argument('--title', default='Untitled video')
    ap.add_argument('--fps', type=int, default=30); ap.add_argument('--size', default='1080x1920'); ap.add_argument('--no-sfx', action='store_true'); ap.add_argument('--force', action='store_true')
    a = ap.parse_args()
    proj = Path(a.project).resolve(); proj.mkdir(parents=True, exist_ok=True); w, h = (int(x) for x in a.size.lower().split('x'))
    if min(w, h, a.fps) <= 0: sys.exit('size and fps must be positive')
    print(f'Project: {proj}  theme: {a.theme}')
    plan_p = proj / 'video' / 'plan.json'
    if plan_p.exists() and not a.force: print('  keep   video/plan.json (exists)')
    else:
        plan = json.load(open(HERE.parent / 'assets' / 'plan.template.json')); plan.update(title=a.title, theme=a.theme, fps=a.fps, width=w, height=h)
        plan_p.parent.mkdir(parents=True, exist_ok=True); json.dump(plan, open(plan_p, 'w'), indent=2, ensure_ascii=False); print('  wrote  video/plan.json')
    kit = THEMES / a.theme / 'kit'
    if not kit.exists(): sys.exit(f'unknown theme {a.theme}; available: ' + ', '.join(p.name for p in THEMES.iterdir() if p.is_dir()))
    put(kit, proj / 'src' / 'theme', a.force)
    fonts = THEMES / '_shared' / 'fonts'
    if fonts.exists():
        for font in sorted(fonts.iterdir()):
            if font.is_file(): put(font, proj / 'public' / 'fonts' / font.name, a.force)
    ent = THEMES / a.theme / 'entry'
    if ent.exists():
        put(ent / 'StudioRoot.tsx', proj / 'src' / 'StudioRoot.tsx', a.force)
        idx = proj / 'src' / 'index.ts'
        if not idx.exists() or 'StudioRoot' not in idx.read_text():
            if idx.exists() and not a.force:
                print('  keep   src/index.ts (existing entry; register StudioRoot manually, or use --force after review)')
            else:
                if idx.exists(): shutil.copy2(idx, proj / 'src' / 'index.ts.orig')
                shutil.copy2(ent / 'index.ts', idx); print('  wrote  src/index.ts (registers StudioRoot; old one saved as index.ts.orig)')
    put(SND / 'assets' / 'SfxTrack.tsx', proj / 'src' / 'SfxTrack.tsx', a.force)
    cues = proj / 'src' / 'sfxCues.ts'
    if not cues.exists(): cues.write_text('export const sfxCues = [] as const;\n'); print('  wrote  src/sfxCues.ts (empty until auto_sfx.py)')
    tm = proj / 'src' / 'data' / 'timing.json'
    if not tm.exists(): tm.parent.mkdir(parents=True, exist_ok=True); tm.write_text('{}\n')
    sfx = proj / 'public' / 'sfx'
    if not a.no_sfx and not (sfx / 'manifest.json').exists():
        sys.path.insert(0, str(SND / 'scripts')); import synth_sfx; synth_sfx.build(str(sfx)); print(f'  wrote  {sfx} (synthesized sound library)')
    print(f'\nDirector scripts: {HERE}\nNext:\n  1. Read video-director/references/production-quality.md; inspect the actual theme images.\n  2. npx remotion add @remotion/media @remotion/transitions   (once)\n  3. python3 "{HERE / "doctor.py"}" --project .\n  4. Fill video/plan.json including production direction and theme_reference_review, then: python3 "{HERE / "plan_docs.py"}" video/plan.json\n  The theme kit is a scaffold: author topic-specific scenes and smooth subtitles after plan approval.\n  Scene names stay hidden; display text has a finite window; smooth motion is the default.')

if __name__ == '__main__': main()
