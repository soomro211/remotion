#!/usr/bin/env python3
"""Initialize neutral project records. Configure only explicit CLI values.
No artwork, font selection, scene schedule or sound is injected.
"""
import argparse,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('project');ap.add_argument('--title');ap.add_argument('--theme');ap.add_argument('--fps',type=float);ap.add_argument('--size');ap.add_argument('--profile',choices=['channel']);ap.add_argument('--force',action='store_true');a=ap.parse_args()
    r=Path(a.project).resolve();r.mkdir(parents=True,exist_ok=True);path=r/'video/plan.json'
    if path.exists() and not a.force:
        print('Existing plan preserved; edit its sourced requirements/decisions explicitly.');return
    p=json.loads((HERE.parent/'assets/plan.template.json').read_text())
    if a.profile:
        profile=json.loads((HERE.parent/'profiles'/f'{a.profile}.json').read_text());p['requirements']=profile['requirements'];p['selected_profile']=a.profile
        for req in p['requirements']:
            if req['key']=='medium':p['theme']=req['value']
            elif req['key']=='captions':p['production']['captions']['enabled']=req['value']['enabled']
    values={}
    if a.title is not None:values['title']=a.title
    if a.theme is not None:values['theme']=a.theme
    if a.fps is not None:
        if a.fps<=0:raise ValueError('fps must be positive')
        values['fps']=a.fps
    if a.size:
        parts=a.size.lower().split('x')
        if len(parts)!=2:raise ValueError('size needs WIDTHxHEIGHT')
        width,height=map(int,parts)
        if min(width,height)<=0:raise ValueError('size must be positive')
        values.update(width=width,height=height)
    p.update(values)
    for key,value in values.items():p['assumptions'].append({'decision':key,'value':value,'reason':'Explicit initializer argument; attribute to the user only when supported by their request.'})
    for name in ['video','assets/source','assets/review','src/data','public']:(r/name).mkdir(parents=True,exist_ok=True)
    from check_assets import initialize
    initialize(r)
    path.write_text(json.dumps(p,indent=2)+'\n')
    print('Created schema-3 brief/treatment records with independent empty narration and shots.\nNext: establish sourced requirements and project decisions, then prepare artwork before final assembly.')
if __name__=='__main__':
    try:main()
    except (ValueError,OSError)as e:sys.exit(str(e))
