#!/usr/bin/env python3
"""Turn video/plan.json into the human approval document and the TTS bundle.

  python3 plan_docs.py video/plan.json

Writes next to plan.json:
  PLAN.md          approval message: summary, storyboard, narration, TTS style prompt, paste-ready prompt, checks
  narration.txt    clean narration (one paragraph per scene), nothing else
  tts-prompt.txt   single paste-ready prompt (style + transcript) for Gemini TTS
Also validates the plan (required fields, length vs word count, banned/generic phrases, unsourced numbers).
Exit code 1 if blocking errors were found."""
import json, math, os, re, sys

BANNED = ["revolutionize", "unlock", "supercharge", "elevate", "seamless", "effortless", "cutting-edge", "next-generation", "game-changing", "game changer",
          "harness", "leverage", "empower", "transform your", "next level", "fast-paced world", "imagine a world", "say goodbye", "introducing the future",
          "all-in-one", "powerful yet simple", "delve", "tapestry", "let's dive in", "here's the thing", "in today's"]
REQUIRED = ["title", "theme", "fps", "width", "height", "scenes", "voice"]

def words(t): return len(re.findall(r"[\w'’-]+", t))

def structural_errors(plan):
    """Reject malformed inputs with useful messages before generating any files."""
    if not isinstance(plan, dict): return ['plan must be a JSON object']
    errors = [f'missing field: {k}' for k in REQUIRED if k not in plan]
    if errors: return errors
    if plan['theme'] != 'cut-paper': errors.append('this bundle supports only the cut-paper theme')
    def number(value, minimum, inclusive=False):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and (value >= minimum if inclusive else value > minimum)
    for k in ('fps', 'width', 'height'):
        if not number(plan[k], 0): errors.append(f'{k} must be positive and finite')
    if plan.get('target_seconds') is not None and not number(plan['target_seconds'], 0): errors.append('target_seconds must be positive and finite')
    if not isinstance(plan['voice'], dict): errors.append('voice must be an object')
    else:
        if not number(plan['voice'].get('wpm', 150), 0): errors.append('voice.wpm must be positive and finite')
        if not number(plan['voice'].get('pause_ms', 700), 0, True): errors.append('voice.pause_ms must be nonnegative and finite')
    if not isinstance(plan['scenes'], list) or not plan['scenes']: return errors + ['scenes must be a nonempty list']
    seen = set()
    for i, scene in enumerate(plan['scenes']):
        if not isinstance(scene, dict): errors.append(f'scene {i + 1} must be an object'); continue
        sid = scene.get('id')
        if not isinstance(sid, str) or not sid.strip(): errors.append(f'scene {i + 1} needs a nonempty string id')
        elif sid in seen: errors.append(f'duplicate scene id: {sid}')
        else: seen.add(sid)
        if not isinstance(scene.get('narration', ''), str): errors.append(f'{sid}: narration must be a string')
        if not isinstance(scene.get('onscreen', []), list) or not all(isinstance(x, str) for x in scene.get('onscreen', [])): errors.append(f'{sid}: onscreen must be an array of strings')
        events = scene.get('events', [])
        if not isinstance(events, list): errors.append(f'{sid}: events must be an array')
        elif any(not isinstance(e, dict) or not number(e.get('t'), 0, True) or not isinstance(e.get('kind'), str) for e in events): errors.append(f'{sid}: events need a kind and finite nonnegative t')
    prod = plan.get('production')
    if prod is not None:
        if not isinstance(prod, dict): errors.append('production must be an object')
        else:
            for key in ('captions', 'headings'):
                if key in prod and not isinstance(prod[key], dict): errors.append(f'production.{key} must be an object')
            caps = prod.get('captions')
            if isinstance(caps, dict) and not number(caps.get('max_lines', 2), 0): errors.append('caption max_lines must be positive and finite')
            if not isinstance(prod.get('overrides', []), list): errors.append('production.overrides must be an array')
    return errors

def quality_checks(plan, errs, warns):
    """Review new production settings without rejecting legacy plans or user overrides."""
    prod = plan.get("production") or {}
    overrides = prod.get("overrides") or []
    if not prod:
        warns.append("production defaults missing: add topic-specific art/motion, no persistent headings and smooth theme-matched subtitles")
    if not prod.get("theme_reference_review"):
        warns.append("theme_reference_review missing: inspect actual theme images and record preserved material/type/palette before approval")
    # Overrides must be reviewed per setting; one unrelated exception cannot hide all warnings.
    caps = prod.get("captions") or {}
    if caps.get("enabled") is False:
        warns.append("subtitles disabled without a recorded user/brief override")
    if caps.get("persistent_backing") is False:
        warns.append("subtitle backing should persist across phrase changes; record any deliberate override")
    if caps.get("max_lines", 2) > 2:
        warns.append("subtitle max_lines exceeds the two-line default")
    heads = prod.get("headings") or {}
    if heads.get("persistent") or heads.get("scene_names_visible"):
        warns.append("persistent headings/visible scene names contradict the production default; record a justified override")
    billboard_scenes = []
    for s in plan["scenes"]:
        sid = s["id"]
        if not s.get("visual") or not s.get("motion") or not s.get("transition"):
            warns.append(f"{sid}: describe the topic-specific visual action, motion and transition reason")
        if not s.get("onscreen"):
            continue
        role = s.get("text_role")
        if role not in ("opening-title", "label", "data", "chapter", "cta"):
            warns.append(f"{sid}: display copy needs a text_role; scene headings are not a default")
        window = s.get("text_window")
        if window is None:
            warns.append(f"{sid}: display copy needs an explicit text_window and exit; scaffold uses at most 2.5 seconds")
        elif not isinstance(window, dict):
            errs.append(f"{sid}: text_window must be an object with start_s and end_s")
        else:
            start, end = window.get("start_s"), window.get("end_s")
            valid = all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in (start, end))
            if not valid or start < 0 or end <= start:
                errs.append(f"{sid}: text_window must have finite seconds with 0 <= start_s < end_s")
            elif role == "opening-title" and end - start > 3:
                warns.append(f"{sid}: opening title lasts over 3 seconds; shorten it or explain its reading-time/brief exception")
        if role in ("label", "data", "chapter") and not s.get("text_purpose"):
            warns.append(f"{sid}: record text_purpose and position useful text with its object, not as a chapter billboard")
        if s.get("type") in ("explain", "payoff") and role not in ("label", "data"):
            billboard_scenes.append(sid)
    if billboard_scenes:
        warns.append("explanation/payoff display headings in " + ", ".join(billboard_scenes) + ": prefer onscreen: [] and let visuals/subtitles carry the beat")

def production_notes(plan):
    prod = plan.get("production") or {}
    caps = prod.get("captions") or {}
    heads = prod.get("headings") or {}
    cap_enabled = caps.get("enabled", True)
    notes = [
        "- Theme reference review: " + (prod.get("theme_reference_review") or "PENDING: open the actual theme images; preserve material, palette and type while adapting scenery."),
        "- Visual direction: " + (prod.get("visual_direction") or "Topic-specific full-frame visual action; stock theme layouts are scaffolds."),
        "- Motion: " + (prod.get("motion") or "Smooth frame-driven subject/camera animation with readable holds."),
        "- Camera plan: " + (prod.get("camera_plan") or "PENDING: record focus, scale/travel, depth, overscan and handoffs; see camera-and-continuity.md."),
        "- Transitions: " + (prod.get("transitions") or "Motivated continuity; a small vocabulary; inspect intermediate frames."),
        f"- Main headings: persistent={heads.get('persistent', False)}; scene names visible={heads.get('scene_names_visible', False)}. Optional opening title is brief; useful labels have an exit.",
        f"- Subtitles: {'enabled' if cap_enabled else 'disabled'}; {caps.get('style', 'theme-matched')}; {caps.get('placement', 'lower-safe')}; at most {caps.get('max_lines', 2)} lines; backing persists={caps.get('persistent_backing', True)}; {caps.get('transition', 'soft text changes')}. Align to the real recording.",
        "- Ending: " + (prod.get("ending") or "Resolve the idea visually; CTA only when useful to the brief."),
        "- No unrequested counters, progress bars, scene numbers or filler. Inspect loaded text, subtitle changes, transitions and the final encoded MP4; record video/qa-report.md.",
        "- These are production requirements, not automatic kit features: author the illustrations and subtitle renderer before final delivery.",
    ]
    notes.extend("- Explicit override: " + str(x) for x in prod.get("overrides", []))
    return "\n".join(notes)

def cell(value):
    return str(value).replace("|", "\\|").replace("\n", " ")

def display_text(s):
    if not s.get("onscreen"):
        return "None; visuals + subtitles"
    text = " / ".join(s["onscreen"])
    window = s.get("text_window")
    timing = f"{window['start_s']:g}–{window['end_s']:g}s" if window else "brief; at most 2.5s in scaffold"
    return f"{text} ({s.get('text_role', 'purpose needed')}; {timing})"

def style_prompt(v, n_scenes):
    pr = v.get("pronunciations") or {}
    lines = [
        f"Voice: speak as {v['persona']}.",
        f"Tone: {v['tone']}.",
        f"Pace: {v['pace']}, about {v.get('wpm', 150)} words per minute.",
        f"Accent: {v['accent']}.",
        f"Energy: {v['energy']}.",
        f"Pauses: leave a clear, natural pause of about {v.get('pause_ms', 700)} ms between paragraphs, and a short breath at commas and full stops. Do not rush the first sentence.",
        "Delivery: sound like a real person talking to one listener, with natural emphasis on the key word of each sentence. No announcer voice, no sing-song, no reading of headings or stage directions.",
    ]
    if pr: lines.append("Pronunciations: " + "; ".join(f"{k} = {val}" for k, val in pr.items()) + ".")
    lines.append(f"Read the transcript below exactly as written ({n_scenes} paragraphs). Do not add or skip words.")
    return "\n".join(lines)

def main(path):
    plan = json.load(open(path)); d = os.path.dirname(os.path.abspath(path)); errs, warns = [], []
    errs.extend(structural_errors(plan))
    if errs: print("\n".join("ERROR " + e for e in errs)); return 1
    v = plan["voice"]
    for k in ("persona", "tone", "pace", "accent", "energy"):
        if not v.get(k): errs.append(f"voice.{k} is empty (needed for the TTS style prompt)")
    sc = plan["scenes"]; paras = []
    if not sc: errs.append("scenes must not be empty")
    total_w = 0; est = []
    for s in sc:
        nar = (s.get("narration") or "").strip(); w = words(nar); total_w += w; paras.append(nar)
        sec = w / (v.get("wpm", 150) / 60) + v.get("pause_ms", 700) / 1000 if nar else float(s.get("est_seconds", 2)); est.append(sec)
        if not nar: warns.append(f"{s['id']}: no narration (scene will be music/sfx only)")
        if len(s.get("onscreen", [])) and sum(words(x) for x in s["onscreen"]) > 12: warns.append(f"{s['id']}: more than ~12 words on screen")
        txt = " ".join([nar] + s.get("onscreen", [])).lower()
        for b in BANNED:
            if b in txt: warns.append(f"{s['id']}: generic phrase '{b}'; rewrite with something specific")
        if re.search(r"\b\d[\d,.]*\s?(%|percent|million|billion|km|miles|times|x)\b", txt) and not s.get("proof"): warns.append(f"{s['id']}: contains a number/claim but no 'proof' source field")
    quality_checks(plan, errs, warns)
    total_est = max(0, sum(est) - (v.get("pause_ms", 700) / 1000))
    tgt = plan.get("target_seconds")
    if tgt and abs(total_est - tgt) > max(3, tgt * .2): warns.append(f"estimated voiceover length {total_est:.0f}s vs target {tgt}s: adjust narration ({total_w} words now, about {int(tgt * v.get('wpm',150) / 60)} fit)")
    if errs: print("\n".join("ERROR " + e for e in errs)); return 1
    sp = style_prompt(v, len([p for p in paras if p]))
    transcript = "\n\n".join(p for p in paras if p)
    combined = sp + "\n\nTranscript:\n\n" + transcript
    open(os.path.join(d, "narration.txt"), "w").write(transcript + "\n")
    open(os.path.join(d, "tts-prompt.txt"), "w").write(combined + "\n")
    rows = "\n".join(f"| {i+1} | {cell(s.get('name',''))} | {cell(display_text(s))} | {cell(s.get('visual',''))} | {est[i]:.1f} |" for i, s in enumerate(sc))
    md = f"""# {plan['title']}: plan for approval

**Theme:** {plan['theme']} | **Canvas:** {plan['width']}x{plan['height']} at {plan['fps']} fps | **Length:** about {total_est:.0f}s | **Platform:** {plan.get('platform','')}
**Promise:** {plan.get('creative_promise','')}
**The one thing:** {plan.get('the_one_thing','')}

## Storyboard
| # | Internal scene name | Display copy and window | Visual | Est. sec |
|---|---|---|---|---|
{rows}

## Production defaults and direction
{production_notes(plan)}

## 1. Narration script (what the voice says)
{transcript}

## 2. Style prompt (how it should sound)
```
{sp}
```

## 3. Paste-ready prompt for Gemini TTS (style + transcript in one)
```
{combined}
```
Generate the audio with this prompt, then send me the audio file (wav or mp3). Tip: keep one take for the whole script so the pacing stays consistent; if one line is wrong, regenerate only that paragraph and tell me which one.

## Assets
{chr(10).join('- ' + a['item'] + ': ' + a['status'] for a in plan.get('assets', [])) or '- none'}

## Open questions (defaults if you do not answer)
{chr(10).join('- ' + q['q'] + ' Default: ' + q['default'] for q in plan.get('open_questions', [])) or '- none'}

## Checks
{chr(10).join('- ' + w for w in warns) or '- No automatic plan warnings. Factual, visual and encoded-file review is still required.'}

**Reply "approve" (or send edits).** After approval: send the audio. I will then build the timing, sound design, scenes and final export automatically.
"""
    open(os.path.join(d, "PLAN.md"), "w").write(md)
    print(f"wrote PLAN.md, narration.txt, tts-prompt.txt in {d}  ({total_w} words, ~{total_est:.0f}s)")
    for w in warns: print("WARN", w)
    return 0

if __name__ == "__main__": sys.exit(main(sys.argv[1]))
