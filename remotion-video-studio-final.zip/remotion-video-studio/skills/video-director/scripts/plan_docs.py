#!/usr/bin/env python3
"""Validate schema-3 traceability and write a reviewable treatment/script/shot handoff.
Structural checks report engineering facts, never creative approval.
"""
import argparse,json,math,sys
from pathlib import Path

def finite(v,positive=True):
    return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and (v>0 if positive else v>=0)

def validate_plan(p,render=False):
    errors=[]
    if not isinstance(p,dict):return ['plan must be an object']
    if p.get('schema_version')!=3:return ['schema 3 uses independent narration and shots; older scene-based plans require explicit migration, existing files are not changed']
    if 'scenes' in p:errors.append('schema 3 uses narration and shots, not scenes')
    for k in ['title']:
        if not isinstance(p.get(k),str) or not p[k].strip():errors.append(k+' is unresolved')
    for k in ['width','height','fps']:
        if not finite(p.get(k)):errors.append(k+' must be positive and finite; choose from the brief')
    if p.get('target_seconds') is not None and not finite(p['target_seconds']):errors.append('target_seconds must be positive and finite')
    requirements=p.get('requirements',[])
    if not isinstance(requirements,list):errors.append('requirements must be an array');requirements=[]
    seen=set()
    for r in requirements:
        if not isinstance(r,dict):errors.append('requirement must be an object');continue
        key=r.get('key');source=r.get('source')
        if not isinstance(key,str) or not key or key in seen:errors.append('requirements need unique keys')
        else:seen.add(key)
        if not isinstance(source,dict) or source.get('kind') not in ['user','assumption','technical'] or not isinstance(source.get('reference'),str) or not source['reference'].strip():errors.append(str(key)+': record source kind and reference')
        if r.get('scope') not in ['project','session']:errors.append(str(key)+': scope must be project or session')
        if 'value' not in r:errors.append(str(key)+': value required')
    brief=p.get('brief',{})
    if not isinstance(brief,dict):errors.append('brief must be an object');brief={}
    for k in ['purpose','audience','scope']:
        if not isinstance(brief.get(k),str) or not brief[k].strip():errors.append('brief.'+k+' is unresolved')
    narration=p.get('narration',[]);shots=p.get('shots',[])
    if not isinstance(narration,list):errors.append('narration must be an array');narration=[]
    if not isinstance(shots,list) or not shots:errors.append('shots must be a nonempty array');shots=[]
    groups={}
    for name,items in [('narration',narration),('shots',shots)]:
        ids=set();groups[name]=ids
        for item in items:
            if not isinstance(item,dict):errors.append(name+' entries must be objects');continue
            key=item.get('id')
            if not isinstance(key,str) or not key.strip() or key in ids:errors.append(name+': duplicate/missing id '+str(key))
            else:ids.add(key)
            fields=['text'] if name=='narration' else ['purpose','visual','action','framing','camera','connection_to_next']
            for field in fields:
                if not isinstance(item.get(field),str) or not item[field].strip():errors.append(str(key)+': '+field+' is unresolved')
    for shot in shots:
        if not isinstance(shot,dict):continue
        cues=shot.get('spoken_cues',[])
        if not isinstance(cues,list):errors.append(str(shot.get('id','<missing>'))+': spoken_cues must be an array');continue
        for cue in cues:
            if not isinstance(cue,dict) or cue.get('narration_id') not in groups['narration']:errors.append(str(shot.get('id','<missing>'))+': unknown narration cue')
        if render:
            for key in ['start_frame','duration_frames']:
                val=shot.get(key)
                if not isinstance(val,int) or isinstance(val,bool) or val<(1 if key=='duration_frames' else 0):errors.append(str(shot.get('id','<missing>'))+': valid '+key+' required')
            if all(isinstance(shot.get(k),int) for k in ['start_frame','duration_frames']) and isinstance(p.get('total_frames'),int) and shot['start_frame']+shot['duration_frames']>p['total_frames']:errors.append(str(shot.get('id','<missing>'))+': shot exceeds delivery timeline')
    t=p.get('treatment',{})
    if not isinstance(t,dict):errors.append('treatment must be an object');t={}
    for k in ['approach','reason','opening','ending']:
        if not isinstance(t.get(k),str) or not t[k].strip():errors.append('treatment.'+k+' is unresolved')
    art=t.get('art_direction',{})
    if not isinstance(art,dict):errors.append('art_direction must be an object');art={}
    for k in ['setting','materials','lighting','context','tone','production_method']:
        d=art.get(k)
        if not isinstance(d,dict) or not d.get('value') or not d.get('reason'):errors.append('art_direction.'+k+' needs a value and reason')
    for k in ['palette','typography']:
        d=art.get(k)
        if not isinstance(d,dict) or not isinstance(d.get('roles'),dict) or not d['roles'] or not all(isinstance(v,str) and v.strip() for v in d['roles'].values()) or not d.get('reason'):errors.append('art_direction.'+k+' needs explicit project roles and reason')
    refs=art.get('references',[])
    if not isinstance(refs,list):errors.append('references must be an array');refs=[]
    for ref in refs:
        if not isinstance(ref,dict) or not ref.get('uri') or not isinstance(ref.get('roles'),list) or not ref['roles'] or not ref.get('adopt') or not ref.get('limits'):errors.append('reference needs uri, explicit roles, adopt and limits')
    voice=p.get('voice',{})
    if not isinstance(voice,dict):errors.append('voice must be an object');voice={}
    for k in ['wpm','pause_ms']:
        if voice.get(k) is not None and not finite(voice[k],k=='wpm'):errors.append('voice.'+k+' has an invalid number')
    prod=p.get('production',{})
    if not isinstance(prod,dict):errors.append('production must be an object');prod={}
    caps=prod.get('captions',{})
    if not isinstance(caps,dict) or not isinstance(caps.get('enabled'),bool):errors.append('caption enabled choice is unresolved')
    elif caps['enabled']:
        style=caps.get('style')
        if not isinstance(style,dict):errors.append('enabled captions require explicit project style')
        else:
            for k in ['x','y','width','height','padding','fontSize','lineHeight','fontWeight','inMs','outMs','travelPx']:
                if not finite(style.get(k),k in ['width','height','fontSize','lineHeight','fontWeight']):errors.append('caption style.'+k+' must be finite with valid geometry/timing')
            for k in ['fontFamily','color']:
                if not isinstance(style.get(k),str) or not style[k].strip():errors.append('caption style.'+k+' is unresolved')
            if not isinstance(style.get('surface'),dict):errors.append('caption surface must be an explicit style object (may be empty)')
    if render:
        if not isinstance(p.get('total_frames'),int) or isinstance(p['total_frames'],bool) or p['total_frames']<1:errors.append('total_frames must be positive integer')
        if narration:
            vo=p.get('vo',{})
            if not vo.get('file') or vo.get('timing_verified') is not True or not vo.get('timing_method'):errors.append('narrated delivery needs supplied voice and verified actual-speech alignment')
    return errors

def cell(value):return str(value).replace('|','\\|').replace('\n',' ')
def generate(plan,path):
    errors=validate_plan(plan)
    if errors:raise ValueError('\n'.join(errors))
    out=Path(path).resolve().parent;out.mkdir(parents=True,exist_ok=True)
    paras=[x['text'].strip() for x in plan['narration']];transcript='\n\n'.join(paras)
    voice=plan.get('voice',{});style=[]
    for k in ['persona','tone','pace','accent','energy']:
        if voice.get(k):style.append(k.capitalize()+': '+str(voice[k]))
    if voice.get('wpm'):style.append('Estimated pace: '+str(voice['wpm'])+' words per minute; retain natural phrasing.')
    if voice.get('pause_ms') is not None:style.append('Paragraph breathing guide: '+str(voice['pause_ms'])+' ms; shot changes are independent.')
    if voice.get('pronunciations'):style.append('Pronunciations: '+json.dumps(voice['pronunciations'],ensure_ascii=False))
    style.append('Read only the transcript, exactly as written. Do not read labels or add words.')
    prompt='\n'.join(style)+'\n\nTranscript:\n\n'+transcript
    (out/'narration.txt').write_text(transcript+'\n');(out/'tts-prompt.txt').write_text(prompt+'\n')
    req='\n'.join(f"- {r['key']}: {json.dumps(r['value'],ensure_ascii=False)} ({r['source']['kind']}; {r['scope']}; {r['source']['reference']})" for r in plan['requirements'])or 'No standing requirements recorded; project decisions follow the current brief.'
    shots='\n'.join('| '+' | '.join(cell(s.get(k,'')) for k in ['id','purpose','visual','action','framing','camera','connection_to_next'])+' |' for s in plan['shots'])
    art=plan['treatment']['art_direction'];decisions='\n'.join('- '+k+': '+json.dumps(v,ensure_ascii=False) for k,v in art.items())
    notes='\n'.join('- '+json.dumps(x,ensure_ascii=False) for x in plan.get('assumptions',[]))or 'None recorded.'
    md=f"""# {plan['title']} — treatment for review

Canvas: {plan['width']}×{plan['height']} at {plan['fps']} fps. Requested duration: {plan.get('target_seconds') or 'unresolved'} seconds.
Purpose: {plan['brief']['purpose']}
Audience: {plan['brief']['audience']}
Scope: {plan['brief']['scope']}

## Requirements and source
{req}

## Interpretation and assumptions
{notes}

## Treatment
{plan['treatment']['approach']}
Reason: {plan['treatment']['reason']}
Opening: {plan['treatment']['opening']}
Ending: {plan['treatment']['ending']}

## Art direction and reference roles
{decisions}

## Spoken script
{transcript or 'No narration selected.'}

## Independent shot plan
| ID | Purpose | Visual | Action | Framing | Camera | Outgoing connection |
|---|---|---|---|---|---|---|
{shots}

## Voice prompt
{prompt if transcript else 'Not applicable.'}

## Handoff
Prepare the required project artwork and review style frames/motion ranges before final assembly. Align actual speech and author shot cues independently. Record creative findings separately from engineering checks. This document is a plan, not evidence of finished visual quality. Use the established approval/audio handoff when missing; existing authorization carries forward.
"""
    (out/'PLAN.md').write_text(md);return md

def main():
    ap=argparse.ArgumentParser();ap.add_argument('plan');a=ap.parse_args();path=Path(a.plan);p=json.loads(path.read_text());generate(p,path);print('Wrote PLAN.md, narration.txt and tts-prompt.txt; structural/traceability checks only.')
if __name__=='__main__':
    try:main()
    except (ValueError,OSError,TypeError,KeyError)as e:sys.exit(str(e))
