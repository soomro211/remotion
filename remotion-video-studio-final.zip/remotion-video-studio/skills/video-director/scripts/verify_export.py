#!/usr/bin/env python3
"""Verify encoded media metadata and original narration integrity, not artistic quality.

python3 verify_export.py --project . --input out/final.mp4 [--plan video/plan.json]
Writes video/export-check.json. Visual/motion/caption review is still required.
"""
import argparse
import hashlib
import json
import subprocess
import sys
from fractions import Fraction
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', default='.')
    ap.add_argument('--input', required=True)
    ap.add_argument('--plan', default='video/plan.json')
    a = ap.parse_args()
    project = Path(a.project).resolve()
    video = (project / a.input).resolve()
    plan_path = project / a.plan
    plan = json.loads(plan_path.read_text()) if plan_path.exists() else {}
    probe = subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', str(video)], capture_output=True, text=True, check=True)
    data = json.loads(probe.stdout)
    v = next((s for s in data['streams'] if s['codec_type'] == 'video'), {})
    audio = next((s for s in data['streams'] if s['codec_type'] == 'audio'), {})
    checks = []

    def check(name, ok, detail):
        checks.append(dict(name=name, status='PASS' if ok else 'FAIL', detail=detail))

    check('video', bool(v), v.get('codec_name', 'missing'))
    frames = int(v.get('nb_read_frames', 0))
    check('decoded frames', frames > 0, frames)
    if plan:
        for key in ('width', 'height'):
            check(key, v.get(key) == plan[key], dict(actual=v.get(key), expected=plan[key]))
        fps = float(Fraction(v.get('avg_frame_rate', '0/1')))
        check('fps', abs(fps - plan['fps']) < .001, fps)
        if plan.get('total_frames'):
            check('frame count', frames == plan['total_frames'], dict(actual=frames, expected=plan['total_frames']))
            duration = float(data['format']['duration'])
            expected = plan['total_frames'] / plan['fps']
            check('duration', abs(duration - expected) <= max(.06, 1 / plan['fps']), dict(actual=duration, expected=expected))
    if plan.get('vo'):
        check('audio stream', bool(audio), audio.get('codec_name', 'missing'))
        voice = (project / 'public' / plan['vo']['file'].removeprefix('public/')).resolve()
        check('original voice present', voice.is_file(), voice.name)
        if voice.is_file() and plan['vo'].get('original_sha256'):
            check('original voice bytes', hashlib.sha256(voice.read_bytes()).hexdigest() == plan['vo']['original_sha256'], 'SHA-256 comparison')
        if audio:
            check('audio sample rate', audio.get('sample_rate') == '48000', audio.get('sample_rate'))
    decoded = subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(video), '-f', 'null', '-'], capture_output=True, text=True)
    check('full media decode', decoded.returncode == 0, decoded.stderr[-1000:] or 'no decode errors')
    report = dict(scope='Technical export checks only; see qa-report.md for artistic, subtitle and alignment review.', file=video.name, sha256=hashlib.sha256(video.read_bytes()).hexdigest(), checks=checks)
    output = project / 'video' / 'export-check.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    for c in checks:
        print(f"{c['status']} {c['name']}: {c['detail']}")
    sys.exit(1 if any(c['status'] == 'FAIL' for c in checks) else 0)


if __name__ == '__main__':
    main()
