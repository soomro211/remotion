#!/usr/bin/env python3
"""Set scene timings in plan.json from the real voiceover audio (the TTS file the user sends).

  python3 vo_to_timing.py video/plan.json public/vo.wav [--tail 1.2] [--lead 0.0]

How: finds the pauses in the voiceover, picks the (N-1) longest as the boundaries between the N narrated
scenes, and writes start_frame / duration_frames / vo_start_s / vo_end_s into each scene plus total_frames.
Falls back to rough word-count estimates if the audio has too few clear pauses.
Requires narrated scenes throughout a continuous voice take; manually author inserted silent
scenes and lead-ins in the shared timeline. Needs ffmpeg + numpy."""
import argparse, hashlib, json, re, subprocess, sys
from pathlib import Path
import numpy as np

def load(path):
    p = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', '16000', '-f', 'f32le', '-'], capture_output=True)
    if not p.stdout: sys.exit(f'cannot decode audio: {path}')
    return np.frombuffer(p.stdout, np.float32)

def speech_segments(x, sr=16000, hop=0.01):
    n = int(sr * hop); m = len(x) // n; env = np.sqrt((x[:m * n].reshape(m, n) ** 2).mean(1))
    noise, peak = np.percentile(env, 10), np.percentile(env, 95); thr = max(noise * 3.0, peak * 0.04)
    mask = env > thr; segs = []; i = 0
    while i < m:
        if mask[i]:
            j = i
            while j < m and mask[j]: j += 1
            segs.append([i * hop, j * hop]); i = j
        else: i += 1
    merged = []
    for s in segs:                         # bridge tiny gaps (stops, plosives): < 0.12 s
        if merged and s[0] - merged[-1][1] < 0.12: merged[-1][1] = s[1]
        else: merged.append(s)
    return [s for s in merged if s[1] - s[0] > 0.08], len(x) / sr

def words(t): return len(re.findall(r"[\w'’-]+", t))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('plan'); ap.add_argument('vo'); ap.add_argument('--tail', type=float, default=1.2)
    ap.add_argument('--lead', type=float, default=0.0, help='extra seconds before the first word'); a = ap.parse_args()
    plan = json.load(open(a.plan)); fps = plan['fps']; sc = plan['scenes']
    try: public_path = Path(a.vo).resolve().relative_to((Path(a.plan).resolve().parent.parent / 'public').resolve())
    except ValueError: sys.exit('voice file must be inside the project public/ directory')
    if a.tail < 0: sys.exit('tail must be nonnegative')
    if a.lead != 0: sys.exit('Author a lead-in on the shared narration/caption parent; this estimator preserves the source start at zero.')
    if not sc or any(not (s.get('narration') or '').strip() for s in sc):
        sys.exit('This estimator handles continuous narration with narrated scenes only. Author verified source-relative boundaries for silent scenes; do not insert them into an unchanged voice track.')
    x = load(a.vo); segs, dur = speech_segments(x)
    if not segs: sys.exit('no speech detected in the audio')
    s0, s1 = segs[0][0], segs[-1][1]
    nar = [i for i, s in enumerate(sc) if (s.get('narration') or '').strip()]; N = len(nar)
    gaps = [(segs[i][1], segs[i + 1][0], segs[i + 1][0] - segs[i][1]) for i in range(len(segs) - 1)]
    method = 'pauses'; bounds = []
    chosen = sorted(sorted(gaps, key=lambda g: -g[2])[:N - 1], key=lambda g: g[0]) if N > 1 else []
    if len(chosen) < N - 1 or (chosen and min(g[2] for g in chosen) < 0.3):
        method = 'word-count fallback'; w = [words(sc[i]['narration']) for i in nar]; tot = sum(w); acc = 0; chosen = []
        for k in range(N - 1):
            acc += w[k]; t = s0 + (s1 - s0) * acc / tot; chosen.append((t, t, 0.0))
    bounds = [(g[0] + g[1]) / 2 for g in chosen]
    warn = []
    if method == 'pauses' and len(gaps) > N - 1:
        rest = sorted([g for g in gaps if g not in chosen], key=lambda g: -g[2])
        if rest and chosen and rest[0][2] > 0.8 * min(g[2] for g in chosen): warn.append(f'ambiguous pauses: an unchosen pause of {rest[0][2]:.2f}s at {rest[0][0]:.1f}s is almost as long as the shortest chosen one; check the table below')
    # assemble timeline
    k = 0; out = []
    for i, s in enumerate(sc):
        if i in nar:
            start = 0.0 if k == 0 else bounds[k - 1]; end = bounds[k] if k < N - 1 else max(dur, s1 + a.tail)
            vs = min([g for g in [seg[0] for seg in segs] if g >= start - 1e-6] or [start]); ve = max([seg[1] for seg in segs if seg[1] <= end + 1e-6] or [end])
            if k == 0: start = max(0.0, 0.0 - a.lead)
            out.append((s, start, end, vs, ve)); k += 1
        else: out.append((s, None, None, None, None))
    shift = 0.0; rows = []
    for s, st, en, vs, ve in out:
        if st is None: rows.append((s, None, float(s.get('est_seconds', 2.0)), None, None, True))
        else: rows.append((s, st, en - st, vs, ve, False))
    # contiguous timeline: each scene starts where the previous one ends
    cur = 0
    for s, st, d, vs, ve, fixed in rows:
        frames = max(1, round(d * fps)); s['start_frame'] = cur; s['duration_frames'] = frames; cur += frames
        if not fixed: s['vo_start_s'] = round(vs + shift_before(rows, s), 3); s['vo_end_s'] = round(ve + shift_before(rows, s), 3)
    plan['total_frames'] = cur; plan['vo'] = {'file': public_path.as_posix(), 'original_sha256': hashlib.sha256(Path(a.vo).read_bytes()).hexdigest(), 'duration_s': round(dur, 3), 'timing_method': method, 'timing_verified': False}
    json.dump(plan, open(a.plan, 'w'), indent=2, ensure_ascii=False)
    print(f'voiceover {dur:.1f}s, speech {s0:.1f}-{s1:.1f}s, method: {method}')
    print('id   start  dur   frames  vo window')
    for s in sc: print(f"{s['id']:4s} {s['start_frame']/fps:5.1f}s {s['duration_frames']/fps:4.1f}s {s['duration_frames']:5d}   {s.get('vo_start_s','-')} to {s.get('vo_end_s','-')}")
    print(f"total {cur} frames = {cur/fps:.1f}s")
    for w in warn: print('WARN', w)
    print('REVIEW REQUIRED: pause/word-count boundaries are estimates. Verify against the actual transcript; no caption timing is generated here.')

def shift_before(rows, s):
    """seconds inserted by un-narrated scenes that come before s"""
    sh = 0.0
    for r in rows:
        if r[0] is s: break
        if r[5]: sh += r[2]
    return sh

if __name__ == '__main__': main()
