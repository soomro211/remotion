---
name: video-scriptwriting
description: "Write speech for the current audience and purpose: establish scope, explain causal links clearly, choose an appropriate opening and structure, and coordinate with an independent visual shot plan."
version: 3.0.0
---

# Scriptwriting
Process: [decision architecture](../video-director/references/current-workflow.md).

Understand the audience's knowledge and what the film should change for them. Establish evidence and scope. Choose the explanatory sequence from what must be understood first and what follows; the task determines whether story, demonstration, argument or another structure helps.

Write concrete, speakable language. Explain unfamiliar terms and missing causal steps where the audience needs them. Preserve qualifications that affect meaning. Rehearse mentally or aloud at the intended pace; revise awkward wording and unclear referents. See [voice/craft](references/voice-and-craft.md).

Design the opening with the picture: what can the audience recognize, notice or care about immediately? An action, observation, question, consequence or situation can open the film. Assess the promise against what the film actually delivers. [Opening guide](references/hooks.md) offers evaluation questions, not a format quota.

Write `narration` independently from `shots`. A paragraph can span several shots and a shot can span several paragraphs. Put narration IDs/words in shot cue notes; choose final boundaries after actual-audio alignment. The length follows the requested duration and necessary explanation; estimated word rate is a planning aid.

Review meaning and clarity before polishing phrasing. Verify factual claims and distinguish illustrative examples from measured events. Give pictures and speech useful roles; narration can name a visible mechanism when that helps comprehension. Captions are a separate exact-speech track, while display text has a project-specific purpose.

Inside video-director, include speech and storyboard in the existing plan approval. Existing authorization carries forward. Review [format/handoff](references/script-format-and-checks.md) as needed; no automatic CTA, narrator persona or story arc is selected by this skill.
