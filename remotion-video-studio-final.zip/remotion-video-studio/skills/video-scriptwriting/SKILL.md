---
name: video-scriptwriting
description: Write compelling, specific, non-generic scripts for short videos (promos, launches, explainers, product demos, social clips, brand films, tutorials). Use whenever a video needs a script, voiceover, on-screen copy, captions or a hook, or when an existing script feels flat, generic or AI-sounding. Outputs a scene-by-scene script ready for storyboarding or Remotion.
version: 1.2.0
---

# Video Scriptwriting

A video script is not an essay read aloud. It is a timed sequence of words and
pictures where each one carries part of the meaning. This skill produces scripts
that hook fast, say something specific, sound like a person, and leave room for
visuals to do work.

For this studio, read [production quality defaults](../video-director/references/production-quality.md).
Narrated explainers default to smooth theme-matched subtitles and topic-specific animated visuals.
Separate exact spoken subtitles from optional display copy. Scene names are internal; most explanations
need no main heading (`onscreen: []`). A brief optional opening title exits; labels attach to relevant
objects/actions. Educational endings may resolve visually without a CTA or follow prompt.

**Principles**
1. The viewer owes you nothing. Earn the next 3 seconds, then the next.
2. One video, one idea. One scene, one point.
3. Specific beats clever. Clever beats generic. Generic loses.
4. Words and pictures share the explanation. Use speech to explain causes or context and name useful details; avoid merely describing every visible action.
5. If it cannot be said out loud naturally, it is not finished.
6. Never invent facts, quotes, customers or numbers.

Reference files (read at the step that needs them):

| File | Read at |
|---|---|
| `references/hooks.md` | Step 3 |
| `references/structures-and-formats.md` | Step 2 and 4 |
| `references/voice-and-craft.md` | Step 4 and 5 |
| `references/rewrite-examples.md` | Step 5 (calibrate quality) |
| `references/script-format-and-checks.md` | Step 6 and 7 |

## Workflow

### Step 1: Brief (ask only what is missing, max 4 questions, offer defaults)
- **Outcome:** what should the viewer know, feel or do after? One sentence.
- **Audience:** who exactly, what they already believe, what they care about, what they are sick of hearing.
- **Where and how long:** platform, length, sound on or off, voiceover or text-only.
- **Proof and material:** real facts, numbers, features, quotes, screenshots, existing copy, brand voice, reference scripts or videos they like.
If a product, brand or URL is given, research it (WebSearch/WebFetch when available) before writing: what it actually does, how its customers talk about it, what competitors say. Use the audience's real words.

### Step 2: Find the angle
Before drafting, write down:
- **The one thing:** the single sentence the viewer should repeat to a friend.
- **The tension:** what is the problem, cost, belief or desire that makes this worth watching? No tension, no script.
- **The proof:** the most believable evidence you have (demo, number, before/after, result).
- **Three angles** (one line each) that differ in idea, not just wording: e.g. result-led, pain-led, contrarian, story-led, demo-led. Recommend one and say why. If the user is not available, choose and state your pick.
- **Voice in 3 words plus one "never"**: e.g. "dry, precise, warm; never hypey".
Choose the structure and format from `references/structures-and-formats.md`.

### Step 3: Write 5 hooks, pick the best
Read `references/hooks.md`. Draft five hooks using different techniques, each
with the paired opening visual. Score on: stops the scroll, specific, promises
a payoff the video delivers, works sound-off. Keep the winner, note the runner-up as an alternate.

### Step 4: Outline beats, then draft
- Outline as beats: one line each, with the purpose and the proof for that beat.
- Draft the script to the word budget for the length (see below). Write VO and on-screen text separately. Add visual direction for every beat, because the picture should carry half the meaning.
- Apply `references/voice-and-craft.md` while drafting, not after.

**Word budgets (voiceover is about 2.5 words per second, with pauses)**
| Length | Spoken words | Beats |
|---|---|---|
| 6-10s | 10-20 | hook, payoff |
| 15s | 25-35 | hook, value, CTA |
| 30s | 55-70 | hook, problem, solution, proof, CTA |
| 60s | 120-140 | hook, problem, solution, 2-3 proof beats, CTA |
| 90s+ | 190-220 | chapters, each with its own mini-hook |
Text-only videos: on-screen text 2-7 words per beat, max about 12 visible at once.

### Step 5: Edit like a different person
Run all of these passes and fix what they find:
1. **Cut pass:** delete the first sentence of every scene, then restore only if the scene breaks. Remove every word that carries no meaning.
2. **Specificity pass:** replace each abstract noun with a concrete one; add the number, name or visible result.
3. **Ear pass:** read it aloud (or sub-vocalize at speaking pace). Rewrite anything you stumble over, anything with three consecutive stressed syllables, or any sentence you would not say to a friend.
4. **Slop pass:** remove banned words and patterns listed in `voice-and-craft.md`.
5. **Show-don't-tell pass:** let the picture demonstrate the process while speech adds useful cause, context or emphasis. Naming a visible mechanism is valid; redundant narration is not required.
6. **Proof pass:** every claim has proof on screen or a source. No proof, soften or cut.
7. **Sound-off pass:** can a viewer follow with the sound off? Fix visual clarity and accurate subtitles;
   do not solve it by pinning a slogan over every scene.
8. **First-3-seconds pass:** could someone mid-scroll tell what this is about and want the next second?

### Step 6: Format the deliverable
Use the scene table in `references/script-format-and-checks.md`: per scene, time,
visual direction, on-screen text, VO, proof/source, sound cue. Include the one-line
creative promise, the voice note, the word and duration count, and alternates
(runner-up hook, alternate CTA).

### Step 7: Self-check and deliver
Run the checklist in `references/script-format-and-checks.md`. Fix everything that
fails. List any gaps honestly (missing proof, unsourced number, unclear audience).
When used standalone, present the script for edits. Inside Video Director, include it in the one
plan approval; do not add a separate script gate or unsolicited shorter-cut deliverable.

### Handoff
If the video will be built in Remotion, put the script straight into `video/plan.json`
(`scenes[].narration` = what is said, `scenes[].onscreen` = optional title/label copy, usually `[]`) via `/video-director`.
Subtitles are derived separately from the actual recorded speech. Set text role/window for any display copy.
Narration is read by a TTS voice, so write it for the ear: short sentences, numbers spelled the way they
are spoken, no parentheses or symbols, hard words listed in `voice.pronunciations`. One scene per
sentence group, so the voice's natural pause between scenes becomes the cut.

## Done means
- A stranger can state the one thing after one viewing.
- The hook works in the first 3 seconds without sound.
- No line could be pasted into a competitor's video unchanged.
- Every number and claim is sourced or shown.
- It sounds like a person talking, not a brochure.
