<!-- studio-reference:1.5.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Hooks

The hook is the first 1-3 seconds. It must do three jobs: signal who this is
for, create a reason to keep watching, and be understandable with no sound.
Write the words and the opening visual together.

## Techniques (write at least one of each of 5 different kinds)
1. **Result first.** Open on the outcome, then earn it.
   "Our checkout went from 6 steps to 1." (visual: the 1-step checkout, already done)
2. **Demo first.** Open on the most impressive thing the product does, no words for the first beat. The picture is the hook.
3. **Specific pain.** A recognizable, concrete moment, not a generic question.
   Weak: "Tired of slow reports?" Strong: "It's 11pm and you're still copying numbers into the Monday deck."
4. **Contrarian.** Challenge a belief the audience holds, then prove it in the video.
   "You don't need more leads. You need to answer the ones you have in under 5 minutes."
5. **Curiosity with payoff.** Raise a specific question the video will answer. The gap must be real and closed before the end.
   "We deleted 40% of our codebase. Here is what broke." (only if true and the answer is delivered)
6. **Stakes or number.** A surprising, true, sourced figure that reframes the topic.
7. **Pattern interrupt.** A visual or sound that breaks scroll rhythm, immediately tied to the message (not a random glitch).
8. **Story open.** Drop into the middle of a moment with a person and a problem, in one line.
9. **Direct promise.** "In 30 seconds you'll see how X does Y." Works when the payoff is strong and the video moves fast.

## Hook scorecard (1-5 each, keep the highest, minimum 4 on each)
- **Stops the scroll:** is there tension, surprise or a clear benefit in the first 2 seconds?
- **Specific:** names a real thing, number or moment, not an abstraction.
- **Relevant:** the target viewer knows it is for them.
- **Delivers:** the video fulfils the promise; no bait.
- **Sound-off:** works from the image and on-screen text alone.

## Rules
- Lead with the result or the problem. Never with the logo, a greeting, "Introducing", or "Hey guys".
- No rhetorical question the viewer answers "no" or "meh" to ("Want to save time?").
- No throat-clearing: cut every word before the first meaningful word.
- Keep the hook to about 8-12 words of speech, or one on-screen line of 2-7 words.
- Avoid clickbait that the video cannot honor; it kills retention and trust.
- Test by reading only the hook to someone: do they ask "how?" or "what?" If not, rewrite.

## Fast hook rewrites
| Weak | Why | Stronger |
|---|---|---|
| "Introducing Acme, the all-in-one platform" | Logo and category, no tension | "Your invoices, filed before you open your laptop." |
| "Are you struggling with onboarding?" | Generic question | "New hires quit in week 2. Here's the 3-minute fix." (only with a real stat/source) |
| "In today's fast-paced world..." | Filler | Cut. Start at the claim. |
| "We built something amazing" | Empty adjective | "This button replaces 14 spreadsheets." |
