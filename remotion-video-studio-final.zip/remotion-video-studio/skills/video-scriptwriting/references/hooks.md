# Opening design

Process: [decision architecture](../../video-director/references/current-workflow.md).

Use the opening to establish an appropriate reason to watch. Ask what this audience can immediately recognize and what they need next. The opening can demonstrate a result, reveal an observation, introduce a human situation or ask a question when that form suits the explanation.

Choose alternatives when the opening has a real unresolved problem. Evaluate them for immediate comprehension, relevance to the intended audience and whether the following film delivers the implied promise. Record reasons and revise from actual sequence review.

Speech, action, framing and sound work together. Check the opening as a moving sequence at intended speed and viewing size. A compelling sentence without a readable picture, or a striking image unrelated to the explanation, needs further work.
