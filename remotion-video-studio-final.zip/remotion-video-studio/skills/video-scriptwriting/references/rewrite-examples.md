# Revision method

Process: [decision architecture](../../video-director/references/current-workflow.md).

Revise an actual passage by identifying the listener's difficulty: unclear subject, missing causal link, unfamiliar term, unsupported claim, overloaded sentence or poor relation to its picture. State what the revision changes and why that helps this audience.

For example, replacing an undefined technical term with a short explanation may improve a beginner script while removing useful precision from a specialist script. Evaluate the revision against the brief instead of treating the simpler phrase as universally better.

Keep a before/after passage in the project when it helps review. Recheck its meaning, spoken timing and visual relationship. A pleasing rewrite that changes the facts or exceeds the duration needs another pass.
