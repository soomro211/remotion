<!-- studio-reference:1.4.0 -->
Studio production defaults: [current workflow and asset rules](../../video-director/references/current-workflow.md). Apply the task-specific guidance below within those defaults.

# Rewrite examples (calibrate the quality bar)

All brands and products below are fictional placeholders.

## Example 1: SaaS launch, 30s
**Generic draft**
> Introducing Flowly, the all-in-one platform that revolutionizes how teams collaborate. With powerful features and seamless integrations, Flowly helps you unlock your team's full potential. Try Flowly today!

Problems: logo first, five banned words, no proof, no picture, could be any company.

**Rewritten**
> VO: Your Monday report takes three hours. [beat]
> VO: Flowly builds it while you get coffee.
> (screen: the report assembling itself from three tools, a timer at 0:12)
> VO: Same numbers. Twelve minutes. Checked against the source, every time.
> (screen: one number clicked, source row highlights)
> VO: Teams at <real customer, if permitted> got their Mondays back.
> VO: Try it free. flowly.com/start

Why it works: result before name, specific baseline and number, the picture proves the claim, one CTA.

## Example 2: Product demo line
**Narrates the screen:** "Here we click the Export button and choose PDF."
**Adds meaning:** "One click, and it's a client-ready PDF. No reformatting."

## Example 3: Hook rewrites
| Generic | Rewritten |
|---|---|
| "Want to grow your business?" | "We got 40 customers from one post. Here's the post." (only if true) |
| "Meet the future of design." | "Draw a box. Get the code." |
| "Are you tired of meetings?" | "Your 3pm meeting could have been this 30 second video." |

## Example 4: Social 9:16, 15s
> 0-1s text: "Stop exporting to Excel." (visual: a hand slams a laptop shut)
> 1-5s: product turns raw data into a live chart, VO: "Live charts, straight from your database."
> 5-11s: three quick cuts, each a different team using it, VO: "Sales, ops, finance. Same numbers, no copy-paste."
> 11-15s: CTA text "Try it free", URL large.

## Example 5: Brand film, 45s (few words)
> VO (slow, warm): "My grandmother measured everything by hand." [beat]
> "No scale. No timer." [beat]
> "She just knew." [hold on hands]
> "We built the oven that learns what she knew."
> Super: "Hearth. Cooks the way you do."

Why it works: one human image, restraint, a single earned line.

## Common failures and fixes
| Failure | Fix |
|---|---|
| Starts with the company | Start with the viewer's problem or the result |
| Every sentence is a claim | Alternate claim and proof, or show proof visually |
| VO describes the visuals | VO adds why; or cut the VO |
| Sounds like a press release | Read aloud, add contractions, cut adjectives |
| Ends with "Learn more" | A specific action with a specific URL or handle |
| Too many ideas | Pick the one thing; cut the rest or make a second video |
| Writes to fill the time | Cut to the shortest version that works, then add only what is missing |
