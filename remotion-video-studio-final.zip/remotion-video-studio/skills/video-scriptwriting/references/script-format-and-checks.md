# Script handoff and review

Process: [decision architecture](../../video-director/references/current-workflow.md).

Record the purpose/audience/scope, exact spoken paragraphs, factual sources, voice direction and estimated duration. Separately record shot purpose, visual action, framing/camera, outgoing connection and links to narration IDs/words. Use [schema 3](../../video-director/references/plan-schema.md).

Review whether the audience can follow the reasoning and whether the opening leads into the promised explanation. Check referents, unfamiliar terms, causal steps, claim support and spoken pacing. Revise what creates a real comprehension or timing problem.

Final timing comes from the recording. Captions reproduce the actual take; visual shot timing is independently authored. Useful display text is planned by role and viewing window. Existing user requirements govern headings, branding, calls to action and subtitle behavior.
