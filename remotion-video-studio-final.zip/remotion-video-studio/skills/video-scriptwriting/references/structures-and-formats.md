<!-- studio-reference:1.5.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Structures and formats

Choose structure by goal and length. Every structure is: **attention, tension,
payoff, action**. Adapt, do not fill in blanks mechanically.
For educational explainers, the resolved visual payoff is a complete ending; an
action/CTA is optional. The promotional timing templates below are not mandatory.

## Core structures
**Problem - Agitate - Solution (PAS)**: best for pain-led products. Keep the agitation to one concrete image, then move to the solution fast.
**Before - After - Bridge**: show the old way, the new result, then how the product is the bridge. Best with a visual transformation.
**Result - How - Proof - CTA**: best for 15-30s promos. Open on the outcome.
**Demo narrative**: setup (what the user wants) - action (the product doing it) - result (what changed) - CTA. Words are sparse; the demo carries.
**Contrarian argument**: common belief - why it fails (evidence) - better way - CTA. Best for thought leadership.
**Story arc**: person - want - obstacle - turn - result. Use real stories only; do not fabricate customers.
**Listicle / chapters**: "3 things", each with its own mini-hook and payoff. Order by strength: strongest first or last, weakest in the middle.
**Tutorial**: promise outcome - prerequisites (one line) - steps (each one action, one result) - recap - next step.

## Timing templates
- **6-10s loop:** hook (0-2), payoff (2-7), brand/CTA (7-9). Last frame flows into the first.
- **15s:** hook 0-3, value shown 3-11, CTA 11-15.
- **30s:** hook 0-3, problem 3-8, solution demo 8-20, proof 20-26, CTA 26-30.
- **60s:** hook 0-4, problem 4-12, solution 12-22, feature beats 22-45 (2-3, each 7-10s), proof 45-54, CTA 54-60.
- **90s+:** chapters of 15-25s, each with mini-hook, one idea, resolution.

## Format notes
**Product launch / promo:** lead with what it does for the viewer, not what it is. Show the new thing in action within 5 seconds. One headline feature, 1-2 supporting. Date or availability in CTA.
**Explainer:** establish the question or phenomenon, show a clear causal model, then resolve it visually. Product explainers may demonstrate the product as the answer. Cut definitions the viewer does not need; most scenes need no main heading.
**Product demo / feature walkthrough:** script the screen actions first, then write VO that adds meaning ("so you never retype this") rather than naming controls ("click the button").
**Social short (9:16):** hook quickly, purposeful visual change every few seconds, smooth accurate subtitles for narration, brief display copy only when needed; CTA only if appropriate to the brief.
**Brand film:** emotion first. Fewer words, strong images, one line that could be a slogan but is earned. Silence is allowed.
**Customer story:** only with real customers and real quotes with permission. Structure: situation - decision - change - number. Never write fake testimonials.
**Announcement / update:** what changed - why it matters - what to do. Lead with the change.
**Founder / talking-head style:** conversational, shorter sentences, one point of view, allow imperfection; written to be spoken, not read.
**Text-only (no VO):** every beat is a headline of 2-7 words; rhythm carries the message; timing is the voice.

## Choosing the CTA
Optional for educational explainers; avoid a generic follow prompt when the story is already complete.
One action, specific and low friction. Match to funnel stage:
- Awareness: follow, watch next, learn the name ("Search 'Acme'").
- Consideration: try, see the demo, read the story.
- Action: start free, book, buy, with the URL or handle.
The CTA is said and shown; the URL or handle is large, spelled simply, on screen at least 1.5s.
