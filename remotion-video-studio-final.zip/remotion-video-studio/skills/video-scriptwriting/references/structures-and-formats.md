# Structure and format

Process: [decision architecture](../../video-director/references/current-workflow.md).

Choose structure from the audience's question and the dependencies of the explanation. A mechanism may need context, action and consequence; a historical question may require interacting causes and scope; a demonstration may establish a need and show an action/result. A story or comparison is useful when it makes the subject more understandable.

These are possibilities rather than slots. Decide what earns screen time in this particular duration. Words, shots and sound can have different pacing and boundary locations. A visual resolution, implication, next step or invitation can end the film according to its purpose.

Platform, format and viewing context determine layout, density and accessibility decisions. Verify current technical platform constraints when they matter. Preserve requested timing and disclose an actual conflict with supplied speech rather than silently retiming it.
