<!-- studio-reference:1.6.0 -->
Production defaults: [current workflow](../../video-director/references/current-workflow.md).

# Voice and craft

## Sound like a person
- Write the way a smart friend explains it: contractions, short sentences, direct address ("you").
- Mix sentence lengths. A short line after a longer one lands harder.
- Prefer plain verbs: make, cut, send, find, fix. Avoid nominalizations ("utilization", "implementation").
- Choose the word the audience uses, not the word the company uses. Steal phrases from reviews, support tickets and community posts.
- Keep one point of view (we or you) for the whole script.

## Be specific
Use the specificity ladder: abstract claim, then concrete example, then number, then visible proof.
| Abstract | Concrete | With proof |
|---|---|---|
| "Saves time" | "Cuts reporting from hours to minutes" | "Monday report: 3 hours to 12 minutes" (source) |
| "Better collaboration" | "Everyone edits the same doc" | "Four people, one doc, zero version 7_final" |
| "Secure" | "Encrypted end to end" | Show the lock state and the specific standard |
Always attach the number to a unit, baseline and source.

## Write for the ear
- One idea per sentence. Subject, verb, object. Front-load the key word.
- Avoid hard-to-say clusters ("strategically structured"), tongue twisters, and strings of unstressed small words.
- Avoid parentheses, semicolons and lists of 4 or more items in VO.
- Numbers: write how they are spoken ("twelve minutes", "forty percent"). Keep digits on screen.
- Add intentional pauses with line breaks; mark them `[beat]` where a hold helps.
- Spell phonetically any brand or product name that could be misread, in a pronunciation note.

## Let the visuals work
- VO adds what pictures cannot: why, meaning, context, contrast.
- On-screen text is the key phrase, not the sentence the VO says.
- Write the visual direction in the same pass as the line. If you cannot picture the line, rewrite it.
- Leave short silent beats after key moments so the visual lands.

## Tension and momentum
- Every scene should raise a question or answer one. End scenes on forward motion ("so we...", a cut to the result).
- Escalate: smaller proof first, strongest proof later, or lead with the strongest then deepen.
- Include one moment of surprise, turn or contrast so it does not feel like a list.
- Earn emotion with specifics (a real situation, a real feeling), not with adjectives.

## Banned or suspect language
Words and phrases to remove or justify: revolutionize, unlock, supercharge,
elevate, seamless, effortless, cutting-edge, next-generation, game-changing,
harness, leverage, empower, transform your, take it to the next level, in today's
fast-paced world, imagine a world where, say goodbye to, introducing the future of,
all-in-one solution, powerful yet simple, delve, tapestry, landscape (as metaphor),
"it's not just X, it's Y", "here's the thing", "let's dive in".
Also avoid:
- Triplets of adjectives ("Fast. Simple. Powerful.") unless each is proven in the shot.
- Rhetorical questions the viewer answers "no" to.
- Grand claims with no proof ("the best", "the only", "number one") unless sourced.
- Vague nouns (solution, platform, ecosystem, experience, journey) unless literal.
- Excess em dashes, stacked "not X but Y" lines, and perfectly symmetrical lists. They read as machine-written.
- Fake urgency and fake social proof.

## Honesty and compliance
- Do not invent customers, testimonials, statistics or quotes. Flag any gap.
- Claims about health, money, performance or comparisons need real substantiation and often disclaimers; flag for review.
- Do not impersonate real people or imply endorsements.
- Respect licensing for music, quotes and footage.

## Tone dial (decide once)
Pick a position on each and keep it: formal-casual, serious-playful, bold-humble, technical-plain. Write 3 sample lines in that voice before drafting the full script, then check every line against them.
