# Meaning, voice and spoken clarity

Process: [decision architecture](../../video-director/references/current-workflow.md).

Select voice/tone for the audience, topic and user brief. Write speech that a person could comfortably say in that context. Sentence length, emphasis, contractions and technical vocabulary can vary appropriately.

Check what each statement means, what it refers to and what evidence supports it. Make causes and consequences explicit where understanding depends on them. A familiar example can explain an abstract mechanism; use numbers when they clarify it and have a relevant source/baseline.

Introduce unfamiliar terms through their meaning and use consistent referents. Preserve necessary nuance. Read or rehearse at the intended pace and revise stumbling points, empty setup, overloaded clauses or ambiguous wording based on their effect on the listener.

Pictures can demonstrate relationships while speech supplies context, cause or useful naming. Exact spoken captions are separate from display labels. Plan breath and reading room without deriving shot cuts mechanically from pauses.

Document pronunciation needs and claim limits. Describe hypothetical illustrations honestly. Verify health, financial, historical and other material claims against suitable evidence for the task.
