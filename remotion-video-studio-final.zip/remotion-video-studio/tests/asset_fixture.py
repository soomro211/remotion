"""Synthetic geometry fixture for engineering checks; not reusable production art."""
from pathlib import Path
import base64,json,shutil

def prepare_asset(project):
    project=Path(project)
    (project/'assets/source').mkdir(parents=True,exist_ok=True)
    (project/'assets/review').mkdir(parents=True,exist_ok=True)
    (project/'public/assets').mkdir(parents=True,exist_ok=True)
    (project/'assets/source/fixture.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="#F26A41"/></svg>')
    (project/'assets/review/context.png').write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a6X8AAAAASUVORK5CYII='))
    (project/'assets/review/notes.md').write_text('Synthetic engineering fixture only: solid geometric patch and tiny image proof. No artistic quality, motion review, originality or playback is claimed.')
    shutil.copy2(project/'assets/source/fixture.svg',project/'public/assets/fixture.svg')
    brief={'schema_version':2,'reference_review':'Synthetic technical fixture; no creative review is claimed.','visual_direction':'Project-local geometry to exercise dependency and export contracts.','requirements':[{'key':'fixture','purpose':'Technical integration fixture.','scene_ids':['s1'],'moving':False}]}
    manifest={'schema_version':2,'stage':'prepared-before-assembly','assets':[{'key':'fixture','status':'ready','origin':'project-specific','source_files':['assets/source/fixture.svg'],'preview_files':['assets/review/context.png'],'motion_files':[],'review_notes':'assets/review/notes.md','runtime_copies':[{'source':'assets/source/fixture.svg','target':'public/assets/fixture.svg'}],'files':{}}]}
    for name,data in [('brief',brief),('manifest',manifest)]:(project/f'assets/{name}.json').write_text(json.dumps(data,indent=2)+'\n')
