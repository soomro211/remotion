"""Explicit synthetic project decisions for tests; never initializer defaults."""
from pathlib import Path
import json,copy
ROOT=Path(__file__).resolve().parents[1]
def project_plan():
 p=json.loads((ROOT/'skills/video-director/assets/plan.template.json').read_text());p.update(title='Technical decision fixture',theme='cut-paper',width=1080,height=1920,fps=30,target_seconds=2)
 p['requirements']=[{'key':'duration','value':2,'source':{'kind':'user','reference':'Synthetic brief requests a two-second test.'},'scope':'project'}]
 p['brief'].update(purpose='Exercise the production contract.',audience='Technical reviewers',scope='Synthetic geometry only, no factual history claim.')
 p['narration']=[{'id':'n1','text':'This is a timing fixture.','proof':[]}]
 p['shots']=[{'id':'s1','purpose':'Exercise imported artwork.','visual':'A prepared geometric patch.','action':'The patch translates.','framing':'Whole patch visible.','camera':'Held to observe translation.','connection_to_next':'Settle for the fixture ending.','spoken_cues':[{'narration_id':'n1'}],'events':[]}]
 t=p['treatment'];t.update(approach='Observe one movement.',reason='Isolates technical rendering.',opening='Begin with the prepared patch visible.',ending='Hold its final location.')
 for k in ['setting','materials','lighting','context','tone','production_method']:t['art_direction'][k]={'value':'Synthetic '+k,'reason':'Controlled integration fixture.'}
 t['art_direction']['palette']={'roles':{'surface':'#FFFFFF','ink':'#000000'},'reason':'High contrast for a technical measurement.','evidence':[]}
 t['art_direction']['typography']={'roles':{'caption':'DM Sans'},'reason':'Available licensed test font, explicitly selected in this fixture.'}
 p['voice'].update(persona='Test reader',tone='Measured',pace='Unhurried',accent='English',energy='Even',wpm=120,pause_ms=0)
 p['production']['captions']={'enabled':False,'style':None}
 return p

def legacy_plan():
 return {'title':'Legacy fixture','theme':'cut-paper','width':160,'height':240,'fps':30,'voice':{'wpm':150,'pause_ms':0},'scenes':[{'id':'s1','narration':'This is a technical fixture for speech timing.','onscreen':[],'events':[]}],'production':{'asset_workflow':{'required':True,'mode':'project-local'}}}
