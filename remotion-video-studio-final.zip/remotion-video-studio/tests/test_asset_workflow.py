"""Permanent-library contracts: no video dependency, reviewed source, immutable versions."""
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'skills/remotion-themes/scripts/asset_workflow.py'
spec = importlib.util.spec_from_file_location('asset_workflow', SCRIPT)
workflow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(workflow)


class AssetWorkflow(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.project = self.root / 'video'
        self.library = self.root / 'skill-assets/library'
        self.brief(self.project)

    def brief(self, project, kind='new'):
        workflow.init(project)
        workflow.write_json(project / 'assets/brief.json', {
            'schema_version': 1, 'reference_review': 'Opened actual current paper references.',
            'visual_direction': 'A layered mechanism with editable geometry and clear contact.',
            'reuse_only_reason': 'Reviewed saved mechanism already matches this proof.' if kind == 'reuse' else '',
            'requirements': [{'key': 'hero', 'kind': kind, 'purpose': 'Reveal how the mechanism connects.', 'scene_ids': ['s1']}],
        })

    def package(self, key='mechanism', version='1.0.0'):
        root = workflow.new_package(self.project, key, version, 'topic')
        (root / 'source/shape.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><path d="M2 2H38V38H2Z" fill="#71956D"/></svg>')
        shutil.copy2(root / 'source/shape.svg', root / 'previews/shape.svg')
        (root / 'review/observations.md').write_text('Synthetic fixture for preservation contracts; no artistic quality assertion.\n')
        data = workflow.read(root / 'asset.json')
        data.update(description='Editable paper mechanism.', category='process', tags=['mechanism', 'paper'], status='ready', anchor={'x': 0, 'y': 0, 'units': 'canvas pixels'}, controls=['SVG fill and path geometry'], source_files=['source/shape.svg'], preview_files=['previews/shape.svg'], review_files=['review/observations.md'])
        data['provenance'].update(creator='test fixture', license='original fixture')
        data['review'] = {'status': 'passed', 'checks': {k: {'status': 'not-applicable' if k == 'motion' else 'pass', 'evidence': 'review/observations.md; static synthetic fixture'} for k in workflow.CHECKS}}
        workflow.write_json(root / 'asset.json', data)
        return root

    def archive(self, root):
        return workflow.archive(self.project, root.relative_to(self.project).as_posix(), 'hero', self.library)

    def test_readiness_requires_actual_asset_phase(self):
        untouched = self.root / 'untouched'
        with self.assertRaisesRegex(ValueError, 'stage missing'):
            workflow.check(untouched, self.library)
        workflow.init(untouched)
        with self.assertRaisesRegex(ValueError, 'reference review'):
            workflow.check(untouched, self.library)
        with self.assertRaisesRegex(ValueError, 'Create/review/archive'):
            workflow.check(self.project, self.library)

    def test_archived_asset_restores_without_original_video(self):
        package = self.package()
        shared = self.archive(package)
        self.assertEqual(workflow.check(self.project, self.library)['status'], 'PASS')
        original = workflow.files_in(shared)
        shutil.rmtree(self.project)
        second = self.root / 'other-video'
        self.brief(second, 'reuse')
        restored = workflow.reuse(second, 'mechanism', '1.0.0', 'hero', self.library)
        self.assertEqual(workflow.files_in(restored), original)
        self.assertEqual(workflow.check(second, self.library)['status'], 'PASS')
        self.assertEqual(workflow.read(self.library / 'index.json')['packages'][0]['id'], 'mechanism')

    def test_draft_or_missing_evidence_never_enters_main_library(self):
        package = self.package()
        data = workflow.read(package / 'asset.json')
        data['review']['checks']['silhouette']['evidence'] = ''
        workflow.write_json(package / 'asset.json', data)
        with self.assertRaisesRegex(ValueError, 'evidence: silhouette'):
            self.archive(package)
        self.assertFalse(self.library.exists())
        data['review']['checks']['silhouette']['evidence'] = 'review/observations.md'
        data['status'] = 'draft'
        workflow.write_json(package / 'asset.json', data)
        with self.assertRaisesRegex(ValueError, 'not ready'):
            self.archive(package)

    def test_unarchived_or_damaged_shared_source_blocks_assembly(self):
        package = self.package()
        shared = self.archive(package)
        (shared / 'source/shape.svg').write_text('damaged')
        with self.assertRaises((ValueError, SyntaxError)):
            workflow.check(self.project, self.library)

    def test_rerun_idempotent_and_version_collision_preserves_both_sides(self):
        package = self.package()
        shared = self.archive(package)
        before = workflow.files_in(shared)
        self.archive(package)
        self.assertEqual(before, workflow.files_in(shared))
        data = workflow.read(package / 'asset.json')
        data['description'] = 'Changed without a new version.'
        workflow.write_json(package / 'asset.json', data)
        with self.assertRaisesRegex(ValueError, 'collision'):
            self.archive(package)
        self.assertEqual(before, workflow.files_in(shared))
        self.assertEqual(workflow.read(package / 'asset.json')['description'], data['description'])

    def test_restore_preserves_local_edits(self):
        package = self.package()
        self.archive(package)
        target = package / 'source/shape.svg'
        target.write_text('user edit')
        # Remove the binding so reuse can be chosen deliberately; the edited source still wins.
        workflow.write_json(self.project / 'assets/manifest.json', {'schema_version': 1, 'assets': []})
        with self.assertRaisesRegex(ValueError, 'local edits preserved'):
            workflow.reuse(self.project, 'mechanism', '1.0.0', 'hero', self.library)
        self.assertEqual(target.read_text(), 'user edit')

    def test_reuse_cannot_silently_satisfy_a_new_art_requirement(self):
        self.archive(self.package())
        second = self.root / 'other-video'
        self.brief(second, 'new')
        workflow.reuse(second, 'mechanism', '1.0.0', 'hero', self.library)
        with self.assertRaisesRegex(ValueError, 'newly reviewed and archived'):
            workflow.check(second, self.library)

    def test_external_video_dependencies_and_missing_local_import_rejected(self):
        package = self.package()
        source = package / 'source/shape.svg'
        source.write_text('<svg xmlns="http://www.w3.org/2000/svg"><image href="../../../../../video/public/art.png"/></svg>')
        with self.assertRaisesRegex(ValueError, 'original project'):
            self.archive(package)
        source.write_text('<svg xmlns="http://www.w3.org/2000/svg"/>')
        ts = package / 'source/part.tsx'
        ts.write_text("export {Shape} from './missing';\n")
        with self.assertRaisesRegex(ValueError, 'Missing packaged dependency'):
            self.archive(package)
        ts.write_text("import {staticFile} from 'remotion'; const x=staticFile('old-video.png');\n")
        data = workflow.read(package / 'asset.json'); data['dependencies']['packages'] = ['remotion']; workflow.write_json(package / 'asset.json', data)
        with self.assertRaisesRegex(ValueError, 'staticFile'):
            self.archive(package)

    def test_traversal_and_source_symlinks_rejected_before_archive(self):
        with self.assertRaisesRegex(ValueError, 'Unsafe'):
            workflow.inside(self.project, '../other')
        package = self.package()
        (package / 'source/outside').symlink_to(self.root, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'symlink'):
            self.archive(package)
        self.assertFalse(self.library.exists())

    def test_sync_merges_assets_and_preflights_all_collisions(self):
        first = self.package(); self.archive(first)
        destination = self.root / 'checkout/assets/library'
        workflow.sync(self.library, destination)
        second = self.package('another-mechanism')
        # Use a second requirement to preserve the first binding.
        data = workflow.read(self.project / 'assets/brief.json')
        data['requirements'].append({'key': 'another', 'kind': 'new', 'purpose': 'Another process view.'})
        workflow.write_json(self.project / 'assets/brief.json', data)
        workflow.archive(self.project, second.relative_to(self.project).as_posix(), 'another', self.library)
        broken = destination / 'mechanism/1.0.0/asset.json'
        data = workflow.read(broken); data['description'] = 'Conflicting valid metadata'; workflow.write_json(broken, data)
        with self.assertRaisesRegex(ValueError, 'collision'):
            workflow.sync(self.library, destination)
        self.assertFalse((destination / 'another-mechanism').exists())
        broken.write_bytes((self.library / 'mechanism/1.0.0/asset.json').read_bytes())
        workflow.sync(self.library, destination)
        self.assertEqual(len(workflow.read(destination / 'index.json')['packages']), 2)

    def test_helper_survives_relocated_skill_and_default_archive_stays_in_skill(self):
        package = self.package()
        relocated = self.root / 'installed/remotion-themes/scripts/asset_workflow.py'
        relocated.parent.mkdir(parents=True)
        shutil.copy2(SCRIPT, relocated)
        result = subprocess.run([sys.executable, str(relocated), 'archive', str(self.project), '--package', package.relative_to(self.project).as_posix(), '--requirement', 'hero'], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        library = relocated.parent.parent / 'themes/cut-paper/assets/library'
        self.assertTrue((library / 'mechanism/1.0.0/source/shape.svg').is_file())
        self.assertNotIn(str(self.project), (library / 'index.json').read_text())


if __name__ == '__main__':
    unittest.main()
