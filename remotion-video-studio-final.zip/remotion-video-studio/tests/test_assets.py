"""Meaningful installer contracts: closure, portability, preservation and safe upgrades."""
import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('studio_asset_installer',ROOT/'skills/remotion-themes/scripts/assets.py')
assets=importlib.util.module_from_spec(spec);spec.loader.exec_module(assets)
class AssetInstallation(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.project=Path(self.temp.name)/'project'
 def test_person_dependency_closure_and_relative_imports(self):
  result=assets.install(self.project,['person','journey']);base=Path(result['destination'])
  self.assertEqual(set(result['assets']),{'person','journey','material'})
  self.assertTrue((base/'characters/gait.ts').exists());self.assertTrue((base/'core/material.tsx').exists())
  self.assertFalse((base/'scenery').exists());self.assertIn('sampleJourney',(base/'index.ts').read_text())
  self.assertNotIn('/workspace/',(base/'asset-install.json').read_text())
 def test_rerun_is_idempotent_and_additions_keep_existing_selection(self):
  result=assets.install(self.project,['person']);base=Path(result['destination']);before=(base/'characters/Person.tsx').read_bytes()
  assets.install(self.project,['person']);assets.install(self.project,['tree'])
  self.assertEqual(before,(base/'characters/Person.tsx').read_bytes())
  self.assertIn('PaperPerson',(base/'index.ts').read_text());self.assertIn('PaperTree',(base/'index.ts').read_text())
 def test_local_conflict_is_atomic(self):
  result=assets.install(self.project,['person']);base=Path(result['destination']);record=(base/'asset-install.json').read_bytes()
  custom=base/'core/material.tsx';custom.write_text('// user material edit\n')
  with self.assertRaisesRegex(ValueError,'Local edits preserved'):assets.install(self.project,['tree'])
  self.assertEqual(custom.read_text(),'// user material edit\n');self.assertFalse((base/'scenery').exists())
  self.assertEqual(record,(base/'asset-install.json').read_bytes())
 def test_force_retains_original_edit_in_backup(self):
  result=assets.install(self.project,['person']);base=Path(result['destination']);custom=base/'characters/Person.tsx';custom.write_text('// user character\n')
  assets.install(self.project,['person'],force=True)
  self.assertEqual((base/'characters/Person.tsx.bak').read_text(),'// user character\n')
 def test_unknown_id_creates_no_partial_project(self):
  with self.assertRaisesRegex(ValueError,'Unknown asset'):assets.install(self.project,['person','missing'])
  self.assertFalse(self.project.exists())
 def test_canonical_captions_copy_and_camera_are_independent(self):
  result=assets.install(self.project,['captions','camera']);base=Path(result['destination'])
  self.assertEqual((base/'motion/SmoothPaperCaptions.tsx').read_bytes(),(ROOT/'skills/remotion-captions/assets/SmoothPaperCaptions.tsx').read_bytes())
  self.assertFalse((base/'characters').exists())
 def test_no_downgrade(self):
  result=assets.install(self.project,['tree']);base=Path(result['destination']);p=base/'asset-install.json';d=json.loads(p.read_text());d['version']='9.0.0';p.write_text(json.dumps(d))
  with self.assertRaisesRegex(ValueError,'downgrade'):assets.install(self.project,['person'])
  self.assertFalse((base/'characters').exists())
 def test_destination_symlink_cannot_escape_project(self):
  outside=Path(self.temp.name)/'outside';outside.mkdir();p=self.project/'src/assets';p.mkdir(parents=True);(p/'cut-paper').symlink_to(outside,target_is_directory=True)
  with self.assertRaisesRegex(ValueError,'escapes'):assets.install(self.project,['tree'])
  self.assertEqual(list(outside.iterdir()),[])
 def test_path_traversal_and_dependency_cycle_rejected(self):
  with self.assertRaisesRegex(ValueError,'Unsafe'):assets.safe_path(self.project,'../../outside')
  broken={'assets':[{'id':'cycle','module':'a'}],'modules':{'a':{'requires':['b']},'b':{'requires':['a']}}}
  with self.assertRaisesRegex(ValueError,'Cyclic'):assets.closure(broken,['cycle'])
if __name__=='__main__':unittest.main()
