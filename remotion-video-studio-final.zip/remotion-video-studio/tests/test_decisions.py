"""Scope/traceability/timing regressions for schema 3; no artistic certification."""
import copy,importlib.util,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from plan_fixture import project_plan
ROOT=Path(__file__).resolve().parents[1];SCRIPTS=ROOT/'skills/video-director/scripts'
spec=importlib.util.spec_from_file_location('decision_docs',SCRIPTS/'plan_docs.py');docs=importlib.util.module_from_spec(spec);spec.loader.exec_module(docs)
class DecisionArchitecture(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
 def init(self,name,*args):
  p=self.root/name;subprocess.run([sys.executable,str(SCRIPTS/'init_video.py'),str(p),*args],capture_output=True,check=True);return p,json.loads((p/'video/plan.json').read_text())
 def test_initializer_has_no_visual_voice_timing_or_format_decisions(self):
  path,p=self.init('untouched')
  self.assertEqual(p['narration'],[]);self.assertEqual(p['shots'],[]);self.assertEqual(p['requirements'],[])
  self.assertTrue(all(p[k]is None for k in ['theme','width','height','fps','target_seconds']))
  self.assertEqual(p['treatment']['art_direction']['palette']['roles'],{})
  self.assertEqual(p['treatment']['art_direction']['typography']['roles'],{})
  self.assertEqual(p['voice']['persona'],'');self.assertEqual(p['voice']['wpm'],None)
  self.assertFalse((path/'src/theme').exists());self.assertFalse((path/'public/fonts').exists());self.assertFalse((path/'public/sfx').exists())
 def test_profile_is_explicit_and_retains_user_provenance_without_styling(self):
  _,p=self.init('profile','--profile','channel')
  self.assertEqual(p['theme'],'cut-paper');self.assertTrue(p['production']['captions']['enabled'])
  self.assertIsNone(p['production']['captions']['style'])
  self.assertTrue(all(r['source']['kind']=='user'and r['source']['reference']for r in p['requirements']))
 def test_cli_choices_are_not_falsely_attributed_to_user(self):
  _,p=self.init('configured','--size','900x1200','--fps','24')
  self.assertEqual((p['width'],p['height'],p['fps']),(900,1200,24));self.assertEqual(p['requirements'],[])
  self.assertEqual({a['decision']for a in p['assumptions']},{'width','height','fps'})
 def test_narration_shot_many_to_many_is_valid(self):
  p=project_plan();p['narration'].append({'id':'n2','text':'Another paragraph.','proof':[]});p['shots'][0]['spoken_cues'].append({'narration_id':'n2'})
  self.assertEqual(docs.validate_plan(p),[])
  p['narration']=p['narration'][:1];p['shots'][0]['spoken_cues']=[{'narration_id':'n1'}]
  for i in [2,3]:s=copy.deepcopy(p['shots'][0]);s['id']='s'+str(i);p['shots'].append(s)
  self.assertEqual(docs.validate_plan(p),[])
 def test_source_and_reference_scope_are_required(self):
  p=project_plan();p['requirements'][0]['source']['reference']='';self.assertTrue(any('source kind'in x for x in docs.validate_plan(p)))
  p=project_plan();p['treatment']['art_direction']['references']=[{'uri':'reference.jpg','roles':['material'],'adopt':'Paper depth'}]
  self.assertTrue(any('reference needs'in x for x in docs.validate_plan(p)))
 def test_reference_material_role_does_not_supply_a_palette(self):
  p=project_plan();p['treatment']['art_direction']['references']=[{'uri':'reference.jpg','roles':['material'],'adopt':'Layer thickness','limits':'Color decisions remain based on the scene.'}]
  p['treatment']['art_direction']['palette']['roles']={}
  self.assertTrue(any('palette needs'in x for x in docs.validate_plan(p)))
 def test_caption_style_requires_project_values(self):
  p=project_plan();p['production']['captions']={'enabled':True,'style':None};self.assertIn('enabled captions require explicit project style',docs.validate_plan(p))
 def test_unknown_narration_cue_rejected(self):
  p=project_plan();p['shots'][0]['spoken_cues']=[{'narration_id':'missing'}];self.assertTrue(any('unknown narration'in x for x in docs.validate_plan(p)))
 def test_render_requires_actual_timing_and_verified_speech(self):
  p=project_plan();errors=docs.validate_plan(p,render=True);self.assertTrue(any('start_frame'in x for x in errors));self.assertTrue(any('verified actual-speech'in x for x in errors))
 def test_registering_take_does_not_infer_shots_or_effects(self):
  root,p=self.init('audio','--size','1080x1920','--fps','30');p=project_plan();p['shots'].append({**p['shots'][0],'id':'s2'});(root/'video/plan.json').write_text(json.dumps(p))
  subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=440:duration=1','-ar','24000',str(root/'public/take.wav')],check=True)
  before=(root/'public/take.wav').read_bytes();subprocess.run([sys.executable,str(SCRIPTS/'after_vo.py'),'--project',str(root),'--vo','public/take.wav'],check=True,capture_output=True)
  got=json.loads((root/'video/plan.json').read_text());self.assertEqual(got['shots'],p['shots']);self.assertFalse(got['vo']['timing_verified']);self.assertNotIn('total_frames',got);self.assertFalse((root/'video/cues.json').exists());self.assertEqual(before,(root/'public/take.wav').read_bytes())
 def test_missing_events_generate_silence_without_sound_library(self):
  root,p=self.init('silent');p=project_plan();p.update(total_frames=30);p['shots'][0].update(start_frame=0,duration_frames=30);p['shots'][0].pop('events');(root/'video/plan.json').write_text(json.dumps(p))
  subprocess.run([sys.executable,str(SCRIPTS/'auto_sfx.py'),str(root/'video/plan.json'),'--project',str(root),'--no-preview'],check=True,capture_output=True)
  self.assertEqual(json.loads((root/'video/cues.json').read_text())['cues'],[]);self.assertFalse((root/'public/sfx').exists())
 def test_authored_sound_levels_and_overlap_are_preserved(self):
  root,p=self.init('authored');p=project_plan();p.update(total_frames=30);p['shots'][0].update(start_frame=0,duration_frames=30,events=[{'t':.2,'file':'chosen.wav','volume':.07,'note':'Physical action'} for _ in range(4)])
  (root/'public/sfx').mkdir();subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=500:duration=0.1',str(root/'public/sfx/chosen.wav')],check=True)
  (root/'video/plan.json').write_text(json.dumps(p));subprocess.run([sys.executable,str(SCRIPTS/'auto_sfx.py'),str(root/'video/plan.json'),'--project',str(root),'--no-preview'],check=True,capture_output=True)
  cues=json.loads((root/'video/cues.json').read_text())['cues'];self.assertEqual(len(cues),4);self.assertTrue(all(c['volume']==.07 and c['file']=='chosen.wav'and c['frame']==6 for c in cues))
 def test_schema3_rejects_legacy_scene_field(self):
  p=project_plan();p['scenes']=[];self.assertTrue(any('not scenes'in e for e in docs.validate_plan(p)))
if __name__=='__main__':unittest.main()
