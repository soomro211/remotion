"""Regression checks for the production helpers; requires numpy/scipy and FFmpeg.

These verify technical contracts, not visual quality. All fixtures are temporary
and synthetic. No network, TTS, ASR model or user audio is required.
"""
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIRECTOR = ROOT / 'skills' / 'video-director'
SOUND = ROOT / 'skills' / 'remotion-sound-design'


def run(*args, ok=True, cwd=None):
    result = subprocess.run([str(x) for x in args], capture_output=True, text=True, cwd=cwd)
    if ok and result.returncode:
        raise AssertionError(result.stdout + result.stderr)
    return result


def script(name, *args, **kwargs):
    return run(sys.executable, DIRECTOR / 'scripts' / name, *args, **kwargs)


class PipelineRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        for tool in ('ffmpeg', 'ffprobe'):
            if not shutil.which(tool): raise unittest.SkipTest(f'{tool} is required')
        for module in ('numpy', 'scipy'):
            if importlib.util.find_spec(module) is None: raise unittest.SkipTest(f'{module} is required')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.project = Path(self.temp.name) / 'project'
        (self.project / 'public').mkdir(parents=True)
        (self.project / 'video').mkdir()
        from plan_fixture import legacy_plan
        self.plan = legacy_plan()

    def save_plan(self):
        path = self.project / 'video' / 'plan.json'
        path.write_text(json.dumps(self.plan))
        return path

    def voice(self, name='take.wav', duration=2):
        path = self.project / 'public' / name
        run('ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', f'aevalsrc=0.12*sin(2*PI*431*t)*gt(mod(t\\,0.5)\\,0.12):s=48000:d={duration}', '-af', 'afade=t=in:d=0.08,afade=t=out:st=1.8:d=0.2', path)
        return path

    def test_init_preserves_existing_entry_and_theme_edits(self):
        (self.project / 'src' / 'theme').mkdir(parents=True)
        entry = self.project / 'src' / 'index.ts'
        entry.write_text('// existing user entry\n')
        custom = self.project / 'src' / 'theme' / 'custom.ts'
        custom.write_text('export const custom = true;\n')
        (self.project / 'public' / 'fonts').mkdir()
        custom_font = self.project / 'public' / 'fonts' / 'user-font.txt'
        custom_font.write_text('preserve user font assets')
        script('init_video.py', self.project, '--no-sfx')
        self.assertEqual(entry.read_text(), '// existing user entry\n')
        self.assertTrue(custom.exists())
        self.assertFalse((self.project / 'src' / 'StudioRoot.tsx').exists())
        self.assertFalse((self.project / 'public' / 'fonts' / 'DMSans.ttf').exists())
        self.assertEqual(custom_font.read_text(), 'preserve user font assets')

    def test_invalid_plan_reports_errors_without_writing_approval(self):
        from plan_fixture import project_plan
        self.plan = project_plan()
        self.plan['shots'] *= 2
        self.plan['voice']['wpm'] = 0
        result = script('plan_docs.py', self.save_plan(), ok=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('duplicate/missing id', result.stderr)
        self.assertIn('voice.wpm', result.stderr)
        self.assertFalse((self.project / 'video' / 'PLAN.md').exists())

    def test_plan_handoff_keeps_project_reasons_and_shot_connections(self):
        from plan_fixture import project_plan
        self.plan = project_plan()
        script('plan_docs.py', self.save_plan())
        document = (self.project / 'video' / 'PLAN.md').read_text()
        self.assertIn('Independent shot plan', document)
        self.assertIn('Synthetic brief requests a two-second test.', document)
        self.assertIn('High contrast for a technical measurement.', document)
        self.assertIn('Settle for the fixture ending.', document)

    def test_no_preview_emits_cues_without_replacing_a_mix(self):
        self.plan['total_frames'] = 60
        self.plan['scenes'][0].update(start_frame=0, duration_frames=60)
        self.save_plan()
        preview = self.project / 'video' / 'preview-mix.wav'
        preview.write_bytes(b'previous verified mix')
        script('auto_sfx.py', self.project / 'video' / 'plan.json', '--project', self.project, '--no-preview')
        self.assertEqual(preview.read_bytes(), b'previous verified mix')
        self.assertEqual((self.project / 'src' / 'sfxCues.ts').read_text().count('{"file"'), 0)

    def test_noncanonical_wav_header_decodes_without_changing_the_source(self):
        import numpy as np
        path = self.voice()
        spec = importlib.util.spec_from_file_location('mix_header_test', SOUND / 'scripts' / 'mix_preview.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        original = module.load(path)
        raw = bytearray(path.read_bytes())
        self.assertEqual(raw[12:16], b'fmt ')
        raw[28:32] = (1).to_bytes(4, 'little')  # Noncanonical average-byte-rate field.
        path.write_bytes(raw)
        before = path.read_bytes()
        decoded = module.load(path)
        self.assertTrue(np.array_equal(decoded, original))
        self.assertEqual(path.read_bytes(), before)

    def test_after_vo_preserves_wav_and_compressed_sources_and_silence(self):
        wav = self.voice('vo.wav')
        original = wav.read_bytes()
        mp3 = self.project / 'public' / 'take.mp3'
        run('ffmpeg', '-v', 'error', '-y', '-i', wav, mp3)
        before_mp3 = mp3.read_bytes()
        self.save_plan()
        script('after_vo.py', '--project', self.project, '--vo', 'public/take.mp3', '--tail', '0.1')
        updated = json.loads((self.project / 'video' / 'plan.json').read_text())
        self.assertEqual(wav.read_bytes(), original)
        self.assertEqual(mp3.read_bytes(), before_mp3)
        self.assertEqual(updated['vo']['file'], 'take.mp3')
        self.assertEqual(updated['vo']['original_sha256'], hashlib.sha256(before_mp3).hexdigest())
        self.assertFalse(updated['vo']['timing_verified'])
        self.assertGreaterEqual(updated['total_frames'] / updated['fps'], updated['vo']['duration_s'] - 1 / updated['fps'])
        self.assertEqual(json.loads((self.project / 'video' / 'cues.json').read_text())['cues'], [])
        self.assertNotIn('[\n,', (self.project / 'src' / 'sfxCues.ts').read_text())
        # Portable path still resolves without an explicit --vo when regenerating cues.
        script('auto_sfx.py', self.project / 'video' / 'plan.json', '--project', self.project)
        script('after_vo.py', '--project', self.project, '--vo', 'public/vo.wav', '--tail', '0.1')
        self.assertEqual(wav.read_bytes(), original)
        self.assertEqual(json.loads((self.project / 'video' / 'plan.json').read_text())['vo']['file'], 'vo.wav')

    def test_mono_mix_retains_amplitude_and_supports_short_music(self):
        import numpy as np
        from scipy.io import wavfile
        voice = self.voice()
        spec = importlib.util.spec_from_file_location('mix_under_test', SOUND / 'scripts' / 'mix_preview.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        x = module.load(voice)
        _, original = wavfile.read(voice)
        self.assertAlmostEqual(float(np.max(abs(x))), float(np.max(abs(original.astype(np.float32) / 32768))), places=5)
        cue = dict(fps=30, duration_frames=6, cues=[], music=dict(file=str(voice), volume=.1))
        path = self.project / 'video' / 'short-cues.json'
        path.write_text(json.dumps(cue))
        run(sys.executable, SOUND / 'scripts' / 'mix_preview.py', path, '--out', self.project / 'video' / 'short.wav')
        rate, samples = wavfile.read(self.project / 'video' / 'short.wav')
        self.assertEqual(rate, 48000)
        self.assertEqual(samples.shape, (9600, 2))
        self.assertEqual(samples.dtype, np.float32)

    def test_final_master_project_paths_and_encoded_checks(self):
        from asset_fixture import prepare_asset
        prepare_asset(self.project)
        script('check_assets.py', '--project', self.project, '--seal')
        voice = self.voice()
        raw = self.project / 'video' / 'raw.mp4'
        run('ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=0x1B2845:s=160x240:r=30:d=2', '-i', voice, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', raw)
        self.plan.update(width=160, height=240, total_frames=60)
        self.plan['vo'] = dict(file='take.wav', original_sha256=hashlib.sha256(voice.read_bytes()).hexdigest())
        self.save_plan()
        script('finalize.py', '--project', self.project, '--input', 'video/raw.mp4', '--audio-master', 'public/take.wav', '--out', 'out/final.mp4', cwd=Path(self.temp.name))
        checks = json.loads((self.project / 'video' / 'export-check.json').read_text())['checks']
        self.assertTrue(all(c['status'] == 'PASS' for c in checks))
        voice.write_bytes(voice.read_bytes() + b'changed')
        result = script('verify_export.py', '--project', self.project, '--input', 'out/final.mp4', ok=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('FAIL original voice bytes', result.stdout)

    def test_finalization_refuses_unprepared_project_assets_before_render(self):
        self.save_plan()
        result = script('finalize.py', '--project', self.project, ok=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Asset readiness failed before render', result.stderr)
        self.assertFalse((self.project / 'out').exists())


    def test_explicit_silent_delivery_has_no_invented_audio(self):
        from asset_fixture import prepare_asset
        from plan_fixture import project_plan
        prepare_asset(self.project)
        self.plan = project_plan()
        self.plan.update(width=160, height=240, total_frames=30)
        self.plan['narration'] = []
        self.plan['shots'][0].update(start_frame=0, duration_frames=30, spoken_cues=[])
        self.save_plan()
        script('check_assets.py', '--project', self.project, '--seal')
        raw = self.project / 'video/raw.mp4'
        run('ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=gray:s=160x240:r=30:d=1', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', raw)
        script('finalize.py', '--project', self.project, '--input', 'video/raw.mp4', '--silent', '--out', 'out/silent.mp4')
        data = json.loads(run('ffprobe', '-v', 'error', '-show_streams', '-of', 'json', self.project / 'out/silent.mp4').stdout)
        self.assertFalse(any(s['codec_type'] == 'audio' for s in data['streams']))

if __name__ == '__main__':
    unittest.main()
