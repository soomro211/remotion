"""Failure-path and portability tests for the project-local asset gate."""
import importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
from asset_fixture import prepare_asset
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('project_assets',ROOT/'skills/video-director/scripts/check_assets.py');workflow=importlib.util.module_from_spec(spec);spec.loader.exec_module(workflow)
class ProjectAssets(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.project=Path(self.tmp.name)/'film';prepare_asset(self.project)
 def edit(self,name,mutate):
  p=self.project/'assets'/name;d=json.loads(p.read_text());mutate(d);p.write_text(json.dumps(d))
 def test_portable_project_needs_no_installed_art_archive(self):
  workflow.check_project(self.project,True);dest=Path(self.tmp.name)/'relocated';shutil.move(self.project,dest)
  self.assertEqual(workflow.check_project(dest)['status'],'PASS')
 def test_missing_proof_invalidates_previous_pass(self):
  workflow.check_project(self.project,True);(self.project/'assets/review/context.png').unlink()
  with self.assertRaisesRegex(ValueError,'missing/empty'):workflow.check_project(self.project)
  self.assertNotEqual(json.loads((self.project/'video/asset-check.json').read_text())['status'],'PASS')
 def test_changed_source_rejected_and_copy_must_be_regenerated_before_reseal(self):
  workflow.check_project(self.project,True);p=self.project/'assets/source/fixture.svg';p.write_text(p.read_text().replace('F26A41','4FA8DC'))
  with self.assertRaisesRegex(ValueError,'runtime copy differs'):workflow.check_project(self.project,True)
  shutil.copy2(p,self.project/'public/assets/fixture.svg')
  with self.assertRaisesRegex(ValueError,'changed/unsealed'):workflow.check_project(self.project)
  workflow.check_project(self.project,True);self.assertEqual(workflow.check_project(self.project)['status'],'PASS')
 def test_missing_requirement_rejected(self):
  self.edit('brief.json',lambda d:d['requirements'].append(dict(key='missing',purpose='Planned extra part',scene_ids=['s1'],moving=False)))
  with self.assertRaisesRegex(ValueError,'unprepared requirements'):workflow.check_project(self.project,True)
 def test_path_escape_and_symlink_rejected(self):
  self.edit('manifest.json',lambda d:d['assets'][0].update(source_files=['assets/source/../../outside.svg']))
  with self.assertRaisesRegex(ValueError,'outside allowed'):workflow.check_project(self.project,True)
  prepare_asset(self.project);outside=Path(self.tmp.name)/'outside.svg';outside.write_text('<svg/>');p=self.project/'assets/source/fixture.svg';p.unlink();p.symlink_to(outside)
  with self.assertRaisesRegex(ValueError,'symlinks/escaping'):workflow.check_project(self.project,True)
 def test_moving_art_requires_motion_proof(self):
  self.edit('brief.json',lambda d:d['requirements'][0].update(moving=True))
  with self.assertRaisesRegex(ValueError,'motion proof'):workflow.check_project(self.project,True)
 def test_source_dependency_is_required_and_hashed(self):
  p=self.project/'assets/source/part.ts';p.write_text("export const part=1;\n")
  (self.project/'assets/source/hero.ts').write_text("import {part} from './part'; export const hero=part;\n")
  self.edit('manifest.json',lambda d:d['assets'][0]['source_files'].append('assets/source/hero.ts'))
  with self.assertRaisesRegex(ValueError,'unrecorded source dependency'):workflow.check_project(self.project,True)
  self.edit('manifest.json',lambda d:d['assets'][0]['source_files'].append('assets/source/part.ts'))
  workflow.check_project(self.project,True);p.write_text('export const part=2;\n')
  with self.assertRaisesRegex(ValueError,'changed/unsealed'):workflow.check_project(self.project)
 def test_malformed_requirement_reports_a_useful_error(self):
  self.edit('brief.json',lambda d:d['requirements'].append(None))
  with self.assertRaisesRegex(ValueError,'requirements must be objects'):workflow.check_project(self.project,True)
 def test_old_shared_contract_requires_explicit_migration(self):
  self.edit('manifest.json',lambda d:d.update(schema_version=1))
  with self.assertRaisesRegex(ValueError,'explicitly migrate'):workflow.check_project(self.project,True)
 def test_initialization_does_not_overwrite_reviewed_work(self):
  workflow.check_project(self.project,True);p=self.project/'assets/manifest.json';before=p.read_bytes();workflow.initialize(self.project);self.assertEqual(before,p.read_bytes())
 def test_project_art_direction_change_invalidates_review_context(self):
  (self.project/'video').mkdir(exist_ok=True)
  plan={'schema_version':3,'shots':[{'id':'s1'}],'treatment':{'art_direction':{'palette':{'surface':'chosen'}}}}
  p=self.project/'video/plan.json';p.write_text(json.dumps(plan));workflow.check_project(self.project,True)
  plan['treatment']['art_direction']['palette']['surface']='revised';p.write_text(json.dumps(plan))
  with self.assertRaisesRegex(ValueError,'art-direction context changed'):workflow.check_project(self.project)
if __name__=='__main__':unittest.main()
