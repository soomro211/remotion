#!/usr/bin/env python3
"""Record coverage of the complete Markdown reference corpus and current-default routing."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
def main():
 rows=[];errors=[]
 specific={'remotion-create/video-layout.md','remotion-markup/voiceover.md','remotion-markup/SKILL.md','remotion-captions/display-captions.md','remotion-captions/references/smooth-subtitles.md','video-director/references/camera-and-continuity.md','video-director/references/production-quality.md','video-director/references/industrial-revolution-example.md','video-director/references/plan-schema.md','remotion-preproduction/references/motion-principles.md','remotion-preproduction/references/qa.md','remotion-preproduction/references/anti-slop.md','video-scriptwriting/references/script-format-and-checks.md','remotion-themes/SKILL.md','remotion-themes/themes/cut-paper/THEME.md','video-director/SKILL.md','remotion-create/SKILL.md'}
 for p in sorted((ROOT/'skills').rglob('*.md')):
  relative=p.relative_to(ROOT/'skills').as_posix();text=p.read_text()
  archived='/assets/library/'in relative and len(p.relative_to(ROOT/'skills').parts)>7
  routed='current-workflow.md'in text or p.name in ['THEME.md','current-workflow.md'] or archived
  if not routed:errors.append('Missing current-default routing: '+relative)
  if re.search(r'y\s*=\s*1346|y\s*=\s*1494',text):errors.append('Outdated caption coordinate: '+relative)
  if 'assets/CameraRig.tsx'in text and 'cut-paper/assets/motion/CameraRig.tsx'not in text:errors.append('Old duplicate camera source link: '+relative)
  disposition='Production examples/defaults revised'if relative in specific else 'Current production-default routing added; task-specific guidance retained'
  if relative.endswith('current-workflow.md')or '/assets/'in relative:disposition='Current canonical workflow / asset / QA reference'
  if archived:disposition='Immutable asset-specific source/review record; current workflow applies through the enclosing archive guide'
  rows.append({'file':'skills/'+relative,'disposition':disposition,'current_routing':routed,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 assert not errors,errors
 report={'status':'PASS','version':'1.4.0','markdown_files':len(rows),'skill_entries':sum(Path(x['file']).name=='SKILL.md'for x in rows),'scope':'All Markdown references checked for current-default routing (archived asset evidence inherits its enclosing guide), stale caption positions and duplicate-camera links. Asset-first production/storage references revised. Targeted production conflicts were revised. Upstream API guides retained their API metadata; not every advanced API was independently executed.','rows':rows}
 (ROOT/'REFERENCE-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
 lines=['# Reference audit — 1.4.0','','The complete skill/reference Markdown corpus is aligned with the current production-default authority and asset workflow. This audit preserves task-specific API knowledge while making the studio defaults explicit.','','Changes include mandatory create/review/archive before scene assembly, durable topic/universal packages inside the main skill set, immutable versions, restore/sync commands, asset readiness and finalization checks, and an actual layered-source example. Existing primary images, lower captions, articulated walking, canonical camera/source-time/contact rules and local fonts remain current. The Industrial Revolution study is explicitly historical.','','Reference and preview source hashes are recorded. The bundle validator rejects stale preview sources/pictures; the release manifest protects the remaining file set. Changes to shared assets must update their examples, previews, guides and checks in the same release.','','This is a production-default, example and link audit, not an independent execution of every advanced upstream API. The executable asset paths are tested against the pinned project.','','| Reference | Disposition |','|---|---|']
 for row in rows:lines.append('| ['+row['file']+']('+row['file']+') | '+row['disposition']+' |')
 (ROOT/'REFERENCE-AUDIT.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
