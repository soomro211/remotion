#!/usr/bin/env python3
"""Audit current routing and obsolete production dependencies; not artistic review."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
def main():
 rows=[];errors=[]
 obsolete=['assets/library/','assets/catalog.json','assets.py copy','asset_workflow.py','production-street.png','production-interior.png','images/overview.png','minimum 4 on each','Score 1-5','Hook scored 4+','Reuse the tested person rig','Reusable assets supply','Compare three genuinely','Draft five hooks','x80/y1500','strong blue, warm yellow','sound-palettes.json','scripts/assets.py','default Cut Paper treatment']
 for p in sorted((ROOT/'skills').rglob('*.md')):
  relative=p.relative_to(ROOT).as_posix();text=p.read_text()
  routed='current-workflow.md'in text or p.name=='current-workflow.md'
  if not routed:errors.append('Missing current-default routing: '+relative)
  for token in obsolete:
   if token in text:errors.append('Obsolete instruction: '+relative+' -> '+token)
  if re.search(r'y\s*=\s*1346|y\s*=\s*1494',text):errors.append('Outdated caption coordinate: '+relative)
  rows.append({'file':relative,'current_routing':routed,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 if errors:raise SystemExit('\n'.join(errors))
 report={'status':'PASS','version':'3.0.0','markdown_files':len(rows),'scope':'All skill Markdown routed to decision architecture; obsolete visual-library dependencies, old caption positions and default favorable score gates checked. API references retained, not all APIs executed. Creative quality requires per-film review.','rows':rows}
 (ROOT/'REFERENCE-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS:',len(rows),'Markdown files; routing and obsolete-reference checks.')
if __name__=='__main__':main()
