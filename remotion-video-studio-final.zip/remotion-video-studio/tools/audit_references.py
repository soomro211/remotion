#!/usr/bin/env python3
"""Audit real routing (link graph + filename mentions) and obsolete dependencies; not artistic review."""
from pathlib import Path
import hashlib,json,re
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[1]
def main():
 rows=[];errors=[]
 obsolete=['legacy_pause_estimator','synth_sfx','SfxTrack','example-cues','remotion-sound-design','remotion-themes','remotion-preproduction','video-scriptwriting','Cut Paper','assets/library/','assets/catalog.json','assets.py copy','asset_workflow.py','production-street.png','production-interior.png','images/overview.png','minimum 4 on each','Score 1-5','Hook scored 4+','Reuse the tested person rig','Reusable assets supply','Compare three genuinely','Draft five hooks','x80/y1500','strong blue, warm yellow','sound-palettes.json','scripts/assets.py','default Cut Paper treatment']
 docs={p:p.read_text() for p in (ROOT/'skills').rglob('*.md')}
 roots=[p for p in docs if p.name=='SKILL.md']
 reached=set(roots);stack=list(roots)
 while stack:
  page=stack.pop()
  for target in re.findall(r'\]\(([^)]+)\)',docs[page]):
   target=target.strip().strip('<>').split('#')[0]
   if not target or re.match(r'^[a-z]+:',target):continue
   resolved=(page.parent/unquote(target)).resolve()
   if resolved in docs and resolved not in reached:reached.add(resolved);stack.append(resolved)
 for page in docs:
  if page not in reached:
   named=sum(1 for q,t in docs.items() if q!=page and page.name in t)
   if named==0:errors.append('Unrouted and unmentioned: '+page.relative_to(ROOT).as_posix())
 for p in sorted(docs):
  relative=p.relative_to(ROOT).as_posix();text=docs[p]
  routed='current-workflow.md'in text or p.name=='current-workflow.md'
  if not routed:errors.append('Missing current-default routing: '+relative)
  for token in obsolete:
   if token in text:errors.append('Obsolete instruction: '+relative+' -> '+token)
  if re.search(r'y\s*=\s*1346|y\s*=\s*1494',text):errors.append('Outdated caption coordinate: '+relative)
  rows.append({'file':relative,'current_routing':routed,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 if errors:raise SystemExit('\n'.join(errors))
 report={'status':'PASS','version':'3.1.0','markdown_files':len(rows),'scope':'Reachable from a SKILL.md entry point or named by reachable text; routed to decision architecture; obsolete visual-library dependencies, old caption positions and default favorable score gates checked. API references retained, not all APIs executed. Creative quality requires per-film review.','rows':rows}
 (ROOT/'REFERENCE-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS:',len(rows),'Markdown files; reachability and obsolete-reference checks.')
if __name__=='__main__':main()
