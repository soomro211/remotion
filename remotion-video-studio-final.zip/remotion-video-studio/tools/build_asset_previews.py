#!/usr/bin/env python3
"""Regenerate current references/catalog from reviewed canonical-source renders."""
from pathlib import Path
import argparse,html,json,shutil,re,hashlib
from PIL import Image
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
THEME=ROOT/'skills/remotion-themes/themes/cut-paper'
PROJECT=ROOT/'examples/asset-studio'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--studio-url',default='http://localhost:3006');a=ap.parse_args()
 data=json.loads((THEME/'assets/catalog.json').read_text());images=THEME/'images';dest=images/'assets';dest.mkdir(exist_ok=True)
 gallery=Image.open(PROJECT/'out/review/Gallery/90.png').convert('RGB');gallery.save(dest/'overview.png',optimize=True)
 for i,asset in enumerate(data['assets']):
  x=i%6*640;y=i//6*432
  gallery.crop((x+26,y+77,x+614,y+409)).save(dest/(asset['id']+'.png'),optimize=True)
 # Static, editable SVG poses share the exact stage definitions and local geometry.
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page()
  page.goto(a.studio_url.rstrip('/')+'/Gallery',wait_until='domcontentloaded')
  page.wait_for_function('typeof window.remotion_setFrame==="function" && Boolean(document.querySelector("[data-catalog-entry]"))')
  page.evaluate('()=>window.remotion_setFrame(90,"Gallery",0)');page.wait_for_timeout(500)
  snapshots=page.evaluate('''()=>{const first=document.querySelector('[data-catalog-entry]'),defs=first.ownerSVGElement.querySelector('defs').outerHTML;return [...document.querySelectorAll('[data-catalog-entry]')].map(e=>({id:e.dataset.catalogEntry,body:e.querySelector('g').outerHTML,defs}));}''')
  assert len(snapshots)==len(data['assets'])
  for snapshot in snapshots:
   body='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xhtml="http://www.w3.org/1999/xhtml" width="640" height="432" viewBox="0 0 640 432"><title>'+html.escape(snapshot['id'])+'</title>'+snapshot['defs']+snapshot['body']+'</svg>'
   body=re.sub(r'(<foreignObject[^>]*>)<div',r'\1<div xmlns="http://www.w3.org/1999/xhtml"',body)
   (dest/(snapshot['id']+'.svg')).write_text(body)
  browser.close()
 # Move prior production images into an explicitly historical camera-study folder.
 history=images/'history';history.mkdir(exist_ok=True)
 for name in ['factory','steam','harbor','cotton']:
  old=images/f'production-{name}.png';new=history/f'industrial-{name}.png'
  if old.exists():shutil.move(old,new)
 frames=[('street','Showcase',90),('interior','Showcase',210),('process','Showcase',390),('character','Character',90)]
 overview=Image.new('RGB',(1080*4,1920))
 for i,(name,comp,frame)in enumerate(frames):
  source=PROJECT/f'out/review/{comp}/{frame}.png';im=Image.open(source).convert('RGB');assert im.size==(1080,1920)
  im.save(images/f'production-{name}.png',optimize=True);im.resize((540,960)).save(images/f'frame-{i+1}.png',optimize=True);overview.paste(im,(i*1080,0))
 overview.resize((2160,960)).save(images/'overview.png',optimize=True)
 cards=[]
 for asset in data['assets']:
  key=asset['id'];search=' '.join([key,asset['description'],asset['category']]+asset['tags'])
  cards.append('<article data-search="'+html.escape(search.lower(),quote=True)+'"><label><input type="checkbox" value="'+key+'"> '+key+'</label><a href="'+key+'.svg" target="_blank"><img loading="lazy" src="'+key+'.png" alt="'+html.escape(asset['description'],quote=True)+'"></a><p>'+html.escape(asset['description'])+'</p><small>'+html.escape(asset['anchor'])+'</small><small>Controls: '+html.escape(', '.join(asset['controls']))+'</small><div><a href="'+key+'.svg" download>SVG pose</a> · <a href="'+key+'.png" download>PNG preview</a></div></article>')
 header='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cut Paper asset library 1.4.0</title><style>
body{margin:0;background:#eee5d1;color:#1b2845;font:16px/1.5 system-ui,sans-serif}main{max-width:1400px;margin:auto;padding:32px}h1{font-size:36px;line-height:1.2}p{max-width:85ch}a{color:#246569}input[type=search]{font:inherit;width:min(95%,580px);padding:12px;border:1px solid #bba987;background:#fff8e8;border-radius:6px}section{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin:25px 0}article{background:#f8f0df;padding:16px;border:1px solid #d6c7a9;border-radius:5px}article img{width:100%;height:190px;object-fit:contain}article label{font-weight:700;display:block}small{display:block;color:#54645b;margin-bottom:12px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#263e4f;color:#f4ebd8;padding:16px;border-radius:5px}video{width:100%;max-height:480px;background:#263e4f}details{margin:20px 0}button{font:inherit;padding:8px 15px;background:#d9bd83;border:1px solid #b99c65;border-radius:4px;cursor:pointer}[hidden]{display:none!important}</style>
<main><h1>Cut Paper asset library</h1><p><a href="../../assets/library/catalog.html">Saved story artwork</a> · <a href="../../../../../video-director/references/asset-first-workflow.md">Asset-first workflow</a></p><p>Version 1.4.0 · 29 searchable entries. Select useful parts, adapt their appearance and stage the explanation. SVG files are editable static poses; React components provide animation and controls. All previews and search work locally.</p>
<input id="search" type="search" placeholder="Search people, walking, containers, camera…" aria-label="Search assets"> <span id="count"></span>
<p>Select assets to build an installation command:</p><pre id="command">Select one or more assets below.</pre><button id="copy">Copy command</button>
<details open><summary>Motion previews</summary><section><div><p>Walking comparison</p><video controls loop muted playsinline preload="metadata" src="walking-comparison.mp4"></video></div><div><p>Actions</p><video controls loop muted playsinline preload="metadata" src="actions.mp4"></video></div><div><p>Scene contexts</p><video controls loop muted playsinline preload="metadata" src="showcase.mp4"></video></div></section></details><section id="assets">'''
 footer='''</section><p>The installer copies selected dependencies into your project and protects local edits. Read the <a href="../../assets/README.md">asset recipes</a> for units, anchors, supported controls, contact/attachment rules and QA. Load DM Sans before using captions; their vertical default is x80/y1500/w890/h148 at 1080×1920.</p></main><script>
const cards=[...document.querySelectorAll('article')],search=document.querySelector('#search'),count=document.querySelector('#count'),command=document.querySelector('#command');function filter(){const q=search.value.toLowerCase().split(/\\s+/).filter(Boolean);cards.forEach(c=>c.hidden=!q.every(w=>c.dataset.search.includes(w)));count.textContent=cards.filter(c=>!c.hidden).length+' entries';}search.addEventListener('input',filter);filter();document.querySelector('#assets').addEventListener('change',()=>{const ids=[...document.querySelectorAll('article input:checked')].map(e=>e.value);command.textContent=ids.length?'python3 /path/to/skills/remotion-themes/scripts/assets.py copy /path/to/video --assets '+ids.join(','):'Select one or more assets below.';});document.querySelector('#copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(command.textContent);}catch{const range=document.createRange();range.selectNodeContents(command);getSelection().removeAllRanges();getSelection().addRange(range);}});
</script></html>'''
 (dest/'catalog.html').write_text(header+'\n'.join(cards)+footer)
 # Story packages carry their own proofs/hashes; adding one does not invalidate unrelated core previews.
 sources=sorted([p for p in (THEME/'assets').rglob('*') if p.suffix in ['.ts','.tsx'] and not p.is_relative_to(THEME/'assets/library')]+[ROOT/'skills/remotion-captions/assets/SmoothPaperCaptions.tsx',THEME/'assets/catalog.json']+[p for p in (PROJECT/'src').glob('*')if p.suffix in ['.ts','.tsx']])
 source_hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sources}
 preview_paths=list(dest.glob('*.png'))+list(dest.glob('*.svg'))+[images/'overview.png']+[images/f'production-{name}.png'for name,_,_ in frames]+[images/f'frame-{i+1}.png'for i in range(4)]
 (dest/'preview-build.json').write_text(json.dumps({'version':data['version'],'gallery_frame':90,'entries':len(data['assets']),'production_frames':[{'name':n,'composition':c,'frame':f}for n,c,f in frames],'source_sha256':source_hashes,'picture_sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in preview_paths},'svg_scope':'Editable static preview poses, not animation clips. Source components are canonical.'},indent=2)+'\n')
 print('Built current production references, '+str(len(data['assets']))+' PNG/SVG pairs and searchable local catalog.')
if __name__=='__main__':main()
