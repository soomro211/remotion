#!/usr/bin/env python3
"""Build every catalog pose and current production reference from reviewed source renders."""
import os, shutil
import argparse
import hashlib
import html
import json
import math
import re
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
THEME=ROOT/'skills/remotion-themes/themes/cut-paper'
PROJECT=ROOT/'examples/asset-studio'

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--studio-url',default='http://localhost:3006');args=parser.parse_args()
 data=json.loads((THEME/'assets/catalog.json').read_text());entries=data['assets'];dest=THEME/'images/assets';dest.mkdir(exist_ok=True)
 pages=math.ceil(len(entries)/30);overview=Image.new('RGB',(1920,math.ceil(len(entries)/6)*216),'#F2E9D4')
 font=ImageFont.truetype(str(THEME.parent/'_shared/fonts/DMSans.ttf'),19)
 for page in range(pages):
  name='Gallery' if page==0 else 'Gallery'+str(page+1)
  gallery=Image.open(PROJECT/f'out/review/{name}/90.png').convert('RGB')
  for i,asset in enumerate(entries[page*30:page*30+30]):
   x=i%6*640;y=i//6*432;thumb=gallery.crop((x+26,y+77,x+614,y+409));thumb.save(dest/(asset['id']+'.png'),optimize=True)
   j=page*30+i;left=j%6*320;top=j//6*216
   overview.paste(thumb.resize((294,166)),(left+13,top+38));ImageDraw.Draw(overview).text((left+14,top+10),asset['id'],font=font,fill='#1B2845')
 overview.save(dest/'overview.png',optimize=True)
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path=os.environ.get('REMOTION_BROWSER_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome'),args=['--no-sandbox']);page=browser.new_page();snapshots=[]
  for index in range(pages):
   name='Gallery'if index==0 else'Gallery'+str(index+1)
   page.goto(args.studio_url.rstrip('/')+'/'+name,wait_until='domcontentloaded')
   expected=entries[index*30]['id']
   page.wait_for_function('(id)=>typeof window.remotion_setFrame==="function" && Boolean(document.querySelector(`[data-catalog-entry="${id}"]`))',arg=expected)
   page.evaluate('([name])=>window.remotion_setFrame(90,name,0)',[name]);page.wait_for_timeout(200)
   snapshots+=page.evaluate('''()=>{const first=document.querySelector('[data-catalog-entry]'),defs=first.ownerSVGElement.querySelector('defs').outerHTML;return [...document.querySelectorAll('[data-catalog-entry]')].map(e=>({id:e.dataset.catalogEntry,body:e.querySelector('g').outerHTML,defs}));}''')
  browser.close()
 assert len(snapshots)==len(entries) and len({s['id']for s in snapshots})==len(entries)
 for item in snapshots:
  body='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xhtml="http://www.w3.org/1999/xhtml" width="640" height="432" viewBox="0 0 640 432"><title>'+html.escape(item['id'])+'</title>'+item['defs']+item['body']+'</svg>'
  body=re.sub(r'(<foreignObject[^>]*>)<div',r'\1<div xmlns="http://www.w3.org/1999/xhtml"',body)
  (dest/(item['id']+'.svg')).write_text(body)
 frames=[('street','Showcase',180),('interior','Showcase',60),('process','Showcase',420),('character','Character',90),('garden','Showcase',300)]
 primary=Image.new('RGB',(4320,1920))
 for i,(name,comp,frame)in enumerate(frames):
  im=Image.open(PROJECT/f'out/review/{comp}/{frame}.png').convert('RGB');assert im.size==(1080,1920)
  im.save(THEME/f'images/production-{name}.png',optimize=True)
  if i<4:primary.paste(im,(i*1080,0))
 primary.resize((2160,960)).save(THEME/'images/overview.png',optimize=True)
 cards=[]
 for a in entries:
  key=a['id'];terms=' '.join([key,a['description'],a['category']]+a['tags']).lower()
  cards.append('<article data-search="'+html.escape(terms,quote=True)+'" data-category="'+html.escape(a['category'],quote=True)+'"><label><input type="checkbox" value="'+key+'"> '+key+'</label><a href="'+key+'.svg"><img loading="lazy" src="'+key+'.png" alt="'+html.escape(a['description'],quote=True)+'"></a><p>'+html.escape(a['description'])+'</p><small>'+html.escape(a['anchor'])+'</small><small>Controls: '+html.escape(', '.join(a['controls']))+'</small><a href="'+key+'.svg" download>SVG pose</a> · <a href="'+key+'.png" download>PNG</a></article>')
 options='<option value="">All categories</option>'+''.join('<option>'+html.escape(c)+'</option>'for c in sorted({a['category']for a in entries}))
 header='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cut Paper universal library</title><style>body{margin:0;background:#eee5d1;color:#1b2845;font:16px/1.5 system-ui}main{max-width:1400px;margin:auto;padding:32px}a{color:#246569}input[type=search],select{font:inherit;padding:12px;border:1px solid #bba987;background:#fff8e8;border-radius:5px}input[type=search]{width:min(85%,510px)}section{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:20px;margin:25px 0}article{background:#f8f0df;padding:16px;border:1px solid #d6c7a9;border-radius:5px}article img{width:100%;height:190px;object-fit:contain}article label{font-weight:700;display:block}small{display:block;color:#54645b;margin:10px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#263e4f;color:#f4ebd8;padding:16px}video{width:100%;max-height:440px;background:#263e4f}button{font:inherit;padding:8px 15px;cursor:pointer}summary{cursor:pointer}[hidden]{display:none!important}</style><main><h1>Cut Paper universal library</h1>'''
 header+='<p>Version '+data['version']+' · '+str(len(entries))+' editable entries. Search useful parts, inspect motion, then stage the story.</p><p><a href="../../assets/library/catalog.html">Saved story art</a> · <a href="../../assets/UNIVERSAL.md">Object/motion recipes</a> · <a href="../../../../../video-director/references/asset-first-workflow.md">Asset-first workflow</a></p>'
 header+='<input id="search" type="search" aria-label="Search assets" placeholder="Search objects, actions, materials…"> <select id="category" aria-label="Category">'+options+'</select> <span id="count"></span><pre id="command">Select useful assets below.</pre><button id="copy">Copy command</button><details><summary>Silent motion and scene studies</summary><section>'
 for label,name in [('Physical actions','universal-motion'),('Scene contexts','showcase'),('Grounded walking','character'),('Character actions','actions')]:header+='<div><p>'+label+'</p><video controls loop muted playsinline preload="none" src="'+name+'.mp4"></video></div>'
 footer='''</section></details><section id="assets">'''+ '\n'.join(cards)+'''</section><p>SVGs are editable static poses; React source provides controls and animation. Read <a href="../../assets/README.md">anchors and core recipes</a>. Selective installation protects local edits. Labels in this review catalog are not film headings.</p></main><script>
const cards=[...document.querySelectorAll('article')],search=document.querySelector('#search'),category=document.querySelector('#category'),count=document.querySelector('#count'),command=document.querySelector('#command');function filter(){const q=search.value.toLowerCase().split(/\\s+/).filter(Boolean);cards.forEach(c=>c.hidden=!(q.every(w=>c.dataset.search.includes(w))&&(!category.value||c.dataset.category===category.value)));count.textContent=cards.filter(c=>!c.hidden).length+' entries';}search.addEventListener('input',filter);category.addEventListener('change',filter);filter();document.querySelector('#assets').addEventListener('change',()=>{const ids=[...document.querySelectorAll('article input:checked')].map(e=>e.value);command.textContent=ids.length?'python3 /path/to/skills/remotion-themes/scripts/assets.py copy /path/to/video --assets '+ids.join(','):'Select useful assets below.';});document.querySelector('#copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(command.textContent);}catch{const range=document.createRange();range.selectNodeContents(command);getSelection().removeAllRanges();getSelection().addRange(range);}});</script></html>'''
 (dest/'catalog.html').write_text(header+footer)
 sources=sorted([p for p in (THEME/'assets').rglob('*')if p.suffix in{'.ts','.tsx'}and not p.is_relative_to(THEME/'assets/library')]+[ROOT/'skills/remotion-captions/assets/SmoothPaperCaptions.tsx',THEME/'assets/catalog.json']+[p for p in (PROJECT/'src').glob('*')if p.suffix in{'.ts','.tsx'}])
 pictures=list(dest.glob('*.png'))+list(dest.glob('*.svg'))+[THEME/'images/overview.png']+[THEME/f'images/production-{n}.png'for n,_,_ in frames]
 report={'version':data['version'],'entries':len(entries),'gallery_pages':pages,'gallery_frame':90,'production_frames':[{'name':n,'composition':c,'frame':f}for n,c,f in frames],'source_sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sources},'picture_sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in pictures},'svg_scope':'Static editable poses; animation comes from the versioned React source.'}
 (dest/'preview-build.json').write_text(json.dumps(report,indent=2)+'\n');print(f'Built {len(entries)} PNG/SVG pairs, {pages} gallery pages and current production pictures.')
if __name__=='__main__':main()
