#!/usr/bin/env python3
"""Generate editable layered art and its draft proofs for the asset-first reference.

This creates a draft package. Review the actual PNGs before completing review fields
and archiving with the production helper. It does not mark its own artwork approved.
"""
import argparse
import importlib.util
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('asset_workflow', ROOT / 'skills/remotion-themes/scripts/asset_workflow.py')
workflow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(workflow)


def defs(prefix):
    return f'''<defs>
<filter id="{prefix}-shadow" x="-20%" y="-20%" width="140%" height="150%" color-interpolation-filters="sRGB"><feDropShadow dx="0.7" dy="2" stdDeviation="0.65" flood-color="#24322D" flood-opacity=".25"/><feDropShadow dx="1" dy="5" stdDeviation="3.2" flood-color="#26312B" flood-opacity=".13"/></filter>
<filter id="{prefix}-noise" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".48 .65" numOctaves="2" seed="23"/><feColorMatrix type="saturate" values="0"/></filter>
<pattern id="{prefix}-fibres" width="192" height="192" patternUnits="userSpaceOnUse"><rect width="192" height="192" fill="#9D9685" filter="url(#{prefix}-noise)"/></pattern>
</defs>'''


def piece(prefix, key, path, fill, shadow=True, rim=1.8):
    return f'''<g id="{key}"{' filter="url(#' + prefix + '-shadow)"' if shadow else ''}><path id="{key}-geometry" d="{path}" fill="{fill}" stroke="#FBF2DC" stroke-width="{rim}" stroke-linejoin="round"/><path d="{path}" fill="url(#{prefix}-fibres)" opacity=".13"/></g>'''


def svg(prefix, body):
    return '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1080" viewBox="0 0 1440 1080"><title>Editable Cut Paper river valley depth plane</title>' + defs(prefix) + body + '</svg>'


def build(project):
    workflow.init(project)
    workflow.write_json(project / 'assets/brief.json', {'schema_version': 1, 'reference_review': 'Opened current production street/process references; preserve matte fibre, cream rims, double shadows and warm/teal paper relationships.', 'visual_direction': 'A quiet editable river bend with four depth planes, enough horizontal art for restrained reframing, no baked copy or captions.', 'reuse_only_reason': '', 'requirements': [{'key': 'hero', 'kind': 'new', 'purpose': 'Demonstrate durable layered art that survives removal of its source video.', 'scene_ids': ['reference']}]})
    package = workflow.new_package(project, 'layered-river-valley', '1.0.0', 'universal')
    sky = piece('sky', 'backdrop', 'M-20 -20H1460V1100H-20Z', '#B6D2C8', False, 0)
    sky += piece('sky', 'cloud-left', 'M104 198C81 196 80 172 98 162C94 137 117 121 138 131C146 101 182 97 200 119C221 108 249 123 250 145C282 143 300 169 287 190C282 199 264 203 246 202Z', '#F4EBD8')
    sky += piece('sky', 'sun', 'M1132 117C1189 111 1232 149 1235 202C1238 253 1201 292 1146 296C1094 299 1049 264 1048 211C1044 158 1081 120 1132 117Z', '#F2BC55')
    far = piece('far', 'hill-back', 'M-40 550C103 478 201 421 326 461C425 493 493 427 583 393C659 364 739 398 813 421C909 449 976 360 1086 391C1210 430 1305 397 1480 438V1100H-40Z', '#94AF96')
    far += piece('far', 'hill-middle', 'M-40 646C123 626 197 510 316 537C441 565 458 627 573 568C661 523 724 451 822 487C930 527 1002 483 1085 504C1193 530 1319 472 1480 534V1100H-40Z', '#71956D')
    land = piece('land', 'valley-floor', 'M-40 710C159 614 292 684 471 620C618 567 712 566 866 603C1069 651 1224 602 1480 636V1100H-40Z', '#879C75')
    river_path = 'M706 564C662 610 669 637 752 653C888 678 928 724 864 766C811 800 713 810 634 839C532 876 509 920 559 970C602 1013 648 1047 666 1100H1066C1033 1020 905 974 812 946C727 921 727 902 806 874C911 837 1048 816 1043 753C1039 699 940 662 828 642C757 628 717 604 728 567Z'
    land += piece('land', 'river', river_path, '#5B9F9E', True, 2.6)
    land += '<clipPath id="land-river-clip"><path d="' + river_path + '"/></clipPath><g clip-path="url(#land-river-clip)" fill="none" stroke="#E8EDDA" stroke-linecap="round" opacity=".6"><path d="M826 690c36 7 60 14 79 24M943 730c14 7 16 13 7 21M814 815l-48 16M659 898c-18 9-24 15-25 23M755 1013l54 22" stroke-width="3"/></g>'
    front = piece('front', 'left-bank', 'M-40 858C101 780 230 818 336 787C445 755 509 799 537 836C469 883 468 934 494 981C514 1016 553 1064 562 1100H-40Z', '#597F66')
    front += piece('front', 'right-bank', 'M1112 782C1246 745 1365 797 1480 762V1100H1183C1169 1047 1089 1014 1032 994C1087 946 1138 894 1112 782Z', '#64886A')
    for i, (x, y, scale) in enumerate([(84, 920, 1.1), (160, 966, .85), (368, 874, .7), (1315, 862, .9), (1229, 1021, 1.15)]):
        front += '<g transform="translate(' + str(x) + ' ' + str(y) + ') scale(' + str(scale) + ')">'
        front += piece('front', 'grass-' + str(i), 'M0 0C-9-36-34-66-40-78C-16-69 3-40 8-23C14-57 22-76 43-91C32-53 28-31 22 0Z', '#8BA47B', True, 1.2)
        front += '</g>'
    for i, (x, y) in enumerate([(388, 957), (424, 975), (1157, 919)]):
        front += '<g transform="translate(' + str(x) + ' ' + str(y) + ')">' + piece('front', 'stone-' + str(i), 'M0 5L9-12L33-18L49-4L53 12L26 20L3 16Z', '#B9B298', True, 1.4) + '</g>'
    layers = [('sky', sky), ('distant-hills', far), ('river-and-floor', land), ('foreground-banks', front)]
    for index, (key, body) in enumerate(layers):
        prefix = ['sky', 'far', 'land', 'front'][index]
        (package / 'source' / (key + '.svg')).write_text(svg(prefix, body))
    combined = '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1080" viewBox="0 0 1440 1080">' + ''.join(defs(p) + body for p, (_, body) in zip(['sky', 'far', 'land', 'front'], layers)) + '</svg>'
    (package / 'source/composite.svg').write_text(combined)
    workflow.write_json(package / 'source/layers.json', {'canvas': [1440, 1080], 'stack_back_to_front': [key + '.svg' for key, _ in layers], 'anchor': [720, 1080], 'river_entry': [718, 568], 'river_exit': [866, 1080], 'camera_limits': 'Full-frame proof only. Author/test overscan for any new camera or aspect ratio; depth planes share edges and are not independently movable beyond their coverage.'})
    data = workflow.read(package / 'asset.json')
    data.update(title='Layered river valley', description='Four editable paper depth planes: sky, hills, river floor and foreground banks. A portable source/reference package, with no baked text.', category='environment', tags=['river', 'landscape', 'terrain', 'water', 'layered', 'paper', 'background'], canvas={'width': 1440, 'height': 1080}, anchor={'x': 720, 'y': 1080, 'units': 'canvas pixels; bottom centre'}, controls=['SVG path geometry', 'per-shape fill', 'layer visibility/order; limited movement requires coverage review'], source_files=['source/composite.svg', *['source/' + key + '.svg' for key, _ in layers], 'source/layers.json'], preview_files=['previews/composite.png', 'previews/contact-sheet.png'], review_files=['review/observations.md'])
    data['provenance'].update(creator='Codex; original SVG geometry', license='Original studio asset; reuse and adaptation allowed', sources=['Original geometry; paper material follows the included Cut Paper reference.'])
    workflow.write_json(package / 'asset.json', data)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1080}, device_scale_factor=1)
        for name in ['composite'] + [key for key, _ in layers]:
            page.set_content('<style>body{margin:0}</style>' + (package / 'source' / (name + '.svg')).read_text())
            page.locator('svg').screenshot(path=str(package / 'previews' / (name + '.png')), omit_background=True)
        browser.close()
    sheet = Image.new('RGB', (1440, 1250), '#F4EBD8')
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 25)
    for i, name in enumerate(['composite'] + [key for key, _ in layers]):
        x = (i % 3) * 480; y = (i // 3) * 570
        im = Image.open(package / 'previews' / (name + '.png')).convert('RGBA')
        im.thumbnail((450, 460))
        sheet.paste(im, (x + 15, y + 50), im)
        draw.text((x + 18, y + 13), name.replace('-', ' '), font=font, fill='#1B2845')
    sheet.save(package / 'previews/contact-sheet.png', optimize=True)
    # This file is intentionally pending until the author opens the actual proofs.
    (package / 'review/observations.md').write_text('Visual review: PENDING. Open the composite and contact sheet before completing checks. Static source study; no animated camera or motion playback claimed.\n')
    print(json.dumps({'draft_package': str(package), 'review_required': ['previews/composite.png', 'previews/contact-sheet.png']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    build(parser.parse_args().project.resolve())
