#!/usr/bin/env python3
"""Check both local asset galleries, lazy images, search and linked portable resources.

Serve the complete extracted bundle with `python3 -m http.server 3008 --bind 127.0.0.1`.
Requires Playwright and Chromium; never loads the original video projects.
"""
import argparse
import json
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default='http://127.0.0.1:3008')
    args = parser.parse_args()
    library = ROOT / 'skills/remotion-themes/themes/cut-paper/assets/library'
    saved = len(json.loads((library / 'index.json').read_text())['packages'])
    report = {'status': 'PASS', 'checks': []}
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page = browser.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        for relative, count in [('skills/remotion-themes/themes/cut-paper/images/assets/catalog.html', 29), ('skills/remotion-themes/themes/cut-paper/assets/library/catalog.html', saved)]:
            response = page.goto(args.url.rstrip('/') + '/' + relative, wait_until='networkidle')
            assert response.status == 200
            assert page.locator('article').count() == count
            # The core catalog intentionally lazy-loads thumbnails below the fold.
            page.evaluate('()=>document.querySelectorAll("img").forEach(i=>i.loading="eager")')
            page.wait_for_function('()=>[...document.images].every(i=>i.complete && i.naturalWidth>0)')
            for href in page.locator('a').evaluate_all('(items)=>items.map(a=>a.href)'):
                response = page.request.get(href)
                assert response.status == 200, (href, response.status)
            if relative.endswith('library/catalog.html'):
                page.locator('#search').fill('no-such-asset-xyz')
                assert page.locator('article:visible').count() == 0
                page.locator('#search').fill('river')
                assert page.locator('article:visible').count() >= 1
            report['checks'].append({'page': relative, 'cards': count, 'images_loaded': True, 'all_linked_resources_status': 200, 'saved_asset_search_tested': relative.endswith('library/catalog.html')})
        assert not errors, errors
        report['browser_errors'] = errors
        browser.close()
    (ROOT / 'ASSET-WORKFLOW-CHECK.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
