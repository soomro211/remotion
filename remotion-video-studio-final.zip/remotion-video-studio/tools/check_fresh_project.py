#!/usr/bin/env python3
"""Exercise neutral initialization, project-local art and explicit caption styling after relocation."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tests'))
from asset_fixture import prepare_asset

def run(*args,cwd=None,ok=True):
 r=subprocess.run([str(x)for x in args],cwd=cwd,text=True,capture_output=True)
 if ok and r.returncode:raise RuntimeError(r.stdout+'\n'+r.stderr)
 return r

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--node-modules',type=Path);a=ap.parse_args()
 with tempfile.TemporaryDirectory(prefix='studio-v3-fresh-')as folder:
  temp=Path(folder);skills=temp/'installed-skills';project=temp/'video';shutil.copytree(ROOT/'skills',skills,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  run(sys.executable,skills/'video-director/scripts/init_video.py',project)
  plan=json.loads((project/'video/plan.json').read_text());assert plan['shots']==[]and plan['narration']==[]and plan['theme']is None
  assert not (project/'public/sfx').exists()and not (project/'src/theme').exists()
  assert run(sys.executable,skills/'video-director/scripts/check_assets.py','--project',project,ok=False).returncode!=0
  prepare_asset(project);run(sys.executable,skills/'video-director/scripts/check_assets.py','--project',project,'--seal')
  moved=temp/'relocated';project.rename(moved);project=moved;run(sys.executable,skills/'video-director/scripts/check_assets.py','--project',project)
  report={'status':'PASS','version':'3.1.0','skills_relocated':True,'project_relocated':True,'initializer_creative_choices_unset':True,'project_asset_gate':'PASS','compile_render':'NOT RUN; supply --node-modules','scope':'Technical integration with explicit synthetic fixture styles, not creative quality certification.'}
  if a.node_modules:
   deps=a.node_modules.resolve();(project/'node_modules').symlink_to(deps,target_is_directory=True)
   (project/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2020','module':'ESNext','jsx':'react-jsx','moduleResolution':'node','esModuleInterop':True,'resolveJsonModule':True,'skipLibCheck':True,'strict':True,'noEmit':True,'types':['node']},'include':['src']}))
   (project/'package.json').write_text(json.dumps({'name':'v3-technical-fixture','private':True,'dependencies':{'remotion':'4.0.538','@remotion/cli':'4.0.538','@remotion/captions':'4.0.538','react':'19.2.3','react-dom':'19.2.3'}}))
   (project/'remotion.config.ts').write_text('import {Config} from "@remotion/cli/config";Config.setPixelFormat("yuv420p");Config.setColorSpace("bt709");'+f'Config.setBrowserExecutable({json.dumps(shutil.which("chromium"))});')
   shutil.copy2(skills/'remotion-captions/assets/SmoothPaperCaptions.tsx',project/'src/Captions.tsx')
   (project/'src/index.ts').write_text("import {registerRoot} from 'remotion';import {Root} from './Root';registerRoot(Root);\n")
   (project/'src/Root.tsx').write_text('''import React from 'react';
import {AbsoluteFill,Composition,Img,staticFile,useCurrentFrame} from 'remotion';
import {SmoothPaperCaptions,CaptionStyle} from './Captions';
const style:CaptionStyle={x:100,y:1450,width:880,height:160,padding:16,fontFamily:'sans-serif',fontSize:50,fontWeight:600,lineHeight:1.1,color:'#101010',surface:{background:'#FFFFFF'},inMs:120,outMs:100,travelPx:2};
const Fixture:React.FC=()=>{const f=useCurrentFrame();return <AbsoluteFill style={{background:'#444444'}}><Img src={staticFile('assets/fixture.svg')} style={{width:300,height:300,translate:`${100+f*5}px 400px`}}/><SmoothPaperCaptions pages={[{text:'Explicit project caption treatment.',startMs:0,endMs:1000,timestampMs:0,confidence:null}]} style={style}/></AbsoluteFill>;};
export const Root:React.FC=()=> <Composition id="Main" component={Fixture} width={1080} height={1920} fps={30} durationInFrames={30}/>;
''')
   run(deps/'.bin/tsc','--noEmit',cwd=project)
   root=project/'src/Root.tsx';text=root.read_text();root.write_text(text.replace(' style={style}/>','/>'))
   missing=run(deps/'.bin/tsc','--noEmit',cwd=project,ok=False);assert missing.returncode!=0 and 'style'in missing.stdout
   root.write_text(text)
   run(deps/'.bin/remotion','render','src/index.ts','Main',project/'proof.mp4','--codec','h264','--concurrency','1',cwd=project)
   run('ffmpeg','-v','error','-xerror','-i',project/'proof.mp4','-f','null','-')
   probe=json.loads(run('ffprobe','-v','error','-show_streams','-of','json',project/'proof.mp4').stdout);v=probe['streams'][0]
   assert v['width']==1080 and v['height']==1920 and int(v['nb_frames'])==30 and v['pix_fmt']=='yuv420p'and v['color_space']=='bt709'
   report.update(compile_render='PASS',missing_caption_style_rejected_by_typescript=True,rendered_resolution=[1080,1920],frames=30,pixel_format=v['pix_fmt'],color_space=v['color_space'],dependency_scope='Existing compatible dependency tree; no network install claimed.')
  (ROOT/'FRESH-PROJECT-CHECK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
