#!/usr/bin/env python3
"""Exercise relocated skills and selective assets in a new, disposable video project."""
from pathlib import Path
import json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
def run(*args,cwd=None):
 r=subprocess.run([str(x)for x in args],cwd=cwd,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stdout+'\n'+r.stderr)
 return r.stdout
def main():
 with tempfile.TemporaryDirectory(prefix='paper-fresh-')as folder:
  temp=Path(folder);skills=temp/'installed-skills';project=temp/'video'
  shutil.copytree(ROOT/'skills',skills,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  run(sys.executable,skills/'video-director/scripts/init_video.py',project,'--no-sfx')
  selection=['person','journey','ground','tree','box','camera','captions']
  result=json.loads(run(sys.executable,skills/'remotion-themes/scripts/assets.py','copy',project,'--assets',','.join(selection)))
  for name in ['package.json','package-lock.json','tsconfig.json','remotion.config.ts']:
   shutil.copy2(ROOT/'examples/asset-studio'/name,project/name)
  # Use the same pinned dependency tree; this checks source/skill portability, not a new network install.
  (project/'node_modules').symlink_to((ROOT/'examples/asset-studio/node_modules').resolve(),target_is_directory=True)
  (project/'src/StudioRoot.tsx').write_text('''import React from 'react';
import {AbsoluteFill,Composition,useCurrentFrame,useVideoConfig} from 'remotion';
import {useThemeFonts} from './theme/paper';
import {PaperStage,PaperRect,PaperGround,PaperTree,PaperPerson,PaperBox,sampleJourney,CameraRig,SmoothPaperCaptions} from './assets/cut-paper';
const Scene:React.FC=()=>{useThemeFonts();const {fps}=useVideoConfig(),time=useCurrentFrame()/fps,travel=sampleJourney(time,{startSeconds:.2,durationSeconds:3,distance:450});return <AbsoluteFill style={{background:'#B6D2C8'}}><CameraRig from={{centerX:540,centerY:960,zoom:1}} to={{centerX:560,centerY:960,zoom:1.04}} startSeconds={0} durationSeconds={4}><PaperStage width={1600} height={2200}><PaperRect x={-300} y={-300} width={2400} height={3000} fill="#B6D2C8" shadow={false}/><PaperGround x={-250} y={1400} width={2400} height={1200}/><PaperTree x={850} y={1400} height={500} time={time}/><PaperPerson x={180} y={1400} height={440} time={time} travel={travel} action="carry" item={<PaperBox width={70} height={60}/>}/></PaperStage></CameraRig><SmoothPaperCaptions pages={[{text:'Assets keep their anchors and shared time.',startMs:0,endMs:3900,timestampMs:0,confidence:null}]}/></AbsoluteFill>;};
export const StudioRoot:React.FC=()=> <Composition id="Main" component={Scene} width={1080} height={1920} fps={30} durationInFrames={120}/>;
''')
  run(project/'node_modules/.bin/tsc','--noEmit',cwd=project)
  run(project/'node_modules/.bin/remotion','still','src/index.ts','Main',project/'still.png','--frame','60',cwd=project)
  from PIL import Image
  with Image.open(project/'still.png')as im:assert im.size==(1080,1920)
  install=json.loads((project/'src/assets/cut-paper/asset-install.json').read_text());assert not (project/'src/assets/cut-paper/explain').exists()
  for p in (project/'src/assets/cut-paper').rglob('*'):
   if p.is_file():assert '/workspace/'not in p.read_text()
  report={'status':'PASS','skills_relocated':True,'fresh_source_project':True,'selected':selection,'installed':install['selected'],'files':result['files'],'typescript':'PASS','rendered_frame':60,'rendered_dimensions':[1080,1920],'unselected_explanation_module_absent':True,'dependency_scope':'Reused pinned local Node dependencies; no clean network npm install claimed.'}
  (ROOT/'FRESH-PROJECT-CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
  print(json.dumps(report,indent=2))
if __name__=='__main__':main()
