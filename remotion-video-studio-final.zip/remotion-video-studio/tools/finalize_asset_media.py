#!/usr/bin/env python3
"""Verify actual asset preview encodes, remux for streaming, and extract review evidence."""
from pathlib import Path
import hashlib,json,subprocess,shutil
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];P=R/'examples/asset-studio';D=R/'skills/remotion-themes/themes/cut-paper/images/assets'
def run(args):return subprocess.run([str(x)for x in args],check=True,capture_output=True,text=True)
def main():
 expected={'actions':(300,1920,1080),'showcase':(480,1080,1920),'universal-motion':(240,1920,1080),'character':(180,1080,1920),'gesture-study':(240,1920,1080),'pouring-study':(240,1920,1080),'interactions':(240,1920,1080),'effects':(240,1920,1080)};rows=[]
 for name,(frames,width,height)in expected.items():
  source=P/'out'/f'{name}.mp4';target=D/f'{name}.mp4'
  run(['ffmpeg','-y','-v','error','-i',source,'-map','0:v:0','-an','-c:v','copy','-movflags','+faststart',target])
  info=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',target]).stdout);v=info['streams'][0]
  assert v['codec_name']=='h264' and v['width']==width and v['height']==height and v['r_frame_rate']=='30/1' and int(v['nb_frames'])==frames
  assert abs(float(info['format']['duration'])-frames/30)<.01
  run(['ffmpeg','-v','error','-xerror','-i',target,'-f','null','-'])
  raw=target.read_bytes();assert raw.find(b'moov')<raw.find(b'mdat')
  rows.append({'name':name,'frames':frames,'seconds':frames/30,'width':width,'height':height,'fps':30,'codec':'h264','silent':True,'fast_start':True,'full_decode':'PASS','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 for name in ['rig-check','browser-check','universal-check','universal-browser-check','gesture-check','pouring-check','effects-check','interactions-browser-check']:
  report=json.loads((P/'out'/f'{name}.json').read_text());assert report['status']=='PASS';shutil.copy2(P/'out'/f'{name}.json',D/f'{name}.json')
 output=P/'out/encoded';output.mkdir(exist_ok=True)
 frames=list(range(60,105,4));select='+'.join(f'eq(n,{f})'for f in frames)
 run(['ffmpeg','-y','-v','error','-i',D/'character.mp4','-an','-vf',f"select='{select}'",'-fps_mode','vfr',output/'walking-%02d.png'])
 contact=Image.new('RGB',(1440,((len(frames)+3)//4)*300),'#EDE3CE');draw=ImageDraw.Draw(contact)
 for i,frame in enumerate(frames):
  im=Image.open(output/f'walking-{i+1:02d}.png').convert('RGB').crop((0,650,1080,1520)).resize((360,268));x=i%4*360;y=i//4*300;contact.paste(im,(x,y));draw.text((x+5,y+275),f'{frame/30:.2f}s',fill='#1B2845')
 contact.save(D/'walking-poses.jpg',quality=95)
 checks=[('universal-motion',120),('actions',90),('showcase',60),('showcase',180),('showcase',420),('character',90)]
 sheet=Image.new('RGB',(1200,930),'#EDE3CE')
 for i,(name,frame)in enumerate(checks):
  path=output/f'{name}-{frame}.png';run(['ffmpeg','-y','-v','error','-i',D/f'{name}.mp4','-vf',f"select='eq(n,{frame})'",'-frames:v','1',path])
  im=Image.open(path).convert('RGB')
  if i<2:
   im.thumbnail((600,338));x=i*600;y=0;label_y=342
  else:
   im.thumbnail((300,534));x=(i-2)*300;y=370;label_y=y+539
  sheet.paste(im,(x,y))
  ImageDraw.Draw(sheet).text((x+5,label_y),f'{name} {frame/30:.1f}s',fill='#1B2845')
 sheet.save(D/'encoded-review.jpg',quality=95)
 report={'status':'PASS','media':rows,'encoded_walking_pose_frames':frames,'encoded_review_frames':[{'name':n,'frame':f}for n,f in checks],'scope':'Technical full decode and extracted encoded-picture evidence. Visual assessment and browser-native execution are separate checks; previews are intentionally silent.'}
 (D/'encoded-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
