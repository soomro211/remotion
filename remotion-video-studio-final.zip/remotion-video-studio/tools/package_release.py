#!/usr/bin/env python3
"""Build the single ZIP and its integrity manifest. Does not publish or push."""
import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

from validate_bundle import bundle_files, validate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    release = json.loads((root / 'RELEASE.json').read_text())
    manifest_path = root / 'MANIFEST.json'
    files = bundle_files(root)
    version = json.loads((root / 'RELEASE.json').read_text())['version']
    manifest = dict(algorithm='sha256', version=version, files={
        p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in files if p != manifest_path
    })
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    errors, _ = validate(root)
    if errors: sys.exit('\n'.join(errors))
    output = Path(a.out).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    year, month, day = map(int, release['date'].split('-'))
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in bundle_files(root):
            rel = p.relative_to(root).as_posix()
            info = zipfile.ZipInfo('remotion-video-studio/' + rel, date_time=(year, month, day, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(output) as z:
        bad = z.testzip()
        if bad: sys.exit('corrupt ZIP entry: ' + bad)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix + '.sha256').write_text(f'{digest}  {output.name}\n')
    print(f'Built {output.name}: {output.stat().st_size:,} bytes, SHA-256 {digest}')


if __name__ == '__main__':
    main()
