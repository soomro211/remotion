#!/usr/bin/env python3
"""Build the single ZIP and its integrity manifest. Does not publish or push."""
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile
from pathlib import Path

from validate_bundle import bundle_files, validate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--merge-library', action='append', default=[], help='merge saved installed-library additions into this bundle before packaging; repeatable')
    a = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location('release_asset_workflow', root / 'skills/remotion-themes/scripts/asset_workflow.py')
    workflow = importlib.util.module_from_spec(spec); spec.loader.exec_module(workflow)
    library = root / 'skills/remotion-themes/themes/cut-paper/assets/library'
    for source in a.merge_library:
        workflow.sync(Path(source).resolve(), library)
    workflow.reindex(library)
    release_path = root / 'RELEASE.json'
    release = json.loads(release_path.read_text())
    release['story_asset_packages'] = len(workflow.library_packages(library))
    release_path.write_text(json.dumps(release, indent=2) + '\n')
    manifest_path = root / 'MANIFEST.json'
    files = bundle_files(root)
    version = json.loads((root / 'RELEASE.json').read_text())['version']
    manifest = dict(algorithm='sha256', version=version, files={
        p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in files if p != manifest_path
    })
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    errors, _ = validate(root)
    if errors: sys.exit('\n'.join(errors))
    output = Path(a.out).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    year, month, day = map(int, release['date'].split('-'))
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in bundle_files(root):
            rel = p.relative_to(root).as_posix()
            info = zipfile.ZipInfo('remotion-video-studio/' + rel, date_time=(year, month, day, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(output) as z:
        bad = z.testzip()
        if bad: sys.exit('corrupt ZIP entry: ' + bad)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix + '.sha256').write_text(f'{digest}  {output.name}\n')
    print(f'Built {output.name}: {output.stat().st_size:,} bytes, SHA-256 {digest}')


if __name__ == '__main__':
    main()
