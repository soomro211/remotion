#!/usr/bin/env python3
"""Validate an extracted studio bundle using only the Python standard library."""
import argparse
import ast
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote, urlsplit

EXPECTED_SKILLS = {
    'video-director', 'video-scriptwriting', 'remotion-preproduction',
    'remotion-themes', 'remotion-sound-design', 'remotion-best-practices',
    'remotion-create', 'remotion-markup', 'remotion-studio', 'remotion-render',
    'remotion-captions', 'remotion-maps', 'remotion-multimedia',
    'remotion-interactivity', 'remotion-docs', 'remotion-upgrade',
}
EXCLUDED = {'__pycache__', '.git', '.DS_Store', 'node_modules', 'dist', 'out'}


def bundle_files(root):
    return sorted(p for p in root.rglob('*') if p.is_file()
                  and not any(x in EXCLUDED for x in p.relative_to(root).parts)
                  and p.relative_to(root).parts[0] != 'examples'
                  and p.suffix not in {'.pyc', '.zip'}
                  and '.bak' not in p.name
                  and not p.name.startswith('.env'))


def validate(root, require_manifest=True):
    errors = []
    skills = root / 'skills'
    actual = {p.name for p in skills.iterdir() if p.is_dir()} if skills.exists() else set()
    if actual != EXPECTED_SKILLS:
        errors.append(f'skill folders differ: missing={EXPECTED_SKILLS - actual}, extra={actual - EXPECTED_SKILLS}')
    for name in EXPECTED_SKILLS:
        entry = skills / name / 'SKILL.md'
        if not entry.is_file(): errors.append(f'missing {entry.relative_to(root)}'); continue
        text = entry.read_text(encoding='utf-8')
        front = re.match(r'^---\n(.*?)\n---', text, re.S)
        if not front or not re.search(r'^name:\s*' + re.escape(name) + r'\s*$', front[1], re.M):
            errors.append(f'invalid entry metadata: {name}')
        elif re.search(r'^description:\s+[^\'\"\n][^\n]*:\s', front[1], re.M):
            errors.append(f'quote the colon-containing YAML description: {name}')
        if not (skills / name / 'agents' / 'openai.yaml').is_file(): errors.append(f'missing agent registration: {name}')
    files = bundle_files(root)
    for p in files:
        if p.is_symlink(): errors.append(f'symlink must not enter the release: {p.relative_to(root)}')
        try:
            if p.suffix == '.py': ast.parse(p.read_text(encoding='utf-8'), filename=str(p), feature_version=(3, 9))
            if p.suffix in {'.json', '.geojson'}: json.loads(p.read_text(encoding='utf-8'))
            if p.suffix == '.svg': ET.fromstring(p.read_bytes())
            if p.suffix == '.md':
                for target in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
                    target = target.strip().strip('<>')
                    if not target or urlsplit(target).scheme: continue
                    target = unquote(target.split('#')[0])
                    if target and not (p.parent / target).exists(): errors.append(f'broken local link: {p.relative_to(root)} -> {target}')
                    if target and p.is_relative_to(skills):
                        if not (p.parent / target).resolve().is_relative_to(skills.resolve()): errors.append(f'skill link escapes a skills-only installation: {p.relative_to(root)} -> {target}')
        except (SyntaxError, ValueError, UnicodeError) as exc:
            errors.append(f'{p.relative_to(root)}: {exc}')
    for theme in ('cut-paper',):
        base = skills / 'remotion-themes' / 'themes' / theme
        for rel in ('THEME.md',):
            if not (base / rel).is_file(): errors.append(f'missing theme asset: {theme}/{rel}')
    font_root = skills / 'remotion-themes' / 'themes' / '_shared' / 'fonts'
    if len(list(font_root.glob('*.ttf'))) != 3: errors.append('expected three Cut Paper font files')
    if len(list(font_root.glob('*-OFL.txt'))) != 3: errors.append('expected three font-family notices')
    release = json.loads((root / 'RELEASE.json').read_text())
    if release.get('themes') != ['cut-paper']: errors.append('Cut Paper must be the sole release theme')
    theme_dirs = {p.name for p in (skills / 'remotion-themes' / 'themes').iterdir() if p.is_dir()}
    if theme_dirs != {'_shared', 'cut-paper'}: errors.append('unexpected theme folder')
    if release.get('skill_count') != len(EXPECTED_SKILLS): errors.append('RELEASE.json skill_count differs')
    theme = skills / 'remotion-themes/themes/cut-paper'
    if any((theme / name).exists() for name in ('assets', 'images', 'kit', 'entry')):
        errors.append('reusable visual artwork/catalog must not enter the release')
    if (skills / 'remotion-themes/scripts').exists():
        errors.append('removed visual installer/archive tools must not enter the release')
    if release.get('asset_catalog_entries') != 0 or release.get('story_asset_packages') != 0:
        errors.append('release must declare zero reusable visual packs')
    if release.get('asset_workflow') != 'plan-create-review-project-assets-before-assembly':
        errors.append('release workflow differs from project-specific asset contract')
    template = json.loads((skills / 'video-director/assets/plan.template.json').read_text())
    if template.get('schema_version') != 3 or template.get('narration') != [] or template.get('shots') != []:
        errors.append('starter must have independent empty narration and shots')
    art = template.get('treatment', {}).get('art_direction', {})
    if art.get('palette', {}).get('roles') or art.get('typography', {}).get('roles'):
        errors.append('starter must leave creative roles unset')
    if any(template.get(k) is not None for k in ('theme','width','height','fps','target_seconds')):
        errors.append('starter delivery/medium choices must be resolved from the brief')
    manifest_path = root / 'MANIFEST.json'
    if require_manifest and not manifest_path.is_file(): errors.append('MANIFEST.json is missing')
    if require_manifest and manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text())
        actual_hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p != manifest_path}
        if manifest.get('files') != actual_hashes: errors.append('file set or SHA-256 differs from MANIFEST.json')
    return errors, len(files)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--without-manifest', action='store_true', help='for release authors before packaging only')
    a = ap.parse_args()
    errors, count = validate(Path(a.root).resolve(), not a.without_manifest)
    for e in errors: print('FAIL', e)
    integrity = " and manifest" if not a.without_manifest else " (pre-manifest check)"
    print(f"{'FAIL' if errors else 'PASS'}: {len(EXPECTED_SKILLS)} skills; {count} files; local links, JSON, Python syntax, project-only artwork policy{integrity} checked.")
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
