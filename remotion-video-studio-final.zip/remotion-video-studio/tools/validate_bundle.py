#!/usr/bin/env python3
"""Validate an extracted studio bundle using only the Python standard library."""
import argparse
import ast
import hashlib
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote, urlsplit

EXPECTED_SKILLS = {
    'video-director', 'video-scriptwriting', 'remotion-preproduction',
    'remotion-themes', 'remotion-sound-design', 'remotion-best-practices',
    'remotion-create', 'remotion-markup', 'remotion-studio', 'remotion-render',
    'remotion-captions', 'remotion-maps', 'remotion-multimedia',
    'remotion-interactivity', 'remotion-docs', 'remotion-upgrade',
}
EXCLUDED = {'__pycache__', '.git', '.DS_Store', 'node_modules', 'dist', 'out'}


def bundle_files(root):
    return sorted(p for p in root.rglob('*') if p.is_file()
                  and not any(x in EXCLUDED for x in p.relative_to(root).parts)
                  and p.relative_to(root).parts[:4] != ('examples', 'asset-studio', 'src', 'assets')
                  and p.relative_to(root).parts[:3] != ('examples', 'asset-studio', 'public')
                  and p.suffix not in {'.pyc', '.zip'}
                  and '.bak' not in p.name
                  and not p.name.startswith('.env'))


def validate(root, require_manifest=True):
    errors = []
    skills = root / 'skills'
    actual = {p.name for p in skills.iterdir() if p.is_dir()} if skills.exists() else set()
    if actual != EXPECTED_SKILLS:
        errors.append(f'skill folders differ: missing={EXPECTED_SKILLS - actual}, extra={actual - EXPECTED_SKILLS}')
    for name in EXPECTED_SKILLS:
        entry = skills / name / 'SKILL.md'
        if not entry.is_file(): errors.append(f'missing {entry.relative_to(root)}'); continue
        text = entry.read_text(encoding='utf-8')
        front = re.match(r'^---\n(.*?)\n---', text, re.S)
        if not front or not re.search(r'^name:\s*' + re.escape(name) + r'\s*$', front[1], re.M):
            errors.append(f'invalid entry metadata: {name}')
        elif re.search(r'^description:\s+[^\'\"\n][^\n]*:\s', front[1], re.M):
            errors.append(f'quote the colon-containing YAML description: {name}')
        if not (skills / name / 'agents' / 'openai.yaml').is_file(): errors.append(f'missing agent registration: {name}')
    files = bundle_files(root)
    for p in files:
        if p.is_symlink(): errors.append(f'symlink must not enter the release: {p.relative_to(root)}')
        try:
            if p.suffix == '.py': ast.parse(p.read_text(encoding='utf-8'), filename=str(p), feature_version=(3, 9))
            if p.suffix in {'.json', '.geojson'}: json.loads(p.read_text(encoding='utf-8'))
            if p.suffix == '.svg': ET.fromstring(p.read_bytes())
            if p.suffix == '.md':
                for target in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
                    target = target.strip().strip('<>')
                    if not target or urlsplit(target).scheme: continue
                    target = unquote(target.split('#')[0])
                    if target and not (p.parent / target).exists(): errors.append(f'broken local link: {p.relative_to(root)} -> {target}')
                    if target and p.is_relative_to(skills):
                        if not (p.parent / target).resolve().is_relative_to(skills.resolve()): errors.append(f'skill link escapes a skills-only installation: {p.relative_to(root)} -> {target}')
        except (SyntaxError, ValueError, UnicodeError) as exc:
            errors.append(f'{p.relative_to(root)}: {exc}')
    for theme in ('cut-paper',):
        base = skills / 'remotion-themes' / 'themes' / theme
        for rel in ('THEME.md', 'images/overview.png', 'kit/index.ts', 'entry/StudioRoot.tsx', 'entry/index.ts'):
            if not (base / rel).is_file(): errors.append(f'missing theme asset: {theme}/{rel}')
    font_root = skills / 'remotion-themes' / 'themes' / '_shared' / 'fonts'
    if len(list(font_root.glob('*.ttf'))) != 3: errors.append('expected three Cut Paper font files')
    if len(list(font_root.glob('*-OFL.txt'))) != 3: errors.append('expected three font-family notices')
    release = json.loads((root / 'RELEASE.json').read_text())
    if release.get('themes') != ['cut-paper']: errors.append('Cut Paper must be the sole release theme')
    theme_dirs = {p.name for p in (skills / 'remotion-themes' / 'themes').iterdir() if p.is_dir()}
    if theme_dirs != {'_shared', 'cut-paper'}: errors.append('unexpected theme folder')
    if release.get('skill_count') != len(EXPECTED_SKILLS): errors.append('RELEASE.json skill_count differs')
    library = skills / 'remotion-themes' / 'themes' / 'cut-paper' / 'assets'
    catalog_path = library / 'catalog.json'
    if not catalog_path.is_file(): errors.append('asset catalog is missing')
    else:
        catalog = json.loads(catalog_path.read_text())
        entries = catalog['assets']; ids = [a['id'] for a in entries]
        if len(ids) != len(set(ids)): errors.append('duplicate asset IDs')
        if len(ids) != release.get('asset_catalog_entries'): errors.append('release/catalog asset count differs')
        if catalog['version'] != release['version']: errors.append('release/catalog version differs')
        for name, module in catalog['modules'].items():
            source = skills / module['source'] if 'source' in module else library / name
            if not source.is_file(): errors.append('missing asset module: ' + name)
            for dependency in module.get('requires', []):
                if dependency not in catalog['modules']: errors.append('missing declared module dependency: ' + dependency)
        for asset in entries:
            if asset['module'] not in catalog['modules']: errors.append('missing asset entry module: ' + asset['id'])
            if not asset.get('anchor') or not asset.get('tags'): errors.append('asset needs anchor/tags: ' + asset['id'])
            for extension in ('png', 'svg'):
                if not (library.parent / 'images' / 'assets' / (asset['id'] + '.' + extension)).is_file(): errors.append('asset preview missing: ' + asset['id'] + '.' + extension)
        for name in ('street', 'interior', 'process', 'character', 'landscape'):
            if not (library.parent / 'images' / ('production-' + name + '.png')).is_file(): errors.append('current production reference missing: ' + name)
        for name in ('catalog.html', 'overview.png', 'universal-motion.mp4', 'character.mp4', 'actions.mp4', 'showcase.mp4', 'rig-check.json', 'browser-check.json', 'universal-check.json', 'universal-browser-check.json', 'encoded-check.json', 'preview-build.json', 'gesture-study.mp4', 'pouring-study.mp4', 'interactions.mp4', 'effects.mp4', 'gesture-check.json', 'pouring-check.json', 'effects-check.json', 'interactions-browser-check.json'):
            if not (library.parent / 'images' / 'assets' / name).is_file(): errors.append('asset review artifact missing: ' + name)
    provenance = library.parent / 'images' / 'assets' / 'preview-build.json'
    try:
        workflow_script = skills / 'remotion-themes/scripts/asset_workflow.py'
        spec = importlib.util.spec_from_file_location('bundle_asset_workflow', workflow_script)
        workflow = importlib.util.module_from_spec(spec); spec.loader.exec_module(workflow)
        archive = library / 'library'
        packages = workflow.library_packages(archive)
        if len(packages) != release.get('story_asset_packages'):
            errors.append('release/shared story package count differs')
        expected_rows = [{k: d[k] for k in ('id', 'version', 'title', 'description', 'category', 'scope', 'tags', 'preview_files')} for d in packages]
        index = json.loads((archive / 'index.json').read_text())
        if index != {'schema_version': 1, 'packages': expected_rows}: errors.append('shared story asset index needs regeneration')
        if not (archive / 'catalog.html').is_file(): errors.append('shared story asset gallery missing')
    except (ValueError, OSError, KeyError, TypeError, SyntaxError) as exc:
        errors.append('shared story asset archive: ' + str(exc))
    if provenance.is_file():
        generated = json.loads(provenance.read_text())
        for group in ('source_sha256', 'picture_sha256'):
            for relative, expected in generated.get(group, {}).items():
                target = root / relative
                if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest() != expected:
                    errors.append('references need regeneration: ' + relative)
    manifest_path = root / 'MANIFEST.json'
    if require_manifest and not manifest_path.is_file(): errors.append('MANIFEST.json is missing')
    if require_manifest and manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text())
        actual_hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p != manifest_path}
        if manifest.get('files') != actual_hashes: errors.append('file set or SHA-256 differs from MANIFEST.json')
    return errors, len(files)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--without-manifest', action='store_true', help='for release authors before packaging only')
    a = ap.parse_args()
    errors, count = validate(Path(a.root).resolve(), not a.without_manifest)
    for e in errors: print('FAIL', e)
    integrity = " and manifest" if not a.without_manifest else " (pre-manifest check)"
    print(f"{'FAIL' if errors else 'PASS'}: {len(EXPECTED_SKILLS)} skills; {count} files; local links, JSON, Python syntax, assets{integrity} checked.")
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
