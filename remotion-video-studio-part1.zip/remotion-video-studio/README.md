# Remotion Video Studio

Make finished short videos (Reels / Shorts / TikTok, 1080x1920) with an AI agent. You approve one plan, send one voice audio file, and get the MP4.

## Install
Copy the whole `skills/` folder into your agent's skills directory (Codex: `~/.codex/skills/` or project `.agents/skills/`; Claude Code: `~/.claude/skills/`).
Install all folders together: the scripts reference sibling skills.

Requirements: Node 18+, Python 3.9+ with `numpy` and `scipy`, `ffmpeg`. Optional: `playwright` (only to regenerate theme preview images).

## Use (one prompt)
> Use video-director. Make a 30 second video about <topic> in the cut-paper theme.
> (map video: ... in the night-atlas theme about <country/state/city>.)

1. The agent plans and shows `PLAN.md`: storyboard, narration, **TTS style prompt** and a **paste-ready prompt**. You reply "approve".
2. You paste the prompt into Gemini TTS (or any TTS), and send the audio back.
3. The agent runs `after_vo.py` (timing + sounds from your audio), builds, renders, normalizes loudness, audits, and sends `final.mp4`.

## What is inside
| Skill | Job |
|---|---|
| `video-director` | the pipeline and automation scripts (`init_video`, `doctor`, `plan_docs`, `after_vo`, `finalize`, ...) |
| `remotion-preproduction` | planning rules, anti-AI-slop audit |
| `video-scriptwriting` | hooks, narration for TTS, rewrite examples |
| `remotion-themes` | **Cut Paper** and **Night Atlas** themes with components and preview images |
| `remotion-sound-design` | synthesized SFX library, cue placement on exact frames, mixing, loudness audit |
| `remotion-best-practices`, `remotion-markup`, `remotion-create`, `remotion-studio`, `remotion-render`, `remotion-captions`, `remotion-maps`, `remotion-multimedia`, `remotion-interactivity`, `remotion-docs`, `remotion-upgrade` | official Remotion skills (by Remotion; see remotion.dev/license for their terms) |

## Honest limits
- The Remotion code was type-checked against stubs, not run in a live Remotion project here. Expect to fix small things on first render.
- Sounds were checked with measurements and spectrograms, not by ear. Listen once before publishing.
- Gemini TTS: the prompt is written for the generic style-prompt + transcript format; adjust to the exact model you use.
- Map borders come from Natural Earth: check them against your audience's conventions.

---
## Split package note
This package was split in two to fit upload limits. Part 1 = everything except the `night-atlas` theme. Part 2 = `night-atlas` theme only. Extract both into the same folder (merge) to restore the full studio.
