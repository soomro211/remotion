---
name: remotion-preproduction
description: Planning rules for Remotion videos: concept, script, storyboard, timing and an anti-generic audit. Use inside /video-director (or alone) before any Remotion code whenever the user wants a video, explainer, promo, product demo or social clip. Produces the contents of video/plan.json.
version: 3.0.0
---

# Remotion Pre-production

Bad AI video is bad because nobody decided anything first: generic gradient, centered text, everything fading up
the same way, copy any brand could say. This skill makes the decisions specific, and audits them.
`/video-director` runs this skill as its planning step; the output is `video/plan.json`, not a prose document.

**One approval gate.** Ask at most one batch of questions (max 4, each with a default), then produce the plan and
present `PLAN.md` (made by `plan_docs.py`) for a single approval. Do not build before that. If the user says
"just build it", state assumptions in one short list and continue.

**Principles:** specific beats generic; one idea, one hero per scene, one CTA; restraint reads as quality;
design for sound-off thumb-scroll and for a paused frame that still looks designed; never invent facts,
logos, UI or numbers (use `proof` fields or flag as open questions).

| File | Read at |
|---|---|
| `references/anti-slop.md` | Phase 2 and the audit. Always. |
| `references/script-and-copy.md` | Phase 2 (and use `/video-scriptwriting` for depth) |
| `references/motion-principles.md`, `references/storyboard-timing-specs.md` | Phase 3 |
| `references/design-rules.md` | only when the theme is `custom` |
| `references/qa.md` | Phase 4 audit, and build QA |

## Phase 0: Intake and research (one message, silent where possible)
Needed: goal (what should the viewer believe/do), audience and platform (default 9:16 Reels/Shorts, 20-30 s),
source material (facts, brand assets), tone, narration language and accent. Anything the user did not say gets a
stated default. Research real facts first (WebSearch/WebFetch) and note a source for every number.

## Phase 1: Concept
- **Creative promise** (one sentence) and **the one thing** the viewer must remember.
- One repeatable visual device and one signature moment. Pass the swap test (replace the topic with another
  and the video still works = too generic).
- Theme: `cut-paper` (warm, tactile, explainers, how-it-works, kids/education, stories) or `night-atlas`
  (dark maps: countries, states, cities, distances, geography facts) or `custom` (read `design-rules.md`).

## Phase 2: Script
Hook in 2-3 s, payoff before CTA, one idea per scene. Write narration for the ear (about 2.5 words/second),
on-screen text as 2-5 words per line. Apply the banned-phrase and specificity rules in `script-and-copy.md`.

## Phase 3: Storyboard and timing
Scene list with: id, name, type (`hook` | `explain` | `list` | `route` | `cta`), narration, onscreen lines, a
one-line visual, entrance (`slide` | `pop` | `stamp` | `drop`), and `events` (sound cues at seconds from
scene start: transition, whoosh, land, pop, reveal, tick, cta, riser, zoom, route). Vary scene length and
entrance; no two neighbouring scenes identical. Do not compute frames: the narration audio decides timing later
(`after_vo.py`).

## Phase 4: Audit, then present
Score the plan with `references/qa.md` (fix anything below 4), run the anti-slop checklist, then run
`python3 plan_docs.py video/plan.json`. It validates the plan and writes `PLAN.md` with the storyboard, narration
script, **TTS style prompt** and a paste-ready prompt for the user's TTS (Gemini). Show the user the contents
of PLAN.md and ask for approval and the audio.

## After approval
The user sends the audio. Continue with `/video-director` (timing, sound, build, render).

## Done means
Approved plan, zero unresolved anti-slop hits, every fact sourced, no invented assets.
