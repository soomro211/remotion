# Plan audit and build QA

## Plan audit (run before presenting)
Score 1-5. Anything below 4 must be revised and the change noted.
| Criterion | 5 means |
|---|---|
| Specificity | Every line, color and motion is tied to this brand/idea; passes swap test |
| Hierarchy | One clear hero per scene; 3x scale contrast; passes blur test |
| Rhythm | Varied scene lengths, beat or phrase aligned, signature moment given space |
| Distinctiveness | Customized beyond the stock direction; a designer would not call it a template |
| Brand fit | Uses real brand assets/voice; nothing invented |
| Legibility | Contrast and size verified; safe areas respected; reading time met |
| Sound-off clarity | Story clear with captions/visuals alone |
Then run the five tests and the full `anti-slop.md` checklist. Record hits and fixes.

## Build QA (after each scene and before final render)
- Render stills at: first frame, entrance end, mid-hold, exit start, last frame. Each should look intentional.
- Text: no clipping, no overlap, no orphan words, readable at phone size (view at 25% scale).
- Alignment: elements sit on the grid; margins consistent.
- Motion: check easing feel by scrubbing; no pops, jumps, or gaps where the frame empties; no layout shift when fonts load.
- Timing: scene durations match plan; total frames match target; hold after reading floor.
- Audio: levels, ducking, fades, no clipping; captions synced.
- Determinism: no CSS transitions, no unseeded randomness; render twice and compare a frame.
- Performance: render time reasonable; remove heavy blurs/shadows if slow.
- Compare against `video/plan.json` and update it if anything changed.
- Final: watch it once at full speed, sound off, then sound on, as a first-time viewer.
