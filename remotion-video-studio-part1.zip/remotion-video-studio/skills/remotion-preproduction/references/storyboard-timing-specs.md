# Storyboard, timing and platform specs

## Platform specs (verify current limits before final delivery)
| Platform / use | Canvas | fps | Typical length | Notes |
|---|---|---|---|---|
| YouTube, site hero, decks | 1920x1080 (16:9) | 30 | 20-90s | Captions optional; sound often on |
| Reels / TikTok / Shorts | 1080x1920 (9:16) | 30 | 7-45s | Sound-off friendly, captions, hook in 1-2s, respect UI safe areas |
| LinkedIn, feeds | 1080x1350 (4:5) or 1080x1080 | 30 | 10-45s | Mostly sound-off, text-forward |
| X / Twitter | 1920x1080 or 1080x1080 | 30 | 10-45s | Hook fast, captions |
| In-product / loops | match UI | 30 or 60 | 5-15s | Seamless loop, small file |
Default codec h264 MP4. Use `Composition` ids like `Promo16x9`, `Promo9x16` when delivering multiple formats; plan the responsive layout rules up front (what reflows, what is hidden, what scales) rather than stretching.

## Pacing by purpose
- Social hook video: cut or major change every 1.5-3s, hook by 1s.
- Product promo: scene length 2-4s, one proof moment held 3-5s.
- Explainer: scene length 4-8s, each chapter resolves cleanly.
- Brand film: longer holds, fewer elements, music-led.

## Scene card (one per scene)
```
Scene N — <name>            Time: 0.0-3.0s   Frames: 0-89   Duration: 90f
Purpose:           what this scene must make the viewer understand/feel
Hero element:      the one dominant thing
Supporting:        secondary items (max 3)
Layout:            grid placement (cols/rows), alignment, margins
Background:        color/texture/camera layer behavior
Text on screen:    exact copy (<=12 words)
VO:                exact line (or none)
Entrance:          which element, motion type, frames, easing token
Hold:              what has subtle life, duration
Exit / transition: type, frames, overlap
Camera:            push/pan/parallax values
Sound:             hit/music cue
Capability:        none | maps | captions | 3D | chart | Lottie | video clip
Proof/source:      fact shown and its source
```

## Storyboard table (summary view)
| # | Time | Frames | Visual | Text | VO | Motion | Transition |
|---|---|---|---|---|---|---|---|

## Timing math
1. `frames = seconds x fps`. Round to whole frames.
2. Per scene: `from` (start frame) and `durationInFrames`.
3. With a `TransitionSeries`, total = sum(scene durations) - sum(transition durations).
4. Check: `totalFrames / fps` equals target length within 0.1s.
5. Reading floor: `max(0.8s, 0.25s x words)` after the text has fully arrived.
6. Music: `beatFrames = (60 / BPM) x fps`. Snap cuts and hits to multiples when possible.
7. Voiceover: scene duration = VO duration + 0.3-0.6s breathing room. Draft estimated durations; replace with real audio length once recorded and recompute.
8. Loops: the final frame must visually lead into frame 0.

## Animatic check (before building polish)
List every scene with its duration and the first and last frame description. Read the
list as a rhythm: does the pacing vary, does the hook land in 3s, is the longest scene the most important one?

## Multi-format delivery
If 16:9 and 9:16 are both needed, decide per scene: reflow (re-layout), crop (re-frame), or replace (different shot). Do not scale a landscape layout into portrait. Keep one shared set of tokens and a layout function per aspect ratio.
