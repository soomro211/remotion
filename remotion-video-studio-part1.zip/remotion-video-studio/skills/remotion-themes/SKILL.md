---
name: remotion-themes
description: Two finished, full-screen 1080x1920 video themes for Remotion with ready-made components: Cut Paper (layered paper-craft scenes for explainers, stories, facts) and Night Atlas (dark map visuals for countries, states, cities, routes and distances). Use when building or customizing scenes for a video made with /video-director, or when the user wants theme preview images.
version: 1.0.0
---

# Remotion Themes

| Theme | Use for | Look |
|---|---|---|
| `cut-paper` | explainers, how-things-work, facts, stories, education, any topic | full-bleed layered paper hills, sun, clouds; cream/orange/navy paper slips with tape; stop-motion drift; grain and vignette |
| `night-atlas` | one country, a state, a city, two cities and the distance, geography facts | dark ocean, spinning globe, flat country map with a state zooming in, amber/teal accents, self-drawing routes |

Each theme folder has `images/` (4 preview frames + overview), `THEME.md` (palette, type, rules), `kit/` (TS components),
`entry/` (Remotion root), `generator/` (Python that regenerates the preview PNGs; needs `playwright` + Chromium; optional).

## Using a theme
`python3 ../video-director/scripts/init_video.py <project> --theme cut-paper` copies `kit/` to `src/theme/`, `entry/` to `src/`, and the shared
fonts to `public/fonts`. `PaperVideo` / `AtlasVideo` then render a whole video from `video/plan.json`, so scenes need no code unless you
want to customize. Scene `type` decides the layout (see `video-director/references/plan-schema.md`).

## Customizing (edit the copies in the project's `src/theme/`)
- Cut Paper: components `Piece` (any sheet of paper), `Slip` (title text on a slip, auto-sized), `Card`, `Tape`, `Sun`, `Cloud`, `Tree`, `Bird`,
  `PaperBackground` (variants `day` `sunset` `dusk` `mint`), `PaperWipe` (scene transition), `Texture`. Entrances: `slide` `pop` `stamp` `drop`.
  Ambient motion steps every 3 frames on purpose (stop-motion feel); entrances are smooth springs. Add scenery by composing `Piece` + SVG.
- Night Atlas: `Globe`, `CountryMap` (zoom into a state), `RouteBetween` (great-circle line + km), `Title`, `Chip`, `Stat`; math in `geo.ts`. Geography comes from
  `src/data/geo.json` (`prepare_map_data.py --country X --state Y --cities A,B`). Natural Earth 50m has states for large countries only (US, CA, AU, BR, IN,
  CN, RU, ...); for others the country outline is shown. Respect the audience's border conventions.
- Keep text inside the safe zone (top 270, bottom 420, right 110 px). `paper.safe` / `atlas.safe` hold the numbers.
- For a custom look, follow `remotion-preproduction/references/design-rules.md` and do not fake these themes.

## Regenerating preview images
`cd themes/cut-paper/generator && python3 paper_frames.py` (or `atlas_frames.py`; edit CONFIG at the top for the country). Output goes to `out/` (or `OUT_DIR=...`).
