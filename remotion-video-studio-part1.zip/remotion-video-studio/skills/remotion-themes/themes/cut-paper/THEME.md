# Cut Paper

Full-screen layered paper craft. Warm, tactile, friendly; works for any subject (science, history, money, health, tutorials, stories).

- Palette: cream #F4EBD8, ink navy #1B2845, orange #F26A41, yellow #F2B83B, teal #2FB5A0, pink #E8658A; skies day / sunset / dusk / mint; four hill greens or purples per variant.
- Type: Bricolage 800 uppercase for slips (tight tracking -2), Caveat for handwritten asides (optional), DM Sans for small text.
- Surface: every element is a sheet of paper: hand-cut irregular edges, two-layer shadow (tight + soft), lighter rim, fibre texture, grain and vignette over the whole frame.
- Motion: slips slide in from the left or drop in, tape stamps on, hills drift slowly in parallax, sun rotates, all ambient movement steps at about 10 fps (stop-motion). Scene change = a cream paper sheet sweeping across.
- Layout: full-bleed scenery, text on slips between y=300 and y=1500, clear of the top 270 / bottom 420 / right 110 px.
- Do: one idea per scene, 2-3 slips, strong contrast of colours between neighbouring slips. Don't: shiny gradients, glow, drop shadows on text itself, more than 3 title slips per scene.
- Previews: `images/frame-1..4.png` (hook, diagram, numbered cards, sunset CTA). Sample text is placeholder.
