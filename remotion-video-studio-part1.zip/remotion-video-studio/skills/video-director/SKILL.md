---
name: video-director
description: End-to-end Remotion video production with ONE approval gate. Use whenever the user asks for a video, reel, short, explainer or map video. Plans the video, shows the plan with a TTS style prompt and narration prompt for approval, then (after the user sends the voice audio) times scenes from the audio, builds sound design automatically, builds the scenes in the Cut Paper or Night Atlas theme, renders and audits the final MP4.
version: 1.0.0
---

# Video Director

You run the whole pipeline. The user approves once and sends one audio file; everything else is automatic.
Scripts live in this skill's `scripts/` (run with `python3`, paths relative to the project root).
Install the whole folder together: scripts reference the sibling skills `remotion-themes` and `remotion-sound-design`.

## Pipeline

```
 1 intake -> 2 plan -> 3 APPROVAL GATE (PLAN.md + style prompt + narration) -> 4 user sends TTS audio
 -> 5 after_vo.py -> 6 build -> 7 finalize.py -> 8 deliver
```

### 1. Intake (silent, one message at most)
Use `/remotion-preproduction` and `/video-scriptwriting` rules. Ask only what is missing (max 4 questions, each
with a default). Theme choice: `cut-paper` (tactile paper scenes: explainers, stories, facts, education) or
`night-atlas` (dark maps: country / state / city / distance videos). Never ask about style frames or look
verification: themes are already designed.

### 2. Plan
```
python3 scripts/init_video.py . --theme cut-paper --title "..."          # or night-atlas --country Australia --state Victoria --cities Melbourne,Sydney
python3 scripts/doctor.py --project .                                    # environment check, once
```
`init_video.py` creates `video/plan.json` from the template, copies the theme kit to `src/theme`, fonts to `public/fonts`,
synthesizes the SFX library to `public/sfx`, and registers `src/StudioRoot.tsx`. Fill `video/plan.json` (schema:
`references/plan-schema.md`). Then:
```
python3 scripts/plan_docs.py video/plan.json
```
It validates (length vs word count, banned phrases, unsourced numbers) and writes `PLAN.md`, `narration.txt`, `tts-prompt.txt`.
Fix every error it prints and re-run.

### 3. The approval gate (the only one)
Show the user the **contents of PLAN.md**: summary, storyboard table, the narration script, the **TTS style prompt**, and the
**paste-ready TTS prompt** (style + exact transcript). End with: "Reply **approve** (or tell me what to change). Then generate the
voice with your TTS and send me the audio file." Do not write any scene code before approval. On changes: edit plan.json, re-run
`plan_docs.py`, show it again.

### 4. The user sends the audio (wav/mp3/m4a)
Save it into the project (e.g. `public/vo.mp3`). If it sounds wrong (wrong pace, mispronounced words), the fix is the
style prompt or `voice.pronunciations`: update, re-run `plan_docs.py`, ask for a new take. Do not edit audio.

### 5. One command: timing + sound
```
python3 scripts/after_vo.py --project . --vo public/vo.mp3 [--music public/music.mp3]
```
Detects the pauses between scenes in the voice, writes `start_frame` / `duration_frames` / `total_frames` into plan.json and
`src/data/timing.json`, places every sound cue on its exact frame (`src/sfxCues.ts`), writes `video/cue-sheet.md` and
`video/preview-mix.wav`. Check the printed scene boundaries: if the count of pauses did not match the scene count it falls back to
word counts and says so; in that case ask the user to add a clearer pause (the style prompt already requests ~700 ms) or retake.

### 6. Build
If TypeScript complains about importing `plan.json`, add `"resolveJsonModule": true` to tsconfig. Run once per project: `npx remotion add @remotion/media @remotion/transitions` (project from `/remotion-create`; init works on top of it).
The theme kit already renders every scene from `plan.json` (`PaperVideo` / `AtlasVideo`), so a first full render needs no scene code.
Preview: `npx remotion still src/index.ts Main out/f.png --frame=20` for a few frames (first frame of each scene, last frame of the
longest scene). Look at them: text must not collide or leave the safe zone (top 270 px, bottom 420 px, right 110 px free). To
customize a scene, edit the scene functions in `src/theme/` (read `/remotion-themes`), using `/remotion-best-practices`, `/remotion-markup`,
`/remotion-captions` (for captions) and `/remotion-docs` if unsure. Keep to the anti-slop rules.

### 7. Render, loudness, audit
```
python3 scripts/finalize.py --project . --comp Main --out out/final.mp4
```
Renders, normalizes to about -14 LUFS / -1.5 dBTP with the video stream copied, and audits. Fix any FAIL (see
`remotion-sound-design/references/mixing-and-loudness.md`), re-run.

### 8. Deliver
Send `out/final.mp4` with `SendUserFile`, one line on what it is. Say plainly what you verified (frames viewed, audio measured) and
what you could not (you cannot listen: the sound is checked by measurements and spectrograms, so ask the user to play it once).

## Rules
- One approval gate. No questions after it unless something blocks.
- Never invent facts, numbers, logos or assets; unresolved items go in `open_questions` with a default.
- Do not hardcode frames anywhere: they come from `timing.json` / plan.json.
- Do not re-do finished steps: `init_video.py` and `auto_sfx.py` are idempotent and skip what exists.
- If a step fails, read the message, fix the cause, re-run that one script.
