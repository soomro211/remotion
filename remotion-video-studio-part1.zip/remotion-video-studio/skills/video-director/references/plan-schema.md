# video/plan.json

Template: `assets/plan.template.json` (a complete 4-scene example). Fields:

| Field | Meaning |
|---|---|
| title, theme (`cut-paper`/`night-atlas`/`custom`), fps, width, height | composition basics (1080x1920 at 30 fps default) |
| target_seconds, platform, audience | length and where it plays |
| creative_promise, the_one_thing | one sentence each (see remotion-preproduction) |
| voice | persona, tone, pace, wpm, accent, energy, pause_ms, pronunciations{word: how to say} -> these become the TTS style prompt |
| scenes[] | id, name, type, narration, onscreen[], visual, entrance, events[], proof? |
| scenes[].type | `hook` `explain` `list` `route` (night-atlas) `cta` |
| scenes[].onscreen | 2-5 words per line, up to 3 lines (`list`: up to 4 lines; night-atlas `list` uses `"112|km of coastline"` = `value|label`) |
| scenes[].entrance | `slide` `pop` `stamp` `drop` `none` |
| scenes[].events | `{t: seconds from scene start, kind, gain_db?}`; kinds: transition whoosh land pop reveal tick cta riser type ping pin route zoom error |
| scenes[].proof | source for any number or claim in the scene (required when digits appear) |
| scenes[].paper.variant | cut-paper only: `day` `sunset` `dusk` `mint` |
| map | night-atlas only: `{country, state, cities:[A,B]}` |
| cta | final call to action text |
| music | `null` or `{file, volume}` |
| open_questions | `{q, default}` |

Written by the scripts (do not edit): scenes[].start_frame, duration_frames, vo_start_s, vo_end_s; total_frames; vo{file,duration_s,timing_method}.

Rules of thumb: 4-7 scenes for 20-35 s; narration of one scene = 1-2 short sentences; at most 6 words on screen per line;
the last scene is the CTA; narration must contain every on-screen claim so sound-off viewers still get it from the text.
