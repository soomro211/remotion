#!/usr/bin/env python3
"""Build the whole sound-design track from plan.json in one command.

  python3 auto_sfx.py video/plan.json [--project .] [--vo public/vo.mp3] [--music public/music.mp3] [--no-preview]

1. Generates the SFX library into public/sfx if it is missing (remotion-sound-design/scripts/synth_sfx.py).
2. Turns each scene's `events` (or sensible defaults) into cues using the theme's sound palette, placed on exact frames
   from the scene timing (run vo_to_timing.py first so start_frame exists).
3. Limits density, rotates variants, lowers sounds that sit on top of speech.
4. Writes src/sfxCues.ts (use with SfxTrack.tsx), video/cue-sheet.md, and a preview mix video/preview-mix.wav."""
import argparse, json, os, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent; SKILLS = HERE.parents[1]; SND = SKILLS / 'remotion-sound-design' / 'scripts'
sys.path.insert(0, str(SND))

def default_events(s, i, theme):
    ev = []; ent = s.get('entrance', 'slide'); on = s.get('onscreen', [])
    if i > 0: ev.append({'t': 0.0, 'kind': 'transition'})
    if ent == 'slide': ev += [{'t': 0.12, 'kind': 'whoosh'}, {'t': 0.45, 'kind': 'land'}]
    elif ent in ('pop', 'stamp'): ev.append({'t': 0.2, 'kind': 'land' if ent == 'stamp' else 'pop'})
    elif ent == 'draw': ev.append({'t': 0.2, 'kind': 'route'})
    for j in range(1, len(on)): ev.append({'t': 0.5 + 0.3 * j, 'kind': 'pop'})
    if s.get('type') == 'cta': ev.append({'t': max(0.4, (s.get('vo_end_s', 0) - s.get('start_frame', 0) / 30) - 0.3), 'kind': 'cta'})
    return ev

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('plan'); ap.add_argument('--project', default='.'); ap.add_argument('--vo'); ap.add_argument('--music'); ap.add_argument('--no-preview', action='store_true'); a = ap.parse_args()
    proj = Path(a.project).resolve(); plan = json.load(open(a.plan)); fps = plan['fps']; theme = plan.get('theme', 'default')
    if any('start_frame' not in s for s in plan['scenes']): sys.exit('scene timing missing: run vo_to_timing.py first')
    pal = json.load(open(HERE.parent / 'assets' / 'sound-palettes.json')); P = pal.get(theme, pal['default']); duck = pal.get('speech_duck_db', {})
    sfx = proj / 'public' / 'sfx'
    if not (sfx / 'manifest.json').exists():
        import synth_sfx; synth_sfx.build(str(sfx)); print(f'generated SFX library in {sfx}')
    man = json.load(open(sfx / 'manifest.json')); by = {}
    for e in man: by.setdefault(e['name'], []).append(e)
    rot = {}; cues = []; last = {}
    for i, s in enumerate(plan['scenes']):
        evs = s.get('events') or default_events(s, i, theme)
        for ev in sorted(evs, key=lambda e: e['t']):
            kind = ev['kind']; names = P['map'].get(kind) or pal['default']['map'].get(kind)
            if not names: print(f"skip unknown event kind '{kind}' in {s['id']}"); continue
            name = names[rot.get(kind, 0) % len(names)] if len(names) > 1 and kind in ('pop', 'zoom') else names[0]
            frame = s['start_frame'] + round(ev['t'] * fps); tsec = frame / fps
            if tsec - last.get(kind, -9) < 0.25 and kind not in ('tick', 'type'): continue      # same sound too close
            last[kind] = tsec
            v = by[name][rot.get(name, 0) % len(by[name])]; rot[name] = rot.get(name, 0) + 1
            if kind in ('pop', 'zoom'): rot[kind] = rot.get(kind, 0) + 1
            g = P.get('gain_db', {}).get(kind, 0) + ev.get('gain_db', 0)
            if 'vo_start_s' in s and s['vo_start_s'] <= tsec <= s['vo_end_s']: g += duck.get(v['category'], 0)
            cues.append({'file': v['file'], 'frame': frame, 'volume': round(v['volume'] * 10 ** (g / 20), 3), 'note': f"{s['id']} {kind}"})
    cues.sort(key=lambda c: c['frame']); keep = []                                           # density cap: max 3 cues per 0.5 s
    for c in cues:
        if sum(1 for k in keep if abs(k['frame'] - c['frame']) < fps * .25) >= 3: print('dropped (too dense):', c['note']); continue
        keep.append(c)
    vo = a.vo or (plan.get('vo') or {}).get('file'); cj = {'fps': fps, 'duration_frames': plan.get('total_frames') or max(c['frame'] for c in keep) + fps * 2, 'sfx_dir': str(sfx), 'cues': keep}
    vo_wav = None
    if vo and not a.no_preview:
        vp = Path(vo) if Path(vo).is_absolute() else proj / vo
        if vp.exists():
            vo_wav = proj / 'video' / 'vo-preview.wav'; (proj / 'video').mkdir(exist_ok=True)
            subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(vp), '-ar', '48000', '-ac', '2', str(vo_wav)], check=True); cj['vo'] = {'file': str(vo_wav)}
    mu = a.music or ((plan.get('music') or {}).get('file') if isinstance(plan.get('music'), dict) else None)
    if mu:
        mp = Path(mu) if Path(mu).is_absolute() else proj / mu
        if mp.exists():
            mw = proj / 'video' / 'music-preview.wav'; subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(mp), '-ar', '48000', '-ac', '2', str(mw)], check=True)
            cj['music'] = {'file': str(mw), 'volume': (plan.get('music') or {}).get('volume', 0.18), 'duck_db': -9}
    (proj / 'video').mkdir(exist_ok=True); cp = proj / 'video' / 'cues.json'; json.dump(cj, open(cp, 'w'), indent=1)
    (proj / 'src').mkdir(exist_ok=True)
    r = subprocess.run([sys.executable, str(SND / 'mix_preview.py'), str(cp), '--out', str(proj / 'video' / 'preview-mix.wav'), '--emit', str(proj / 'src' / 'sfxCues.ts')], capture_output=True, text=True)
    print(r.stdout.strip()); 
    if r.returncode: sys.exit(r.stderr)
    rows = '\n'.join(f"| {c['frame']} | {c['frame']/fps:.2f}s | {c['file']} | {c['volume']} | {c['note']} |" for c in keep)
    (proj / 'video' / 'cue-sheet.md').write_text(f"# Cue sheet\n| frame | time | file | volume | note |\n|---|---|---|---|---|\n{rows}\n")
    print(f'{len(keep)} cues -> src/sfxCues.ts, video/cue-sheet.md')

if __name__ == '__main__': main()
