#!/usr/bin/env python3
"""Render, loudness-normalize and audit the final video in one command.

  python3 finalize.py --project . --comp Main [--entry src/index.ts] [--out out/final.mp4] [--target -14]
  python3 finalize.py --input out/raw.mp4 --out out/final.mp4          # skip rendering, only normalize + audit

Steps: npx remotion render -> ffmpeg two-pass loudnorm (video stream copied, AAC 256k) -> audit_audio.py --mix.
Exit code 1 if the audit has a FAIL."""
import argparse, json, re, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent; AUDIT = HERE.parents[1] / 'remotion-sound-design' / 'scripts' / 'audit_audio.py'

def run(cmd, **k): return subprocess.run(cmd, text=True, capture_output=True, **k)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--project', default='.'); ap.add_argument('--comp', default='Main'); ap.add_argument('--entry'); ap.add_argument('--input')
    ap.add_argument('--out', default='out/final.mp4'); ap.add_argument('--target', type=float, default=-14.0); ap.add_argument('--tp', type=float, default=-1.5); a = ap.parse_args()
    proj = Path(a.project).resolve(); out = proj / a.out; out.parent.mkdir(parents=True, exist_ok=True)
    if a.input: raw = Path(a.input)
    else:
        entry = a.entry or next((str(p.relative_to(proj)) for p in (proj / 'src' / 'index.ts', proj / 'src' / 'index.tsx', proj / 'src' / 'index.js') if p.exists()), None)
        if not entry: sys.exit('no Remotion entry found (src/index.ts); pass --entry')
        raw = proj / 'out' / 'raw.mp4'; print('rendering...', flush=True)
        r = subprocess.run(['npx', 'remotion', 'render', entry, a.comp, str(raw)], cwd=proj)
        if r.returncode: sys.exit('render failed (see output above)')
    p1 = run(['ffmpeg', '-nostats', '-i', str(raw), '-vn', '-af', f'loudnorm=I={a.target}:TP={a.tp}:LRA=11:print_format=json', '-f', 'null', '-'])
    m = re.search(r'\{[^{}]*"input_i"[^{}]*\}', p1.stderr, re.S)
    if not m: sys.exit('could not measure loudness (does the video have an audio track?)\n' + p1.stderr[-600:])
    j = json.loads(m.group(0)); print(f"measured: {j['input_i']} LUFS, true peak {j['input_tp']} dBTP")
    af = (f"loudnorm=I={a.target}:TP={a.tp}:LRA=11:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true,aresample=48000")
    p2 = run(['ffmpeg', '-y', '-v', 'error', '-i', str(raw), '-c:v', 'copy', '-af', af, '-c:a', 'aac', '-b:a', '256k', str(out)])
    if p2.returncode: sys.exit('normalize failed:\n' + p2.stderr[-800:])
    print('wrote', out); r = subprocess.run([sys.executable, str(AUDIT), str(out), '--mix']); sys.exit(r.returncode)

if __name__ == '__main__': main()
