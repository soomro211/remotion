#!/usr/bin/env python3
"""Set up a video project in one command (idempotent: safe to re-run, never overwrites without --force).

  python3 init_video.py <project_dir> --theme cut-paper|night-atlas|custom [--title "..."] [--fps 30] [--size 1080x1920] [--no-sfx] [--force]
  night-atlas also takes: --country Australia --state Victoria --cities Melbourne,Sydney

Creates: video/plan.json, public/fonts, public/sfx (synthesized), src/theme/ (theme kit), src/SfxTrack.tsx, src/sfxCues.ts, src/data/timing.json.
The Remotion project itself comes from /remotion-create (or `npx create-video@latest`); run this inside or on top of it."""
import argparse, json, shutil, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent; SK = HERE.parents[1]
THEMES = SK / 'remotion-themes' / 'themes'; SND = SK / 'remotion-sound-design'

def put(src, dst, force):
    if dst.exists() and not force: print(f'  keep   {dst.name} (exists)'); return
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir(): shutil.copytree(src, dst, dirs_exist_ok=True)
    else: shutil.copy2(src, dst)
    print(f'  wrote  {dst}')

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('--theme', default='cut-paper'); ap.add_argument('--title', default='Untitled video')
    ap.add_argument('--fps', type=int, default=30); ap.add_argument('--size', default='1080x1920'); ap.add_argument('--no-sfx', action='store_true'); ap.add_argument('--force', action='store_true')
    ap.add_argument('--country'); ap.add_argument('--state'); ap.add_argument('--cities'); a = ap.parse_args()
    proj = Path(a.project).resolve(); proj.mkdir(parents=True, exist_ok=True); w, h = (int(x) for x in a.size.lower().split('x'))
    print(f'Project: {proj}  theme: {a.theme}')
    plan_p = proj / 'video' / 'plan.json'
    if plan_p.exists() and not a.force: print('  keep   video/plan.json (exists)')
    else:
        plan = json.load(open(HERE.parent / 'assets' / 'plan.template.json')); plan.update(title=a.title, theme=a.theme, fps=a.fps, width=w, height=h)
        if a.theme == 'night-atlas' and a.country: plan['map'] = dict(country=a.country, state=a.state or '', cities=[c.strip() for c in (a.cities or '').split(',') if c.strip()])
        plan_p.parent.mkdir(parents=True, exist_ok=True); json.dump(plan, open(plan_p, 'w'), indent=2, ensure_ascii=False); print('  wrote  video/plan.json')
    kit = THEMES / a.theme / 'kit'
    if a.theme != 'custom':
        if not kit.exists(): sys.exit(f'unknown theme {a.theme}; available: ' + ', '.join(p.name for p in THEMES.iterdir() if p.is_dir()))
        put(kit, proj / 'src' / 'theme', a.force)
        fonts = THEMES / '_shared' / 'fonts'
        if fonts.exists(): put(fonts, proj / 'public' / 'fonts', a.force)
    ent = THEMES / a.theme / 'entry'
    if ent.exists():
        put(ent / 'StudioRoot.tsx', proj / 'src' / 'StudioRoot.tsx', a.force)
        idx = proj / 'src' / 'index.ts'
        if not idx.exists() or 'StudioRoot' not in idx.read_text():
            if idx.exists(): shutil.copy2(idx, proj / 'src' / 'index.ts.orig')
            shutil.copy2(ent / 'index.ts', idx); print('  wrote  src/index.ts (registers StudioRoot; old one saved as index.ts.orig)')
    put(SND / 'assets' / 'SfxTrack.tsx', proj / 'src' / 'SfxTrack.tsx', a.force)
    cues = proj / 'src' / 'sfxCues.ts'
    if not cues.exists(): cues.write_text('export const sfxCues = [] as const;\n'); print('  wrote  src/sfxCues.ts (empty until auto_sfx.py)')
    tm = proj / 'src' / 'data' / 'timing.json'
    if not tm.exists(): tm.parent.mkdir(parents=True, exist_ok=True); tm.write_text('{}\n')
    if a.theme == 'night-atlas' and a.country:
        r = subprocess.run([sys.executable, str(HERE / 'prepare_map_data.py'), '--project', str(proj), '--country', a.country, '--state', a.state or '', '--cities', a.cities or ''])
        if r.returncode: print('  map data step failed (see above); re-run prepare_map_data.py after fixing')
    sfx = proj / 'public' / 'sfx'
    if not a.no_sfx and not (sfx / 'manifest.json').exists():
        sys.path.insert(0, str(SND / 'scripts')); import synth_sfx; synth_sfx.build(str(sfx)); print(f'  wrote  {sfx} (synthesized sound library)')
    print('\nNext:\n  1. npx remotion add @remotion/media @remotion/transitions   (once)\n  2. python3 doctor.py --project .\n  3. fill video/plan.json (the agent does this), then: python3 plan_docs.py video/plan.json')

if __name__ == '__main__': main()
