#!/usr/bin/env python3
"""Turn video/plan.json into the human approval document and the TTS bundle.

  python3 plan_docs.py video/plan.json

Writes next to plan.json:
  PLAN.md          approval message: summary, storyboard, narration, TTS style prompt, paste-ready prompt, checks
  narration.txt    clean narration (one paragraph per scene), nothing else
  tts-prompt.txt   single paste-ready prompt (style + transcript) for Gemini TTS
Also validates the plan (required fields, length vs word count, banned/generic phrases, unsourced numbers).
Exit code 1 if blocking errors were found."""
import json, os, re, sys

BANNED = ["revolutionize", "unlock", "supercharge", "elevate", "seamless", "effortless", "cutting-edge", "next-generation", "game-changing", "game changer",
          "harness", "leverage", "empower", "transform your", "next level", "fast-paced world", "imagine a world", "say goodbye", "introducing the future",
          "all-in-one", "powerful yet simple", "delve", "tapestry", "let's dive in", "here's the thing", "in today's"]
REQUIRED = ["title", "theme", "fps", "width", "height", "scenes", "voice"]

def words(t): return len(re.findall(r"[\w'’-]+", t))

def style_prompt(v, n_scenes):
    pr = v.get("pronunciations") or {}
    lines = [
        f"Voice: speak as {v['persona']}.",
        f"Tone: {v['tone']}.",
        f"Pace: {v['pace']}, about {v.get('wpm', 150)} words per minute.",
        f"Accent: {v['accent']}.",
        f"Energy: {v['energy']}.",
        f"Pauses: leave a clear, natural pause of about {v.get('pause_ms', 700)} ms between paragraphs, and a short breath at commas and full stops. Do not rush the first sentence.",
        "Delivery: sound like a real person talking to one listener, with natural emphasis on the key word of each sentence. No announcer voice, no sing-song, no reading of headings or stage directions.",
    ]
    if pr: lines.append("Pronunciations: " + "; ".join(f"{k} = {val}" for k, val in pr.items()) + ".")
    lines.append(f"Read the transcript below exactly as written ({n_scenes} paragraphs). Do not add or skip words.")
    return "\n".join(lines)

def main(path):
    plan = json.load(open(path)); d = os.path.dirname(os.path.abspath(path)); errs, warns = [], []
    for k in REQUIRED:
        if k not in plan: errs.append(f"missing field: {k}")
    if errs: print("\n".join("ERROR " + e for e in errs)); return 1
    v = plan["voice"]
    for k in ("persona", "tone", "pace", "accent", "energy"):
        if not v.get(k): errs.append(f"voice.{k} is empty (needed for the TTS style prompt)")
    sc = plan["scenes"]; paras = []
    total_w = 0; est = []
    for s in sc:
        nar = (s.get("narration") or "").strip(); w = words(nar); total_w += w; paras.append(nar)
        sec = w / (v.get("wpm", 150) / 60) + v.get("pause_ms", 700) / 1000 if nar else float(s.get("est_seconds", 2)); est.append(sec)
        if not nar: warns.append(f"{s['id']}: no narration (scene will be music/sfx only)")
        if len(s.get("onscreen", [])) and sum(words(x) for x in s["onscreen"]) > 12: warns.append(f"{s['id']}: more than ~12 words on screen")
        txt = " ".join([nar] + s.get("onscreen", [])).lower()
        for b in BANNED:
            if b in txt: warns.append(f"{s['id']}: generic phrase '{b}'; rewrite with something specific")
        if re.search(r"\b\d[\d,.]*\s?(%|percent|million|billion|km|miles|times|x)\b", txt) and not s.get("proof"): warns.append(f"{s['id']}: contains a number/claim but no 'proof' source field")
    total_est = sum(est) - (v.get("pause_ms", 700) / 1000)
    tgt = plan.get("target_seconds")
    if tgt and abs(total_est - tgt) > max(3, tgt * .2): warns.append(f"estimated voiceover length {total_est:.0f}s vs target {tgt}s: adjust narration ({total_w} words now, about {int(tgt * v.get('wpm',150) / 60)} fit)")
    if errs: print("\n".join("ERROR " + e for e in errs)); return 1
    sp = style_prompt(v, len([p for p in paras if p]))
    transcript = "\n\n".join(p for p in paras if p)
    combined = sp + "\n\nTranscript:\n\n" + transcript
    open(os.path.join(d, "narration.txt"), "w").write(transcript + "\n")
    open(os.path.join(d, "tts-prompt.txt"), "w").write(combined + "\n")
    rows = "\n".join(f"| {i+1} | {s.get('name','')} | {' / '.join(s.get('onscreen', [])) or '-'} | {s.get('visual','')} | {est[i]:.1f} |" for i, s in enumerate(sc))
    md = f"""# {plan['title']}: plan for approval

**Theme:** {plan['theme']} | **Canvas:** {plan['width']}x{plan['height']} at {plan['fps']} fps | **Length:** about {total_est:.0f}s | **Platform:** {plan.get('platform','')}
**Promise:** {plan.get('creative_promise','')}
**The one thing:** {plan.get('the_one_thing','')}

## Storyboard
| # | Scene | On-screen text | Visual | Est. sec |
|---|---|---|---|---|
{rows}

## 1. Narration script (what the voice says)
{transcript}

## 2. Style prompt (how it should sound)
```
{sp}
```

## 3. Paste-ready prompt for Gemini TTS (style + transcript in one)
```
{combined}
```
Generate the audio with this prompt, then send me the audio file (wav or mp3). Tip: keep one take for the whole script so the pacing stays consistent; if one line is wrong, regenerate only that paragraph and tell me which one.

## Assets
{chr(10).join('- ' + a['item'] + ': ' + a['status'] for a in plan.get('assets', [])) or '- none'}

## Open questions (defaults if you do not answer)
{chr(10).join('- ' + q['q'] + ' Default: ' + q['default'] for q in plan.get('open_questions', [])) or '- none'}

## Checks
{chr(10).join('- ' + w for w in warns) or '- No issues found.'}

**Reply "approve" (or send edits).** After approval: send the audio. I will then build the timing, sound design, scenes and final export automatically.
"""
    open(os.path.join(d, "PLAN.md"), "w").write(md)
    print(f"wrote PLAN.md, narration.txt, tts-prompt.txt in {d}  ({total_w} words, ~{total_est:.0f}s)")
    for w in warns: print("WARN", w)
    return 0

if __name__ == "__main__": sys.exit(main(sys.argv[1]))
