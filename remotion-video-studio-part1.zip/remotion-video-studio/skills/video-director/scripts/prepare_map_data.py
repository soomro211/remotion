#!/usr/bin/env python3
"""Extract a compact geography file for the Night Atlas kit.

  python3 prepare_map_data.py --project . --country Australia [--state Victoria] [--cities Melbourne,Sydney] [--out src/data/geo.json]

Output geo.json: {world:[rings], country:{name,rings,bbox}, states:[{name,abbr,rings,centroid}], places:[{name,lon,lat,pop,capital}], focus:{state,cities}}
Data: Natural Earth (public domain), shipped in remotion-themes/themes/night-atlas/generator/ne/geojson.
50m admin-1 covers only big countries (US, CA, AU, BR, IN, CN, RU...); for others states[] is empty and the kit shows the country outline only."""
import argparse, json, math, unicodedata
from pathlib import Path
HERE = Path(__file__).resolve().parent
NE = HERE.parents[1] / 'remotion-themes' / 'themes' / 'night-atlas' / 'generator' / 'ne' / 'geojson'
def norm(t): return unicodedata.normalize('NFKD', t or '').encode('ascii', 'ignore').decode().lower()
def polys(g): return [g['coordinates']] if g['type'] == 'Polygon' else g['coordinates'] if g['type'] == 'MultiPolygon' else []
def area(r): return abs(sum(r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1] for i in range(len(r) - 1))) / 2
def rdp(pts, eps):
    if len(pts) < 4: return pts
    (x1, y1), (x2, y2) = pts[0], pts[-1]; dx, dy = x2 - x1, y2 - y1; n = math.hypot(dx, dy) or 1e-9; best, bi = 0, 0
    for i in range(1, len(pts) - 1):
        d = abs(dy * pts[i][0] - dx * pts[i][1] + x2 * y1 - y2 * x1) / n
        if d > best: best, bi = d, i
    if best <= eps: return [pts[0], pts[-1]]
    return rdp(pts[:bi + 1], eps)[:-1] + rdp(pts[bi:], eps)
def rings(f, eps, nd, minfrac=0.0):
    rs = [p[0] for p in polys(f['geometry'])]; m = max((area(r) for r in rs), default=0)
    out = []
    for r in rs:
        if area(r) < m * minfrac: continue
        s = rdp([(x, y) for x, y in r], eps); out.append([[round(x, nd), round(y, nd)] for x, y in s])
    return out
def centroid(r):
    a = cx = cy = 0
    for i in range(len(r) - 1):
        k = r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1]; a += k; cx += (r[i][0] + r[i + 1][0]) * k; cy += (r[i][1] + r[i + 1][1]) * k
    return [round(cx / (3 * a), 3), round(cy / (3 * a), 3)] if a else r[0]
def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--project', default='.'); ap.add_argument('--country', required=True); ap.add_argument('--state', default=''); ap.add_argument('--cities', default=''); ap.add_argument('--out', default='src/data/geo.json'); a = ap.parse_args()
    C = json.load(open(NE / 'ne_50m_admin_0_countries.geojson'))['features']; A1 = json.load(open(NE / 'ne_50m_admin_1_states_provinces.geojson'))['features']; PL = json.load(open(NE / 'ne_10m_populated_places_simple.geojson'))['features']
    pick = [f for f in C if norm(a.country) in (norm(f['properties'].get('NAME')), norm(f['properties'].get('ADMIN')), norm(f['properties'].get('NAME_LONG')))]
    if not pick: raise SystemExit('country not found. Examples: ' + ', '.join(sorted(f['properties']['NAME'] for f in C)[:12]) + ' ...')
    cf = pick[0]; adm = cf['properties']['ADMIN']; iso = cf['properties'].get('ADM0_A3')
    world = [r for f in C for r in rings(f, 0.12, 1, 0.01)]
    country = dict(name=cf['properties']['NAME'], rings=rings(cf, 0.03, 2, 0.01))
    xs = [p[0] for r in country['rings'] for p in r]; ys = [p[1] for r in country['rings'] for p in r]; country['bbox'] = [min(xs), min(ys), max(xs), max(ys)]
    states = []
    for f in A1:
        p = f['properties']
        if p.get('adm0_a3') != iso and norm(p.get('admin')) != norm(adm): continue
        rs = rings(f, 0.02, 2, 0.01)
        if rs: states.append(dict(name=p['name'], abbr=(p.get('postal') or p['name'][:3]).upper(), rings=rs, centroid=centroid(max(rs, key=area))))
    places = []
    for f in PL:
        p = f['properties']
        if p.get('adm0_a3') == iso and (p.get('pop_max') or 0) > 150000 or any(norm(p['name']) == norm(c) for c in a.cities.split(',') if c.strip()):
            places.append(dict(name=p['name'], lon=round(f['geometry']['coordinates'][0], 3), lat=round(f['geometry']['coordinates'][1], 3), pop=p.get('pop_max') or 0, capital=bool(p.get('adm0cap'))))
    places = sorted({(q['name'], q['lon']): q for q in places}.values(), key=lambda q: -q['pop'])[:60]
    want = [c.strip() for c in a.cities.split(',') if c.strip()]; missing = [c for c in want if not any(norm(c) == norm(q['name']) for q in places)]
    if missing: print('WARNING city not in dataset:', missing, '(give lon/lat manually in plan.map.coords)')
    out = Path(a.project) / a.out; out.parent.mkdir(parents=True, exist_ok=True)
    json.dump(dict(world=world, country=country, states=states, places=places, focus=dict(state=a.state, cities=want)), open(out, 'w'), separators=(',', ':'), ensure_ascii=False)
    print(f'  wrote  {out} ({out.stat().st_size // 1024} KB): {len(world)} world rings, {len(states)} states, {len(places)} places')
if __name__ == '__main__': main()
