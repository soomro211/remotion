# Remotion Video Studio — Part 2 of 2

Contains only the `night-atlas` theme (skills/remotion-themes/themes/night-atlas).

## Install
Extract Part 2 into the SAME folder as Part 1 and merge/overwrite when prompted.
The final layout must have `remotion-video-studio/skills/remotion-themes/themes/night-atlas/` next to `cut-paper/` and `_shared/`.
Part 1 contains everything else (all other skills, README, and the cut-paper theme).
