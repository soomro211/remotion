# Night Atlas

Dark, precise map visuals for geography videos: one country, a state or province, a city, or two cities and the distance.

- Palette: ocean #08141E to #10283A, land #223A4C, highlighted land #2B4A61, border #41647F, amber #FFB23E (focus), teal #35E0C2 (routes, data), text #EAF2F7, muted #7F97A8.
- Type: Inter Tight 800 titles (tight tracking), JetBrains Mono for labels, codes and distances, DM Sans for captions.
- Visuals: orthographic globe with graticule that turns to the country; flat country map with state borders and codes; the focus state brightens while others dim as the camera zooms; routes draw themselves along the great circle with a km chip.
- Motion: ease-out cubic everywhere, staggered titles (6 frames), pulsing city markers, no bounce.
- Data: Natural Earth (public domain). 50m state borders exist for large countries only. Verify that borders and names suit the audience before publishing.
- Previews: `images/frame-1..4.png` (globe hook, country map with state, route, CTA). Example data is Australia / Victoria / Melbourne / Sydney.
- Change the subject: `prepare_map_data.py --country Japan --state "" --cities Tokyo,Osaka` (or edit CONFIG in `generator/atlas_frames.py` for preview images).
