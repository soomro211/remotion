import React from "react";
import {Composition} from "remotion";
import {AtlasVideo, Geo, Plan} from "./theme";
import plan from "../video/plan.json";
import geo from "./data/geo.json";

const p = plan as unknown as Plan;
export const StudioRoot: React.FC = () => (
  <Composition id="Main" component={AtlasVideo} durationInFrames={Math.max(30, p.total_frames || 30)} fps={p.fps || 30} width={(p as any).width || 1080} height={(p as any).height || 1920} defaultProps={{plan: p, geo: geo as unknown as Geo}} />
);
