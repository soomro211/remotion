#!/usr/bin/env python3
"""NIGHT ATLAS: map-video theme generator (1080x1920 style frames) from Natural Earth GeoJSON.
Edit CONFIG to feature any country / state / two cities, then run:  python3 atlas_frames.py
Data: Natural Earth (public domain) 50m admin-0 countries, 50m admin-1 states, 10m populated places.
Note: Natural Earth 50m admin-1 covers a handful of large countries (e.g. USA, Canada, Australia, Brazil, India, China, Russia);
use the 10m admin-1 file for others. Check your audience's border conventions before publishing."""
import json, math, os, sys
from common import *
CONFIG = dict(country='Australia', state='Victoria', state_label='Meet', city_a='Melbourne', city_b='Sydney',
              capital='Melbourne', cta_cities=['Lagos', 'Mumbai', 'Tokyo', 'Sao Paulo', 'Cairo', 'Mexico City', 'Istanbul'],
              data=os.path.join(HERE, 'ne', 'geojson'),
              abbr={'New South Wales':'NSW','Victoria':'VIC','Queensland':'QLD','South Australia':'SA','Western Australia':'WA','Tasmania':'TAS','Northern Territory':'NT'})
C = CONFIG
load = lambda n: json.load(open(os.path.join(C['data'], n)))
COUNTRIES = load('ne_50m_admin_0_countries.geojson')['features']
ADMIN1 = load('ne_50m_admin_1_states_provinces.geojson')['features']
PLACES = load('ne_10m_populated_places_simple.geojson')['features']

# ---------- geometry helpers ----------
def polys(geom):
    if geom['type'] == 'Polygon': return [geom['coordinates']]
    if geom['type'] == 'MultiPolygon': return geom['coordinates']
    return []
def ring_area(r): return abs(sum(r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1] for i in range(len(r) - 1))) / 2
def ring_centroid(r):
    a = cx = cy = 0
    for i in range(len(r) - 1):
        k = r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1]; a += k; cx += (r[i][0] + r[i + 1][0]) * k; cy += (r[i][1] + r[i + 1][1]) * k
    return (cx / (3 * a), cy / (3 * a)) if a else r[0]
def feat(fs, key, val): return next(f for f in fs if f['properties'].get(key) == val)
def main_rings(f, frac=.02):
    P = [p[0] for p in polys(f['geometry'])]; m = max(ring_area(r) for r in P); return [r for r in P if ring_area(r) >= m * frac]
def bbox_of(rs):
    xs = [p[0] for r in rs for p in r]; ys = [p[1] for r in rs for p in r]; return min(xs), min(ys), max(xs), max(ys)
def feat_bbox(f): return bbox_of([r for p in polys(f['geometry']) for r in p[:1]])
def haversine(a, b):
    (lo1, la1), (lo2, la2) = [(math.radians(x), math.radians(y)) for x, y in (a, b)]
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371.0088 * math.asin(math.sqrt(h))
import unicodedata
def _n(t): return unicodedata.normalize('NFKD', t).encode('ascii', 'ignore').decode().lower()
def place(name):
    c = [p for p in PLACES if _n(p['properties']['name']) == _n(name)]
    if not c: raise SystemExit(f'city not found in Natural Earth places: {name}')
    pref = [p for p in c if p['properties'].get('adm0name') == C['country']]
    f = (pref or sorted(c, key=lambda p: -(p['properties'].get('pop_max') or 0)))[0]
    return tuple(f['geometry']['coordinates'])
def abbr(f): return C['abbr'].get(f['properties']['name']) or f['properties']['name'][:3].upper()
def hemi(v, pos, neg): return f"{abs(v):.2f}° {pos if v >= 0 else neg}"

# ---------- projections ----------
def ortho(l0, p0, R, cx, cy):
    l0, p0 = math.radians(l0), math.radians(p0)
    def f(lon, lat):
        l, p = math.radians(lon) - l0, math.radians(lat)
        x = math.cos(p) * math.sin(l); y = math.cos(p0) * math.sin(p) - math.sin(p0) * math.cos(p) * math.cos(l)
        vis = math.sin(p0) * math.sin(p) + math.cos(p0) * math.cos(p) * math.cos(l) > 0
        if not vis:
            n = math.hypot(x, y) or 1; x, y = x / n, y / n
        return cx + R * x, cy - R * y, vis
    return f
def local(bbox, box, pad=0):
    """Equirectangular scaled by cos(mid-lat), fitted & centered into box=(x,y,w,h). Returns (fn, px_per_km)."""
    x0, y0, x1, y1 = bbox; k = math.cos(math.radians((y0 + y1) / 2))
    s = min(box[2] / ((x1 - x0) * k), box[3] / (y1 - y0)) * (1 - pad)
    ox = box[0] + (box[2] - (x1 - x0) * k * s) / 2; oy = box[1] + (box[3] - (y1 - y0) * s) / 2
    f = lambda lon, lat: (ox + (lon - x0) * k * s, oy + (y1 - lat) * s)
    return f, s / 111.195
def flat_world(box):
    x, y, w, h = box; return lambda lon, lat: (x + (lon + 180) / 360 * w, y + (90 - lat) / 180 * h)

def path_d(f, proj, ortho_mode=False, within=None):
    d = []
    for poly in polys(f['geometry']):
        if within:
            c = ring_centroid(poly[0])
            if not (within[0] - 1 <= c[0] <= within[2] + 1 and within[1] - 1 <= c[1] <= within[3] + 1): continue
        for r in poly:
            pts = [proj(*p[:2]) for p in r]
            if ortho_mode and not any(p[2] for p in pts): continue
            d.append('M' + 'L'.join(f'{p[0]:.1f},{p[1]:.1f}' for p in pts) + 'Z')
    return ''.join(d)
def graticule(proj, step=15, vis_only=True):
    out = []
    def line(pts):
        seg = []
        for x, y, v in pts:
            if v: seg.append((x, y))
            elif len(seg) > 1: out.append('M' + 'L'.join(f'{a:.1f},{b:.1f}' for a, b in seg)); seg = []
            else: seg = []
        if len(seg) > 1: out.append('M' + 'L'.join(f'{a:.1f},{b:.1f}' for a, b in seg))
    for lat in range(-75, 90, step): line([proj(lo, lat) for lo in range(-180, 181, 3)])
    for lon in range(-180, 180, step): line([proj(lon, la) for la in range(-88, 89, 3)])
    return ''.join(out)

# ---------- style ----------
CSS = """
.f{background:radial-gradient(ellipse at 50% 42%,#10283A 0%,#08141E 58%,#040A10 100%);color:#EAF2F7;font-family:'Inter Tight'}
.mono{font-family:'JetBrains Mono';letter-spacing:.16em;text-transform:uppercase;font-size:24px;color:#7F97A8}
.am{color:#FFB23E}.tl{color:#35E0C2}
.h{font-weight:800;letter-spacing:-4px;line-height:.92}
.chip{position:absolute;font-family:'JetBrains Mono';font-size:25px;letter-spacing:.1em;text-transform:uppercase;padding:14px 22px;border:2px solid rgba(255,178,62,.7);color:#FFB23E;background:rgba(8,20,30,.85);border-radius:6px}
.chip b{color:#EAF2F7;font-weight:600;margin-left:12px}
svg text{font-family:'DM Sans';font-weight:700;letter-spacing:.14em;paint-order:stroke;stroke:#08141E;stroke-width:7px;stroke-linejoin:round}
.vig{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 45%,transparent 45%,rgba(2,6,10,.6) 100%)}
"""
LAND, EDGE, AMB, TEAL, MUT = '#223A4C', '#41647F', '#FFB23E', '#35E0C2', '#7F97A8'
DEFS = "<defs><filter id='glow' x='-30%' y='-30%' width='160%' height='160%'><feGaussianBlur stdDeviation='16'/></filter><filter id='glow2' x='-30%' y='-30%' width='160%' height='160%'><feGaussianBlur stdDeviation='7'/></filter><radialGradient id='sea' cx='40%' cy='35%' r='80%'><stop offset='0' stop-color='#17405A'/><stop offset='.6' stop-color='#0B1E2C'/><stop offset='1' stop-color='#071019'/></radialGradient></defs>"
def tag(left, right): return f"<div class='abs mono' style='left:70px;top:296px'>{left}</div><div class='abs mono' style='right:150px;top:296px;text-align:right'>{right}</div>"
def svg(inner): return f"<svg class='abs' style='left:0;top:0' width='1080' height='1920' viewBox='0 0 1080 1920'>{DEFS}{inner}</svg>"
def ring_marker(x, y, col=AMB, r=18):
    return f"<circle cx='{x}' cy='{y}' r='{r*2.6}' fill='none' stroke='{col}' stroke-width='2' opacity='.35'/><circle cx='{x}' cy='{y}' r='{r*1.6}' fill='none' stroke='{col}' stroke-width='3' opacity='.7'/><circle cx='{x}' cy='{y}' r='{r*.55}' fill='{col}'/>"

# ---------- frames ----------
def frame1():
    cf = feat(COUNTRIES, 'ADMIN', C['country']); cen = ring_centroid(max(main_rings(cf), key=ring_area))
    P = ortho(cen[0], cen[1] * .8, 430, 540, 1030)
    land = ''.join(f"<path d='{path_d(f, P, True)}' fill='{LAND}' stroke='{EDGE}' stroke-width='1' fill-rule='evenodd'/>" for f in COUNTRIES if f is not cf and f['properties']['ADMIN'] != 'Antarctica')
    tgt = path_d(cf, P, True); px, py, _ = P(*cen)
    s = f"<circle cx='540' cy='1030' r='470' fill='none' stroke='#3FB6FF' stroke-opacity='.18' stroke-width='3' filter='url(#glow2)'/><circle cx='540' cy='1030' r='430' fill='url(#sea)'/><path d='{graticule(P)}' fill='none' stroke='#6FB6DA' stroke-opacity='.13' stroke-width='1'/>{land}"
    s += f"<path d='{tgt}' fill='{AMB}' opacity='.75' filter='url(#glow)'/><path d='{tgt}' fill='{AMB}' stroke='#FFE2A6' stroke-width='1.5' fill-rule='evenodd'/>{ring_marker(px, py, '#FFFFFF', 9)}"
    s += f"<path d='M{px+30:.0f},{py-30:.0f}L{px+150:.0f},{py-150:.0f}L{px+250:.0f},{py-150:.0f}' fill='none' stroke='#EAF2F7' stroke-width='2'/><circle cx='540' cy='1030' r='430' fill='none' stroke='#9FD8FF' stroke-opacity='.25' stroke-width='2'/>"
    html = tag('Night Atlas · 01', 'World') + f"<div class='abs mono' style='left:70px;top:372px'>Where in the world is</div><div class='abs h' style='left:62px;top:410px;font-size:{min(182, int(1500/(len(C['country'])+1)))}px'>{C['country'].upper()}<span class='am'>?</span></div>"
    html += f"<div class='chip' style='left:{px+260:.0f}px;top:{py-185:.0f}px'>{C['country']}</div><div class='abs mono' style='left:70px;top:1470px;font-size:22px'>{hemi(cen[1],'N','S')} &nbsp;·&nbsp; {hemi(cen[0],'E','W')}</div>"
    return svg(s) + html + "<div class='vig'></div>"

def frame2():
    cf = feat(COUNTRIES, 'ADMIN', C['country']); states = [f for f in ADMIN1 if f['properties'].get('admin') == C['country']]
    bb = bbox_of(main_rings(cf, .004)); P, pxkm = local(bb, (50, 640, 980, 840))
    s = f"<path d='{graticule(lambda lo,la:(*P(lo,la),True), 10)}' fill='none' stroke='#6FB6DA' stroke-opacity='.08'/>"
    tgt = None; lab = ''
    for f in states:
        pr = lambda lo, la: (*P(lo, la), True)
        d = path_d(f, pr, within=bb)
        if not d: continue
        hit = f['properties']['name'] == C['state']
        if hit: tgt = d
        else: s += f"<path d='{d}' fill='{LAND}' stroke='{EDGE}' stroke-width='2' stroke-linejoin='round' fill-rule='evenodd'/>"
        r = max([r for p in polys(f['geometry']) for r in p[:1] if bb[0] <= ring_centroid(r)[0] <= bb[2] and bb[1] <= ring_centroid(r)[1] <= bb[3]], key=ring_area)
        if ring_area(r) > 1.5 and not hit:
            x, y = P(*ring_centroid(r)); lab += f"<text x='{x:.0f}' y='{y+8:.0f}' text-anchor='middle' font-size='24' fill='{MUT}'>{abbr(f)}</text>"
    s += f"<path d='{tgt}' fill='{AMB}' opacity='.8' filter='url(#glow)'/><path d='{tgt}' fill='{AMB}' fill-opacity='.9' stroke='#FFE2A6' stroke-width='2.5' stroke-linejoin='round' fill-rule='evenodd'/>" + lab
    sf = feat(states, 'name', C['state']); cx, cy = P(*ring_centroid(max(main_rings(sf), key=ring_area)))
    s += f"<text x='{cx:.0f}' y='{cy+8:.0f}' text-anchor='middle' font-size='26' fill='#1A1205' style='stroke:none'>{abbr(sf)}</text>"
    km = 500; w = km * pxkm; s += f"<path d='M70,1500H{70+w:.0f}M70,1488V1512M{70+w:.0f},1488V1512' stroke='#EAF2F7' stroke-width='3' fill='none'/><text x='{70+w+18:.0f}' y='1507' font-size='22' style='stroke:none' fill='{MUT}'>{km} KM</text>"
    chx, chy = 380, 1425
    s += f"<path d='M{cx-12:.0f},{cy+34:.0f}L{chx+250},{chy}' stroke='#EAF2F7' stroke-width='2' fill='none'/>"
    html = tag('Night Atlas · 02', C['country']) + f"<div class='abs h' style='left:62px;top:370px;font-size:128px'>{C['state_label']}<br><span class='am'>{C['state']}.</span></div>"
    html += f"<div class='chip' style='left:{chx}px;top:{chy}px'>Capital<b>{C['capital']}</b></div>"
    return svg(s) + html + "<div class='vig'></div>"

def frame3():
    A, B = place(C['city_a']), place(C['city_b']); dist = haversine(A, B)
    cl = [place(n) for n in ('Canberra',)] if C['city_a'] == 'Melbourne' else []
    lo0, lo1 = min(A[0], B[0]), max(A[0], B[0]); la0, la1 = min(A[1], B[1]), max(A[1], B[1])
    pw, ph = (lo1 - lo0) * .45 + .8, (la1 - la0) * .6 + .8; bb = (lo0 - pw, la0 - ph, lo1 + pw, la1 + ph)
    P, pxkm = local(bb, (0, 690, 1080, 760)); pr = lambda lo, la: (*P(lo, la), True)
    s = "<clipPath id='mc'><rect x='0' y='690' width='1080' height='760'/></clipPath><g clip-path='url(#mc)'>"
    s += f"<path d='{graticule(pr, 2)}' fill='none' stroke='#6FB6DA' stroke-opacity='.08'/>"
    for f in COUNTRIES:
        fb = feat_bbox(f)
        if fb[2] < bb[0] or fb[0] > bb[2] or fb[3] < bb[1] or fb[1] > bb[3]: continue
        s += f"<path d='{path_d(f, pr)}' fill='#13232F' stroke='none' fill-rule='evenodd'/>"
    for f in ADMIN1:
        fb = feat_bbox(f)
        if fb[2] < bb[0] or fb[0] > bb[2] or fb[3] < bb[1] or fb[1] > bb[3]: continue
        hit = f['properties']['name'] == C['state']
        s += f"<path d='{path_d(f, pr)}' fill='{AMB if hit else LAND}' fill-opacity='{.16 if hit else 1}' stroke='{AMB if hit else EDGE}' stroke-width='{3 if hit else 1.6}' stroke-linejoin='round' fill-rule='evenodd'/>"
    a, b = P(*A), P(*B); mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2; dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy)
    qx, qy = mx - dy * .22, my + dx * .22
    s += f"<path d='M{a[0]:.0f},{a[1]:.0f}Q{qx:.0f},{qy:.0f} {b[0]:.0f},{b[1]:.0f}' fill='none' stroke='{TEAL}' stroke-width='9' opacity='.45' filter='url(#glow2)'/><path d='M{a[0]:.0f},{a[1]:.0f}Q{qx:.0f},{qy:.0f} {b[0]:.0f},{b[1]:.0f}' fill='none' stroke='{TEAL}' stroke-width='5' stroke-dasharray='2 16' stroke-linecap='round'/>"
    for c in cl:
        x, y = P(*c); s += f"<circle cx='{x:.0f}' cy='{y:.0f}' r='8' fill='#EAF2F7'/><text x='{x+16:.0f}' y='{y+9:.0f}' font-size='24' fill='#CFE0EB'>CANBERRA</text>"
    for p, n, dxl in ((a, C['city_a'], -20), (b, C['city_b'], 20)):
        s += ring_marker(round(p[0]), round(p[1]), TEAL, 13) + f"<text x='{p[0]+dxl:.0f}' y='{p[1]+(50 if dxl<0 else -34):.0f}' text-anchor='{'end' if dxl<0 else 'start'}' font-size='34' fill='#EAF2F7'>{n.upper()}</text>"
    s += "</g>"
    mapsvg = f"<svg class='abs' style='left:0;top:0;-webkit-mask-image:linear-gradient(90deg,transparent,#000 9%,#000 91%,transparent),linear-gradient(180deg,transparent 36%,#000 44%,#000 72%,transparent 80%);-webkit-mask-composite:source-in;mask-composite:intersect' width='1080' height='1920' viewBox='0 0 1080 1920'>{DEFS}{s}</svg>"
    bx, by = (mx + qx) / 2 + 40, (my + qy) / 2
    html = tag('Night Atlas · 03', 'City to city') + f"<div class='abs h' style='left:62px;top:370px;font-size:124px'>{C['city_a']}<br><span class='tl'>→</span> {C['city_b']}</div>"
    html += f"<div class='chip' style='left:{bx:.0f}px;top:{by-22:.0f}px;border-color:{TEAL};color:{TEAL}'>{dist:,.0f} km</div>"
    html += f"<div class='abs mono' style='left:70px;top:1470px;font-size:21px;line-height:1.6'>Straight-line distance<br>{hemi(A[1],'N','S')} {hemi(A[0],'E','W')} &nbsp;→&nbsp; {hemi(B[1],'N','S')} {hemi(B[0],'E','W')}</div>"
    return mapsvg + html + "<div class='vig'></div>"

def frame4():
    W = lambda lo, la: (-40 + (lo + 180) / 360 * 1160, 760 + (84 - la) / 142 * 457); pr = lambda lo, la: (*W(lo, la), True)
    s = f"<path d='{graticule(pr, 30)}' fill='none' stroke='#6FB6DA' stroke-opacity='.12'/>"
    for f in COUNTRIES:
        if f['properties']['ADMIN'] == 'Antarctica': continue
        s += f"<path d='{path_d(f, pr)}' fill='{LAND}' stroke='{EDGE}' stroke-width='1' fill-rule='evenodd'/>"
    for n in C['cta_cities']:
        x, y = W(*place(n)); s += ring_marker(round(x), round(y), AMB, 9)
    html = tag('Night Atlas · 04', 'Next') + "<div class='abs h' style='left:62px;top:370px;font-size:190px'>Where<br><span class='am'>next?</span></div>"
    html += "<div class='abs' style='left:70px;top:1330px;font-size:54px;font-weight:700;letter-spacing:-1px'>Comment a place.<br><span style='color:#7F97A8'>I'll map it.</span></div><div class='chip' style='left:660px;top:1360px;font-size:28px'>Follow →</div>"
    return svg(s) + html + "<div class='vig'></div>"

if __name__ == '__main__':
    frames = [page(CSS, f()) for f in (frame1, frame2, frame3, frame4)]
    render_all({'night-atlas': ('frame', frames)})
    print('done')
