// Builds a map video from video/plan.json. plan.map = {country, state, cities:[A,B]} (set by init_video.py --country ...).
// Scene mapping by `type`: hook -> globe turns to the country + title; explain -> country map zooming into the state; route -> A to B route with distance; list -> stats; cta -> globe + follow chip.
import React from "react";
import {AbsoluteFill, Sequence, staticFile} from "remotion";
import {Audio} from "@remotion/media";
import {AtlasBackground, Chip, CountryMap, Globe, RouteBetween, Stat, Title, atlas, useThemeFonts} from "./atlas";
import {Geo, findPlace, haversineKm} from "./geo";
import {SfxTrack} from "../SfxTrack";

export type PlanScene = {id: string; name?: string; type: string; onscreen: string[]; start_frame: number; duration_frames: number};
export type Plan = {fps: number; total_frames: number; cta?: string; vo?: {file?: string}; music?: {file?: string; volume?: number} | null; scenes: PlanScene[]; map?: {country: string; state?: string; cities?: string[]}};

const View: React.FC<{s: PlanScene; plan: Plan; geo: Geo}> = ({s, plan, geo}) => {
  const lines = s.onscreen, c = geo.country.bbox, centre = [(c[0] + c[2]) / 2, (c[1] + c[3]) / 2], st = plan.map?.state || undefined, [A, B] = plan.map?.cities ?? [];
  const title = <Title lines={lines.length ? lines : [s.name ?? ""]} y={atlas.safe.top + 40} size={s.type === "hook" ? 130 : 96} />;
  switch (s.type) {
    case "hook": return <><Globe geo={geo} center={centre} R={440} cy={1040} />{title}</>;
    case "route": return A && B ? <><RouteBetween geo={geo} a={A} b={B} />{title}<Chip text={`${A} → ${B}`} y={1920 - atlas.safe.bottom - 80} delay={20} /></> : <>{title}</>;
    case "list": return <>{title}{(lines.slice(1, 4)).map((l, i) => { const [v, ...r] = l.split("|"); return <Stat key={i} value={v.trim()} label={(r.join("|") || "").trim()} x={70} y={620 + i * 260} delay={8 + i * 10} />; })}</>;
    case "cta": return <><Globe geo={geo} center={centre} R={380} cy={1000} spin={20} startLon={centre[0] - 40} />{title}<Chip text={plan.cta ?? "Follow for more maps"} y={1920 - atlas.safe.bottom - 80} delay={24} color={atlas.amber} /></>;
    default: return <><CountryMap geo={geo} zoomTo={st} zoomDelay={30} />{title}{st ? <Chip text={st} y={1920 - atlas.safe.bottom - 80} delay={50} /> : null}</>;
  }
};
export const AtlasVideo: React.FC<{plan: Plan; geo: Geo}> = ({plan, geo}) => {
  useThemeFonts();
  return (
    <AbsoluteFill>
      <AtlasBackground />
      {plan.scenes.map((s) => <Sequence key={s.id} from={s.start_frame} durationInFrames={s.duration_frames} name={s.name ?? s.id}><View s={s} plan={plan} geo={geo} /></Sequence>)}
      {plan.vo?.file ? <Audio src={staticFile(String(plan.vo.file).replace(/^public\//, ""))} /> : null}
      {plan.music?.file ? <Audio src={staticFile(String(plan.music.file).replace(/^public\//, ""))} volume={plan.music.volume ?? 0.08} loop /> : null}
      <SfxTrack />
    </AbsoluteFill>
  );
};
export {haversineKm, findPlace};
