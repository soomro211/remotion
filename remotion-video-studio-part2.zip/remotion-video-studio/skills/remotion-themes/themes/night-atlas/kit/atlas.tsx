// NIGHT ATLAS theme kit: dark map visuals with amber/teal accents, animated with Remotion.
import React, {useEffect, useState} from "react";
import {AbsoluteFill, continueRender, delayRender, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Easing} from "remotion";
import {Geo, Proj, bboxOf, findPlace, fit, graticule, greatCircle, haversineKm, lerpBox, ortho, pathD} from "./geo";

export const atlas = {ocean: ["#08141E", "#10283A"], land: "#223A4C", landHi: "#2B4A61", border: "#41647F", amber: "#FFB23E", teal: "#35E0C2", text: "#EAF2F7", muted: "#7F97A8", safe: {top: 270, bottom: 420, left: 60, right: 110}};
export const FONT_FILES = [{family: "Inter Tight", file: "fonts/InterTight.ttf", weight: "100 900"}, {family: "JetBrains Mono", file: "fonts/JetBrainsMono.ttf", weight: "100 800"}, {family: "DM Sans", file: "fonts/DMSans.ttf", weight: "100 1000"}];
export const useThemeFonts = () => {
  const [h] = useState(() => delayRender("theme fonts"));
  useEffect(() => { Promise.all(FONT_FILES.map((f) => new FontFace(f.family, `url(${staticFile(f.file)})`, {weight: f.weight}).load().then((ff) => document.fonts.add(ff)))).catch(() => undefined).then(() => continueRender(h)); }, [h]);
};
const ease = Easing.bezier(0.22, 1, 0.36, 1);
export const useProgress = (delay: number, dur: number) => { const f = useCurrentFrame(); return interpolate(f - delay, [0, dur], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease}); };

export const AtlasBackground: React.FC = () => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 40%, ${atlas.ocean[1]}, ${atlas.ocean[0]} 70%)`}}>
    <AbsoluteFill style={{background: "radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,.45) 100%)"}} />
  </AbsoluteFill>
);

// Spinning/settling globe that can turn to centre on a lon/lat. `focus` rings are drawn brighter.
export const Globe: React.FC<{geo: Geo; center: number[]; startLon?: number; R?: number; cx?: number; cy?: number; delay?: number; spin?: number; tilt?: number}> =
  ({geo, center, startLon, R = 430, cx = 540, cy = 900, delay = 0, spin = 70, tilt = 18}) => {
    const t = useProgress(delay, spin); const lon0 = (startLon ?? center[0] - 140) + (center[0] - (startLon ?? center[0] - 140)) * t; const lat0 = tilt + (center[1] * 0.5 - tilt) * t;
    const p = ortho(lon0, lat0, R, cx, cy);
    return (
      <svg width={1080} height={1920} style={{position: "absolute", inset: 0}}>
        <defs><radialGradient id="gl" cx="38%" cy="32%"><stop offset="0" stopColor="#1B3E57" /><stop offset="1" stopColor="#0A1A27" /></radialGradient><radialGradient id="atm" cx="50%" cy="50%" r="50%"><stop offset="0.9" stopColor={atlas.teal} stopOpacity=".0" /><stop offset="1" stopColor={atlas.teal} stopOpacity=".35" /></radialGradient></defs>
        <circle cx={cx} cy={cy} r={R * 1.06} fill="url(#atm)" /><circle cx={cx} cy={cy} r={R} fill="url(#gl)" stroke={atlas.border} strokeWidth={2} />
        <path d={graticule(p, true)} fill="none" stroke="rgba(127,151,168,.18)" strokeWidth={1} />
        <path d={pathD(geo.world, p, true)} fill="none" stroke={atlas.border} strokeWidth={1.4} />
        <path d={pathD(geo.country.rings, p, true)} fill="none" stroke={atlas.amber} strokeWidth={3} />
      </svg>
    );
  };

// Flat country map that zooms from the full country box to a state box. States draw in with a stroke animation.
export const CountryMap: React.FC<{geo: Geo; zoomTo?: string; box?: {x: number; y: number; w: number; h: number}; delay?: number; zoomDelay?: number; showLabels?: boolean}> =
  ({geo, zoomTo, box = {x: 60, y: 330, w: 910, h: 1140}, delay = 0, zoomDelay = 40, showLabels = true}) => {
    const f = useCurrentFrame(); const a = useProgress(delay, 30); const z = useProgress(zoomDelay, 45);
    const target = geo.states.find((s) => s.name === zoomTo); const bb0 = geo.country.bbox, bb1 = target ? bboxOf(target.rings) : bb0;
    const pad = (b: number[]) => { const w = b[2] - b[0], h = b[3] - b[1]; return [b[0] - w * 0.08, b[1] - h * 0.08, b[2] + w * 0.08, b[3] + h * 0.08]; };
    const {proj} = fit(lerpBox(pad(bb0), pad(bb1), z), box);
    return (
      <svg width={1080} height={1920} style={{position: "absolute", inset: 0, opacity: a}}>
        {geo.states.map((s) => { const on = s.name === zoomTo; return <path key={s.name} d={pathD(s.rings, proj)} fill={on ? atlas.landHi : atlas.land} stroke={on ? atlas.amber : atlas.border} strokeWidth={on ? 3.5 : 1.6} strokeLinejoin="round" opacity={zoomTo && !on ? 1 - 0.55 * z : 1} />; })}
        {!geo.states.length && <path d={pathD(geo.country.rings, proj)} fill={atlas.land} stroke={atlas.amber} strokeWidth={3} />}
        {showLabels && geo.states.map((s) => { const [x, y] = proj(s.centroid[0], s.centroid[1]); return <text key={s.name} x={x} y={y} textAnchor="middle" fontFamily="JetBrains Mono" fontSize={26} fill={atlas.muted} opacity={zoomTo ? 1 - z : 1} style={{letterSpacing: 2}}>{s.abbr}</text>; })}
        <Markers geo={geo} proj={proj} f={f} />
      </svg>
    );
  };
const Markers: React.FC<{geo: Geo; proj: Proj; f: number}> = ({geo, proj, f}) => (
  <>{geo.focus.cities.map((c, i) => { const p = findPlace(geo, c); if (!p) return null; const [x, y] = proj(p.lon, p.lat); const s = spring({frame: f - 20 - i * 10, fps: 30, config: {damping: 10}});
    return <g key={c} transform={`translate(${x} ${y})`}><circle r={28 * (1 + ((f % 45) / 45))} fill="none" stroke={atlas.amber} opacity={1 - (f % 45) / 45} /><circle r={11 * s} fill={atlas.amber} stroke={atlas.ocean[0]} strokeWidth={4} /><text x={22} y={-18} fontFamily="Inter Tight" fontWeight={800} fontSize={40} fill={atlas.text} stroke={atlas.ocean[0]} strokeWidth={8} paintOrder="stroke" opacity={s}>{c}</text></g>; })}</>
);

// Route between two cities that draws itself and shows the distance.
export const RouteBetween: React.FC<{geo: Geo; a: string; b: string; box?: {x: number; y: number; w: number; h: number}; delay?: number}> = ({geo, a, b, box = {x: 90, y: 480, w: 900, h: 820}, delay = 10}) => {
  const A = findPlace(geo, a), B = findPlace(geo, b); const t = useProgress(delay, 50); if (!A || !B) return null;
  const bb = [Math.min(A.lon, B.lon), Math.min(A.lat, B.lat), Math.max(A.lon, B.lon), Math.max(A.lat, B.lat)]; const padx = Math.max(1.5, (bb[2] - bb[0]) * 0.5), pady = Math.max(1.5, (bb[3] - bb[1]) * 0.5);
  const {proj} = fit([bb[0] - padx, bb[1] - pady, bb[2] + padx, bb[3] + pady], box); const pts = greatCircle([A.lon, A.lat], [B.lon, B.lat]).map(([lo, la]) => proj(lo, la)); const d = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join("");
  const km = Math.round(haversineKm([A.lon, A.lat], [B.lon, B.lat])); const mid = pts[Math.floor(pts.length / 2)]; const [ax, ay] = proj(A.lon, A.lat), [bx, by] = proj(B.lon, B.lat);
  return (
    <svg width={1080} height={1920} style={{position: "absolute", inset: 0}}>
      <path d={pathD(geo.country.rings, proj)} fill={atlas.land} stroke={atlas.border} strokeWidth={2} />
      <path d={d} pathLength={1} fill="none" stroke={atlas.teal} strokeWidth={6} strokeLinecap="round" strokeDasharray={1} strokeDashoffset={1 - t} />
      {[[ax, ay, a], [bx, by, b]].map(([x, y, n]) => <g key={String(n)}><circle cx={Number(x)} cy={Number(y)} r={12} fill={atlas.amber} stroke={atlas.ocean[0]} strokeWidth={4} /><text x={Number(x) + 22} y={Number(y) - 18} fontFamily="Inter Tight" fontWeight={800} fontSize={42} fill={atlas.text} stroke={atlas.ocean[0]} strokeWidth={8} paintOrder="stroke">{String(n)}</text></g>)}
      <g opacity={interpolate(t, [0.7, 1], [0, 1], {extrapolateLeft: "clamp"})}><rect x={mid[0] - 130} y={mid[1] + 20} width={260} height={64} rx={32} fill={atlas.ocean[0]} stroke={atlas.teal} strokeWidth={2} /><text x={mid[0]} y={mid[1] + 62} textAnchor="middle" fontFamily="JetBrains Mono" fontWeight={700} fontSize={32} fill={atlas.teal}>{km.toLocaleString()} km</text></g>
    </svg>
  );
};

export const Title: React.FC<{lines: string[]; y?: number; delay?: number; size?: number; accent?: number}> = ({lines, y = 330, delay = 0, size = 120, accent = 1}) => {
  const f = useCurrentFrame();
  return <div style={{position: "absolute", left: 70, top: y, width: 900}}>{lines.map((l, i) => { const t = interpolate(f - delay - i * 6, [0, 14], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease}); const fs = Math.min(size, Math.floor(900 / (Math.max(5, l.length) * 0.56)));
    return <div key={i} style={{fontFamily: "Inter Tight", fontWeight: 800, fontSize: fs, lineHeight: 1.02, letterSpacing: -2, color: i === accent ? atlas.amber : atlas.text, opacity: t, transform: `translateY(${(1 - t) * 40}px)`}}>{l}</div>; })}</div>;
};
export const Chip: React.FC<{text: string; x?: number; y: number; delay?: number; color?: string}> = ({text, x = 70, y, delay = 0, color = atlas.teal}) => { const t = useProgress(delay, 14);
  return <div style={{position: "absolute", left: x, top: y, padding: "14px 28px", borderRadius: 40, border: `2px solid ${color}`, background: "rgba(8,20,30,.8)", color, fontFamily: "JetBrains Mono", fontWeight: 700, fontSize: 34, opacity: t, transform: `translateY(${(1 - t) * 20}px)`}}>{text}</div>; };
export const Stat: React.FC<{value: string; label: string; x: number; y: number; delay?: number}> = ({value, label, x, y, delay = 0}) => { const t = useProgress(delay, 16);
  return <div style={{position: "absolute", left: x, top: y, width: 440, opacity: t, transform: `translateY(${(1 - t) * 24}px)`}}><div style={{fontFamily: "Inter Tight", fontWeight: 800, fontSize: 110, color: atlas.amber, letterSpacing: -3, lineHeight: 1}}>{value}</div><div style={{fontFamily: "DM Sans", fontSize: 38, color: atlas.muted, marginTop: 6}}>{label}</div></div>; };
