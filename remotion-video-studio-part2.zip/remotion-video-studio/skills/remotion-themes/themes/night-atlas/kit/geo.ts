// Pure-TS map math (no d3). Data comes from src/data/geo.json made by prepare_map_data.py.
export type Ring = number[][];
export type Geo = {world: Ring[]; country: {name: string; rings: Ring[]; bbox: number[]}; states: {name: string; abbr: string; rings: Ring[]; centroid: number[]}[]; places: {name: string; lon: number; lat: number; pop: number; capital: boolean}[]; focus: {state: string; cities: string[]}};
export type Proj = (lon: number, lat: number) => [number, number, boolean];
const rad = Math.PI / 180;

export const ortho = (lon0: number, lat0: number, R: number, cx: number, cy: number): Proj => (lon, lat) => {
  const l = (lon - lon0) * rad, p = lat * rad, p0 = lat0 * rad;
  let x = Math.cos(p) * Math.sin(l), y = Math.cos(p0) * Math.sin(p) - Math.sin(p0) * Math.cos(p) * Math.cos(l);
  const vis = Math.sin(p0) * Math.sin(p) + Math.cos(p0) * Math.cos(p) * Math.cos(l) > 0;
  if (!vis) { const n = Math.hypot(x, y) || 1; x /= n; y /= n; }
  return [cx + R * x, cy - R * y, vis];
};
// Flat map fitted to a lon/lat box inside a pixel box; cos(lat) keeps shapes honest.
export const fit = (bbox: number[], box: {x: number; y: number; w: number; h: number}): {proj: Proj; scale: number} => {
  const [x0, y0, x1, y1] = bbox, k = Math.cos(((y0 + y1) / 2) * rad), W = (x1 - x0) * k, H = y1 - y0, s = Math.min(box.w / W, box.h / H);
  const ox = box.x + (box.w - W * s) / 2, oy = box.y + (box.h - H * s) / 2;
  return {scale: s, proj: (lon, lat) => [ox + (lon - x0) * k * s, oy + (y1 - lat) * s, true]};
};
export const lerpBox = (a: number[], b: number[], t: number) => a.map((v, i) => v + (b[i] - v) * t);

// SVG path string. In globe mode, rings are split at the horizon so back-side land never draws.
export const pathD = (rings: Ring[], proj: Proj, globe = false) => {
  let d = "";
  for (const r of rings) {
    let pen = false;
    for (const [lo, la] of r) { const [x, y, v] = proj(lo, la); if (globe && !v) { pen = false; continue; } d += `${pen ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`; pen = true; }
    if (!globe) d += "Z";
  }
  return d;
};
export const graticule = (proj: Proj, globe = false, step = 15) => {
  const rings: Ring[] = [];
  for (let lo = -180; lo <= 180; lo += step) rings.push(Array.from({length: 91}, (_, i) => [lo, -90 + i * 2]));
  for (let la = -75; la <= 75; la += step) rings.push(Array.from({length: 181}, (_, i) => [-180 + i * 2, la]));
  return pathD(rings, proj, globe);
};
export const greatCircle = (a: number[], b: number[], n = 48): number[][] => {
  const [l1, p1, l2, p2] = [a[0] * rad, a[1] * rad, b[0] * rad, b[1] * rad];
  const d = 2 * Math.asin(Math.sqrt(Math.sin((p2 - p1) / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin((l2 - l1) / 2) ** 2)) || 1e-9;
  return Array.from({length: n + 1}, (_, i) => { const f = i / n, A = Math.sin((1 - f) * d) / Math.sin(d), B = Math.sin(f * d) / Math.sin(d);
    const x = A * Math.cos(p1) * Math.cos(l1) + B * Math.cos(p2) * Math.cos(l2), y = A * Math.cos(p1) * Math.sin(l1) + B * Math.cos(p2) * Math.sin(l2), z = A * Math.sin(p1) + B * Math.sin(p2);
    return [Math.atan2(y, x) / rad, Math.atan2(z, Math.hypot(x, y)) / rad]; });
};
export const haversineKm = (a: number[], b: number[]) => {
  const h = Math.sin(((b[1] - a[1]) * rad) / 2) ** 2 + Math.cos(a[1] * rad) * Math.cos(b[1] * rad) * Math.sin(((b[0] - a[0]) * rad) / 2) ** 2;
  return 2 * 6371.0088 * Math.asin(Math.sqrt(h));
};
const norm = (t: string) => t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
export const findPlace = (g: Geo, name: string) => g.places.find((p) => norm(p.name) === norm(name));
export const bboxOf = (rings: Ring[]) => { const xs = rings.flat().map((p) => p[0]), ys = rings.flat().map((p) => p[1]); return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]; };
